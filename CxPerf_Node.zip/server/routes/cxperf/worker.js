var config = require('../../configuration.json');
//require express library
var express = require('express');
//require the express router
var router = express.Router();
var mongo = require('mongodb');
var Request = require("request");

let mongodb;

mongo.connect(config.mongoDBURL, function (err, mDB) {
    mongodb = mDB.db();
    console.log("Connected to MongoDB - worker.js");
});
let ObjectID = mongo.ObjectID;
router.get('/startscript', function (req, res) {
    //console.log(" inside start script ");
    try {
        console.log(" inside start script ");
        let scriptid = req.query.id;
        let runId = new ObjectID();
        var scheduledScript = {};
        var appid;
        var applicationId;
        if (scriptid) {
            let orginalScript;
            mongodb.collection("Customers").aggregate([{ "$match": { 'application': { $elemMatch: { 'scripts': { $elemMatch: { 'scriptid': mongo.ObjectID(scriptid) } } } } } }, { $project: { '_id': 1, 'customerName': 1, 'application.appid': 1, 'application.applicationName': 1, 'application.scripts': 1 } }]).toArray((err, result) => {
                if (err) {
                    //console.log("Error in getdata : " + err);
                    return res.status(500).json(err);
                } else {
                    let apps = result[0].application; //.scripts

                    let customerName = result[0].customerName;
                    let customerid = result[0]._id;
                    apps.forEach((app) => {
                        let scripts = app.scripts;
                        let appName = app.applicationName;
                        appid = app.appid;
                        scripts.forEach((script) => {
                            if (script.scriptid == scriptid) {
                                // console.log(JSON.stringify(script));
                                orginalScript = JSON.parse(JSON.stringify(script));
                                orginalScript.applicationName = appName;
                                orginalScript.customerid = customerid;
                                orginalScript.customerName = customerName;
                                orginalScript.scriptversion = script.scriptname;
                                orginalScript.Runid = runId;
                                orginalScript.appid = appid;
                                orginalScript.scriptid = script.scriptid;
                                scheduledScript = JSON.parse(JSON.stringify(script));
                                scheduledScript.scriptid = script.scriptid;
                                scheduledScript._id = runId;
                                scheduledScript.status = "InProgress";
                                scheduledScript.applicationId = appid;
                                scheduledScript.applicationName = appName;
                                scheduledScript.customerId = customerid;
                                scheduledScript.customerName = customerName;
                                scheduledScript.scriptversion = script.scriptname;
                                scheduledScript.slaMet = ""
                                scheduledScript.start_time = "";
                                scheduledScript.end_time = "";
                                applicationId=appid;
                            }
                        });
                    });
                    mongodb.collection("RunIDGenerate").findOne({ "RunIDName": customerid + '_' + applicationId }, (err, result) => {
                        if (err) {
                            //console.log("err" + result)
                            return res.status(500).json(err);
                        }
                        else if (result == null) {
                            console.log("inside RunIDGenerate result : " + result);
                            scheduledScript.RunIDValue = 1;
                            console.log(" RunIDValue add  to test run " + scheduledScript.RunIDValue);
                            mongodb.collection("RunIDGenerate").insert({ "RunIDName": customerid + '_' + applicationId, "RunIDValue": 1 }, function (err, result) {
                                if (err) {
                                    console.log(err);
                                }
                                else {
                                    console.log(" document inserted into RunIDGenerate");
                                }
                            });
                        }
                        else {
                            console.log("inside RunIDGenerate result count" + result.RunIDValue);
                            let runidvalue = result.RunIDValue + 1;
                            scheduledScript.RunIDValue = runidvalue;
                            console.log(" RunIDValue add  to test run " + scheduledScript.RunIDValue);
                            mongodb.collection("RunIDGenerate").updateOne({ "RunIDName": customerid + '_' + applicationId }, {
                                "$set": {
                                    "RunIDValue": runidvalue,
                                }
                            }, function (err) {
                                if (err) {
                                    console.log(err);
                                }
                                else {
                                    console.log(" document updated into RunIDGenerate");
                                }
                            });
                        }

                    });
                    mongodb.collection("scheduling_table").insert(orginalScript, function (err, result) {
                        if (err) {
                            console.log("Error in inserting scheduling_table : " + err);
                            return res.status(500).json(err);
                        } else {
                            console.log("No Error in inserting scheduling_table : ");
                            //res.status(200).json(result.ops[0]._id);
                            console.log(result); //  edited one
                            Request.get("http://" + config.actionControllerHost + ":8080/CxPerfActionController/rest/startscript/" + result.ops[0]._id, (error, response, body) => {
                                if (error) {
                                    console.error(error);
                                    return res.status(500).json(error);
                                }
                                console.log(body);
                                //"Runnable"
                                //"Script schedule started"

                                if (body === "Script schedule started") {


                                    mongodb.collection("TestRuns").insert(scheduledScript, function (err, result) {
                                        if (err) {
                                            console.log("Error in adding test run documents  : " + err);
                                            return res.status(500).json(err);
                                        }
                                        else {
                                            console.log("No Error in  inserting data in Test Runs : ");
                                            return res.status(200).json({
                                                status: body,
                                                //statusmessage:result.
                                            });
                                            // mongodb.collection("Customers").update({ "_id": mongo.ObjectID(orginalScript.customerid), "application.appid": mongo.ObjectID(orginalScript.appid) }, 
                                            // { $set: { "application.$[a].scripts.$[s].status": "Runnable" } }, { arrayFilters: [{ "a.appid": mongo.ObjectId(orginalScript.appid) }, { "s.scriptid": mongo.ObjectId(orginalScript.scriptid) }] }, function(err, result) {
                                            //     if (err) {
                                            //         console.log("Error in updating status : " + err);
                                            //         return res.status(500).json("Internal Server Error : Error in updating status");
                                            //     } else {
                                            //         console.log("Updated script status as Runnable");
                                            //         console.log(JSON.stringify(result));
                                            //        return res.status(200).json({
                                            //             status: body
                                            //         });
                                            //     }
                                            // });
                                        }
                                    });
                                } else {

                                    return res.status(500).json(body);
                                }
                            });
                        }
                    });
                }
            });
        }
    } catch (error) {
        //console.log("Error in startscript " + e);
        return res.status(500).json(error);

    }
});


//This API will get one message from queue, for a given region
//Will be called multiple SeleniumControllers
router.get('/getMessageFromRegionQueue', function (req, res) {
    var regionQueueName = req.query.regionQueueName;
    if (typeof regionQueueName == "undefined" || regionQueueName == null) {
        return res.status(500).json({
            status: "ERROR",
            message: "Region Queue name not passed as parameter"
        });
    }

    /*res.setTimeout(5000, function(){
        //console.log('Request has timed out, guess no messages in the queue');
        return  res.status(200).json({
            status: "No messages found, after waiting & timedout",
          });
    });*/

    try {
        Request.get("http://" + config.actionControllerHost + ":8080/CxPerfActionController/rest/getMessageFromQueue/" + regionQueueName, (error, response, body) => {
            if (error) {
                console.error(error);
                return res.status(500).json({
                    status: error
                });
            }
            //console.log(body);
            return res.status(200).json(body);
        });
    } catch (e) {
        console.log("Error in getMessageFromRegionQueue " + e);
        return res.status(500).json({
            status: "ERROR",
            message: e
        });
    }


});
module.exports = router;