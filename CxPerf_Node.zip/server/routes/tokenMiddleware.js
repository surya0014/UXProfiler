var jwt = require('jsonwebtoken');
var config = require('../configuration.json');
let validationRoute = require('./validation.js');
var secretKey = config.bcryptSecretKey;


module.exports = function (req, res, next) {

    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    // res.header("Access-Control-Allow-Origin", "http://ec2-13-234-166-85.ap-south-1.compute.amazonaws.com");
    // res.header("Access-Control-Allow-Origin", "https://www.ciptszantmeter.com");//uncomment while Prod

    var authorization = req.headers['authorization'];

    var token = '';
    if (typeof authorization !== 'undefined') {
        const bearer = authorization.split(' ');
        token = bearer[1];

        if (token === null || token === undefined || token === "")//|| validationRoute(token))
        {
            return res.status(404).json({ message: "Token is not specified or not valid" });
        }
    } else {
        //If header is undefined return Forbidden (403)
        return res.status(403).send({
            error: true,
            message: "Forbidden - No token found"
        });
    }
    /* let user_session = req.session;
    if (!user_session.hasOwnProperty('user')) {
        return res.status(401).json({ message: "Session is expired or not valid" });
    } */

    if (token) {
        /* if (user_session.hasOwnProperty('user')) {
            if (user_session.user) {
                if (user_session.user.data.token != token) {
                    return res.status(401).json({ message: "Token is expired or not valid" });
                }
            }
        } */
        
        // verifies secret and checks exp
        jwt.verify(token, secretKey, function (err, decoded) {
            /* console.log("decoded: "+JSON.stringify(decoded)); */
            if (err) { //failed verification.
                console.log(err.message);
                return res.status(403).send({
                    error: true,
                    message: "Forbidden - No token found"
                });
            }

            req.decoded = decoded;
            next(); //no error, proceed
        });
    } else {
        // forbidden without token
        return res.status(403).send({
            error: true,
            message: "Forbidden - No token found"
        });
    }
}