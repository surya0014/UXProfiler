(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~app-pages-pages-module~mobileperf-mobileperf-module"],{

/***/ "./src/app/pages/mobileperf/analysis/analysis.component.html":
/*!*******************************************************************!*\
  !*** ./src/app/pages/mobileperf/analysis/analysis.component.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n    <div class=\"col-md-12\">\n        <span class=\"fRight\" matTooltip=\"Ux Profiler Mobile\" matTooltipPosition=\"below\">\n            <img class=\"logosize\" src=\"assets\\images\\ux_logo.png\" />\n        </span>\n    </div>\n</div>\n<a style=\"font-weight:bold;font-size:115%;color:green\" id=\"back\" routerLink=\"/pages/uxmob/testruns\"\n    routerLinkActive=\"active\">\n    <<Back to Run Summary</a>\n        <br>\n        <!--  <h4 align=\"center\">Analysis</h4> -->\n        <div class=\"row\">\n            <div class=\"col-md-1\">\n                <button mat-icon-button mat-button color=\"primary\" matTooltip=\"Click here to copy scramble URL\"\n                    (click)=\"getScrambleURL()\" type=\"button\">\n                    <mat-icon aria-label=\"link\">link</mat-icon>\n                </button>\n            </div>\n            <div class=\"col-md-11\">\n                <h4 align=\"center\"> Analysis </h4>\n            </div>\n        </div>\n        <br>\n        <div class=\"row\">\n            <div class=\"col\" *ngFor=\"let statusCard of statuscards\">\n                <ngx-status-card [title]=\"statusCard.title\" [type]=\"statusCard.type\" [value]=\"statusCard.value\"\n                    [value2]=\"statusCard.value2\">\n                    <button type=\"button\" mat-icon-button>\n                        <mat-icon class=\"statusicon\">{{statusCard.iconClass}}</mat-icon>\n                    </button>\n                </ngx-status-card>\n\n            </div>\n        </div>\n        <mat-tab-group class=\"tabbg\" mat-stretch-tabs>\n            <mat-tab label=\"Test Setup\">\n                <div class=\"row justify-content-center\">\n                    <div class=\"col-md-4\">\n                        <br>\n                        <img src=\"./../../../../assets/images/TestSetupMobileImage.png\">\n                    </div>\n                    <div class=\"col-md-6\">\n                        <table mat-table [dataSource]=\"testsetup\" width=\"100%\">\n                            <div>\n                                <ng-container matColumnDef=\"Attribute\">\n\n                                    <td mat-cell *matCellDef=\"let element\">\n                                        <h6>{{element.Attribute}}</h6>\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"Value\">\n\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.Value}} </td>\n                                </ng-container>\n                            </div>\n                            <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>\n                        </table>\n                    </div>\n                </div>\n            </mat-tab>\n            <mat-tab label=\"Transaction Analysis\">\n                <div class=\"row\">\n                    <div class=\"col-md-1\">\n                    </div>\n                    <div class=\"col-md-3\">\n                        <mat-form-field>\n                            <mat-label>Search</mat-label>\n                            <input matInput (keyup)=\"applyFilter($event)\" placeholder=\"Ex. Mia\">\n                        </mat-form-field>\n                    </div>\n                    <div class=\"col-md-12\">\n                        <table class=\"table table-bordered table-hover\" matSort mat-table [dataSource]=\"dataSource\"\n                            width=\"100%;\">\n                            <ng-container matColumnDef=\"TransactionName\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"20%;\">\n                                    <h6>Transaction Name</h6>\n                                </th>\n                                <td title=\"Click here for more details\" class=\"pointer\" mat-cell\n                                    (click)=\"openpopupcomponent(element)\" *matCellDef=\"let element\">\n                                    {{element.TransactionName}} </td>\n\n                            </ng-container>\n                            <ng-container matColumnDef=\"ResponseTime\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"10%;\">\n                                    <h6> Response Time (ms)</h6>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\">\n                                    <div class=\"row justify-content-center\">\n                                        <div class=\"col-7 justify-content-right\">\n                                            {{element.ResponseTime}}\n                                        </div>\n                                        <div class=\"col-5 justify-content-center\">\n                                            <mat-icon [ngClass]=\"{'greenColor': element.ResponseTimeBenchmark =='green', \n                            'redColor': element.ResponseTimeBenchmark =='red',\n                            'yellowColor': element.ResponseTimeBenchmark =='yellow'}\">\n                                                fiber_manual_record</mat-icon>\n                                        </div>\n                                    </div>\n                                </td>\n                            </ng-container>\n                            <ng-container matColumnDef=\"CpuParams\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"15%;\">\n                                    <h6>Cpu (%)\n                                        <br>\n                                        Max || Increase</h6>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\">\n                                    <div class=\"row justify-content-center\">\n                                        <div class=\"col-7 justify-content-right\">\n                                            {{element.CpuParams}}\n                                        </div>\n                                        <div class=\"col-5 justify-content-center\">\n                                            <mat-icon [ngClass]=\"{'greenColor': element.IncreaseincpuBenchmark =='green', \n                            'redColor': element.IncreaseincpuBenchmark =='red',\n                            'yellowColor': element.IncreaseincpuBenchmark =='yellow'}\">\n                                                fiber_manual_record</mat-icon>\n                                        </div>\n                                    </div>\n                                </td>\n                            </ng-container>\n                            <ng-container matColumnDef=\"MemoryParams\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"15%;\">\n                                    <h6> Memory (mb)\n                                        <br>\n                                        Max || Increase</h6>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\">\n                                    <div class=\"row justify-content-center\">\n                                        <div class=\"col-7 justify-content-right\">\n                                            {{element.MemoryParams}}\n                                        </div>\n                                        <div class=\"col-5 justify-content-center\">\n                                            <mat-icon [ngClass]=\"{'greenColor': element.IncreaseinmemoryBenchmark =='green', \n                            'redColor': element.IncreaseinmemoryBenchmark =='red',\n                            'yellowColor': element.IncreaseinmemoryBenchmark =='yellow'}\">\n                                                fiber_manual_record</mat-icon>\n                                        </div>\n                                    </div>\n                                </td>\n\n\n                            </ng-container>\n                            <ng-container matColumnDef=\"Size\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"10%;\">\n                                    <h6>Transaction Size(Bytes)</h6>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\">\n                                    <div class=\"row justify-content-center\">\n                                        <div class=\"col-7 justify-content-right\">\n                                            {{element.Size}}\n                                        </div>\n                                        <div class=\"col-5 justify-content-center\">\n                                            <mat-icon [ngClass]=\"{'greenColor': element.SizeBenchmark =='green', \n                            'redColor': element.SizeBenchmark =='red',\n                            'yellowColor': element.SizeBenchmark =='yellow'}\">\n                                                fiber_manual_record</mat-icon>\n                                        </div>\n                                    </div>\n                                </td>\n                            </ng-container>\n                            <ng-container matColumnDef=\"NetworkCalls\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"10%;\">\n                                    <h6>No of Network Calls</h6>\n                                </th>\n\n                                <td mat-cell *matCellDef=\"let element\">\n                                    <div class=\"row justify-content-center\">\n                                        <div class=\"col-7 justify-content-right\">\n                                            {{element.NetworkCalls}}\n                                        </div>\n                                        <div class=\"col-5 justify-content-center\">\n                                            <mat-icon [ngClass]=\"{'greenColor': element.NetworkCallsBenchmark =='green', \n                            'redColor': element.NetworkCallsBenchmark =='red',\n                            'yellowColor': element.NetworkCallsBenchmark =='yellow'}\">\n                                                fiber_manual_record</mat-icon>\n                                        </div>\n                                    </div>\n                                </td>\n                            </ng-container>\n                            <ng-container class=\"images\" matColumnDef=\"BeforeImage\">\n                                <th mat-header-cell mat-sort-header *matHeaderCellDef width=\"20%;\">\n                                    <h6>Image\n                                        <br>\n                                        <br>\n                                        Before &nbsp; &#10144; &nbsp;After</h6>\n\n                                </th>\n                                <td title=\"Click here to view Image\" class=\"pointer\"\n                                    (click)=\"openimageviewer(element.BeforeImage,element.AfterImage,element.TransactionName)\"\n                                    mat-cell *matCellDef=\"let element\">\n                                    <div class=\"row \">\n                                        <div class=\"col-md-4\">\n                                            <img class=\"transactionimages\" src={{element.BeforeImage}}>\n                                        </div>\n                                        <div class=\"col-md-2  justify-content-center \">\n                                            <h2>&#10144;</h2>\n                                        </div>\n                                        <div class=\"col-md-4 justify-content-center\">\n                                            <img class=\"transactionimages\" src={{element.AfterImage}}>\n                                        </div>\n                                    </div>\n                                </td>\n                            </ng-container>\n                            <tr mat-header-row *matHeaderRowDef=\"transactionanalysiscolumns\"></tr>\n                            <tr mat-row *matRowDef=\"let row; columns: transactionanalysiscolumns;\"></tr>\n                        </table>\n\n                        <mat-paginator [pageSizeOptions]=\"[5, 10, 25, 100]\"></mat-paginator>\n                    </div>\n\n                </div>\n\n            </mat-tab>\n            <mat-tab label=\"Detailed Analysis\">\n                <nb-card>\n                    <nb-card-body>\n\n                        <div class=\"row justify-content-md-center\">\n                            <div class=\"col-md-1\"></div>\n                            <div class=\"col-md-2 justify-content-md-center\">\n                                <br>\n                                <h5>Choose an Usecase</h5>\n                            </div>\n                            <div class=\"col-md-4\">\n\n                                <mat-form-field>\n\n                                    <mat-select (selectionChange)=\"changeusecase()\" [(ngModel)]=\"defaultusecase\">\n                                        <mat-option *ngFor=\"let usecase of usecaselist\" [value]=\"usecase.value\">\n                                            {{usecase.viewValue}}\n                                        </mat-option>\n                                    </mat-select>\n                                </mat-form-field>\n                            </div>\n                        </div>\n                        <br>\n                        <br>\n                        <div *ngFor=\"let charts of Ngxcharts\">\n                            <div class=\"row justify-content-center\">\n                                <div class=\"col-md-12\">\n                                    <h4>{{defaultusecase}} {{charts[0]}}</h4>\n                                </div>\n\n                            </div>\n                            <br>\n                            <br>\n                            <br>\n                            <div class=\"row  justify-content-center\">\n                                <ngx-charts-line-chart [view]=\"chartsize\" [scheme]=\"colorScheme\" showXAxisLabel=\"false\"\n                                    showYAxisLabel=\"true\" xAxis=\"true\" yAxis=\"true\" [yAxisLabel]=\"charts[2]\"\n                                    timeline=\"true\" [results]=\"charts[1]\" (select)=\"onSelect($event)\"\n                                    (activate)=\"onActivate($event)\" (deactivate)=\"onDeactivate($event)\">\n                                    <ng-template #tooltipTemplate let-model=\"model\">\n                                        <span class=\"tooltip-label\" style=\"text-align:left;\"><b>{{model.series}}-</b>\n                                            {{model.value}} </span>\n                                    </ng-template>\n\n                                </ngx-charts-line-chart>\n                            </div>\n                            <br>\n                            <br>\n                        </div>\n                        <br>\n                    </nb-card-body>\n                </nb-card>\n            </mat-tab>\n            <mat-tab label=\"Performance Benchmarks\">\n                <br>\n                <div class=\"row justify-content-center\">\n                    <br>\n                    <table mat-table [dataSource]=\"benchmarks\" width=\"100%\">\n                        <div>\n                            <ng-container matColumnDef=\"Metrics\">\n                                <th mat-header-cell *matHeaderCellDef width=\"20%;\">\n                                    <h5 style=\"font-weight:bold;color:darkblue\">Metrics</h5>\n                                    <br>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\">\n                                    <h6 style=\"text-align:left;margin-left: 25%;;\">{{element.Metrics}}</h6>\n                                </td>\n                            </ng-container>\n                        </div>\n                        <div>\n                            <ng-container matColumnDef=\"Good\">\n                                <th mat-header-cell *matHeaderCellDef width=\"20%;\">\n                                    <div>\n                                        <h5 style=\"color:green\">Good</h5>\n                                        <mat-icon style=\"color:green\">\n                                            fiber_manual_record</mat-icon>\n                                    </div>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\"> {{element.Good}} </td>\n                            </ng-container>\n                        </div>\n                        <div>\n                            <ng-container matColumnDef=\"Poor\">\n                                <th mat-header-cell *matHeaderCellDef width=\"20%;\">\n                                    <h5 style=\"color:red\">Poor</h5>\n                                    <mat-icon style=\"color:red\">\n                                        fiber_manual_record</mat-icon>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\"> {{element.Poor}} </td>\n                            </ng-container>\n                        </div>\n                        <div>\n                            <ng-container matColumnDef=\"Average\">\n                                <th mat-header-cell *matHeaderCellDef width=\"20%;\">\n                                    <h5 style=\"color:#ffbf00\">Average</h5>\n                                    <mat-icon style=\"color:#ffbf00\">\n                                        fiber_manual_record</mat-icon>\n                                </th>\n                                <td mat-cell *matCellDef=\"let element\"> {{element.Average}} </td>\n                            </ng-container>\n                        </div>\n                        <tr mat-header-row *matHeaderRowDef=\"benchmarksDisplayedColumns\"></tr>\n                        <tr mat-row *matRowDef=\"let row; columns: benchmarksDisplayedColumns;\"></tr>\n                    </table>\n                </div>\n                <div>\n\n                </div>\n            </mat-tab>\n        </mat-tab-group>"

/***/ }),

/***/ "./src/app/pages/mobileperf/analysis/analysis.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/mobileperf/analysis/analysis.component.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-header-cell {\n  text-align: center; }\n\n.mat-cell {\n  word-break: break-all; }\n\n.statusicon {\n  color: black; }\n\nh5 {\n  font-weight: normal;\n  text-align: center; }\n\nh4 {\n  font-weight: bold;\n  text-align: center; }\n\n.tabbg {\n  background-color: white; }\n\n:host ::ng-deep .mat-sort-header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-weight: bold; }\n\n:host ::ng-deep .images {\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: start; }\n\ntr.mat-header-row {\n  height: 10%; }\n\n.pointer {\n  cursor: pointer; }\n\nth.mat-header-cell, td.mat-cell {\n  text-align: center; }\n\nth.mat-header-row {\n  height: 30%; }\n\n.col-xs-15,\n.col-sm-15,\n.col-md-15,\n.col-lg-15 {\n  position: relative;\n  min-height: 1px;\n  padding-right: 15px;\n  padding-left: 15px; }\n\n.redColor {\n  color: red; }\n\n.greenColor {\n  color: green; }\n\n.yellowColor {\n  color: #ffbf00; }\n\n.transactionimages {\n  height: 20px; }\n\n.col-xs-15 {\n  width: 20%;\n  float: left; }\n\n@media (min-width: 768px) {\n  .col-sm-15 {\n    width: 20%;\n    float: center; } }\n\n@media (min-width: 992px) {\n  .col-md-15 {\n    width: 20%;\n    float: center; } }\n\n@media (min-width: 1200px) {\n  .col-lg-15 {\n    width: 20%;\n    float: center; }\n  .margin {\n    margin-left: 3%;\n    margin-right: 3%; } }\n\n.logosize {\n  width: 50px !important;\n  height: 50px !important; }\n\n.fRight {\n  float: right; }\n\n.custom-dialog-container .mat-dialog-container {\n  overflow-y: scroll; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9hbmFseXNpcy9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxtb2JpbGVwZXJmXFxhbmFseXNpc1xcYW5hbHlzaXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBa0IsRUFBQTs7QUFHdEI7RUFFSSxxQkFBcUIsRUFBQTs7QUFHekI7RUFDSSxZQUFXLEVBQUE7O0FBRWY7RUFDSSxtQkFBbUI7RUFDbkIsa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksaUJBQWlCO0VBQ2pCLGtCQUFrQixFQUFBOztBQUV0QjtFQUNJLHVCQUF1QixFQUFBOztBQUUzQjtFQUNJLG9CQUFhO0VBQWIsb0JBQWE7RUFBYixhQUFhO0VBQ2Isd0JBQXVCO01BQXZCLHFCQUF1QjtVQUF2Qix1QkFBdUI7RUFDdkIsaUJBQWlCLEVBQUE7O0FBSXJCO0VBQ0ksdUJBQXNCO01BQXRCLG9CQUFzQjtVQUF0QixzQkFBc0IsRUFBQTs7QUFFMUI7RUFDSSxXQUFVLEVBQUE7O0FBRWQ7RUFDSSxlQUFjLEVBQUE7O0FBRWxCO0VBQ0ksa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0ksV0FBVSxFQUFBOztBQUVkOzs7O0VBSUksa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIsa0JBQWtCLEVBQUE7O0FBRXRCO0VBQ0ksVUFBVSxFQUFBOztBQUVkO0VBQ0ksWUFBWSxFQUFBOztBQUVoQjtFQUNJLGNBQWMsRUFBQTs7QUFFbEI7RUFDSSxZQUFXLEVBQUE7O0FBR2Y7RUFDSSxVQUFVO0VBQ1YsV0FBVyxFQUFBOztBQUVmO0VBQ0E7SUFDUSxVQUFVO0lBQ1YsYUFBYSxFQUFBLEVBQ2hCOztBQUVMO0VBQ0k7SUFDSSxVQUFVO0lBQ1YsYUFBYSxFQUFBLEVBQ2hCOztBQUVMO0VBQ0k7SUFDSSxVQUFVO0lBQ1YsYUFBYSxFQUFBO0VBRWpCO0lBQ0ksZUFBZTtJQUNmLGdCQUFlLEVBQUEsRUFDbEI7O0FBSUw7RUFDSSxzQkFBc0I7RUFDdEIsdUJBQXVCLEVBQUE7O0FBRzNCO0VBQ0ksWUFBWSxFQUFBOztBQUVoQjtFQUNJLGtCQUFrQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9hbmFseXNpcy9hbmFseXNpcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtaGVhZGVyLWNlbGx7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5tYXQtY2VsbHtcclxuICAgXHJcbiAgICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XHJcblxyXG59XHJcbi5zdGF0dXNpY29ue1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbn1cclxuaDV7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxufVxyXG5oNHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi50YWJiZ3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcbjpob3N0IDo6bmctZGVlcCAgLm1hdC1zb3J0LWhlYWRlci1jb250YWluZXIgeyBcclxuICAgIGRpc3BsYXk6IGZsZXg7ICBcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyOyBcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgXHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCAgLmltYWdlc3tcclxuICAgIGp1c3RpZnktY29udGVudDogc3RhcnQ7O1xyXG59XHJcbnRyLm1hdC1oZWFkZXItcm93e1xyXG4gICAgaGVpZ2h0OjEwJTtcclxufVxyXG4ucG9pbnRlcntcclxuICAgIGN1cnNvcjpwb2ludGVyO1xyXG59XHJcbnRoLm1hdC1oZWFkZXItY2VsbCwgdGQubWF0LWNlbGwgeyBcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgIFxyXG59XHJcbnRoLm1hdC1oZWFkZXItcm93e1xyXG4gICAgaGVpZ2h0OjMwJTtcclxufVxyXG4uY29sLXhzLTE1LFxyXG4uY29sLXNtLTE1LFxyXG4uY29sLW1kLTE1LFxyXG4uY29sLWxnLTE1IHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIG1pbi1oZWlnaHQ6IDFweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XHJcbn1cclxuLnJlZENvbG9ye1xyXG4gICAgY29sb3I6IHJlZDtcclxufVxyXG4uZ3JlZW5Db2xvcntcclxuICAgIGNvbG9yOiBncmVlbjtcclxufVxyXG4ueWVsbG93Q29sb3J7XHJcbiAgICBjb2xvcjogI2ZmYmYwMDtcclxufVxyXG4udHJhbnNhY3Rpb25pbWFnZXN7XHJcbiAgICBoZWlnaHQ6MjBweDtcclxufVxyXG5cclxuLmNvbC14cy0xNSB7XHJcbiAgICB3aWR0aDogMjAlO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcbn1cclxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbi5jb2wtc20tMTUge1xyXG4gICAgICAgIHdpZHRoOiAyMCU7XHJcbiAgICAgICAgZmxvYXQ6IGNlbnRlcjtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgKG1pbi13aWR0aDogOTkycHgpIHtcclxuICAgIC5jb2wtbWQtMTUge1xyXG4gICAgICAgIHdpZHRoOiAyMCU7XHJcbiAgICAgICAgZmxvYXQ6IGNlbnRlcjtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgKG1pbi13aWR0aDogMTIwMHB4KSB7XHJcbiAgICAuY29sLWxnLTE1IHtcclxuICAgICAgICB3aWR0aDogMjAlO1xyXG4gICAgICAgIGZsb2F0OiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAubWFyZ2lue1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAzJTtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6MyU7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG4ubG9nb3NpemUge1xyXG4gICAgd2lkdGg6IDUwcHggIWltcG9ydGFudDtcclxuICAgIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZlJpZ2h0e1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcbi5jdXN0b20tZGlhbG9nLWNvbnRhaW5lciAubWF0LWRpYWxvZy1jb250YWluZXJ7XHJcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/mobileperf/analysis/analysis.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/mobileperf/analysis/analysis.component.ts ***!
  \*****************************************************************/
/*! exports provided: AnalysisComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnalysisComponent", function() { return AnalysisComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
/* harmony import */ var _popupview_popupview_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../popupview/popupview.component */ "./src/app/pages/mobileperf/popupview/popupview.component.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/esm5/paginator.es5.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _imageviewer_imageviewer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../imageviewer/imageviewer.component */ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.ts");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
/* harmony import */ var simple_crypto_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! simple-crypto-js */ "./node_modules/simple-crypto-js/build/SimpleCrypto.js");
/* harmony import */ var simple_crypto_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(simple_crypto_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var AnalysisComponent = /** @class */ (function () {
    function AnalysisComponent(data, sidebarService, toastr, changeDetectorRefs, activatedRoute, popup) {
        this.data = data;
        this.sidebarService = sidebarService;
        this.toastr = toastr;
        this.changeDetectorRefs = changeDetectorRefs;
        this.activatedRoute = activatedRoute;
        this.popup = popup;
        this.statuscards = []; //inherits interface
        //Charts Properties
        this.Ngxcharts = [];
        this.Cpudetailsresults = [];
        this.Memorydetailsresults = [];
        this.chartsize = [1000, 400]; //chartsize-ngx-chart
        this.colorScheme = { domain: ['blue'] };
        this.JsonArray = [];
        this.displayedColumns = ['Attribute', 'Value']; //testsetupcolumnnames
        this.benchmarksDisplayedColumns = ['Metrics', 'Good', 'Poor', 'Average'];
        this.transactionanalysiscolumns = ['TransactionName', 'ResponseTime', 'CpuParams', 'MemoryParams', 'Size', 'NetworkCalls', 'BeforeImage']; //transactionanalysiscolumnnames
        this.testsetup = [];
        this.transactionanalysis = [];
        this.benchmarks = [];
        this.usecaselist = [];
        this.conditiondotsimagepath = "./../../../../assets/images/";
        this.slaconfig = {};
        this.scrambledURL = "";
        this.scrambled = [];
        this.sidebarService.expand('menu-sidebar');
        this.sidebarService.toggle(true, 'menu-sidebar');
    }
    AnalysisComponent.prototype.ngOnInit = function () {
        var _this = this;
        //console.log(localStorage.getItem('appid'))
        this.activatedRoute.params.subscribe(function (params) {
            _this.objectid = params['objectid'];
            _this.devicetype = params['devicetype'];
            console.log(_this.objectid, _this.devicetype);
            _this.data.getslaconfig(_this.devicetype).subscribe(function (data) {
                //console.log(data)
                _this.slaconfig = data["0"];
                _this.benchmarks = [{
                        'Metrics': 'Launch Response Time(ms)',
                        'Good': 'Less than ' + _this.slaconfig["responsetimegood"],
                        'Average': 'Between ' + _this.slaconfig["responsetimegood"] + ' and ' + _this.slaconfig["responsetimemax"],
                        'Poor': 'Greater than ' + _this.slaconfig["responsetimemax"]
                    },
                    {
                        'Metrics': 'CPU(%)',
                        'Good': 'Less than ' + _this.slaconfig["cpugood"],
                        'Average': 'Between ' + _this.slaconfig["cpugood"] + ' and ' + _this.slaconfig["cpumax"],
                        'Poor': 'Greater than ' + _this.slaconfig["cpumax"]
                    },
                    {
                        'Metrics': 'Memory(mb)',
                        'Good': 'Less than ' + _this.slaconfig["memorygood"],
                        'Average': 'Between ' + _this.slaconfig["memorygood"] + ' and ' + _this.slaconfig["memorymax"],
                        'Poor': 'Greater than ' + _this.slaconfig["memorymax"]
                    },
                    {
                        'Metrics': 'App Size(mb)',
                        'Good': 'Less than ' + _this.slaconfig["appsizegood"],
                        'Average': 'Between ' + _this.slaconfig["appsizegood"] + ' and ' + _this.slaconfig["appsizemax"],
                        'Poor': 'Greater than ' + _this.slaconfig["appsizemax"]
                    },
                    {
                        'Metrics': 'Increase in CPU(%)',
                        'Good': 'Less than ' + _this.slaconfig["cpuincreasegood"],
                        'Average': 'Between ' + _this.slaconfig["cpuincreasegood"] + ' and ' + _this.slaconfig["cpuincreasemax"],
                        'Poor': 'Greater than ' + _this.slaconfig["cpuincreasemax"]
                    },
                    {
                        'Metrics': 'Increase in Memory(mb)',
                        'Good': 'Less than ' + _this.slaconfig["memoryincreasegood"],
                        'Average': 'Between ' + _this.slaconfig["memoryincreasegood"] + ' and ' + _this.slaconfig["memoryincreasemax"],
                        'Poor': 'Greater than ' + _this.slaconfig["memoryincreasemax"]
                    },
                    {
                        'Metrics': 'Transaction Size(Bytes)',
                        'Good': 'Less than ' + _this.slaconfig["transsizegood"],
                        'Average': 'Between ' + _this.slaconfig["transsizegood"] + ' and ' + _this.slaconfig["transsizemax"],
                        'Poor': 'Greater than ' + _this.slaconfig["transsizemax"]
                    },
                    {
                        'Metrics': 'No of Network calls',
                        'Good': 'Less than ' + _this.slaconfig["networkcallsgood"],
                        'Average': 'Between ' + _this.slaconfig["networkcallsgood"] + ' and ' + _this.slaconfig["networkcallsmax"],
                        'Poor': 'Greater than ' + _this.slaconfig["networkcallsmax"]
                    }
                ];
                if (_this.devicetype == "Android") {
                    _this.benchmarks.push({
                        'Metrics': 'Battery(%)',
                        'Good': 'Less than ' + _this.slaconfig["batterygood"],
                        'Average': 'Between ' + _this.slaconfig["batterygood"] + ' and ' + _this.slaconfig["batterymax"],
                        'Poor': 'Greater than ' + _this.slaconfig["batterymax"]
                    });
                }
                //console.log(this.slaconfig)
                _this.url = _this.data.geturl();
                _this.data.gettestrunsbyId(_this.objectid).subscribe(function (data) {
                    _this.appid = data["appid"];
                    _this.customerId = data["customerId"];
                    _this.RunId = data["RunId"];
                    //console.log(data)
                    _this.Cpudetailsresults = [];
                    _this.Memorydetailsresults = [];
                    _this.JsonArray = data;
                    //console.log(this.JsonArray)
                    _this.transactionanalysis = [];
                    _this.statuscards = _this.statuscardsdata(_this.JsonArray);
                    _this.testsetup = [
                        { Attribute: "Device Name", Value: _this.JsonArray["DeviceName"] },
                        { Attribute: "App Package Name", Value: _this.JsonArray["PackageName"] },
                        { Attribute: "Device OS", Value: _this.JsonArray["DeviceOS"] },
                        { Attribute: "RAM", Value: _this.JsonArray["Ram"] },
                        { Attribute: "Time Zone", Value: _this.JsonArray["TimeZone"] },
                        { Attribute: "Cpu Cores", Value: _this.JsonArray["Cores"] },
                        { Attribute: "Network Bandwidth", Value: _this.JsonArray["NetworkBandwidth"] }
                    ];
                    _this.data.storerunid(_this.JsonArray["RunId"]);
                    for (var k = 0; k < _this.JsonArray["Usecases"].length; k++) {
                        _this.usecaselist.push({
                            value: _this.JsonArray["Usecases"][k].UsecaseName,
                            viewValue: _this.JsonArray["Usecases"][k].UsecaseName
                        });
                        _this.defaultusecase = _this.usecaselist["0"]["value"];
                        for (var i = 0; i < _this.JsonArray["Usecases"][k].Transactions.length; i++) {
                            var Networklength;
                            if (_this.JsonArray["Usecases"][k].Transactions.length == 0) {
                                k++;
                            }
                            else {
                                var Size = 0;
                                if (_this.JsonArray["Usecases"]["0"].Transactions[i].hasOwnProperty('NetworkDetails')) {
                                    for (var j = 0; j < _this.JsonArray["Usecases"]["0"].Transactions[i]["NetworkDetails"].length; j++) {
                                        var Responsesize = _this.JsonArray["Usecases"]["0"].Transactions[i]["NetworkDetails"][j]["ResponseSize"];
                                        Size = Responsesize + Size;
                                    }
                                    Networklength = _this.JsonArray["Usecases"]["0"].Transactions[i]["NetworkDetails"].length;
                                }
                                else {
                                    Networklength = 0;
                                }
                                var responsetimebenchmark = _this.getresponsetimebenchmark(i);
                                var cpuincreasebenchmark = _this.getcpuincreasebenchmark(i);
                                var memoryincreasebenchmark = _this.getmemoryincreasebenchmark(i);
                                var sizebenchmark = _this.getsizebenchmark(i, Size);
                                var networkcallsbenchmark = _this.getnetworkcallsbenchmark(i);
                                _this.transactionanalysis.push({
                                    TransactionName: _this.JsonArray["Usecases"]["0"].Transactions[i]["TransactionName"],
                                    ResponseTime: _this.JsonArray["Usecases"]["0"].Transactions[i]["ResponseTime"],
                                    ResponseTimeBenchmark: responsetimebenchmark,
                                    CpuParams: _this.JsonArray["Usecases"]["0"].Transactions[i]["cpumax"].toString() + " || " +
                                        _this.JsonArray["Usecases"]["0"].Transactions[i]["cpuincrease"].toString(),
                                    IncreaseincpuBenchmark: cpuincreasebenchmark,
                                    MemoryParams: Math.round((_this.JsonArray["Usecases"]["0"].Transactions[i]["memorymax"]) / 1000).toString() + " || " +
                                        Math.round((_this.JsonArray["Usecases"]["0"].Transactions[i]["memoryincrease"]) / 1000).toString(),
                                    IncreaseinmemoryBenchmark: memoryincreasebenchmark,
                                    NetworkCalls: Networklength,
                                    NetworkCallsBenchmark: networkcallsbenchmark,
                                    BeforeImage: _this.url + "/mobileperfFiles/uploads/" + _this.appid + "_" + _this.customerId + "/" + _this.RunId + "/" + "Zip/" +
                                        _this.JsonArray["Usecases"]["0"].Transactions[i]["TransactionName"] + "/screen_before.jpg",
                                    Size: Size,
                                    SizeBenchmark: sizebenchmark,
                                    AfterImage: _this.url + "/mobileperfFiles/uploads/" + _this.appid + "_" + _this.customerId + "/" + _this.RunId + "/" + "Zip/" +
                                        _this.JsonArray["Usecases"]["0"].Transactions[i]["TransactionName"] + "/screen_after.jpg",
                                });
                            }
                        }
                    }
                    console.log(_this.transactionanalysis);
                    _this.transactionanalysis.sort(_this.sorter);
                    _this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_7__["MatTableDataSource"](_this.transactionanalysis);
                    _this.dataSource.paginator = _this.paginator;
                    _this.dataSource.sort = _this.sort;
                    _this.Cpudetailsresults = _this.renderdetailedanalysisgraphcpu(_this.JsonArray["Usecases"], _this.defaultusecase);
                    _this.Memorydetailsresults = _this.renderdetailedanalysisgraphmemory(_this.JsonArray["Usecases"], _this.defaultusecase);
                    _this.Ngxcharts = [[' CPU', _this.Cpudetailsresults, 'CPU (%)'], [' Memory', _this.Memorydetailsresults, 'Memory(mb)']];
                });
            });
        });
    };
    AnalysisComponent.prototype.statuscardsdata = function (jsonarray) {
        var _this = this;
        var arraytemp = [];
        var slaarrayworker = [];
        var cpuarrayworker = [];
        var memoryarrayworker = [];
        var cpumaxarrayworker = [];
        var memorymaxarrayworker = [];
        for (var k = 0; k < jsonarray["Usecases"].length; k++) {
            cpuarrayworker.push(jsonarray["Usecases"][k]["averagecpu"]);
            cpumaxarrayworker.push(jsonarray["Usecases"][k]["maxcpu"]);
            memoryarrayworker.push(jsonarray["Usecases"][k]["averagememory"] / 1024);
            memorymaxarrayworker.push(jsonarray["Usecases"][k]["maxmemory"] / 1024);
            for (var i = 0; i < jsonarray["Usecases"][k].Transactions.length; i++) {
                if (jsonarray["Usecases"][k].Transactions.length == 0) {
                    k++;
                }
                else {
                    slaarrayworker.push(jsonarray["Usecases"][k].Transactions[i]["ResponseTime"]);
                }
            }
        }
        var criteria1 = slaarrayworker.every(function (value) { return value < _this.slaconfig["responsetimegood"]; });
        var criteria2 = slaarrayworker.some(function (value) { return value > _this.slaconfig["responsetimemax"]; });
        var totaltransactionscount = slaarrayworker.length;
        var errortransactionscount = 0;
        var warningtransactionscount = 0;
        slaarrayworker.forEach(function (value) {
            if (value >= _this.slaconfig["responsetimegood"] && value <= _this.slaconfig["responsetimemax"]) {
                warningtransactionscount++;
            }
            else if (value > _this.slaconfig["responsetimemax"]) {
                errortransactionscount++;
            }
        });
        var cpuaveragesum = cpuarrayworker.reduce(function (a, b) {
            return a + b;
        }, 0);
        var memoryaveragesum = memoryarrayworker.reduce(function (a, b) {
            return a + b;
        }, 0);
        var cpumax = Math.max.apply(Math, cpumaxarrayworker);
        var memorymax = Math.max.apply(Math, memorymaxarrayworker);
        if (criteria1 == true) {
            arraytemp.push({
                title: 'Transaction SLA',
                iconClass: 'assessment',
                type: 'success',
                value: 'All Transactions',
                value2: 'within SLA'
            });
        }
        else if (criteria2 == true) {
            arraytemp.push({
                title: 'Transaction SLA',
                iconClass: 'assessment',
                type: 'danger',
                value: errortransactionscount + ' Transactions',
                value2: 'exceeding SLA'
            });
        }
        else {
            arraytemp.push({
                title: 'Transaction SLA',
                iconClass: 'assessment',
                type: 'warning',
                value: warningtransactionscount + ' Transactions',
                value2: 'exceeding SLA'
            });
        }
        if ((cpuaveragesum / cpuarrayworker.length) < this.slaconfig["cpugood"]) {
            arraytemp.push({
                title: 'CPU(%)',
                iconClass: 'alarm',
                type: 'success',
                value: 'Average- ' + ((cpuaveragesum / cpuarrayworker.length).toFixed(2)),
                value2: 'Max-  ' + ((cpumax).toFixed(2))
            });
        }
        else if ((cpuaveragesum / cpuarrayworker.length) > this.slaconfig["cpumax"]) {
            arraytemp.push({
                title: 'CPU (%)',
                iconClass: 'alarm',
                type: 'danger',
                value: 'Average- ' + ((cpuaveragesum / cpuarrayworker.length).toFixed(2)),
                value2: 'Max-  ' + ((cpumax).toFixed(2))
            });
        }
        else {
            arraytemp.push({
                title: 'CPU (%)',
                iconClass: 'alarm',
                type: 'warning',
                value: 'Average- ' + ((cpuaveragesum / cpuarrayworker.length).toFixed(2)),
                value2: 'Max-  ' + ((cpumax).toFixed(2))
            });
        }
        if ((memoryaveragesum / memoryarrayworker.length) < this.slaconfig["memorygood"]) {
            arraytemp.push({
                title: 'Memory (mb)',
                iconClass: 'memory',
                type: 'success',
                value: 'Average- ' + ((memoryaveragesum / memoryarrayworker.length).toFixed(2)),
                value2: 'Max- ' + ((memorymax).toFixed(2))
            });
        }
        else if ((memoryaveragesum / memoryarrayworker.length) > this.slaconfig["memorymax"]) {
            arraytemp.push({
                title: 'Memory (mb)',
                iconClass: 'memory',
                type: 'danger',
                value: 'Average- ' + ((memoryaveragesum / memoryarrayworker.length).toFixed(2)),
                value2: 'Max- ' + ((memorymax).toFixed(2))
            });
        }
        else {
            arraytemp.push({
                title: 'Memory (mb)',
                iconClass: 'memory',
                type: 'warning',
                value: 'Average- ' + ((memoryaveragesum / memoryarrayworker.length).toFixed(2)),
                value2: 'Max- ' + ((memorymax).toFixed(2))
            });
        }
        if (jsonarray.hasOwnProperty("AppSize")) {
            if ((jsonarray["AppSize"] < this.slaconfig["appsizegood"])) {
                arraytemp.push({
                    title: 'App Size (mb)',
                    iconClass: 'archive',
                    type: 'success',
                    value: jsonarray["AppSize"]
                });
            }
            else if ((jsonarray["AppSize"] > this.slaconfig["appsizemax"])) {
                arraytemp.push({
                    title: 'App Size (mb)',
                    iconClass: 'archive',
                    type: 'danger',
                    value: jsonarray["AppSize"]
                });
            }
            else {
                arraytemp.push({
                    title: 'App Size (mb)',
                    iconClass: 'archive',
                    type: 'warning',
                    value: jsonarray["AppSize"]
                });
            }
        }
        if (jsonarray.hasOwnProperty(["BatteryUtilization"])) {
            if (jsonarray["BatteryUtilization"]["Battery_percentage"] < this.slaconfig["batterygood"]) {
                arraytemp.push({
                    title: 'Battery',
                    iconClass: 'battery_charging_full',
                    type: 'success',
                    value: 'Battery(%) - ' + ((jsonarray["BatteryUtilization"]["Battery_percentage"]).toFixed(2)),
                    value2: 'Drain(mah) - ' + ((jsonarray["BatteryUtilization"]["Battery_drain"]).toFixed(2))
                });
            }
            else if (jsonarray["BatteryUtilization"]["Battery_percentage"] >= this.slaconfig["batterymax"]) {
                arraytemp.push({
                    title: 'Battery',
                    iconClass: 'battery_charging_full',
                    type: 'danger',
                    value: 'Battery(%) - ' + ((jsonarray["BatteryUtilization"]["Battery_percentage"]).toFixed(2)),
                    value2: 'Drain(mah) - ' + ((jsonarray["BatteryUtilization"]["Battery_drain"]).toFixed(2))
                });
            }
            else {
                arraytemp.push({
                    title: 'Battery',
                    iconClass: 'battery_charging_full',
                    type: 'warning',
                    value: 'Battery(%) - ' + ((jsonarray["BatteryUtilization"]["Battery_percentage"]).toFixed(2)),
                    value2: 'Drain(mah) - ' + ((jsonarray["BatteryUtilization"]["Battery_drain"]).toFixed(2))
                });
            }
        }
        return arraytemp;
    };
    AnalysisComponent.prototype.changeusecase = function () {
        this.Cpudetailsresults = [];
        this.Memorydetailsresults = [];
        this.Ngxcharts = [];
        this.Cpudetailsresults = this.renderdetailedanalysisgraphcpu(this.JsonArray["Usecases"], this.defaultusecase);
        this.Memorydetailsresults = this.renderdetailedanalysisgraphmemory(this.JsonArray["Usecases"], this.defaultusecase);
        this.Ngxcharts = [[' CPU', this.Cpudetailsresults, 'CPU (%)'], [' Memory', this.Memorydetailsresults, 'Memory(mb)']];
        //console.log(this.Ngxcharts)
    };
    AnalysisComponent.prototype.renderdetailedanalysisgraphcpu = function (usecasearray, usecase) {
        var chartresults = [];
        var seriesresults = [];
        for (var i = 0; i < usecasearray.length; i++) {
            if (usecasearray[i]["UsecaseName"] == usecase) {
                for (var cpudetail in usecasearray[i]["cpudetails"]) {
                    if (usecasearray[i]["cpudetails"].hasOwnProperty(cpudetail)) {
                        seriesresults.push({
                            name: parseInt(cpudetail.replace("s", "")),
                            value: usecasearray[i]["cpudetails"][cpudetail]
                        });
                    }
                }
            }
        }
        seriesresults.sort();
        chartresults.push({
            name: usecase,
            series: seriesresults
        });
        return chartresults;
    };
    AnalysisComponent.prototype.renderdetailedanalysisgraphmemory = function (usecasearray, usecase) {
        var chartresults = [];
        var seriesresults = [];
        for (var i = 0; i < usecasearray.length; i++) {
            if (usecasearray[i]["UsecaseName"] == usecase) {
                for (var memorydetail in usecasearray[i]["memorydetails"]) {
                    if (usecasearray[i]["memorydetails"].hasOwnProperty(memorydetail)) {
                        seriesresults.push({
                            name: parseInt(memorydetail.replace("s", "")),
                            value: usecasearray[i]["memorydetails"][memorydetail] / 1024
                        });
                    }
                }
            }
        }
        seriesresults.sort();
        chartresults.push({
            name: usecase,
            series: seriesresults
        });
        return chartresults;
    };
    AnalysisComponent.prototype.getresponsetimebenchmark = function (i) {
        if (this.JsonArray["Usecases"]["0"].Transactions[i]["ResponseTime"] < this.slaconfig["responsetimegood"]) {
            return "green";
        }
        else if (this.JsonArray["Usecases"]["0"].Transactions[i]["ResponseTime"] >= this.slaconfig["responsetimegood"] && this.JsonArray["Usecases"]["0"].Transactions[i]["ResponseTime"] <= this.slaconfig["responsetimemax"]) {
            return "yellow";
        }
        else {
            return "red";
        }
    };
    AnalysisComponent.prototype.getcpuincreasebenchmark = function (i) {
        if (this.JsonArray["Usecases"]["0"].Transactions[i]["cpuincrease"] <= this.slaconfig["cpuincreasegood"]) {
            return "green";
        }
        else if (this.JsonArray["Usecases"]["0"].Transactions[i]["cpuincrease"] > this.slaconfig["cpuincreasegood"] && this.JsonArray["Usecases"]["0"].Transactions[i]["cpuincrease"] <= this.slaconfig["cpuincreasemax"]) {
            return "yellow";
        }
        else {
            return "red";
        }
    };
    AnalysisComponent.prototype.getmemoryincreasebenchmark = function (i) {
        if ((this.JsonArray["Usecases"]["0"].Transactions[i]["memoryincrease"] / 1000) <= this.slaconfig["memoryincreasegood"]) {
            return "green";
        }
        else if ((this.JsonArray["Usecases"]["0"].Transactions[i]["memoryincrease"] / 1000) > this.slaconfig["memoryincreasegood"] && ((this.JsonArray["Usecases"]["0"].Transactions[i]["memoryincrease"]) / 1000) <= this.slaconfig["memoryincreasemax"]) {
            return "yellow";
        }
        else {
            return "red";
        }
    };
    AnalysisComponent.prototype.getsizebenchmark = function (i, size) {
        if (size > 0) {
            if ((size / 1000) <= this.slaconfig["transsizegood"]) {
                return "green";
            }
            else if ((size / 1000) > this.slaconfig["transsizegood"] && (size / 1000) <= this.slaconfig["transsizemax"]) {
                return "yellow";
            }
            else {
                return "red";
            }
        }
    };
    AnalysisComponent.prototype.getnetworkcallsbenchmark = function (i) {
        if (this.JsonArray["Usecases"]["0"].Transactions[i].hasOwnProperty('NetworkDetails')) {
            if ((this.JsonArray["Usecases"]["0"].Transactions[i]["NetworkDetails"].length) <= this.slaconfig["networkcallsgood"]) {
                return "green";
            }
            else if ((this.JsonArray["Usecases"]["0"].Transactions[i]["NetworkDetails"].length) > this.slaconfig["networkcallsgood"] && (this.JsonArray["Usecases"]["0"].Transactions[i]["NetworkDetails"].length) <= this.slaconfig["networkcallsmax"]) {
                return "yellow";
            }
            else {
                return "red";
            }
        }
    };
    AnalysisComponent.prototype.openpopupcomponent = function (row) {
        var networkdetailsrowdata = [];
        var recommendationrowdata = [];
        for (var k = 0; k < this.JsonArray["Usecases"].length; k++) {
            for (var i = 0; i < this.JsonArray["Usecases"][k].Transactions.length; i++) {
                if (this.JsonArray["Usecases"][k].Transactions[i]["TransactionName"] == row["TransactionName"]) {
                    networkdetailsrowdata.push(this.JsonArray["Usecases"][k].Transactions[i]["NetworkDetails"]);
                    recommendationrowdata.push(this.JsonArray["Usecases"][k].Transactions[i]["Recommendation"]);
                }
            }
        }
        this.popup.open(_popupview_popupview_component__WEBPACK_IMPORTED_MODULE_2__["PopupviewComponent"], {
            height: '80%',
            width: '300%',
            data: [networkdetailsrowdata, recommendationrowdata, row["TransactionName"], this.devicetype]
        });
    };
    AnalysisComponent.prototype.openimageviewer = function (imagepath1, imagepath2, TransactionName) {
        this.popup.open(_imageviewer_imageviewer_component__WEBPACK_IMPORTED_MODULE_8__["ImageviewerComponent"], {
            panelClass: 'trend-dialog',
            data: [imagepath1, imagepath2, TransactionName],
            height: '75%',
            width: '60%'
        });
    };
    //Search table
    AnalysisComponent.prototype.applyFilter = function (event) {
        var filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    };
    AnalysisComponent.prototype.sorter = function (a, b) {
        // Use toUpperCase() to ignore character casing
        var t1 = a.TransactionName.toUpperCase();
        var t2 = b.TransactionName.toUpperCase();
        var comparison = 0;
        if (t1 > t2) {
            comparison = 1;
        }
        else if (t1 < t2) {
            comparison = -1;
        }
        return comparison;
    };
    AnalysisComponent.prototype.getScrambleURL = function () {
        var _this = this;
        this.data.getScrambleForUxPerfMobile().subscribe(function (resdata) {
            console.log(resdata);
            var scramble = JSON.parse(JSON.stringify(resdata));
            _this.scrambled = scramble;
            _this.scrambledServer = _this.scrambled["URI"];
            _this.scrambledSecretKey = _this.scrambled["secretKey"];
            _this.scrambledURL = _this.generateScrambledURL();
            console.log(" scrambledURL : " + _this.scrambledURL);
            var val = _this.scrambledServer + "/#/scramble/uxperfmobile/analysis/" + _this.scrambledURL;
            var selBox = document.createElement('textarea');
            selBox.style.position = 'fixed';
            selBox.style.left = '0';
            selBox.style.top = '0';
            selBox.style.opacity = '0';
            selBox.value = val;
            document.body.appendChild(selBox);
            selBox.focus();
            selBox.select();
            document.execCommand('copy');
            document.body.removeChild(selBox);
            _this.toastr.info('Scramble URL Copied to your clipboard', val);
            _this.changeDetectorRefs.markForCheck();
        });
    };
    AnalysisComponent.prototype.generateScrambledURL = function () {
        var simpleCrypto = new simple_crypto_js__WEBPACK_IMPORTED_MODULE_10___default.a(this.scrambledSecretKey);
        var chiperedText = simpleCrypto.encrypt(this.objectid + "&&" + this.devicetype + "&&" + this.customerId + "&&" + this.appid);
        return encodeURIComponent(chiperedText);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"]),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"])
    ], AnalysisComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_5__["MatSort"]),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__["MatSort"])
    ], AnalysisComponent.prototype, "sort", void 0);
    AnalysisComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'analysis',
            template: __webpack_require__(/*! ./analysis.component.html */ "./src/app/pages/mobileperf/analysis/analysis.component.html"),
            styles: [__webpack_require__(/*! ./analysis.component.scss */ "./src/app/pages/mobileperf/analysis/analysis.component.scss")]
        }),
        __metadata("design:paramtypes", [_mobileperf_data_service__WEBPACK_IMPORTED_MODULE_1__["MobilePerfService"], _nebular_theme__WEBPACK_IMPORTED_MODULE_9__["NbSidebarService"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_11__["ToastrService"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]])
    ], AnalysisComponent);
    return AnalysisComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/execution/execution.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/pages/mobileperf/execution/execution.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <div class=\"col-md-12\">\n      <span class=\"fRight\" matTooltip=\"Ux Profiler Mobile\" matTooltipPosition=\"below\">\n          <img class=\"logosize\" src=\"assets\\images\\ux_logo.png\" />\n      </span>\n  </div>\n</div>\n<br>\n<mat-horizontal-stepper linear=\"true\" #stepper>\n  <mat-step [completed]=\"configcompleted\" [stepControl]=\"Configurationformgroup\">\n    <form [formGroup]=\"Configurationformgroup\">\n      <ng-template matStepLabel>Configuration</ng-template>\n      <br>\n      <div class=\"row \">\n        <div class=\"col-9\">\n        </div>\n        <div class=\"col-3\">\n          <button id=\"openbutton\" style=\"cursor: pointer;\" mat-icon-button color=\"primary\" type=\"button\"\n            title=\"View/Update Sla Config\" (click)=\"opensladialog()\">\n            SLA Configuration <mat-icon>settings</mat-icon>\n          </button>\n        </div>\n      </div>\n      <div class=\"row justify-content-center \">\n        <div class=\"col-md-3\">\n        </div>\n        <div class=\"col-md-3\">\n          <mat-label>Select Device Type</mat-label>\n        </div>\n        <div class=\"col-md-3\">\n          <mat-radio-group id=\"padding\" (change)=\"radiochange(radiovalue)\" [(ngModel)]=\"radiovalue\" formControlName=\"radiovalue\" id=\"padding2\"\n            aria-label=\"Select an option\">\n            <mat-radio-button value=\"Android\">Android</mat-radio-button>\n            <mat-radio-button value=\"Ios\">iOS</mat-radio-button>\n          </mat-radio-group>\n        </div>\n        <div class=\"col-md-3\">\n        </div>\n      </div>\n      <div class=\"row justify-content-center \">\n        <div class=\"col-3 justify-content-center\"></div>\n        <div class=\"col-3 justify-content-center\">\n          <mat-form-field>\n            <mat-label>*Package Name</mat-label>\n            <input formControlName=\"packagename\" matInput>\n          </mat-form-field>\n        </div>\n        <div class=\"col-3 justify-content-center\">\n          <mat-form-field class=\"example-full-width\">\n            <mat-label>*Application Size</mat-label>\n            <input [(ngModel)]=\"sizeoffile\" formControlName=\"applicationsize\" matInput>\n            <input accept=\".ipa,.apk\" hidden (change)=\"onFileSelected()\" #fileInput type=\"file\" id=\"fileappsize\">\n            <span style=\"cursor:pointer;\" title=\"Choose file\" matSuffix (click)=\"fileInput.click()\"\n              class=\"material-icons\">\n              attachment\n            </span>\n          </mat-form-field>\n        </div>\n        <div class=\"col-3 justify-content-center\"></div>\n      </div>\n      <div class=\"row justify-content-center\">\n        <div class=\"col-3 justify-content-center\"></div>\n        <div class=\"col-3 justify-content-center\">\n          <mat-form-field class=\"example-full-width\">\n            <mat-label>*Device Name</mat-label>\n            <input type=\"text\" formControlName=\"devicename\"  matInput [matAutocomplete]=\"auto\">\n            <mat-autocomplete #auto=\"matAutocomplete\">\n              <mat-option *ngFor=\"let devicename of devicenameoptions \" [value]=\"devicename.value\" >\n                {{devicename.value}}\n              </mat-option>\n            </mat-autocomplete>\n          </mat-form-field>\n\n        </div>\n        <div class=\"col-3 justify-content-center\">\n          <mat-form-field class=\"example-full-width\">\n            <mat-label>*Device OS</mat-label>\n            <input type=\"text\" formControlName=\"deviceos\"  matInput [matAutocomplete]=\"auto2\">\n            <mat-autocomplete #auto2=\"matAutocomplete\">\n              <mat-option *ngFor=\"let deviceos of deviceosoptions \" [value]=\"deviceos.value\" >\n                {{deviceos.value}}\n              </mat-option>\n            </mat-autocomplete>\n          </mat-form-field>\n        </div>\n        <div class=\"col-3 justify-content-center\"></div>\n      </div>\n      <div class=\"row justify-content-center \">\n        <div class=\"col-3 justify-content-center\"></div>\n         <div class=\"col-3 justify-content-center\">\n          <mat-form-field class=\"example-full-width\">\n            <mat-label>*Ram</mat-label>\n            <input type=\"text\" formControlName=\"ram\"  matInput [matAutocomplete]=\"auto3\">\n            <mat-autocomplete #auto3=\"matAutocomplete\">\n              <mat-option value=\"2 GB\" >\n                2 GB\n              </mat-option>\n              <mat-option value=\"4 GB\" >\n                4 GB\n              </mat-option>\n              <mat-option value=\"6 GB\" >\n                6 GB\n              </mat-option>\n              <mat-option value=\"8 GB\" >\n                8 GB\n              </mat-option>\n            </mat-autocomplete>\n          </mat-form-field>\n        </div>\n        <div class=\"col-3 justify-content-center\">\n          <mat-form-field class=\"example-full-width\">\n            <mat-label>*Cpu Cores</mat-label>\n            <input type=\"text\" formControlName=\"cpucores\"  matInput [matAutocomplete]=\"auto4\">\n            <mat-autocomplete #auto4=\"matAutocomplete\">\n              <mat-option value=\"2\" >\n                2\n              </mat-option>\n              <mat-option value=\"4\" >\n                4\n              </mat-option>\n              <mat-option value=\"6\" >\n                6\n              </mat-option>\n              <mat-option value=\"8\" >\n                8\n              </mat-option>\n            </mat-autocomplete>\n          </mat-form-field>\n        </div>\n        <div class=\"col-3 justify-content-center\"></div>\n      </div>\n      <div class=\"row justify-content-center \">\n        <div class=\"col-3 justify-content-center\"></div>\n        <div class=\"col-3 justify-content-center\">\n          <mat-form-field class=\"example-full-width\">\n            <mat-select placeholder=\"Network Bandwidth\" formControlName=\"networkbandwidth\"\n              [(ngModel)]=\"networkbandwidth\">\n              <mat-option value=\"3G (down - 4096kbps, up - 1024 kbps)\">\n                3G (down - 4096kbps, up - 1024 kbps)\n              </mat-option>\n              <mat-option value=\"4G (down - 16384kbps, up - 8192 kbps)\">\n                4G (down - 16384kbps, up - 8192 kbps)\n              </mat-option>\n            </mat-select>\n          </mat-form-field>\n        </div>\n        <div *ngIf=\"showonlyforios\" class=\"col-3 justify-content-center\">\n          <mat-form-field>\n            <mat-label>UDID</mat-label>\n            <input formControlName=\"udid\" matInput>\n          </mat-form-field>\n        </div>\n        <div *ngIf=\"!showonlyforios\" class=\"col-6 justify-content-center\"></div>\n        <div *ngIf=\"showonlyforios\" class=\"col-3 justify-content-center\"></div>\n      </div>\n      <div class=\"row justify-content-center\">\n        <button style=\"cursor: pointer;\" title=\"Click here to validate your configuration\" color=\"primary\"\n          (click)=\"configdetailsvalidate(Configurationformgroup.value,stepper)\"\n          [disabled]=\"validatealreadyclicked || !Configurationformgroup.valid\" mat-button>Validate</button>\n      </div>\n      <br>\n      <div class=\"row justify-content-center\">\n        <mat-spinner [diameter]=\"diameter\" *ngIf=\"enablespinner\"></mat-spinner>\n      </div>\n      <br>\n      <div *ngIf=\"invalidconfiguration\">\n        <nb-alert status=\"warning\">Invalid Configuration</nb-alert>\n      </div>\n      <div *ngIf=\"noresponsefromserver\">\n        <nb-alert status=\"warning\">No response from server!!</nb-alert>\n      </div>\n    </form>\n  </mat-step>\n  <mat-step [stepControl]=\"Dummyformgroup\">\n    <ng-template matStepLabel>Validation</ng-template>\n    <mat-list>\n      <div class=\"row  justify-content-center \">\n        <div class=\"col-md-4 justify-content-right\">\n          <mat-list-item> {{communication}}\n\n          </mat-list-item>\n        </div>\n        <div class=\"col-md-1 justify-content-left\">\n          <br>\n          <label *ngIf=\"spinner1done\">&#9989;</label>\n          <label *ngIf=\"!spinner1done\">&#10060;</label>\n        </div>\n      </div>\n      <div class=\"row  justify-content-center \">\n        <div class=\"col-md-4 justify-content-right\">\n          <mat-list-item style=\"margin-top:5px\"> Device Connectivity\n\n          </mat-list-item>\n        </div>\n        <div class=\"col-md-1 justify-content-left\">\n          <br>\n          <label *ngIf=\"spinner2done\">&#9989;</label>\n          <label *ngIf=\"!spinner2done\">&#10060;</label>\n        </div>\n      </div>\n\n      <div class=\"row  justify-content-center \">\n        <div class=\"col-md-4 justify-content-right\">\n          <mat-list-item> Proxy Tool Handshake\n          </mat-list-item>\n        </div>\n        <div class=\"col-md-1 justify-content-left\">\n          <br>\n          <label *ngIf=\"spinner3done\">&#9989;</label>\n          <label *ngIf=\"!spinner3done\">&#10060;</label>\n        </div>\n      </div>\n\n      <div class=\"row  justify-content-center \">\n        <div class=\"col-md-4 justify-content-right\">\n          <mat-list-item> Analyser Plugin\n          </mat-list-item>\n        </div>\n        <div class=\"col-md-1 justify-content-left\">\n          <br>\n          <label *ngIf=\"spinner4done\">&#9989;</label>\n          <label *ngIf=\"!spinner4done\">&#10060;</label>\n        </div>\n      </div>\n\n      <div *ngIf=\"radiovalue=='Android'\" class=\"row  justify-content-center \">\n        <div class=\"col-md-4 justify-content-right\">\n          <mat-list-item>Package Validation\n          </mat-list-item>\n        </div>\n        <div class=\"col-md-1 justify-content-left\">\n          <br>\n          <label *ngIf=\"spinner5done\">&#9989;</label>\n          <label *ngIf=\"!spinner5done\">&#10060;</label>\n        </div>\n      </div>\n\n      <div class=\"row  justify-content-center \">\n        <div class=\"col-md-4 justify-content-right\">\n          <mat-list-item> Temp Result repository setup\n          </mat-list-item>\n        </div>\n        <div class=\"col-md-1 justify-content-left\">\n          <br>\n          <label *ngIf=\"spinner6done\">&#9989;</label>\n          <label *ngIf=\"!spinner6done\">&#10060;</label>\n        </div>\n      </div>\n\n\n    </mat-list>\n    <div class=\"row justify-content-center\">\n      <button *ngIf=\"waitforcompletion\" style=\"cursor: pointer;\" title=\"Click here to change configuration\"\n        color=\"primary\" mat-button (click)=\"backtoconfig(stepper)\">Back</button>\n      <button style=\"cursor: pointer;\" title=\"Click here to start recording\" color=\"primary\" mat-button\n        [disabled]=\"!waitforsuccess\" (click)=\"validateconfig(stepper)\">Start Recording</button>\n    </div>\n  </mat-step>\n  <mat-step>\n    <div *ngIf=\"startsuccessalert\">\n      <nb-alert status=\"info\">Recording started successfully!!</nb-alert>\n    </div>\n    <ng-template matStepLabel>Recording</ng-template>\n    <div class=\"row justify-content-center\">\n      <mat-form-field class=\"example-full-width\">\n        <mat-label>Usecase Name</mat-label>\n\n        <input [(ngModel)]=\"usecasename\" [disabled]=\"!usecasenameenabled \" matInput>\n        <button style=\"font-size:170%;margin-left:100%\" matSuffix id=\"toggle\" type=\"button\" mat-icon-button\n          color=\"primary\" [(ngModel)]=\"buttonvalue\" ngDefaultControl\n          [disabled]=\"usecasename=='' || !usecasenametoggleenabled\" (click)=\"usecasetoggle(usecasename)\">\n          <mat-icon title=\"Start Usecase\" *ngIf=\"buttonvalue=='Start'\">play_circle_filled</mat-icon>\n          <mat-icon title=\"Stop Usecase\" *ngIf=\"buttonvalue=='Stop'\">stop</mat-icon>\n        </button>\n      </mat-form-field>\n\n    </div>\n    <div class=\"row justify-content-center\">\n      <mat-form-field class=\"example-full-width\">\n        <mat-label>Transaction Name</mat-label>\n\n        <input [(ngModel)]=\"transactionname\" [disabled]=\"!transactionnameenabled\" matInput>\n        <button style=\"font-size:170%;margin-left:100%\" matSuffix id=\"toggle\" color=\"primary\" mat-icon-button\n          (click)=\"transactiontoggle($event,transactionname)\" [(ngModel)]=\"transactionbuttonvalue\" ngDefaultControl\n          [disabled]=\"transactionname=='' || !transactionnametoggleenabled\">\n          <mat-icon title=\"Start Transaction\" *ngIf=\"transactionbuttonvalue=='Start'\">play_circle_filled</mat-icon>\n          <mat-icon title=\"Stop Transaction\" *ngIf=\"transactionbuttonvalue=='Stop'\">stop</mat-icon>\n        </button>\n      </mat-form-field>\n    </div>\n    <div class=\"row justify-content-center\">\n      <button style=\"cursor: pointer;\" title=\"Click here to stop recording\" [disabled]=\"!enablestoprecording\"\n        (click)=\"uploadform(stepper)\" color=\"primary\" mat-button>Stop\n        Recording</button>\n    </div>\n    <br>\n\n    <div *ngIf=\"showusecasealert\">\n      <nb-alert status=\"info\">{{usecasealertmessage}}</nb-alert>\n    </div>\n    <div *ngIf=\"showtransactionalert\">\n      <nb-alert status=\"info\">{{transactionnamealertmessage}}</nb-alert>\n    </div>\n\n    <br>\n    <br>\n  </mat-step>\n  <mat-step>\n    <form>\n      <div *ngIf=\"stopsuccessalert\">\n        <nb-alert status=\"info\">Recording completed successfully!!</nb-alert>\n      </div>\n      <br>\n      <div class=\"row justify-content-center\">\n        <ng-template matStepLabel>Upload</ng-template>\n\n        <div id=\"uploader\" class=\"input-group \">\n          <div class=\"input-group-prepend\">\n            <span class=\"input-group-text\" id=\"inputGroupFileAddon01\">Upload</span>\n          </div>\n          <div class=\"custom-file\">\n            <input style=\"cursor: pointer;\" title=\"Choose File\" (change)=\"fileChangeEvent($event)\" accept=\".zip\"\n              type=\"file\" id=\"file\" name=\"file\" class=\"custom-file-input\" aria-describedby=\"inputGroupFileAddon01\">\n            <label class=\"custom-file-label\" for=\"file\">{{uploadfilename}}</label>\n          </div>\n\n        </div>\n      </div>\n      <br>\n      <div class=\"row justify-content-center\">\n        <button [disabled]=\"submitalreadyclicked\" style=\"cursor: pointer;\"  (click)=\"uploadfilestoserver(stepper)\" title=\"Click here to upload file\"\n          color=\"primary\" mat-button>Submit</button>\n      </div>\n      <br>\n      <div *ngIf=\"showfilealert\">\n        <nb-alert status=\"info\">{{filealertmessage}}</nb-alert>\n      </div>\n    </form>\n  </mat-step>\n\n</mat-horizontal-stepper>"

/***/ }),

/***/ "./src/app/pages/mobileperf/execution/execution.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/pages/mobileperf/execution/execution.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "nb-alert {\n  margin-left: 25%;\n  height: 40px;\n  width: 45%;\n  text-align: center; }\n\n#devicetype {\n  margin-left: 25%; }\n\n#ipdiv {\n  margin-top: -30%; }\n\n.mat-radio-button ~ .mat-radio-button {\n  margin-left: 16px; }\n\n#uploader {\n  width: 60%; }\n\n#spinnerdiv {\n  width: 10%;\n  height: 10%; }\n\n.spinnerstyle {\n  margin-left: 3%; }\n\n#toggle {\n  cursor: pointer;\n  font-size: 20px; }\n\n#openbutton {\n  outline: none; }\n\n::ng-deep .mat-horizontal-stepper-header {\n  pointer-events: none !important; }\n\n.logosize {\n  width: 50px !important;\n  height: 50px !important; }\n\n.fRight {\n  float: right; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar {\n  width: 10px !important;\n  height: 5px; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar-thumb {\n  background: #a8a6a6 !important;\n  cursor: pointer;\n  border-radius: 5px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9leGVjdXRpb24vQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxwYWdlc1xcbW9iaWxlcGVyZlxcZXhlY3V0aW9uXFxleGVjdXRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBZTtFQUNmLFlBQVc7RUFDWCxVQUFTO0VBQ1Qsa0JBQWtCLEVBQUE7O0FBRXRCO0VBQ0ksZ0JBQ0osRUFBQTs7QUFDQTtFQUNJLGdCQUFlLEVBQUE7O0FBRW5CO0VBQ0ksaUJBQWlCLEVBQUE7O0FBR25CO0VBQ0ksVUFBUyxFQUFBOztBQUVmO0VBQ0ksVUFBUztFQUNULFdBQVUsRUFBQTs7QUFFZDtFQUNJLGVBQWMsRUFBQTs7QUFFbEI7RUFDSSxlQUFlO0VBQ2YsZUFBYyxFQUFBOztBQUVsQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSwrQkFBK0IsRUFBQTs7QUFJbkM7RUFDSSxzQkFBc0I7RUFDdEIsdUJBQXVCLEVBQUE7O0FBRzNCO0VBQ0ksWUFBWSxFQUFBOztBQUloQjtFQUNJLHNCQUFzQjtFQUN0QixXQUFXLEVBQUE7O0FBR2Y7RUFDSSw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmLDZCQUE2QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9leGVjdXRpb24vZXhlY3V0aW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsibmItYWxlcnR7XHJcbiAgICBtYXJnaW4tbGVmdDoyNSU7XHJcbiAgICBoZWlnaHQ6NDBweDtcclxuICAgIHdpZHRoOjQ1JTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4jZGV2aWNldHlwZXtcclxuICAgIG1hcmdpbi1sZWZ0OjI1JVxyXG59XHJcbiNpcGRpdntcclxuICAgIG1hcmdpbi10b3A6LTMwJTtcclxufVxyXG4ubWF0LXJhZGlvLWJ1dHRvbiB+IC5tYXQtcmFkaW8tYnV0dG9uIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xyXG4gIH1cclxuXHJcbiAgI3VwbG9hZGVye1xyXG4gICAgICB3aWR0aDo2MCU7XHJcbiAgfVxyXG4jc3Bpbm5lcmRpdntcclxuICAgIHdpZHRoOjEwJTtcclxuICAgIGhlaWdodDoxMCU7XHJcbn1cclxuLnNwaW5uZXJzdHlsZXtcclxuICAgIG1hcmdpbi1sZWZ0OjMlO1xyXG59XHJcbiN0b2dnbGV7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBmb250LXNpemU6MjBweDtcclxufVxyXG4jb3BlbmJ1dHRvbntcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgfVxyXG46Om5nLWRlZXAgLm1hdC1ob3Jpem9udGFsLXN0ZXBwZXItaGVhZGVyIHtcclxuICAgIHBvaW50ZXItZXZlbnRzOiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcblxyXG4ubG9nb3NpemUge1xyXG4gICAgd2lkdGg6IDUwcHggIWltcG9ydGFudDtcclxuICAgIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZlJpZ2h0e1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcblxyXG5cclxuL2RlZXAvIC5uYi10aGVtZS1kZWZhdWx0IG5iLWxheW91dCA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgIHdpZHRoOiAxMHB4ICFpbXBvcnRhbnQ7IC8vNXB4O1xyXG4gICAgaGVpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi9kZWVwLyAubmItdGhlbWUtZGVmYXVsdCBuYi1sYXlvdXQgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjYThhNmE2ICFpbXBvcnRhbnQ7IC8vI2RhZGFkYTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweCAhaW1wb3J0YW50OyAvLzIuNXB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/mobileperf/execution/execution.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/mobileperf/execution/execution.component.ts ***!
  \*******************************************************************/
/*! exports provided: ExecutionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExecutionComponent", function() { return ExecutionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_stepper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/stepper */ "./node_modules/@angular/material/esm5/stepper.es5.js");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _sla_config_sla_config_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sla-config/sla-config.component */ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.ts");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};








var ExecutionComponent = /** @class */ (function () {
    function ExecutionComponent(fb, popup, cdref, el, data, toastr, sidebarService) {
        this.fb = fb;
        this.popup = popup;
        this.cdref = cdref;
        this.el = el;
        this.data = data;
        this.toastr = toastr;
        this.sidebarService = sidebarService;
        this.startsuccessalert = false;
        this.stopsuccessalert = false;
        this.enablestoprecording = false;
        this.usecasename = "";
        this.transactionname = "";
        this.transactionnameenabled = false;
        this.transactionnametoggleenabled = false;
        this.usecasenameenabled = true;
        this.transactiontriggercount = 0;
        this.usecasenametoggleenabled = true;
        this.radiovalue = 'Android';
        this.ipisinvalid = false;
        this.invalidconfiguration = false;
        this.uploadfilename = " Choose file";
        this.validationenabled = false;
        this.configcompleted = false;
        this.validatealreadyclicked = false;
        this.enablespinner = false;
        this.diameter = 30;
        this.diametervalidation = 25;
        this.configdetailsverified = false;
        this.communication = "ADB Communication";
        this.networkbandwidth = "";
        this.waitforsuccess = false;
        this.waitforcompletion = false;
        this.noresponsefromserver = false;
        this.usecasealertmessage = '';
        this.showusecasealert = false;
        this.showtransactionalert = false;
        this.transactionnamealertmessage = '';
        this.buttonvalue = "Start";
        this.transactionbuttonvalue = "Start";
        this.stoprecordingalert = false;
        this.filealertmessage = "";
        this.showfilealert = false;
        this.submitalreadyclicked = false;
        this.devicenameoptions = [
            {
                value: "Samsung"
            },
            {
                value: "Redmi"
            },
            {
                value: "Moto"
            },
            {
                value: "One Plus"
            }
        ];
        this.deviceosoptions = [{
                value: "Android 6"
            },
            {
                value: "Android 7"
            },
            {
                value: "Android 8"
            },
            {
                value: "Android 10"
            }];
        this.showonlyforios = false;
        this.sidebarService.expand('menu-sidebar');
        this.sidebarService.toggle(true, 'menu-sidebar');
    }
    ExecutionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.data.getslaconfig(this.radiovalue).subscribe(function (data) {
            //console.log(data)
            //console.log(data["0"]["responsetimemax"])
            _this.responsetimemax = data["0"]["responsetimemax"];
            _this.data.updateresponsetimemax(_this.responsetimemax);
        });
        this.Dummyformgroup = this.fb.group({
            value: ['value', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
        });
        this.Configurationformgroup = this.fb.group({
            radiovalue: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            packagename: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            applicationsize: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            devicename: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            deviceos: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            ram: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            cpucores: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required],
            networkbandwidth: [''],
            udid: ['']
        });
    };
    ExecutionComponent.prototype.validateconfig = function (stepper) {
        stepper.selected.completed = true;
        stepper.selected.editable = false;
        stepper.next();
    };
    ExecutionComponent.prototype.configdetailsvalidate = function (Configurationformgroupvalues, stepper) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var component, op;
            return __generator(this, function (_a) {
                console.log(Configurationformgroupvalues);
                component = "uxMobile";
                op = "validate";
                this.enablespinner = true;
                this.data.getValidationForMobPerf(component, op).subscribe((function (data) { return __awaiter(_this, void 0, void 0, function () {
                    var _this = this;
                    var cpucores, bandwidth, startjson, response, responsejson;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                if (!(data == "valid")) return [3 /*break*/, 2];
                                this.enablespinner = true;
                                this.configcompleted = true;
                                this.validatealreadyclicked = true;
                                cpucores = 0;
                                bandwidth = "";
                                if (Configurationformgroupvalues["cpucores"] == null) {
                                    cpucores = 0;
                                }
                                else {
                                    cpucores = Configurationformgroupvalues["cpucores"];
                                }
                                if (this.networkbandwidth == null || this.networkbandwidth == "") {
                                    bandwidth = "";
                                }
                                else {
                                    bandwidth = this.networkbandwidth;
                                }
                                this.responsetimemax = this.data.getmaxresponsetime();
                                startjson = {
                                    "Cores": cpucores,
                                    "DeviceType": Configurationformgroupvalues["radiovalue"],
                                    "DeviceOS": Configurationformgroupvalues["deviceos"],
                                    "DeviceName": Configurationformgroupvalues["devicename"],
                                    "Ram": Configurationformgroupvalues["ram"],
                                    "Appname": "app01",
                                    "Appsize": Configurationformgroupvalues["applicationsize"],
                                    "PackageName": Configurationformgroupvalues["packagename"],
                                    "NetworkBandwidth": bandwidth,
                                    "responsetimemax": this.responsetimemax
                                };
                                return [4 /*yield*/, this.postapi(startjson)];
                            case 1:
                                response = _a.sent();
                                if (response == undefined || response == null) {
                                    this.validatealreadyclicked = false;
                                    this.enablespinner = false;
                                    this.noresponsefromserver = true;
                                    setTimeout(function () {
                                        _this.noresponsefromserver = false;
                                    }, 2000);
                                }
                                else {
                                    this.validatealreadyclicked = false;
                                    responsejson = (JSON.parse(response.toString()));
                                    if (responsejson["status"] == "success") {
                                        this.spinner1done = responsejson["communication"];
                                        this.spinner2done = responsejson["deviceconnectivity"];
                                        this.spinner3done = responsejson["proxytoolhandshake"];
                                        this.spinner4done = responsejson["analyserplugin"];
                                        this.spinner5done = responsejson["packagevalidation"];
                                        this.spinner6done = responsejson["tempresultrepositorysetup"];
                                        this.enablespinner = false;
                                        if (this.radiovalue == "Ios") {
                                            responsejson["packagevalidation"] = true;
                                        }
                                        if (responsejson["communication"] == true && responsejson["deviceconnectivity"] == true &&
                                            responsejson["proxytoolhandshake"] == true && responsejson["analyserplugin"] == true &&
                                            responsejson["packagevalidation"] == true && responsejson["tempresultrepositorysetup"] == true) {
                                            this.waitforsuccess = true;
                                            stepper.selected.completed = true;
                                            stepper.selected.editable = false;
                                            this.waitforcompletion = false;
                                        }
                                        else {
                                            this.waitforsuccess = false;
                                            stepper.selected.completed = false;
                                            stepper.selected.editable = true;
                                            this.waitforcompletion = true;
                                        }
                                        stepper.next();
                                        //console.log(stepper)
                                    }
                                    else {
                                        this.enablespinner = false;
                                        this.invalidconfiguration = true;
                                        setTimeout(function () {
                                            _this.invalidconfiguration = false;
                                        }, 2000);
                                    }
                                }
                                return [3 /*break*/, 3];
                            case 2:
                                this.toastr.warning('License is Expired.Scenario is not started. ');
                                this.enablespinner = false;
                                _a.label = 3;
                            case 3:
                                this.cdref.markForCheck();
                                return [2 /*return*/];
                        }
                    });
                }); }), function (error) {
                    console.log(" errors :  ");
                    console.log(error);
                    _this.toastr.error("Internal Server Error: Error in Starting Scenario");
                    _this.enablespinner = false;
                    _this.cdref.markForCheck();
                });
                return [2 /*return*/];
            });
        });
    };
    ExecutionComponent.prototype.usecasetoggle = function (usecasename) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var response, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(this.buttonvalue == "Start")) return [3 /*break*/, 2];
                        //console.log("enter")
                        this.color = "accent";
                        this.enablestoprecording = false;
                        return [4 /*yield*/, this.usecaseapicall(usecasename)
                            //console.log(response)
                        ];
                    case 1:
                        response = _a.sent();
                        //console.log(response)
                        if (response == "success") {
                            this.buttonvalue = "Stop";
                            this.transactionnameenabled = true;
                            this.transactionnametoggleenabled = true;
                            this.usecasenameenabled = false;
                            this.usecasenametoggleenabled = false;
                            this.showusecasealert = true;
                            this.usecasealertmessage = "Usecase successfully started";
                            setTimeout(function () {
                                _this.showusecasealert = false;
                            }, 2000);
                        }
                        else {
                            this.buttonvalue = "Start";
                            this.usecasenameenabled = true;
                            this.showusecasealert = true;
                            this.usecasenametoggleenabled = true;
                            this.usecasealertmessage = "Failed to start usecase";
                            setTimeout(function () {
                                _this.showusecasealert = false;
                            }, 2000);
                            //this.usecasechecked = false;
                        }
                        return [3 /*break*/, 4];
                    case 2:
                        if (!(this.buttonvalue == "Stop")) return [3 /*break*/, 4];
                        this.transactiontriggercount = 0;
                        return [4 /*yield*/, this.usecasestopapicall(usecasename)];
                    case 3:
                        response = _a.sent();
                        if (response == "success") {
                            this.buttonvalue = "Start";
                            this.transactionnameenabled = false;
                            this.transactionnametoggleenabled = false;
                            this.usecasenameenabled = true;
                            this.usecasenametoggleenabled = true;
                            this.showusecasealert = true;
                            this.enablestoprecording = true;
                            this.usecasealertmessage = "Usecase successfully stopped";
                            setTimeout(function () {
                                _this.showusecasealert = false;
                            }, 2000);
                        }
                        else {
                            this.buttonvalue = "Start";
                            this.showusecasealert = true;
                            this.enablestoprecording = false;
                            this.buttonvalue = "Start";
                            this.usecasealertmessage = "Failed to stop usecase";
                            setTimeout(function () {
                                _this.showusecasealert = false;
                            }, 2000);
                            //this.usecasechecked = false;
                        }
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    ExecutionComponent.prototype.transactiontoggle = function (e, transactionname) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var response, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.transactionnametoggleenabled = false;
                        if (!(this.transactionbuttonvalue == "Start")) return [3 /*break*/, 2];
                        this.transactionbuttonvalue = "Stop";
                        this.color = "accent";
                        this.transactionchecked = true;
                        this.transactionstarttime = +new Date();
                        return [4 /*yield*/, this.transactionapicall(transactionname)];
                    case 1:
                        response = _a.sent();
                        if (response == "success") {
                            this.transactionendtime = +new Date();
                            this.transactiontimedifference = this.transactionendtime - this.transactionstarttime;
                            this.transactionnameenabled = false;
                            this.transactionnametoggleenabled = true;
                            this.usecasenametoggleenabled = false;
                            this.showtransactionalert = true;
                            this.transactionnamealertmessage = "Transaction successfully started";
                            setTimeout(function () {
                                _this.showtransactionalert = false;
                            }, 2000);
                        }
                        else {
                            this.transactionbuttonvalue = "Start";
                            this.transactionchecked = false;
                            this.transactionnameenabled = true;
                            this.transactionnametoggleenabled = true;
                            this.showtransactionalert = true;
                            this.transactionnamealertmessage = "Failed to start Transaction";
                            setTimeout(function () {
                                _this.showtransactionalert = false;
                            }, 2000);
                        }
                        return [3 /*break*/, 4];
                    case 2:
                        if (!(this.transactionbuttonvalue = "Stop")) return [3 /*break*/, 4];
                        return [4 /*yield*/, this.transactionstopapicall(transactionname)];
                    case 3:
                        response = _a.sent();
                        if (response == "success") {
                            this.transactionbuttonvalue = "Start";
                            this.transactionnameenabled = true;
                            this.transactionnametoggleenabled = true;
                            this.showtransactionalert = true;
                            this.transactionnamealertmessage = "Transaction Stopped";
                            this.usecasenametoggleenabled = true;
                            setTimeout(function () {
                                _this.showtransactionalert = false;
                            }, 2000);
                            this.transactionname = "";
                        }
                        else {
                            this.transactionbuttonvalue = "Start";
                            this.transactionchecked = false;
                            this.transactionnameenabled = true;
                            this.transactionnametoggleenabled = true;
                            this.showtransactionalert = true;
                            this.transactionnamealertmessage = "Failed to stop Transaction";
                            setTimeout(function () {
                                _this.showtransactionalert = false;
                            }, 2000);
                        }
                        this.transactionstarttime = null;
                        this.transactionendtime = null;
                        this.transactiontimedifference = null;
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    ExecutionComponent.prototype.postapi = function (startjson) {
        return __awaiter(this, void 0, void 0, function () {
            var url, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.radiovalue == "Android") {
                            url = "http://localhost:8080/AndroidWebApi/rest/Android/startExecution";
                        }
                        else if (this.radiovalue == "Ios") {
                            url = "http://localhost:8080/iosapi/rest/ios/startExecution";
                        }
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var request = new XMLHttpRequest();
                                var formdata = new FormData();
                                //var url = "http://localhost:8080/AndroidWebApi/rest/Android/startExecution";
                                request.open("POST", url, true);
                                request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                request.onload = function () {
                                    //console.log(this.response)
                                    resolve(this.response);
                                };
                                request.onerror = function () {
                                    resolve(undefined);
                                };
                                request.send("startjson=" + JSON.stringify(startjson));
                            })];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                }
            });
        });
    };
    ExecutionComponent.prototype.usecaseapicall = function (usecasename) {
        return __awaiter(this, void 0, void 0, function () {
            var url, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.radiovalue == "Android") {
                            url = "http://localhost:8080/AndroidWebApi/rest/Android/startUsecase?usecasename=" + usecasename;
                        }
                        else if (this.radiovalue == "Ios") {
                            url = "http://localhost:8080/iosapi/rest/ios/startUsecase?usecasename=" + usecasename;
                        }
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var request = new XMLHttpRequest();
                                request.open('GET', url, true);
                                request.onload = function () {
                                    resolve(this.response);
                                };
                                request.onerror = function () {
                                    resolve(undefined);
                                };
                                request.send();
                            })];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                }
            });
        });
    };
    ExecutionComponent.prototype.usecasestopapicall = function (usecasename) {
        return __awaiter(this, void 0, void 0, function () {
            var url, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.transactiontriggercount = 0;
                        if (this.radiovalue == "Android") {
                            url = "http://localhost:8080/AndroidWebApi/rest/Android/stopUsecase?usecasename=" + usecasename;
                        }
                        else if (this.radiovalue == "Ios") {
                            url = "http://localhost:8080/iosapi/rest/ios/stopUsecase?usecasename=" + usecasename;
                        }
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var request = new XMLHttpRequest();
                                request.open('GET', url, true);
                                request.onload = function () {
                                    resolve(this.response);
                                };
                                request.onerror = function () {
                                    resolve(undefined);
                                };
                                request.send();
                            })];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                }
            });
        });
    };
    ExecutionComponent.prototype.transactionapicall = function (transactionname) {
        return __awaiter(this, void 0, void 0, function () {
            var url, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.transactiontriggercount++;
                        if (this.transactiontriggercount < 10) {
                            transactionname = this.usecasename + '_' + 'T0' + this.transactiontriggercount.toString() + '_' + transactionname;
                        }
                        else {
                            transactionname = this.usecasename + '_' + 'T' + this.transactiontriggercount.toString() + '_' + transactionname;
                        }
                        if (this.radiovalue == "Android") {
                            url = 'http://localhost:8080/AndroidWebApi/rest/Android/startTransaction?transactioname=' + transactionname;
                        }
                        else if (this.radiovalue == "Ios") {
                            url = 'http://localhost:8080/iosapi/rest/ios/startTransaction?transactioname=' + transactionname;
                        }
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var request = new XMLHttpRequest();
                                request.open('GET', url, true);
                                request.onload = function () {
                                    resolve(this.response);
                                };
                                request.onerror = function () {
                                    resolve(undefined);
                                };
                                request.send();
                            })];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                }
            });
        });
    };
    ExecutionComponent.prototype.transactionstopapicall = function (transactionname) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.transactiontriggercount < 10) {
                            transactionname = this.usecasename + '_' + 'T0' + this.transactiontriggercount.toString() + '_' + transactionname;
                        }
                        else {
                            transactionname = this.usecasename + '_' + 'T' + this.transactiontriggercount.toString() + '_' + transactionname;
                        }
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var request = new XMLHttpRequest();
                                var time = _this.transactiontimedifference;
                                var url;
                                if (_this.radiovalue == "Android") {
                                    url = 'http://localhost:8080/AndroidWebApi/rest/Android/stopTransaction?transactioname=' + transactionname + '&responsetime=' + time;
                                }
                                else if (_this.radiovalue == "Ios") {
                                    url = 'http://localhost:8080/iosapi/rest/ios/stopTransaction?transactioname=' + transactionname + '&responsetime=' + time;
                                }
                                request.open('GET', url, true);
                                request.onload = function () {
                                    resolve(this.response);
                                };
                                request.onerror = function () {
                                    resolve(undefined);
                                };
                                request.send();
                            })];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                }
            });
        });
    };
    ExecutionComponent.prototype.uploadform = function (stepper) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.Stoprecording()];
                    case 1:
                        response = _a.sent();
                        if (response == "success") {
                            stepper.selected.completed = true;
                            stepper.selected.editable = false;
                            stepper.next();
                            this.stopsuccessalert = true;
                            setTimeout(function () {
                                _this.stopsuccessalert = false;
                            }, 2000);
                        }
                        else {
                            this.stoprecordingalertmessage = "Failed to stop recording";
                            this.usecasenameenabled = true;
                            this.usecasenametoggleenabled = true;
                            this.enablestoprecording = false;
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    ExecutionComponent.prototype.Stoprecording = function () {
        return __awaiter(this, void 0, void 0, function () {
            var url, response;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.radiovalue == "Android") {
                            url = 'http://localhost:8080/AndroidWebApi/rest/Android/stopExecution';
                        }
                        else if (this.radiovalue == "Ios") {
                            url = 'http://localhost:8080/iosapi/rest/ios/stopExecution';
                        }
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var request = new XMLHttpRequest();
                                request.open('GET', url, true);
                                request.onload = function () {
                                    resolve(this.response);
                                };
                                request.onerror = function () {
                                    resolve(undefined);
                                };
                                request.send();
                            })];
                    case 1:
                        response = _a.sent();
                        return [2 /*return*/, response];
                }
            });
        });
    };
    ExecutionComponent.prototype.backtoconfig = function (stepper) {
        this.validationenabled = false;
        this.waitforsuccess = false;
        this.waitforcompletion = false;
        //console.log(stepper)
        stepper.selected.editable = false;
        stepper.selected.completed = false;
        stepper.previous();
        stepper.selected.editable = true;
        stepper.selected.completed = false;
        //console.log(stepper)
    };
    ExecutionComponent.prototype.fileChangeEvent = function (fileInput) {
        //console.log(fileInput)
        this.uploadfilename = fileInput["srcElement"].files[0]["name"];
        this.cdref.markForCheck();
        //this.product.photo = fileInput.target.files[0]['name'];
    };
    ExecutionComponent.prototype.uploadfilestoserver = function (stepper) {
        var _this = this;
        this.submitalreadyclicked = true;
        var inputEl = this.el.nativeElement.querySelector('#file');
        var fileCount = inputEl.files.length;
        var formdata = new FormData();
        if (fileCount > 0) {
            formdata.append('file', inputEl.files.item(0));
            var filesize = (inputEl.files.item(0)["size"] / 1024);
            if (filesize > 1) {
                this.data.uploadzipapi(formdata, inputEl.files.item(0)["name"]).subscribe(function (data) {
                    if (data["Status"] == "error") {
                        _this.showfilealert = true;
                        _this.submitalreadyclicked = false;
                        _this.filealertmessage = "Error in uploading file";
                        setTimeout(function () {
                            _this.showfilealert = false;
                        }, 2000);
                    }
                    else if (data["Status"] == "emptyjson") {
                        _this.showfilealert = true;
                        _this.filealertmessage = "Json Report is empty";
                        _this.submitalreadyclicked = false;
                        setTimeout(function () {
                            _this.showfilealert = false;
                        }, 2000);
                    }
                    else {
                        _this.showfilealert = true;
                        _this.submitalreadyclicked = true;
                        _this.filealertmessage = "File uploaded successfully...Please wait";
                        setTimeout(function () {
                            _this.showfilealert = false;
                        }, 2000);
                        setTimeout(function () {
                            window.location.reload();
                        }, 4000);
                        _this.uploadfilename = "'Choose file";
                    }
                });
            }
            else {
                this.showfilealert = true;
                this.submitalreadyclicked = false;
                this.filealertmessage = "File size not valid";
                setTimeout(function () {
                    _this.showfilealert = false;
                }, 2000);
            }
        }
    };
    ExecutionComponent.prototype.opensladialog = function () {
        this.popup.open(_sla_config_sla_config_component__WEBPACK_IMPORTED_MODULE_5__["SlaConfigComponent"], {
            height: '75%',
            width: '60%',
            data: [this.radiovalue]
        });
    };
    ExecutionComponent.prototype.onFileSelected = function () {
        var inputEl = this.el.nativeElement.querySelector('#fileappsize');
        if (typeof (FileReader) !== 'undefined') {
            var reader = new FileReader();
            // console.log(inputEl.files.item(0))
            this.sizeoffile = ((inputEl.files.item(0)["size"]) / 1000000).toFixed(2);
        }
    };
    ExecutionComponent.prototype.radiochange = function (type) {
        this.devicenameoptions = [];
        this.deviceosoptions = [];
        console.log(type);
        if (type == "Android") {
            this.showonlyforios = false;
            this.devicenameoptions.push({
                value: "Samsung"
            }, {
                value: "Redmi"
            }, {
                value: "Moto"
            }, {
                value: "One Plus"
            });
            this.deviceosoptions.push({
                value: "Android 6"
            }, {
                value: "Android 7"
            }, {
                value: "Android 8"
            }, {
                value: "Android 10"
            });
        }
        else if (type == "Ios") {
            this.showonlyforios = true;
            this.devicenameoptions.push({
                value: "IPhone 10"
            }, {
                value: "Iphone 11"
            }, {
                value: "Ipad Air"
            }, {
                value: "Ipad Mini"
            });
            this.deviceosoptions.push({
                value: "iOS 10"
            }, {
                value: "iOS 11"
            }, {
                value: "iOS 12"
            });
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('stepper'),
        __metadata("design:type", _angular_material_stepper__WEBPACK_IMPORTED_MODULE_2__["MatStepper"])
    ], ExecutionComponent.prototype, "myStepper", void 0);
    ExecutionComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'execution',
            template: __webpack_require__(/*! ./execution.component.html */ "./src/app/pages/mobileperf/execution/execution.component.html"),
            styles: [__webpack_require__(/*! ./execution.component.scss */ "./src/app/pages/mobileperf/execution/execution.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialog"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"],
            _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_3__["MobilePerfService"], ngx_toastr__WEBPACK_IMPORTED_MODULE_7__["ToastrService"],
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__["NbSidebarService"]])
    ], ExecutionComponent);
    return ExecutionComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/mobileperf/execution/sla-config/sla-config.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row  \">\n  <div class=\"col-md-8 justify-content-center\">\n    <h1 mat-dialog-title>SLA Configuration</h1>\n  </div>\n  <div class=\"col-md-3 justify-content-center\">\n  </div>\n  <button id=\"closebutton\" mat-icon-button style=\"float:right\" type=\"button\" (click)=\"onNoClick()\">\n    <mat-icon aria-label=\"close\">close</mat-icon>\n  </button>\n\n</div>\n<div class=\"row\">\n  <div class=\"col-9\">\n    <div id=\"alert3\" *ngIf=\"editalert\">\n      <nb-alert status=\"success\">Configuration now editable!!</nb-alert>\n    </div>\n  </div>\n  <div class=\"col-3\">\n    <button title=\"Edit Configuration Details\" id=\"editbutton\" color=\"primary\" (click)=\"makeconfigeditable()\"\n      mat-icon-button type=\"button\">\n      <mat-icon>edit</mat-icon>Edit Configuration\n    </button>\n  </div>\n</div>\n<br>\n<div class=\"row \">\n  <div class=\"col-3  \">\n    <h5 style=\"color:darkblue\">Metrics</h5>\n  </div>\n  <div class=\"col-3 \">\n    <h5 style=\"color:green\">Good\n    </h5>\n    <mat-icon style=\"color:green\">\n      fiber_manual_record</mat-icon>\n  </div>\n  <div class=\"col-3 \">\n    <h5 style=\"color:red\">Poor</h5>\n    <mat-icon style=\"color:red\">\n      fiber_manual_record</mat-icon>\n  </div>\n  <div class=\"col-3 \">\n    <h5 style=\"color:#ffbf00\">Average</h5>\n    <mat-icon style=\"color:#ffbf00\">\n      fiber_manual_record</mat-icon>\n  </div>\n</div>\n\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>Response Time(ms)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Response Time</mat-label>\n      <input type=\"number\" (input)=\"responsetimeaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"responsetimegood\"\n        autocomplete=\"off\" list=\"responsetimegoodlist\" matInput>\n      <datalist id=\"responsetimegoodlist\">\n        <option value=\"2500\">\n        <option value=\"3500\">\n        <option value=\"4000\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Response Time</mat-label>\n      <input (input)=\"responsetimeaveragechange()\" type=\"number\" [readonly]=\"readonly\" [(ngModel)]=\"responsetimemax\"\n        autocomplete=\"off\" list=\"responsetimepoorlist\" matInput>\n      <datalist id=\"responsetimepoorlist\">\n        <option value=\"4500\">\n        <option value=\"5500\">\n        <option value=\"6000\">\n        <option value=\"6500\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Response Time</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"responsetimeaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>CPU(%)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min CPU</mat-label>\n      <input type=\"number\" (input)=\"cpuaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"cpugood\" autocomplete=\"off\"\n        list=\"cpugoodlist\" matInput>\n      <datalist id=\"cpugoodlist\">\n        <option value=\"40\">\n        <option value=\"45\">\n        <option value=\"55\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max CPU </mat-label>\n      <input type=\"number\" (input)=\"cpuaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"cpumax\" autocomplete=\"off\"\n        list=\"cpupoorlist\" matInput>\n      <datalist id=\"cpupoorlist\">\n        <option value=\"65\">\n        <option value=\"75\">\n        <option value=\"80\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average CPU</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"cpuaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>Memory(mb)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Memory</mat-label>\n      <input type=\"number\" (input)=\"memoryaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"memorygood\"\n        autocomplete=\"off\" list=\"memorygoodlist\" matInput>\n      <datalist id=\"memorygoodlist\">\n        <option value=\"60\">\n        <option value=\"80\">\n        <option value=\"90\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Memory</mat-label>\n      <input type=\"number\" (input)=\"memoryaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"memorymax\"\n        autocomplete=\"off\" list=\"memorypoorlist\" matInput>\n      <datalist id=\"memorypoorlist\">\n        <option value=\"180\">\n        <option value=\"220\">\n        <option value=\"240\">\n        <option value=\"260\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Memory</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"memoryaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>App Size(mb)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min App Size</mat-label>\n      <input type=\"number\" (input)=\"appsizeaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"appsizegood\"\n        autocomplete=\"off\" list=\"appsizegoodlist\" matInput>\n      <datalist id=\"appsizegoodlist\">\n        <option value=\"9\">\n        <option value=\"13\">\n        <option value=\"15\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max App Size</mat-label>\n      <input type=\"number\" (input)=\"appsizeaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"appsizemax\"\n        autocomplete=\"off\" list=\"appsizepoorlist\" matInput>\n      <datalist id=\"appsizepoorlist\">\n        <option value=\"45\">\n        <option value=\"55\">\n        <option value=\"60\">\n        <option value=\"65\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average App Size</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"appsizeaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n\n<div *ngIf=\"type[0]=='Android'\" class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>Battery(%)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Battery</mat-label>\n      <input type=\"number\" (input)=\"batteryaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"batterygood\"\n        autocomplete=\"off\" list=\"batterygoodlist\" matInput>\n      <datalist id=\"batterygoodlist\">\n        <option value=\"1.8\">\n        <option value=\"1.9\">\n        <option value=\"2.1\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Battery</mat-label>\n      <input type=\"number\" (input)=\"batteryaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"batterymax\"\n        autocomplete=\"off\" list=\"batterypoorlist\" matInput>\n      <datalist id=\"batterypoorlist\">\n        <option value=\"2.9\">\n        <option value=\"3.1\">\n        <option value=\"3.3\">\n        <option value=\"3.5\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Battery</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"batteryaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>Increase in CPU(%)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Cpu Increase</mat-label>\n      <input type=\"number\" (input)=\"cpuincreaseaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"cpuincreasegood\"\n        autocomplete=\"off\" list=\"increaseincpugoodlist\" matInput>\n      <datalist id=\"increaseincpugoodlist\">\n        <option value=\"9\">\n        <option value=\"11\">\n        <option value=\"12\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Cpu Increase</mat-label>\n      <input type=\"number\" (input)=\"cpuincreaseaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"cpuincreasemax\"\n        autocomplete=\"off\" list=\"increaseincpupoorlist\" matInput>\n      <datalist id=\"increaseincpupoorlist\">\n        <option value=\"14\">\n        <option value=\"17\">\n        <option value=\"19\">\n        <option value=\"21\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Cpu Increase</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"cpuincreaseaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>Increase in Memory(mb)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Memory Increase</mat-label>\n      <input type=\"number\" (input)=\"memoryincreaseaveragechange()\" [readonly]=\"readonly\"\n        [(ngModel)]=\"memoryincreasegood\" autocomplete=\"off\" list=\"increaseinmemorygoodlist\" matInput>\n      <datalist id=\"increaseinmemorygoodlist\">\n        <option value=\"25\">\n        <option value=\"35\">\n        <option value=\"40\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Memory Increase</mat-label>\n      <input type=\"number\" (input)=\"memoryincreaseaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"memoryincreasemax\"\n        autocomplete=\"off\" list=\"increaseinmemorypoorlist\" matInput>\n      <datalist id=\"increaseinmemorypoorlist\">\n        <option value=\"45\">\n        <option value=\"55\">\n        <option value=\"60\">\n        <option value=\"65\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Memory Increase</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"memoryincreaseaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>Transaction Size(Bytes)</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Transaction Size</mat-label>\n      <input type=\"number\" (input)=\"transsizeaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"transsizegood\"\n        autocomplete=\"off\" list=\"transsizegoodlist\" matInput>\n      <datalist id=\"transsizegoodlist\">\n        <option value=\"450\">\n        <option value=\"550\">\n        <option value=\"600\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Transaction Size</mat-label>\n      <input type=\"number\" (input)=\"transsizeaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"transsizemax\"\n        autocomplete=\"off\" list=\"transsizepoorlist\" matInput>\n      <datalist id=\"transsizepoorlist\">\n        <option value=\"700\">\n        <option value=\"800\">\n        <option value=\"900\">\n        <option value=\"950\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Transaction Size</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"transsizeaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n<div class=\"row\">\n  <div class=\"col-3\">\n    <br>\n    <h6>No of Network calls</h6>\n  </div>\n  <div class=\"col-3\">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Min Network Calls</mat-label>\n      <input type=\"number\" (input)=\"networkcallsaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"networkcallsgood\"\n        autocomplete=\"off\" list=\"networkcallsgoodlist\" matInput>\n      <datalist id=\"networkcallsgoodlist\">\n        <option value=\"5\">\n        <option value=\"15\">\n        <option value=\"20\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Max Network Calls</mat-label>\n      <input type=\"number\" (input)=\"networkcallsaveragechange()\" [readonly]=\"readonly\" [(ngModel)]=\"networkcallsmax\"\n        autocomplete=\"off\" list=\"networkcallspoorlist\" matInput>\n      <datalist id=\"networkcallspoorlist\">\n        <option value=\"45\">\n        <option value=\"55\">\n        <option value=\"60\">\n        <option value=\"70\">\n      </datalist>\n    </mat-form-field>\n  </div>\n  <div class=\"col-3 \">\n    <mat-form-field class=\"example-full-width\">\n      <mat-label>Average Network Calls</mat-label>\n      <input [readonly]=\"true\" [(ngModel)]=\"networkcallsaverage\" autocomplete=\"off\" matInput>\n    </mat-form-field>\n  </div>\n</div>\n<div class=\"row justify-content-center\">\n  <button title=\"Update SLA Configuration\" style=\"cursor: pointer;\" color=\"primary\" mat-button [disabled]=\"readonly\"\n    (click)=\"updateslaconfiguration()\">Update</button>\n</div>\n<br>\n<div id=\"alert1\" *ngIf=\"showalert\">\n  <nb-alert status=\"danger\">{{showalertmessage}}</nb-alert>\n</div>\n<div id=\"alert2\" *ngIf=\"updatealert\">\n  <nb-alert [status]=\"updatestatus\">{{updatemessage}}</nb-alert>\n</div>"

/***/ }),

/***/ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/mobileperf/execution/sla-config/sla-config.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h1 {\n  text-align: center;\n  margin-left: 40%;\n  color: green;\n  font-weight: bold; }\n\n#alert1 {\n  margin-left: 25%;\n  height: 60px;\n  width: 45%;\n  text-align: center; }\n\n#alert2 {\n  margin-left: 25%;\n  height: 30px;\n  width: 45%;\n  text-align: center; }\n\nh5 {\n  font-weight: bold; }\n\nh6 {\n  color: darkblue; }\n\n#closebutton {\n  outline: none; }\n\n#editlabel {\n  font-size: 15px; }\n\n#editbutton {\n  outline: none; }\n\nmat-form-field {\n  width: 60%; }\n\n#float {\n  float: left; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9leGVjdXRpb24vc2xhLWNvbmZpZy9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxtb2JpbGVwZXJmXFxleGVjdXRpb25cXHNsYS1jb25maWdcXHNsYS1jb25maWcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBa0I7RUFDbEIsZ0JBQWU7RUFDZixZQUFXO0VBQ1gsaUJBQWlCLEVBQUE7O0FBRXJCO0VBQ0ksZ0JBQWU7RUFDZixZQUFXO0VBQ1gsVUFBUztFQUNULGtCQUFrQixFQUFBOztBQUV0QjtFQUNJLGdCQUFlO0VBQ2YsWUFBVztFQUNYLFVBQVM7RUFDVCxrQkFBa0IsRUFBQTs7QUFHdEI7RUFDSSxpQkFBaUIsRUFBQTs7QUFFckI7RUFDSSxlQUFjLEVBQUE7O0FBRWxCO0VBQ0ksYUFBYSxFQUFBOztBQUVmO0VBQ0ksZUFBZSxFQUFBOztBQUVyQjtFQUNJLGFBQWEsRUFBQTs7QUFHZjtFQUNJLFVBQVMsRUFBQTs7QUFHYjtFQUNJLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21vYmlsZXBlcmYvZXhlY3V0aW9uL3NsYS1jb25maWcvc2xhLWNvbmZpZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5oMXtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi1sZWZ0OjQwJTtcclxuICAgIGNvbG9yOmdyZWVuO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuI2FsZXJ0MXtcclxuICAgIG1hcmdpbi1sZWZ0OjI1JTtcclxuICAgIGhlaWdodDo2MHB4O1xyXG4gICAgd2lkdGg6NDUlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbiNhbGVydDJ7XHJcbiAgICBtYXJnaW4tbGVmdDoyNSU7XHJcbiAgICBoZWlnaHQ6MzBweDtcclxuICAgIHdpZHRoOjQ1JTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaDV7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5oNntcclxuICAgIGNvbG9yOmRhcmtibHVlO1xyXG59XHJcbiNjbG9zZWJ1dHRvbntcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgfVxyXG4gICNlZGl0bGFiZWx7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICB9XHJcbiNlZGl0YnV0dG9ue1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxuICB9XHJcblxyXG4gIG1hdC1mb3JtLWZpZWxke1xyXG4gICAgICB3aWR0aDo2MCU7XHJcbiAgfVxyXG5cclxuICAjZmxvYXR7XHJcbiAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/mobileperf/execution/sla-config/sla-config.component.ts ***!
  \*******************************************************************************/
/*! exports provided: SlaConfigComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SlaConfigComponent", function() { return SlaConfigComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};



var SlaConfigComponent = /** @class */ (function () {
    function SlaConfigComponent(dialogRef, data, type) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.type = type;
        this.slaconfig = {};
        this.slaconfigupdated = {};
        this.readonly = true;
        this.editalert = false;
        this.showalert = false;
        this.showalertmessage = "";
        this.updatealert = false;
        this.updatemessage = "";
        this.updatestatus = "";
    }
    SlaConfigComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    SlaConfigComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.data.getslaconfig(this.type[0]).subscribe(function (data) {
            //console.log(data)
            _this.slaconfig = data["0"];
            //console.log(this.slaconfig)
            _this.responsetimegood = _this.slaconfig["responsetimegood"];
            _this.responsetimemax = _this.slaconfig["responsetimemax"];
            _this.cpugood = _this.slaconfig["cpugood"];
            _this.cpumax = _this.slaconfig["cpumax"];
            _this.memorygood = _this.slaconfig["memorygood"];
            _this.memorymax = _this.slaconfig["memorymax"];
            _this.appsizegood = _this.slaconfig["appsizegood"];
            _this.appsizemax = _this.slaconfig["appsizemax"];
            _this.batterygood = _this.slaconfig["batterygood"];
            _this.batterymax = _this.slaconfig["batterymax"];
            _this.cpuincreasegood = _this.slaconfig["cpuincreasegood"];
            _this.cpuincreasemax = _this.slaconfig["cpuincreasemax"];
            _this.memoryincreasegood = _this.slaconfig["memoryincreasegood"];
            _this.memoryincreasemax = _this.slaconfig["memoryincreasemax"];
            _this.transsizegood = _this.slaconfig["transsizegood"];
            _this.transsizemax = _this.slaconfig["transsizemax"];
            _this.networkcallsgood = _this.slaconfig["networkcallsgood"];
            _this.networkcallsmax = _this.slaconfig["networkcallsmax"];
            _this.apirequestsize = _this.slaconfig["apirequestsize"];
            _this.apiresponsesize = _this.slaconfig["apiresponsesize"];
            _this.apiresponsetime = _this.slaconfig["apiresponsetime"];
            _this.responsetimeaverage = _this.responsetimegood + ' - ' + _this.responsetimemax;
            _this.cpuaverage = _this.cpugood + ' - ' + _this.cpumax;
            _this.memoryaverage = _this.memorygood + ' - ' + _this.memorymax;
            _this.appsizeaverage = _this.appsizegood + ' - ' + _this.appsizemax;
            _this.batteryaverage = _this.batterygood + ' - ' + _this.batterymax;
            _this.cpuincreaseaverage = _this.cpuincreasegood + ' - ' + _this.cpuincreasemax;
            _this.memoryincreaseaverage = _this.memoryincreasegood + ' - ' + _this.memoryincreasemax;
            _this.transsizeaverage = _this.transsizegood + ' - ' + _this.transsizemax;
            _this.networkcallsaverage = _this.networkcallsgood + ' - ' + _this.networkcallsmax;
        });
    };
    SlaConfigComponent.prototype.responsetimeaveragechange = function () {
        this.responsetimeaverage = this.responsetimegood + ' - ' + this.responsetimemax;
    };
    SlaConfigComponent.prototype.cpuaveragechange = function () {
        this.cpuaverage = this.cpugood + ' - ' + this.cpumax;
    };
    SlaConfigComponent.prototype.memoryaveragechange = function () {
        this.memoryaverage = this.memorygood + ' - ' + this.memorymax;
    };
    SlaConfigComponent.prototype.appsizeaveragechange = function () {
        this.appsizeaverage = this.appsizegood + ' - ' + this.appsizemax;
    };
    SlaConfigComponent.prototype.batteryaveragechange = function () {
        this.batteryaverage = this.batterygood + ' - ' + this.batterymax;
    };
    SlaConfigComponent.prototype.cpuincreaseaveragechange = function () {
        this.cpuincreaseaverage = this.cpuincreasegood + ' - ' + this.cpuincreasemax;
    };
    SlaConfigComponent.prototype.memoryincreaseaveragechange = function () {
        this.memoryincreaseaverage = this.memoryincreasegood + ' - ' + this.memoryincreasemax;
    };
    SlaConfigComponent.prototype.transsizeaveragechange = function () {
        this.transsizeaverage = this.transsizegood + ' - ' + this.transsizemax;
    };
    SlaConfigComponent.prototype.networkcallsaveragechange = function () {
        this.networkcallsaverage = this.networkcallsgood + ' - ' + this.networkcallsmax;
    };
    SlaConfigComponent.prototype.makeconfigeditable = function () {
        var _this = this;
        this.readonly = false;
        this.editalert = true;
        setTimeout(function () {
            _this.editalert = false;
        }, 3500);
    };
    SlaConfigComponent.prototype.updateslaconfiguration = function () {
        var _this = this;
        if (this.responsetimegood > this.responsetimemax) {
            this.showalert = true;
            this.showalertmessage = "Response time minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.cpugood > this.cpumax) {
            this.showalert = true;
            this.showalertmessage = "Cpu minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.memorygood > this.memorymax) {
            this.showalert = true;
            this.showalertmessage = "Memory minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.appsizegood > this.appsizemax) {
            this.showalert = true;
            this.showalertmessage = "App size minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.batterygood > this.batterymax) {
            this.showalert = true;
            this.showalertmessage = "Battery minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.cpuincreasegood > this.cpuincreasemax) {
            this.showalert = true;
            this.showalertmessage = "Increase in cpu minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.memoryincreasegood > this.memoryincreasemax) {
            this.showalert = true;
            this.showalertmessage = "Increase in memory minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.transsizegood > this.transsizemax) {
            this.showalert = true;
            this.showalertmessage = "Transaction size minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else if (this.networkcallsgood > this.networkcallsmax) {
            this.showalert = true;
            this.showalertmessage = "Network calls minimum value cannot be greater than maximum value";
            setTimeout(function () {
                _this.showalert = false;
            }, 3500);
        }
        else {
            this.data.updateresponsetimemax(this.responsetimemax);
            this.slaconfigupdated = {
                "responsetimegood": this.responsetimegood,
                "responsetimemax": this.responsetimemax,
                "cpugood": this.cpugood,
                "cpumax": this.cpumax,
                "memorygood": this.memorygood,
                "memorymax": this.memorymax,
                "appsizegood": this.appsizegood,
                "appsizemax": this.appsizemax,
                "cpuincreasegood": this.cpuincreasegood,
                "cpuincreasemax": this.cpuincreasemax,
                "memoryincreasegood": this.memoryincreasegood,
                "memoryincreasemax": this.memoryincreasemax,
                "transsizegood": this.transsizegood,
                "transsizemax": this.transsizemax,
                "networkcallsgood": this.networkcallsgood,
                "networkcallsmax": this.networkcallsmax,
                "apirequestsize": this.apirequestsize,
                "apiresponsesize": this.apiresponsesize,
                "apiresponsetime": this.apiresponsetime
            };
            if (this.type[0] == "Android") {
                this.slaconfigupdated["batterygood"] = this.batterygood;
                this.slaconfigupdated["batterymax"] = this.batterymax;
            }
            //console.log(this.slaconfigupdated)
            this.data.updateslaconfig(this.slaconfigupdated, this.type[0]).subscribe(function (data) {
                //console.log(data)
                if (data["Status"] == "success") {
                    _this.updatealert = true;
                    _this.updatestatus = "success";
                    _this.updatemessage = "Updated Successfully";
                    setTimeout(function () {
                        _this.updatealert = false;
                    }, 3500);
                }
                else {
                    _this.updatealert = true;
                    _this.updatestatus = "danger";
                    _this.updatemessage = "Updated failed";
                    setTimeout(function () {
                        _this.updatealert = false;
                    }, 3500);
                }
            });
        }
    };
    SlaConfigComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'sla-config',
            template: __webpack_require__(/*! ./sla-config.component.html */ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.html"),
            styles: [__webpack_require__(/*! ./sla-config.component.scss */ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.scss")]
        }),
        __param(2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_2__["MatDialogRef"], _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_1__["MobilePerfService"], Object])
    ], SlaConfigComponent);
    return SlaConfigComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.html":
/*!*************************************************************************!*\
  !*** ./src/app/pages/mobileperf/imageviewer/imageviewer.component.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-md-8 justify-content-center\">\r\n        <h1 mat-dialog-title>{{images[2]}}</h1>\r\n    </div>\r\n    <div class=\"col-md-3 justify-content-center\">\r\n    </div>\r\n    <button id=\"closebutton\" mat-icon-button style=\"float:right\" type=\"button\" (click)=\"onNoClick()\">\r\n        <mat-icon aria-label=\"close\">close</mat-icon>\r\n      </button>\r\n</div>\r\n\r\n\r\n<div class=\"col-md-6 justify-content-center\">\r\n    <img class=\"expandedimage\" src={{imagepath1}}>\r\n</div>\r\n<div class=\"col-md-6 justify-content-center\">\r\n    <img class=\"expandedimage\" src={{imagepath2}}>\r\n</div>"

/***/ }),

/***/ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/pages/mobileperf/imageviewer/imageviewer.component.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@media only screen and (min-width: 1280px) {\n  .expandedimage {\n    width: 100%;\n    height: 350px; } }\n\n@media only screen and (min-width: 1580px) {\n  .expandedimage {\n    width: 100%;\n    height: 680px; } }\n\n.column {\n  float: left; }\n\nh1 {\n  text-align: center;\n  margin-left: 40%;\n  color: green;\n  font-weight: bold; }\n\n#closebutton {\n  outline: none; }\n\nlabel {\n  font-size: 24px;\n  cursor: pointer; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9pbWFnZXZpZXdlci9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxtb2JpbGVwZXJmXFxpbWFnZXZpZXdlclxcaW1hZ2V2aWV3ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSTtJQUNJLFdBQVU7SUFDVixhQUFZLEVBQUEsRUFDZjs7QUFFSDtFQUNFO0lBQ0ksV0FBVTtJQUNWLGFBQVksRUFBQSxFQUNmOztBQUVMO0VBQ0ksV0FBVSxFQUFBOztBQUVkO0VBQ0ksa0JBQWtCO0VBQ2xCLGdCQUFlO0VBQ2YsWUFBVztFQUNYLGlCQUFpQixFQUFBOztBQUVyQjtFQUNJLGFBQVksRUFBQTs7QUFFaEI7RUFDSSxlQUFjO0VBQ2QsZUFBZSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9pbWFnZXZpZXdlci9pbWFnZXZpZXdlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDEyODBweCkge1xyXG4gICAgLmV4cGFuZGVkaW1hZ2V7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBoZWlnaHQ6MzUwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIEBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTU4MHB4KSB7XHJcbiAgICAuZXhwYW5kZWRpbWFnZXtcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIGhlaWdodDo2ODBweDtcclxuICAgIH1cclxuICB9XHJcbi5jb2x1bW57XHJcbiAgICBmbG9hdDpsZWZ0O1xyXG59XHJcbmgxe1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLWxlZnQ6NDAlO1xyXG4gICAgY29sb3I6Z3JlZW47XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG4jY2xvc2VidXR0b257XHJcbiAgICBvdXRsaW5lOm5vbmU7XHJcbn1cclxubGFiZWx7XHJcbiAgICBmb250LXNpemU6MjRweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/mobileperf/imageviewer/imageviewer.component.ts ***!
  \***********************************************************************/
/*! exports provided: ImageviewerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageviewerComponent", function() { return ImageviewerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};


var ImageviewerComponent = /** @class */ (function () {
    function ImageviewerComponent(dialogRef, images) {
        this.dialogRef = dialogRef;
        this.images = images;
    }
    ImageviewerComponent.prototype.ngOnInit = function () {
        this.imagepath1 = this.images[0];
        this.imagepath2 = this.images[1];
    };
    ImageviewerComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    ImageviewerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'imageviewer',
            template: __webpack_require__(/*! ./imageviewer.component.html */ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.html"),
            styles: [__webpack_require__(/*! ./imageviewer.component.scss */ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.scss")]
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], ImageviewerComponent);
    return ImageviewerComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/mobileperf-data.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/mobileperf/mobileperf-data.service.ts ***!
  \*************************************************************/
/*! exports provided: MobilePerfService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobilePerfService", function() { return MobilePerfService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_add_operator_timeout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/timeout */ "./node_modules/rxjs-compat/_esm5/add/operator/timeout.js");
/* harmony import */ var rxjs_add_operator_take__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/take */ "./node_modules/rxjs-compat/_esm5/add/operator/take.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var MobilePerfService = /** @class */ (function () {
    //private url: string = 'http://ec2-52-52-49-127.us-west-1.compute.amazonaws.com';
    //private url: string = 'http://ec2-13-233-83-221.ap-south-1.compute.amazonaws.com:1000';//Fastest
    // private url: string = 'http://ec2-13-234-166-85.ap-south-1.compute.amazonaws.com'; //AWS Dev 3
    function MobilePerfService(http) {
        this.http = http;
        /*
        toolURIs = JSON.parse(localStorage.getItem("toolURIs"));
        MobilePerf = this.toolURIs.find((x) => { return (x.toolName == "MobilePerf"); });
        private url: string = this.MobilePerf.URI;//dynamically fetching URIs
         */
        this.url = ''; //Production
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        this.waterfallChartData = {};
        // --- Analysis API for scrambled  --- //
        this.waterfallChartDataScrambled = {};
    }
    MobilePerfService.prototype.storerunid = function (runid) {
        this.runid = runid;
    };
    MobilePerfService.prototype.geturl = function () {
        return this.url;
    };
    MobilePerfService.prototype.getharfile = function (transactionname) {
        var body = {
            appid: localStorage.getItem('appid'),
            transactionname: transactionname,
            runid: this.runid
        };
        return this.http.post(this.url + "/mobileperfAPI/gethardata", body);
    };
    MobilePerfService.prototype.updateresponsetimemax = function (maxresponsetime) {
        this.maxresponsetime = maxresponsetime;
    };
    MobilePerfService.prototype.getmaxresponsetime = function () {
        return this.maxresponsetime;
    };
    MobilePerfService.prototype.updateslaconfig = function (object, devicetype) {
        var body = { object: object, devicetype: devicetype };
        var appid = localStorage.getItem('appid');
        return this.http.post(this.url + "/mobileperfAPI/updateslaconfig?appid=" + appid, body);
    };
    MobilePerfService.prototype.uploadzipapi = function (body, filename) {
        var appid = localStorage.getItem('appid');
        return this.http.post(this.url + "/mobileperfAPI/uploadzipapi?appid=" + appid + "&filename=" + filename, body);
    };
    MobilePerfService.prototype.getslaconfig = function (devicetype) {
        var body = { devicetype: devicetype };
        var appid = localStorage.getItem('appid');
        return this.http.post(this.url + '/mobileperfAPI/getslaconfig?appid=' + appid, body);
    };
    MobilePerfService.prototype.gettestruns = function () {
        var appid = localStorage.getItem('appid');
        return this.http.get(this.url + '/mobileperfAPI/getTestDetails?appid=' + appid); //.timeout(5000);
    };
    MobilePerfService.prototype.gettestrunsbyId = function (objectid) {
        return this.http.get(this.url + '/mobileperfAPI/getTestDetailsByID?objectid=' + objectid); //.timeout(5000);
    };
    //validate before execution 
    MobilePerfService.prototype.getValidationForMobPerf = function (component, op) {
        var users = 1;
        return this.http.get(this.url + "/license/LicenseValidatorApi?component=" + component + "&users=" + users + "&op=" + op);
    };
    MobilePerfService.prototype.getAppAccessLevelByID = function (appID) {
        return this.http.get(this.url + '/userAPI/getAppAccessLevelByID?appID=' + appID);
    };
    MobilePerfService.prototype.getScrambleForUxPerfMobile = function () {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/scrambleAPIForUxPerfMob/getScramble", httpOptions);
    };
    MobilePerfService.prototype.storerunidForScrambled = function (runid) {
        this.runid = runid;
    };
    MobilePerfService.prototype.geturlForScrambled = function () {
        return this.url;
    };
    MobilePerfService.prototype.gettestrunsbyIdForScrambled = function (objectid) {
        return this.http.get(this.url + '/scrambleAPIForUxPerfMob/getTestDetailsByID?objectid=' + objectid); //.timeout(5000);
    };
    MobilePerfService.prototype.getslaconfigForScrambled = function (devicetype, appId, customerId) {
        var body = {
            devicetype: devicetype,
            customerID: customerId
        };
        return this.http.post(this.url + '/scrambleAPIForUxPerfMob/getslaconfig?appid=' + appId, body);
    };
    MobilePerfService.prototype.getharfileForScrambled = function (transactionname, customerId, appId) {
        var body = {
            appid: appId,
            transactionname: transactionname,
            runid: this.runid
        };
        return this.http.post(this.url + "/scrambleAPIForUxPerfMob/gethardata?customerID=" + customerId, body);
    };
    MobilePerfService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], MobilePerfService);
    return MobilePerfService;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/mobileperf-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/mobileperf/mobileperf-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: MobilePerfRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobilePerfRoutingModule", function() { return MobilePerfRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _analysis_analysis_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./analysis/analysis.component */ "./src/app/pages/mobileperf/analysis/analysis.component.ts");
/* harmony import */ var _test_runs_test_runs_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./test-runs/test-runs.component */ "./src/app/pages/mobileperf/test-runs/test-runs.component.ts");
/* harmony import */ var _execution_execution_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./execution/execution.component */ "./src/app/pages/mobileperf/execution/execution.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var routes = [
    {
        path: 'testruns',
        component: _test_runs_test_runs_component__WEBPACK_IMPORTED_MODULE_3__["TestRunsComponent"]
    },
    {
        path: 'execution',
        component: _execution_execution_component__WEBPACK_IMPORTED_MODULE_4__["ExecutionComponent"]
    },
    {
        path: 'analysis/:objectid/:devicetype',
        component: _analysis_analysis_component__WEBPACK_IMPORTED_MODULE_2__["AnalysisComponent"]
    }
];
var MobilePerfRoutingModule = /** @class */ (function () {
    function MobilePerfRoutingModule() {
    }
    MobilePerfRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], MobilePerfRoutingModule);
    return MobilePerfRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/mobileperf.component.html":
/*!************************************************************!*\
  !*** ./src/app/pages/mobileperf/mobileperf.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/pages/mobileperf/mobileperf.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/mobileperf/mobileperf.component.ts ***!
  \**********************************************************/
/*! exports provided: MobilePerfComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobilePerfComponent", function() { return MobilePerfComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var MobilePerfComponent = /** @class */ (function () {
    function MobilePerfComponent() {
    }
    MobilePerfComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-mobileperf',
            template: __webpack_require__(/*! ./mobileperf.component.html */ "./src/app/pages/mobileperf/mobileperf.component.html")
        }),
        __metadata("design:paramtypes", [])
    ], MobilePerfComponent);
    return MobilePerfComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/mobileperf.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/mobileperf/mobileperf.module.ts ***!
  \*******************************************************/
/*! exports provided: MobilePerfModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MobilePerfModule", function() { return MobilePerfModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
/* harmony import */ var _mobileperf_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./mobileperf-routing.module */ "./src/app/pages/mobileperf/mobileperf-routing.module.ts");
/* harmony import */ var _analysis_analysis_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./analysis/analysis.component */ "./src/app/pages/mobileperf/analysis/analysis.component.ts");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @swimlane/ngx-charts */ "./node_modules/@swimlane/ngx-charts/release/index.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _status_card_status_card_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./status-card/status-card.component */ "./src/app/pages/mobileperf/status-card/status-card.component.ts");
/* harmony import */ var _test_runs_test_runs_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./test-runs/test-runs.component */ "./src/app/pages/mobileperf/test-runs/test-runs.component.ts");
/* harmony import */ var _waterfallchart_waterfallchart_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./waterfallchart/waterfallchart.component */ "./src/app/pages/mobileperf/waterfallchart/waterfallchart.component.ts");
/* harmony import */ var _execution_sla_config_sla_config_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./execution/sla-config/sla-config.component */ "./src/app/pages/mobileperf/execution/sla-config/sla-config.component.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
/* harmony import */ var _popupview_popupview_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./popupview/popupview.component */ "./src/app/pages/mobileperf/popupview/popupview.component.ts");
/* harmony import */ var _popupview_url_popups_url_popups_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./popupview/url-popups/url-popups.component */ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.ts");
/* harmony import */ var _imageviewer_imageviewer_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./imageviewer/imageviewer.component */ "./src/app/pages/mobileperf/imageviewer/imageviewer.component.ts");
/* harmony import */ var _execution_execution_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./execution/execution.component */ "./src/app/pages/mobileperf/execution/execution.component.ts");
/* harmony import */ var _mobileperf_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./mobileperf.component */ "./src/app/pages/mobileperf/mobileperf.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



















var MobilePerfModule = /** @class */ (function () {
    function MobilePerfModule() {
    }
    MobilePerfModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbAlertModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbPopoverModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ReactiveFormsModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_7__["NgxChartsModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbCardModule"],
                _mobileperf_routing_module__WEBPACK_IMPORTED_MODULE_4__["MobilePerfRoutingModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbTabsetModule"],
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__["CdkTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatAutocompleteModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatBadgeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatBottomSheetModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatButtonToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatChipsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatDatepickerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatDialogModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatDividerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatGridListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatNativeDateModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatProgressBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatProgressSpinnerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatRippleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSliderModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSlideToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSnackBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatStepperModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTabsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTooltipModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_12__["MatTreeModule"]
            ],
            declarations: [_analysis_analysis_component__WEBPACK_IMPORTED_MODULE_5__["AnalysisComponent"], _waterfallchart_waterfallchart_component__WEBPACK_IMPORTED_MODULE_10__["WaterfallchartComponent"], _test_runs_test_runs_component__WEBPACK_IMPORTED_MODULE_9__["TestRunsComponent"], _popupview_popupview_component__WEBPACK_IMPORTED_MODULE_14__["PopupviewComponent"], _popupview_url_popups_url_popups_component__WEBPACK_IMPORTED_MODULE_15__["UrlPopupsComponent"], _status_card_status_card_component__WEBPACK_IMPORTED_MODULE_8__["StatusCardComponent"], _imageviewer_imageviewer_component__WEBPACK_IMPORTED_MODULE_16__["ImageviewerComponent"], _execution_execution_component__WEBPACK_IMPORTED_MODULE_17__["ExecutionComponent"], _mobileperf_component__WEBPACK_IMPORTED_MODULE_18__["MobilePerfComponent"], _execution_sla_config_sla_config_component__WEBPACK_IMPORTED_MODULE_11__["SlaConfigComponent"]],
            providers: [_mobileperf_data_service__WEBPACK_IMPORTED_MODULE_13__["MobilePerfService"]],
            entryComponents: [_analysis_analysis_component__WEBPACK_IMPORTED_MODULE_5__["AnalysisComponent"], _popupview_popupview_component__WEBPACK_IMPORTED_MODULE_14__["PopupviewComponent"], _popupview_url_popups_url_popups_component__WEBPACK_IMPORTED_MODULE_15__["UrlPopupsComponent"], _imageviewer_imageviewer_component__WEBPACK_IMPORTED_MODULE_16__["ImageviewerComponent"], _execution_sla_config_sla_config_component__WEBPACK_IMPORTED_MODULE_11__["SlaConfigComponent"]]
        })
    ], MobilePerfModule);
    return MobilePerfModule;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/popupview/popupview.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/pages/mobileperf/popupview/popupview.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"overflow-x: hidden;\">\n    <div class=\"row\">\n        <div class=\"col-md-8 justify-content-center\">\n            <h1 mat-dialog-title>{{popupdata[2]}}</h1>\n        </div>\n        <div class=\"col-md-3 justify-content-center\">\n        </div>\n        <button id=\"closebutton\" mat-icon-button style=\"float:right\" type=\"button\" (click)=\"onNoClick()\">\n            <mat-icon aria-label=\"close\">close</mat-icon>\n        </button>\n    </div>\n    <div>\n        <br>\n        <mat-tab-group (selectedIndexChange)=\"popuptabschanged($event)\" mat-stretch-tabs>\n            <mat-tab label=\"API Analysis\">\n                <div *ngIf=\"pagewisenull\" class=\"row justify-content-center\">\n                    <h6>{{pagewisenullmessage}}</h6>\n                    <br>\n                    <br>\n                </div>\n                <div *ngIf=\"!pagewisenull\" class=\"row\">\n                    <div class=\"col-md-1\">\n                    </div>\n                    <div class=\"col-md-3\">\n                        <mat-form-field>\n                            <mat-label>Search</mat-label>\n                            <input matInput (keyup)=\"applyFilter($event)\" placeholder=\"Ex. Mia\">\n                        </mat-form-field>\n                    </div>\n                    <div class=\"col-md-12\">\n                        <table class=\"table table-bordered table-hover\" matSort mat-table [dataSource]=\"dataSource\"\n                            width=\"100%;\">\n                            <div>\n                                <ng-container matColumnDef=\"Sla\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"10%;\">\n                                        <h6>SLA\n                                            Met </h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\">\n                                        <mat-icon [ngClass]=\"{'greenColor': element.Sla, 'redColor': !element.Sla}\">\n                                            fiber_manual_record</mat-icon>\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"Url\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"30%;\">\n                                        <h6>URL</h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.Url}} </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"Status\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"10%;\">\n                                        <h6>Status</h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.Status}}\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"RequestSize\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"10%;\">\n                                        <h6>Request Size (mb)</h6>\n\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.RequestSize}}\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"ResponseSize\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"5%;\">\n                                        <h6>Response Size (mb)</h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.ResponseSize}}\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"ResponseTime\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"5%;\">\n                                        <h6>Response Time (ms)</h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.ResponseTime}}\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"Api\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"30%;\">\n                                        <h6>API</h6>\n                                    </th>\n                                    <td title=\"Click here to view more\" mat-cell *matCellDef=\"let element\">\n                                        {{element.Api | slice:0:30}}\n                                        <br>\n                                        <span id=\"arrow\" (click)=\"openurlcomponent(element.Api,'pagewise',popupdata[2])\"\n                                            *ngIf=\"(element.Api).length>30\" class=\"material-icons\">\n                                            keyboard_arrow_down\n                                        </span>\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <tr mat-header-row *matHeaderRowDef=\"pagewiseviewtablecolumns\"></tr>\n                            <tr mat-row *matRowDef=\"let row; columns: pagewiseviewtablecolumns;\"></tr>\n                        </table>\n                        <mat-paginator #paginator [pageSizeOptions]=\"[3, 10, 25, 100]\"></mat-paginator>\n                    </div>\n                </div>\n            </mat-tab>\n            <mat-tab label=\"Waterfall Analysis\">\n                <br>\n\n                <div *ngIf=\"showwaterfallchart\">\n                    <waterfallchart style=\"overflow: auto;\"> </waterfallchart>\n                </div>\n            </mat-tab>\n            <mat-tab label=\"Recommendations view\">\n\n                <div *ngIf=\"recommendationsnull\" class=\"row justify-content-center\">\n                    <h6>{{recommendationsnullmessage}}</h6>\n                </div>\n                <div *ngIf=\"!recommendationsnull\" class=\"row\">\n                    <div class=\"col-md-1\">\n                    </div>\n                    <div class=\"col-md-3\">\n                        <mat-form-field>\n                            <mat-label>Search</mat-label>\n                            <input matInput (keyup)=\"applyFiltertable2($event)\" placeholder=\"Ex. Mia\">\n                        </mat-form-field>\n                    </div>\n                    <div class=\"col-md-12\">\n                        <table id=\"page-table\" class=\"table table-bordered table-hover\" matSort mat-table\n                            [dataSource]=\"dataSourcetable2\" width=\"100%;\">\n                            <div>\n                                <ng-container matColumnDef=\"ruleheader\">\n                                    <th mat-header-cell mat-sort-header class=\"headercell\" *matHeaderCellDef\n                                        width=\"30%;\">\n                                        <h6>Rule\n                                            Header </h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.ruleheader}} </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"message\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"30%;\">\n                                        <h6>Message</h6>\n                                    </th>\n                                    <td title=\"Click here to view more\" mat-cell *matCellDef=\"let element\">\n                                        {{element.message  | slice:0:30}}\n                                        <br>\n                                        <span id=\"arrow\"\n                                            (click)=\"openurlcomponent(element.message,'recommendation',popupdata[2])\"\n                                            *ngIf=\"(element.message).length>30\" class=\"material-icons\">\n                                            keyboard_arrow_down\n                                        </span>\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <div>\n                                <ng-container matColumnDef=\"recommendation\">\n                                    <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef\n                                        width=\"40%;\">\n                                        <h6>Recommendation</h6>\n                                    </th>\n                                    <td mat-cell *matCellDef=\"let element\"> {{element.recommendation}}\n                                    </td>\n                                </ng-container>\n                            </div>\n                            <tr mat-header-row *matHeaderRowDef=\"recommendationtablecolumns\"></tr>\n                            <tr mat-row *matRowDef=\"let row; columns: recommendationtablecolumns;\"></tr>\n                        </table>\n                        <mat-paginator #paginator2 [pageSizeOptions]=\"[2, 10, 25, 100]\"></mat-paginator>\n                    </div>\n                </div>\n            </mat-tab>\n        </mat-tab-group>\n    </div>\n</div>"

/***/ }),

/***/ "./src/app/pages/mobileperf/popupview/popupview.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/pages/mobileperf/popupview/popupview.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".mat-cell {\n  text-align: center;\n  color: black;\n  font-family: sans-serif;\n  word-break: break-all; }\n\n:host ::ng-deep .mat-sort-header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center; }\n\n#closebutton {\n  outline: none; }\n\nh1 {\n  text-align: center;\n  margin-left: 40%;\n  color: green;\n  font-weight: bold; }\n\nlabel {\n  font-size: 24px;\n  cursor: pointer; }\n\n.redColor {\n  color: red; }\n\n.greenColor {\n  color: green; }\n\n.yellowColor {\n  color: yellow; }\n\nth.mat-header-cell, td.mat-cell {\n  text-align: center; }\n\n#arrow {\n  font-size: 35px;\n  cursor: pointer; }\n\n#viewmorebutton {\n  color: blue;\n  background-color: white; }\n\nh5 {\n  font-weight: normal;\n  text-align: center; }\n\n.button {\n  color: blue;\n  font-size: 100%; }\n\n.recommendation {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9wb3B1cHZpZXcvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxwYWdlc1xcbW9iaWxlcGVyZlxccG9wdXB2aWV3XFxwb3B1cHZpZXcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxrQkFBa0I7RUFDbEIsWUFBVztFQUNYLHVCQUF1QjtFQUN2QixxQkFBcUIsRUFBQTs7QUFFekI7RUFDSSxvQkFBYTtFQUFiLG9CQUFhO0VBQWIsYUFBYTtFQUNiLHdCQUF1QjtNQUF2QixxQkFBdUI7VUFBdkIsdUJBQXVCLEVBQUE7O0FBRTNCO0VBQ0UsYUFBYSxFQUFBOztBQUVmO0VBQ0ksa0JBQWtCO0VBQ2xCLGdCQUFlO0VBQ2YsWUFBVztFQUNYLGlCQUFpQixFQUFBOztBQUVyQjtFQUNJLGVBQWM7RUFDZCxlQUFlLEVBQUE7O0FBRW5CO0VBQ0ksVUFBVSxFQUFBOztBQUVkO0VBQ0ksWUFBWSxFQUFBOztBQUVoQjtFQUNJLGFBQWEsRUFBQTs7QUFFakI7RUFDSSxrQkFBa0IsRUFBQTs7QUFFdEI7RUFDSSxlQUFjO0VBQ2QsZUFBZSxFQUFBOztBQUVuQjtFQUNJLFdBQVU7RUFDVix1QkFBdUIsRUFBQTs7QUFFM0I7RUFDSSxtQkFBbUI7RUFDbkIsa0JBQWtCLEVBQUE7O0FBRXRCO0VBQ0csV0FBVTtFQUNWLGVBQWUsRUFBQTs7QUFHbEI7RUFDSSxXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tb2JpbGVwZXJmL3BvcHVwdmlldy9wb3B1cHZpZXcuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLm1hdC1jZWxse1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIHdvcmQtYnJlYWs6IGJyZWFrLWFsbDtcclxufVxyXG46aG9zdCA6Om5nLWRlZXAgLm1hdC1zb3J0LWhlYWRlci1jb250YWluZXIgeyBcclxuICAgIGRpc3BsYXk6IGZsZXg7ICBcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyOyBcclxufVxyXG4jY2xvc2VidXR0b257XHJcbiAgb3V0bGluZTogbm9uZTtcclxufVxyXG5oMXtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi1sZWZ0OjQwJTtcclxuICAgIGNvbG9yOmdyZWVuO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxubGFiZWx7XHJcbiAgICBmb250LXNpemU6MjRweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4ucmVkQ29sb3J7XHJcbiAgICBjb2xvcjogcmVkO1xyXG59XHJcbi5ncmVlbkNvbG9ye1xyXG4gICAgY29sb3I6IGdyZWVuO1xyXG59XHJcbi55ZWxsb3dDb2xvcntcclxuICAgIGNvbG9yOiB5ZWxsb3c7XHJcbn1cclxudGgubWF0LWhlYWRlci1jZWxsLCB0ZC5tYXQtY2VsbCB7IFxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyOyBcclxufVxyXG4jYXJyb3d7XHJcbiAgICBmb250LXNpemU6MzVweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4jdmlld21vcmVidXR0b257XHJcbiAgICBjb2xvcjpibHVlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuaDV7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5idXR0b257XHJcbiAgIGNvbG9yOmJsdWU7XHJcbiAgIGZvbnQtc2l6ZTogMTAwJTtcclxufVxyXG5cclxuLnJlY29tbWVuZGF0aW9uIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/mobileperf/popupview/popupview.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/mobileperf/popupview/popupview.component.ts ***!
  \*******************************************************************/
/*! exports provided: PopupviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopupviewComponent", function() { return PopupviewComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/esm5/paginator.es5.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _url_popups_url_popups_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./url-popups/url-popups.component */ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.ts");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};







var PopupviewComponent = /** @class */ (function () {
    function PopupviewComponent(dialogRef, urlpopup, data, popupdata) {
        this.dialogRef = dialogRef;
        this.urlpopup = urlpopup;
        this.data = data;
        this.popupdata = popupdata;
        this.pagewiseviewtable = [];
        this.recommendationtable = [];
        this.pagewisenull = false;
        this.pagewisenullmessage = '';
        this.recommendationsnull = false;
        this.recommendationsnullmessage = '';
        this.pagewisearray = [];
        this.recommendationsarray = [];
        this.waterfallChartData = {};
        this.showwaterfallchart = false;
        this.slaconfig = {};
        this.pagewiseviewtablecolumns = ['Sla',
            'Url',
            'Status',
            'RequestSize',
            'ResponseSize',
            'ResponseTime',
            'Api'];
        this.recommendationtablecolumns = ['ruleheader', 'message', 'recommendation'];
    }
    PopupviewComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    PopupviewComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.data.getslaconfig(this.popupdata[3]).subscribe(function (data) {
            //console.log(data)
            _this.slaconfig = data["0"];
            //console.log(this.slaconfig)
        });
        this.pagewiseviewtable = [];
        this.recommendationtable = [];
        this.pagewisearray = [];
        this.recommendationsarray = [];
        this.pagewisearray = this.popupdata[0][0];
        this.recommendationsarray = this.popupdata[1][0];
        if (this.pagewisearray.length == 0) {
            this.pagewisenull = true;
            this.pagewisenullmessage = 'No Pagewise Data Found';
        }
        else {
            this.pagewisenull = false;
            for (var i = 0; i < this.pagewisearray.length; i++) {
                var slamet;
                slamet = this.checkifslaismet(i);
                this.pagewiseviewtable.push({
                    Sla: slamet,
                    Url: this.pagewisearray[i]["Domain"],
                    Status: this.pagewisearray[i]["STATUS"],
                    RequestSize: this.pagewisearray[i]["RequestSize"],
                    ResponseSize: this.pagewisearray[i]["ResponseSize"],
                    ResponseTime: this.pagewisearray[i]["ResponseTime"],
                    Api: this.pagewisearray[i]["RequestedPage"]
                });
            }
        }
        if (this.recommendationsarray.length == 0) {
            this.recommendationsnull = true;
            this.recommendationsnullmessage = 'No Recommendations Data Found';
        }
        else {
            this.recommendationsnull = false;
            for (var i = 0; i < this.recommendationsarray.length; i++) {
                this.recommendationtable.push({
                    ruleheader: this.recommendationsarray[i]["ruleHeader"],
                    message: this.recommendationsarray[i]["Message"],
                    recommendation: this.recommendationsarray[i]["Recommendation"]
                });
            }
        }
        this.pagewiseviewtable.sort(this.sorter);
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](this.pagewiseviewtable);
        this.dataSourcetable2 = new _angular_material_table__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](this.recommendationtable);
        this.waterfallChartData = {
            transaction: this.popupdata[2]
        };
        this.data.waterfallChartData = this.waterfallChartData;
        this.showwaterfallchart = true;
    };
    PopupviewComponent.prototype.ngAfterViewInit = function () {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSourcetable2.paginator2 = this.paginator2;
        this.dataSourcetable2.sort = this.sort;
    };
    PopupviewComponent.prototype.checkifslaismet = function (i) {
        if (((this.pagewisearray[i]["RequestSize"] > this.slaconfig["apirequestsize"]) || (this.pagewisearray[i]["ResponseSize"] > this.slaconfig["apiresponsesize"]) || (this.pagewisearray[i]["ResponseTime"] > this.slaconfig["apiresponsetime"]) || (this.pagewisearray[i]["STATUS"] != 200))) {
            return false;
        }
        else {
            return true;
        }
    };
    PopupviewComponent.prototype.applyFilter = function (event) {
        var filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    };
    PopupviewComponent.prototype.applyFiltertable2 = function (event) {
        var filterValue = event.target.value;
        this.dataSourcetable2.filter = filterValue.trim().toLowerCase();
        if (this.dataSourcetable2.paginator2) {
            this.dataSourcetable2.paginator2.firstPage();
        }
    };
    PopupviewComponent.prototype.openurlcomponent = function (url, type, TransactionName) {
        this.urlpopup.open(_url_popups_url_popups_component__WEBPACK_IMPORTED_MODULE_5__["UrlPopupsComponent"], {
            height: '40%',
            width: '50%',
            data: [url, type, TransactionName]
        });
    };
    PopupviewComponent.prototype.popuptabschanged = function (indexNumber) {
        var _this = this;
        setTimeout(function () {
            switch (indexNumber) {
                case 0:
                    !_this.dataSource.paginator ? _this.dataSource.paginator = _this.paginator : null;
                    break;
                case 2:
                    !_this.dataSourcetable2.paginator ? _this.dataSourcetable2.paginator = _this.paginator2 : null;
            }
        });
    };
    PopupviewComponent.prototype.sorter = function (a, b) {
        // Use toUpperCase() to ignore character casing
        var t1 = a.Url.toUpperCase();
        var t2 = b.Url.toUpperCase();
        var comparison = 0;
        if (t1 > t2) {
            comparison = 1;
        }
        else if (t1 < t2) {
            comparison = -1;
        }
        return comparison;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('paginator'),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"])
    ], PopupviewComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('paginator2'),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"])
    ], PopupviewComponent.prototype, "paginator2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_3__["MatSort"]),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_3__["MatSort"])
    ], PopupviewComponent.prototype, "sort", void 0);
    PopupviewComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'popupview',
            template: __webpack_require__(/*! ./popupview.component.html */ "./src/app/pages/mobileperf/popupview/popupview.component.html"),
            styles: [__webpack_require__(/*! ./popupview.component.scss */ "./src/app/pages/mobileperf/popupview/popupview.component.scss")]
        }),
        __param(3, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"],
            _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialog"], _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_6__["MobilePerfService"], Object])
    ], PopupviewComponent);
    return PopupviewComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <div class=\"col-md-8 justify-content-center\">\n    <h1  mat-dialog-title>{{urlpopup[2]}}</h1>\n</div>\n<div class=\"col-md-3 justify-content-center\">\n</div>\n<button id=\"closebutton\" mat-icon-button style=\"float:right\" type=\"button\" (click)=\"onNoClick()\">\n  <mat-icon aria-label=\"close\">close</mat-icon>\n</button>\n</div>\n\n<div *ngIf=\"!ispagewise\">\n<p  *ngFor=\"let url of Arraysplitsurl[0]\">\n  {{url}} \n  <br>\n</p>\n</div>\n<div *ngIf=\"ispagewise\">\n<p  >\n  {{this.urlpopup[0]}}\n</p>\n</div>\n"

/***/ }),

/***/ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "div {\n  word-break: break-all; }\n\nh1 {\n  text-align: center;\n  margin-left: 40%;\n  color: green;\n  font-weight: bold; }\n\nlabel {\n  font-size: 24px;\n  cursor: pointer; }\n\n#closebutton {\n  outline: none; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9wb3B1cHZpZXcvdXJsLXBvcHVwcy9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxtb2JpbGVwZXJmXFxwb3B1cHZpZXdcXHVybC1wb3B1cHNcXHVybC1wb3B1cHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBcUIsRUFBQTs7QUFFekI7RUFDSSxrQkFBa0I7RUFDbEIsZ0JBQWU7RUFDZixZQUFXO0VBQ1gsaUJBQWlCLEVBQUE7O0FBRXJCO0VBQ0ksZUFBYztFQUNkLGVBQWUsRUFBQTs7QUFFbkI7RUFDSSxhQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tb2JpbGVwZXJmL3BvcHVwdmlldy91cmwtcG9wdXBzL3VybC1wb3B1cHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJkaXZ7XHJcbiAgICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XHJcbn1cclxuaDF7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tbGVmdDo0MCU7XHJcbiAgICBjb2xvcjpncmVlbjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbmxhYmVse1xyXG4gICAgZm9udC1zaXplOjI0cHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuI2Nsb3NlYnV0dG9ue1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.ts ***!
  \*******************************************************************************/
/*! exports provided: UrlPopupsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UrlPopupsComponent", function() { return UrlPopupsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};


var UrlPopupsComponent = /** @class */ (function () {
    function UrlPopupsComponent(dialogRef, urlpopup) {
        this.dialogRef = dialogRef;
        this.urlpopup = urlpopup;
        this.Arraysplitsurl = [];
        this.ispagewise = false;
    }
    UrlPopupsComponent.prototype.ngOnInit = function () {
        if (this.urlpopup[1] == "recommendation") {
            this.ispagewise = false;
            this.Arraysplitsurl.push(this.urlpopup[0].split(','));
        }
        else if (this.urlpopup[1] == "pagewise") {
            this.ispagewise = true;
        }
    };
    UrlPopupsComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    UrlPopupsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'url-popups',
            template: __webpack_require__(/*! ./url-popups.component.html */ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.html"),
            styles: [__webpack_require__(/*! ./url-popups.component.scss */ "./src/app/pages/mobileperf/popupview/url-popups/url-popups.component.scss")]
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], UrlPopupsComponent);
    return UrlPopupsComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/status-card/status-card.component.html":
/*!*************************************************************************!*\
  !*** ./src/app/pages/mobileperf/status-card/status-card.component.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nb-card>\r\n  <div class=\"icon-container\">\r\n    <div class=\"icon {{ type }}\">\r\n      <ng-content></ng-content>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"details\">\r\n    <div class=\"title\">{{ title }}</div>\r\n    <div>\r\n      <label >{{value}}</label>\r\n      <br>\r\n      <label >{{value2}}</label>\r\n    </div>\r\n  </div>\r\n</nb-card>\r\n\r\n\r\n<!--  (click)=\"on = !on\" \r\n      [ngClass]=\"{'off': !on}\"\r\n      \r\n      class=\"status\"\r\n      \r\n      \r\n      {{ on ? 'ON' : 'OFF' }} -->"

/***/ }),

/***/ "./src/app/pages/mobileperf/status-card/status-card.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/pages/mobileperf/status-card/status-card.component.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This is a starting point where we declare the maps of themes and globally available functions/mixins\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/*\n      :host can be prefixed\n      https://github.com/angular/angular/blob/8d0ee34939f14c07876d222c25b405ed458a34d3/packages/compiler/src/shadow_css.ts#L441\n\n      We have to use :host insted of :host-context($theme), to be able to prefix theme class\n      with something defined inside of @content, by prefixing &.\n      For example this scss code:\n        .nb-theme-default {\n          .some-selector & {\n            ...\n          }\n        }\n      Will result in next css:\n        .some-selector .nb-theme-default {\n          ...\n        }\n\n      It doesn't work with :host-context because angular splitting it in two selectors and removes\n      prefix in one of the selectors.\n    */\n.nb-theme-default :host nb-card {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 80%;\n  width: 100%;\n  overflow: hidden;\n  -webkit-box-shadow: 0 0 0 0 #dbdbdb, none;\n          box-shadow: 0 0 0 0 #dbdbdb, none;\n  border: 1px solid #d5dbe0;\n  border-top-color: #d5dbe0;\n  border-top-style: solid;\n  border-top-width: 1px;\n  border-right-color: #d5dbe0;\n  border-right-style: solid;\n  border-right-width: 1px;\n  border-bottom-color: #d5dbe0;\n  border-bottom-style: solid;\n  border-bottom-width: 1px;\n  border-left-color: #d5dbe0;\n  border-left-style: solid;\n  border-left-width: 1px;\n  border-image-source: initial;\n  border-image-slice: initial;\n  border-image-width: initial;\n  border-image-outset: initial;\n  border-image-repeat: initial; }\n.nb-theme-default :host nb-card .icon-container {\n    height: 100%;\n    padding: 0.625rem; }\n.nb-theme-default :host nb-card .icon {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    width: 2.25rem;\n    height: 2.75rem;\n    font-size: 1.25rem;\n    border-radius: 0.375rem;\n    -webkit-transition: width 0.4s ease;\n    transition: width 0.4s ease;\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n    -webkit-transform-style: preserve-3d;\n    -webkit-backface-visibility: hidden;\n    color: #ffffff; }\n.nb-theme-default :host nb-card .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#b57fff), to(#8a7fff));\n      background-image: linear-gradient(to right, #b57fff, #8a7fff);\n      -webkit-box-shadow: 0 0 0 0 #896ddb, 0 0 0 0 #9f7fff;\n              box-shadow: 0 0 0 0 #896ddb, 0 0 0 0 #9f7fff; }\n.nb-theme-default :host nb-card .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#40dcb2), to(#40dc7e));\n      background-image: linear-gradient(to right, #40dcb2, #40dc7e);\n      -webkit-box-shadow: 0 0 0 0 #37bd83, 0 0 0 0 #40dc98;\n              box-shadow: 0 0 0 0 #37bd83, 0 0 0 0 #40dc98; }\n.nb-theme-default :host nb-card .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#4cc4ff), to(#4ca6ff));\n      background-image: linear-gradient(to right, #4cc4ff, #4ca6ff);\n      -webkit-box-shadow: 0 0 0 0 #419cdb, 0 0 0 0 #4cb5ff;\n              box-shadow: 0 0 0 0 #419cdb, 0 0 0 0 #4cb5ff; }\n.nb-theme-default :host nb-card .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffcc00), to(#ffa100));\n      background-image: linear-gradient(to right, #ffcc00, #ffa100);\n      -webkit-box-shadow: 0 0 0 0 #db9d00, 0 0 0 0 #ffb600;\n              box-shadow: 0 0 0 0 #db9d00, 0 0 0 0 #ffb600; }\n.nb-theme-default :host nb-card .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff4ca6), to(#ff4c6a));\n      background-image: linear-gradient(to right, #ff4ca6, #ff4c6a);\n      -webkit-box-shadow: 0 0 0 0 #db4175, 0 0 0 0 #ff4c88;\n              box-shadow: 0 0 0 0 #db4175, 0 0 0 0 #ff4c88; }\n.nb-theme-default :host nb-card .icon.secondary {\n      background-color: transparent;\n      -webkit-box-shadow: 0 0 0 0 #bbbec6, 0 0 0 0 #dadde6;\n              box-shadow: 0 0 0 0 #bbbec6, 0 0 0 0 #dadde6;\n      color: #a4abb3; }\n.nb-theme-default :host nb-card:hover {\n    background: white; }\n.nb-theme-default :host nb-card:hover .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#bf91ff), to(#9a91ff));\n      background-image: linear-gradient(to right, #bf91ff, #9a91ff); }\n.nb-theme-default :host nb-card:hover .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#5be1bd), to(#5be190));\n      background-image: linear-gradient(to right, #5be1bd, #5be190); }\n.nb-theme-default :host nb-card:hover .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#65ccff), to(#65b2ff));\n      background-image: linear-gradient(to right, #65ccff, #65b2ff); }\n.nb-theme-default :host nb-card:hover .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffd324), to(#ffae24));\n      background-image: linear-gradient(to right, #ffd324, #ffae24); }\n.nb-theme-default :host nb-card:hover .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff65b2), to(#ff657f));\n      background-image: linear-gradient(to right, #ff65b2, #ff657f); }\n.nb-theme-default :host nb-card:hover .icon.secondary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#dfe0ea), to(rgba(255, 255, 255, 0.14)));\n      background-image: linear-gradient(to right, #dfe0ea, rgba(255, 255, 255, 0.14)); }\n.nb-theme-default :host nb-card.off {\n    color: #a4abb3; }\n.nb-theme-default :host nb-card.off .icon {\n      color: #a4abb3; }\n.nb-theme-default :host nb-card.off .icon.primary, .nb-theme-default :host nb-card.off .icon.success, .nb-theme-default :host nb-card.off .icon.info, .nb-theme-default :host nb-card.off .icon.warning, .nb-theme-default :host nb-card.off .icon.danger {\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background-image: -webkit-gradient(linear, left top, right top, from(transparent), to(transparent));\n        background-image: linear-gradient(to right, transparent, transparent); }\n.nb-theme-default :host nb-card.off .icon.secondary {\n        background: transparent; }\n.nb-theme-default :host nb-card.off .title {\n      color: #a4abb3; }\n.nb-theme-default :host nb-card .details {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    height: 100%;\n    border-left: 1px solid transparent; }\n[dir=ltr] .nb-theme-default :host nb-card .details {\n      padding: 0 0.5rem 0 0.75rem; }\n[dir=rtl] .nb-theme-default :host nb-card .details {\n      padding: 0 0.75rem 0 0.5rem; }\n.nb-theme-default :host nb-card label {\n    font-size: 70%;\n    line-height: 0.1rem;\n    word-wrap: break-word; }\n.nb-theme-default :host nb-card .title {\n    font-family: Roboto;\n    font-size: 85%;\n    font-weight: 600;\n    color: #2a2a2a;\n    word-wrap: break-word; }\n.nb-theme-default :host nb-card .status {\n    font-size: 100%;\n    font-weight: 300;\n    text-transform: uppercase;\n    color: #a4abb3; }\n/*\n      :host can be prefixed\n      https://github.com/angular/angular/blob/8d0ee34939f14c07876d222c25b405ed458a34d3/packages/compiler/src/shadow_css.ts#L441\n\n      We have to use :host insted of :host-context($theme), to be able to prefix theme class\n      with something defined inside of @content, by prefixing &.\n      For example this scss code:\n        .nb-theme-default {\n          .some-selector & {\n            ...\n          }\n        }\n      Will result in next css:\n        .some-selector .nb-theme-default {\n          ...\n        }\n\n      It doesn't work with :host-context because angular splitting it in two selectors and removes\n      prefix in one of the selectors.\n    */\n.nb-theme-cosmic :host nb-card {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 80%;\n  width: 100%;\n  overflow: hidden;\n  -webkit-box-shadow: 0 3px 0 0 #342f6e, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n          box-shadow: 0 3px 0 0 #342f6e, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n  border: 1px solid #d5dbe0;\n  border-top-color: #d5dbe0;\n  border-top-style: solid;\n  border-top-width: 1px;\n  border-right-color: #d5dbe0;\n  border-right-style: solid;\n  border-right-width: 1px;\n  border-bottom-color: #d5dbe0;\n  border-bottom-style: solid;\n  border-bottom-width: 1px;\n  border-left-color: #d5dbe0;\n  border-left-style: solid;\n  border-left-width: 1px;\n  border-image-source: initial;\n  border-image-slice: initial;\n  border-image-width: initial;\n  border-image-outset: initial;\n  border-image-repeat: initial; }\n.nb-theme-cosmic :host nb-card .icon-container {\n    height: 100%;\n    padding: 0.625rem; }\n.nb-theme-cosmic :host nb-card .icon {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    width: 2.25rem;\n    height: 2.75rem;\n    font-size: 1.25rem;\n    border-radius: 0.5rem;\n    -webkit-transition: width 0.4s ease;\n    transition: width 0.4s ease;\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n    -webkit-transform-style: preserve-3d;\n    -webkit-backface-visibility: hidden;\n    color: #ffffff; }\n.nb-theme-cosmic :host nb-card .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ad59ff), to(#7659ff));\n      background-image: linear-gradient(to right, #ad59ff, #7659ff);\n      -webkit-box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#00d9bf), to(#00d977));\n      background-image: linear-gradient(to right, #00d9bf, #00d977);\n      -webkit-box-shadow: 0 3px 0 0 #00bb85, 0 2px 8px 0 #00d99b, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #00bb85, 0 2px 8px 0 #00d99b, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#00b3ff), to(#0088ff));\n      background-image: linear-gradient(to right, #00b3ff, #0088ff);\n      -webkit-box-shadow: 0 3px 0 0 #0087db, 0 2px 8px 0 #009dff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #0087db, 0 2px 8px 0 #009dff, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffcc00), to(#ffa100));\n      background-image: linear-gradient(to right, #ffcc00, #ffa100);\n      -webkit-box-shadow: 0 3px 0 0 #db9d00, 0 2px 8px 0 #ffb600, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #db9d00, 0 2px 8px 0 #ffb600, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff38ac), to(#ff386a));\n      background-image: linear-gradient(to right, #ff38ac, #ff386a);\n      -webkit-box-shadow: 0 3px 0 0 #db3078, 0 2px 8px 0 #ff388b, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #db3078, 0 2px 8px 0 #ff388b, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.secondary {\n      background-color: transparent;\n      -webkit-box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n      color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card:hover {\n    background: #463f92; }\n.nb-theme-cosmic :host nb-card:hover .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#b970ff), to(#8970ff));\n      background-image: linear-gradient(to right, #b970ff, #8970ff); }\n.nb-theme-cosmic :host nb-card:hover .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#24dec8), to(#24de8a));\n      background-image: linear-gradient(to right, #24dec8, #24de8a); }\n.nb-theme-cosmic :host nb-card:hover .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#24bdff), to(#2499ff));\n      background-image: linear-gradient(to right, #24bdff, #2499ff); }\n.nb-theme-cosmic :host nb-card:hover .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffd324), to(#ffae24));\n      background-image: linear-gradient(to right, #ffd324, #ffae24); }\n.nb-theme-cosmic :host nb-card:hover .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff54b8), to(#ff547f));\n      background-image: linear-gradient(to right, #ff54b8, #ff547f); }\n.nb-theme-cosmic :host nb-card:hover .icon.secondary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#b970ff), to(rgba(255, 255, 255, 0.14)));\n      background-image: linear-gradient(to right, #b970ff, rgba(255, 255, 255, 0.14)); }\n.nb-theme-cosmic :host nb-card.off {\n    color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card.off .icon {\n      color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card.off .icon.primary, .nb-theme-cosmic :host nb-card.off .icon.success, .nb-theme-cosmic :host nb-card.off .icon.info, .nb-theme-cosmic :host nb-card.off .icon.warning, .nb-theme-cosmic :host nb-card.off .icon.danger {\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background-image: -webkit-gradient(linear, left top, right top, from(transparent), to(transparent));\n        background-image: linear-gradient(to right, transparent, transparent); }\n.nb-theme-cosmic :host nb-card.off .icon.secondary {\n        background: transparent; }\n.nb-theme-cosmic :host nb-card.off .title {\n      color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card .details {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    height: 100%;\n    border-left: 1px solid transparent; }\n[dir=ltr] .nb-theme-cosmic :host nb-card .details {\n      padding: 0 0.5rem 0 0.75rem; }\n[dir=rtl] .nb-theme-cosmic :host nb-card .details {\n      padding: 0 0.75rem 0 0.5rem; }\n.nb-theme-cosmic :host nb-card label {\n    font-size: 70%;\n    line-height: 0.1rem;\n    word-wrap: break-word; }\n.nb-theme-cosmic :host nb-card .title {\n    font-family: Exo;\n    font-size: 85%;\n    font-weight: 600;\n    color: #ffffff;\n    word-wrap: break-word; }\n.nb-theme-cosmic :host nb-card .status {\n    font-size: 100%;\n    font-weight: 300;\n    text-transform: uppercase;\n    color: #a1a1e5; }\n/*\n      :host can be prefixed\n      https://github.com/angular/angular/blob/8d0ee34939f14c07876d222c25b405ed458a34d3/packages/compiler/src/shadow_css.ts#L441\n\n      We have to use :host insted of :host-context($theme), to be able to prefix theme class\n      with something defined inside of @content, by prefixing &.\n      For example this scss code:\n        .nb-theme-default {\n          .some-selector & {\n            ...\n          }\n        }\n      Will result in next css:\n        .some-selector .nb-theme-default {\n          ...\n        }\n\n      It doesn't work with :host-context because angular splitting it in two selectors and removes\n      prefix in one of the selectors.\n    */\n.nb-theme-corporate :host nb-card {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 80%;\n  width: 100%;\n  overflow: hidden;\n  -webkit-box-shadow: 0 0 0 0 #dbdbdb, none;\n          box-shadow: 0 0 0 0 #dbdbdb, none;\n  border: 1px solid #d5dbe0;\n  border-top-color: #d5dbe0;\n  border-top-style: solid;\n  border-top-width: 1px;\n  border-right-color: #d5dbe0;\n  border-right-style: solid;\n  border-right-width: 1px;\n  border-bottom-color: #d5dbe0;\n  border-bottom-style: solid;\n  border-bottom-width: 1px;\n  border-left-color: #d5dbe0;\n  border-left-style: solid;\n  border-left-width: 1px;\n  border-image-source: initial;\n  border-image-slice: initial;\n  border-image-width: initial;\n  border-image-outset: initial;\n  border-image-repeat: initial; }\n.nb-theme-corporate :host nb-card .icon-container {\n    height: 100%;\n    padding: 0.625rem; }\n.nb-theme-corporate :host nb-card .icon {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    width: 2.25rem;\n    height: 2.75rem;\n    font-size: 1.25rem;\n    border-radius: 0.17rem;\n    -webkit-transition: width 0.4s ease;\n    transition: width 0.4s ease;\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n    -webkit-transform-style: preserve-3d;\n    -webkit-backface-visibility: hidden;\n    color: #ffffff; }\n.nb-theme-corporate :host nb-card .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#73a1ff), to(#73a1ff));\n      background-image: linear-gradient(to right, #73a1ff, #73a1ff);\n      -webkit-box-shadow: 0 0 0 0 #638adb, 0 0 20px 0 #73a1ff;\n              box-shadow: 0 0 0 0 #638adb, 0 0 20px 0 #73a1ff; }\n.nb-theme-corporate :host nb-card .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#5dcfe3), to(#5dcfe3));\n      background-image: linear-gradient(to right, #5dcfe3, #5dcfe3);\n      -webkit-box-shadow: 0 0 0 0 #50b2c3, 0 0 20px 0 #5dcfe3;\n              box-shadow: 0 0 0 0 #50b2c3, 0 0 20px 0 #5dcfe3; }\n.nb-theme-corporate :host nb-card .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ba7fec), to(#ba7fec));\n      background-image: linear-gradient(to right, #ba7fec, #ba7fec);\n      -webkit-box-shadow: 0 0 0 0 #a06dcb, 0 0 20px 0 #ba7fec;\n              box-shadow: 0 0 0 0 #a06dcb, 0 0 20px 0 #ba7fec; }\n.nb-theme-corporate :host nb-card .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffa36b), to(#ffa36b));\n      background-image: linear-gradient(to right, #ffa36b, #ffa36b);\n      -webkit-box-shadow: 0 0 0 0 #db8c5c, 0 0 20px 0 #ffa36b;\n              box-shadow: 0 0 0 0 #db8c5c, 0 0 20px 0 #ffa36b; }\n.nb-theme-corporate :host nb-card .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff6b83), to(#ff6b83));\n      background-image: linear-gradient(to right, #ff6b83, #ff6b83);\n      -webkit-box-shadow: 0 0 0 0 #db5c71, 0 0 20px 0 #ff6b83;\n              box-shadow: 0 0 0 0 #db5c71, 0 0 20px 0 #ff6b83; }\n.nb-theme-corporate :host nb-card .icon.secondary {\n      background-color: #edf2f5;\n      -webkit-box-shadow: 0 0 0 0 #ccd0d3, 0 0 0 0 #edf2f5;\n              box-shadow: 0 0 0 0 #ccd0d3, 0 0 0 0 #edf2f5;\n      color: #a4abb3; }\n.nb-theme-corporate :host nb-card .icon.primary, .nb-theme-corporate :host nb-card .icon.success, .nb-theme-corporate :host nb-card .icon.info, .nb-theme-corporate :host nb-card .icon.warning, .nb-theme-corporate :host nb-card .icon.danger, .nb-theme-corporate :host nb-card .icon.secondary {\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n.nb-theme-corporate :host nb-card:hover {\n    background: white; }\n.nb-theme-corporate :host nb-card:hover .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#87aeff), to(#87aeff));\n      background-image: linear-gradient(to right, #87aeff, #87aeff); }\n.nb-theme-corporate :host nb-card:hover .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#74d6e7), to(#74d6e7));\n      background-image: linear-gradient(to right, #74d6e7, #74d6e7); }\n.nb-theme-corporate :host nb-card:hover .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#c491ef), to(#c491ef));\n      background-image: linear-gradient(to right, #c491ef, #c491ef); }\n.nb-theme-corporate :host nb-card:hover .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffb080), to(#ffb080));\n      background-image: linear-gradient(to right, #ffb080, #ffb080); }\n.nb-theme-corporate :host nb-card:hover .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff8094), to(#ff8094));\n      background-image: linear-gradient(to right, #ff8094, #ff8094); }\n.nb-theme-corporate :host nb-card:hover .icon.secondary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#f0f4f6), to(#f0f4f6));\n      background-image: linear-gradient(to right, #f0f4f6, #f0f4f6); }\n.nb-theme-corporate :host nb-card.off {\n    color: #a4abb3; }\n.nb-theme-corporate :host nb-card.off .icon {\n      color: #a4abb3; }\n.nb-theme-corporate :host nb-card.off .icon.primary, .nb-theme-corporate :host nb-card.off .icon.success, .nb-theme-corporate :host nb-card.off .icon.info, .nb-theme-corporate :host nb-card.off .icon.warning, .nb-theme-corporate :host nb-card.off .icon.danger {\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background-image: -webkit-gradient(linear, left top, right top, from(transparent), to(transparent));\n        background-image: linear-gradient(to right, transparent, transparent); }\n.nb-theme-corporate :host nb-card.off .icon.secondary {\n        background: transparent; }\n.nb-theme-corporate :host nb-card.off .title {\n      color: #a4abb3; }\n.nb-theme-corporate :host nb-card .details {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    height: 100%;\n    border-left: 1px solid transparent; }\n[dir=ltr] .nb-theme-corporate :host nb-card .details {\n      padding: 0 0.5rem 0 0.75rem; }\n[dir=rtl] .nb-theme-corporate :host nb-card .details {\n      padding: 0 0.75rem 0 0.5rem; }\n.nb-theme-corporate :host nb-card label {\n    font-size: 70%;\n    line-height: 0.1rem;\n    word-wrap: break-word; }\n.nb-theme-corporate :host nb-card .title {\n    font-family: Roboto;\n    font-size: 85%;\n    font-weight: 600;\n    color: #181818;\n    word-wrap: break-word; }\n.nb-theme-corporate :host nb-card .status {\n    font-size: 100%;\n    font-weight: 300;\n    text-transform: uppercase;\n    color: #a4abb3; }\n.nb-theme-corporate :host nb-card .icon-container {\n  height: auto; }\n/*  @include nb-for-theme(cosmic) {\r\n    nb-card {\r\n      &.off .icon-container {\r\n        @include nb-ltr(border-right, 1px solid nb-theme(separator));\r\n        @include nb-rtl(border-left, 1px solid nb-theme(separator));\r\n      }\r\n\r\n      .icon-container {\r\n        padding: 0;\r\n      }\r\n\r\n      .details {\r\n        @include nb-ltr(padding-left, 1.25rem);\r\n        @include nb-rtl(padding-right, 1.25rem);\r\n      }\r\n\r\n      .icon {\r\n        width: 7rem;\r\n        height: 100%;\r\n        font-size: 4.5rem;\r\n        @include nb-ltr(border-radius, nb-theme(card-border-radius) 0 0 nb-theme(card-border-radius));\r\n        @include nb-rtl(border-radius, 0 nb-theme(card-border-radius) nb-theme(card-border-radius) 0);\r\n      }\r\n\r\n      .title {\r\n        font-weight: nb-theme(font-weight-bolder);\r\n      }\r\n\r\n      .status {\r\n        font-weight: nb-theme(font-weight-light);\r\n      }\r\n    }\r\n  }*/\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcX3RoZW1pbmcuc2NzcyIsInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9zdGF0dXMtY2FyZC9zdGF0dXMtY2FyZC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcY29yZVxcX21peGlucy5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb2JpbGVwZXJmL3N0YXR1cy1jYXJkL0M6XFxQZXJmQXNzdXJlXFxHaXRMYWJcXFBlcmZBc3N1cmVfQW5ndWxhci9ub2RlX21vZHVsZXNcXEBuZWJ1bGFyXFx0aGVtZVxcc3R5bGVzXFxjb3JlXFxfZnVuY3Rpb25zLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL21vYmlsZXBlcmYvc3RhdHVzLWNhcmQvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL25vZGVfbW9kdWxlc1xcQG5lYnVsYXJcXHRoZW1lXFxzdHlsZXNcXHRoZW1lc1xcX2RlZmF1bHQuc2NzcyIsInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcdGhlbWVzXFxfY29zbWljLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL21vYmlsZXBlcmYvc3RhdHVzLWNhcmQvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL25vZGVfbW9kdWxlc1xcQG5lYnVsYXJcXHRoZW1lXFxzdHlsZXNcXHRoZW1lc1xcX2NvcnBvcmF0ZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb2JpbGVwZXJmL3N0YXR1cy1jYXJkL0M6XFxQZXJmQXNzdXJlXFxHaXRMYWJcXFBlcmZBc3N1cmVfQW5ndWxhci9ub2RlX21vZHVsZXNcXEBuZWJ1bGFyXFx0aGVtZVxcc3R5bGVzXFxnbG9iYWxcXGJvb3RzdHJhcFxcX2hlcm8tYnV0dG9ucy5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb2JpbGVwZXJmL3N0YXR1cy1jYXJkL0M6XFxQZXJmQXNzdXJlXFxHaXRMYWJcXFBlcmZBc3N1cmVfQW5ndWxhci9zcmNcXGFwcFxccGFnZXNcXG1vYmlsZXBlcmZcXHN0YXR1cy1jYXJkXFxzdGF0dXMtY2FyZC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXEB0aGVtZVxcc3R5bGVzXFx0aGVtZXMuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7OztFQ0lFO0FER0Y7O0VDQUU7QUNQRjs7OztFRFlFO0FDOEpGOzs7O0VEekpFO0FDbUxGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NEL0RDO0FFcklEOzs7O0VGMElFO0FHMUlGOzs7O0VIK0lFO0FFL0lGOzs7O0VGb0pFO0FDcEpGOzs7O0VEeUpFO0FDaUJGOzs7O0VEWkU7QUNzQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0Q4RUM7QUlsUkQ7Ozs7RUp1UkU7QUV2UkY7Ozs7RUY0UkU7QUM1UkY7Ozs7RURpU0U7QUN2SEY7Ozs7RUQ0SEU7QUNsR0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0RzTkM7QUcxWkQ7Ozs7RUgrWkU7QUUvWkY7Ozs7RUZvYUU7QUNwYUY7Ozs7RUR5YUU7QUMvUEY7Ozs7RURvUUU7QUMxT0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0Q4VkM7QUtsaUJEOzs7O0VMdWlCRTtBRXZpQkY7Ozs7RUY0aUJFO0FDNWlCRjs7OztFRGlqQkU7QUN2WUY7Ozs7RUQ0WUU7QUNsWEY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0RzZUM7QUcxcUJEOzs7O0VIK3FCRTtBRS9xQkY7Ozs7RUZvckJFO0FDcHJCRjs7OztFRHlyQkU7QUMvZ0JGOzs7O0VEb2hCRTtBQzFmRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDRDhtQkM7QU1sekJEOzs7O0VOdXpCRTtBRHJzQkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0N5dEJDO0FPdjBCSDtFQUNFLDhCQUFtQjtFQUFuQiw2QkFBbUI7TUFBbkIsdUJBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQix5QkFBbUI7TUFBbkIsc0JBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQixXQUFXO0VBQ1gsV0FBVztFQUNYLGdCQUFnQjtFQUloQix5Q0oyVW1CO1VJM1VuQixpQ0oyVW1CO0VJelVuQix5QkFBeUI7RUFDekIseUJBQW9DO0VBQ3BDLHVCQUF1QjtFQUN2QixxQkFBcUI7RUFDckIsMkJBQXNDO0VBQ3RDLHlCQUF5QjtFQUN6Qix1QkFBdUI7RUFDdkIsNEJBQXVDO0VBQ3ZDLDBCQUEwQjtFQUMxQix3QkFBd0I7RUFDeEIsMEJBQXFDO0VBQ3JDLHdCQUF3QjtFQUN4QixzQkFBc0I7RUFDdEIsNEJBQTRCO0VBQzVCLDJCQUEyQjtFQUMzQiwyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLDRCQUE0QixFQUFBO0FBRTVCO0lBQ0UsWUFBWTtJQUNaLGlCQUFpQixFQUFBO0FBR25CO0lBQ0Usb0JBQWE7SUFBYixvQkFBYTtJQUFiLGFBQWE7SUFDYix5QkFBbUI7UUFBbkIsc0JBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQix3QkFBdUI7UUFBdkIscUJBQXVCO1lBQXZCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2QsZUFBZTtJQUNmLGtCQUFrQjtJQUNsQix1QkpqQlk7SUlrQlosbUNBQTJCO0lBQTNCLDJCQUEyQjtJQUMzQix1Q0FBK0I7WUFBL0IsK0JBQStCO0lBQy9CLG9DQUFvQztJQUNwQyxtQ0FBbUM7SUFDbkMsY0pOZ0IsRUFBQTtBSVFoQjtNTlJKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLG9EQTVQb0U7Y0E0UHBFLDRDQTVQb0UsRUFBQTtBQ25HaEU7TU5aSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSxvREF4UG9FO2NBd1BwRSw0Q0F4UG9FLEVBQUE7QUNuR2hFO01OaEJKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLG9EQWhQOEQ7Y0FnUDlELDRDQWhQOEQsRUFBQTtBQ3ZHMUQ7TU5wQkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsb0RBcFBvRTtjQW9QcEUsNENBcFBvRSxFQUFBO0FDL0ZoRTtNTnhCSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSxvREE1T2tFO2NBNE9sRSw0Q0E1T2tFLEVBQUE7QUNuRzlEO01EaVJKLDZCSGpDNkI7TUcrRjdCLG9EQXhPNEU7Y0F3TzVFLDRDQXhPNEU7TUNwR3RFLGNKeENXLEVBQUE7QUl1RGY7SUFDRSxpQkFBMEMsRUFBQTtBQUd4QztNQUNFLDJGRHlGb0Q7TUN6RnBELDZERHlGb0QsRUFBQTtBQ3ZGdEQ7TUFDRSwyRkRzRm9EO01DdEZwRCw2RERzRm9ELEVBQUE7QUNwRnREO01BQ0UsMkZEbUZvRDtNQ25GcEQsNkREbUZvRCxFQUFBO0FDakZ0RDtNQUNFLDJGRGdGb0Q7TUNoRnBELDZERGdGb0QsRUFBQTtBQzlFdEQ7TUFDRSwyRkQ2RW9EO01DN0VwRCw2REQ2RW9ELEVBQUE7QUMzRXREO01BQ0UsNkdEMEVvRDtNQzFFcEQsK0VEMEVvRCxFQUFBO0FDckUxRDtJQUNFLGNKakZhLEVBQUE7QUltRmI7TUFDRSxjSnBGVyxFQUFBO0FJc0ZYO1FBQ0Usd0JBQWdCO2dCQUFoQixnQkFBZ0I7UUFDaEIsbUdBQXFFO1FBQXJFLHFFQUFxRSxFQUFBO0FBR3ZFO1FBQ0UsdUJBQXVCLEVBQUE7QUFJM0I7TUFDRSxjSmpHVyxFQUFBO0FJcUdmO0lBQ0Usb0JBQWE7SUFBYixvQkFBYTtJQUFiLGFBQWE7SUFDYiw0QkFBc0I7SUFBdEIsNkJBQXNCO1FBQXRCLDBCQUFzQjtZQUF0QixzQkFBc0I7SUFDdEIsd0JBQXVCO1FBQXZCLHFCQUF1QjtZQUF2Qix1QkFBdUI7SUFDdkIsWUFBWTtJQUdaLGtDQUFrQyxFQUFBO0FQdXhCcEM7TUMzbUJFLDJCTTlLMkMsRUFBQTtBUDJ4QjdDO01DN21CRSwyQk03SzJDLEVBQUE7QUFHNUM7SUFDRSxjQUFjO0lBQ2QsbUJBQWtCO0lBQ2xCLHFCQUFxQixFQUFBO0FBRXhCO0lBQ0UsbUJDeklrQjtJRDBJbEIsY0FBYztJQUNkLGdCSnpJaUI7SUkwSWpCLGNKdEhxQjtJSXVIckIscUJBQXFCLEVBQUE7QUFHdkI7SUFDRSxlQUFlO0lBQ2YsZ0JKbkprQjtJSW9KbEIseUJBQXlCO0lBQ3pCLGNKL0hhLEVBQUE7QUo4RWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0M0MUJDO0FPMThCSDtFQUNFLDhCQUFtQjtFQUFuQiw2QkFBbUI7TUFBbkIsdUJBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQix5QkFBbUI7TUFBbkIsc0JBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQixXQUFXO0VBQ1gsV0FBVztFQUNYLGdCQUFnQjtFQUloQix3RUg0RWdEO1VHNUVoRCxnRUg0RWdEO0VHMUVoRCx5QkFBeUI7RUFDekIseUJBQW9DO0VBQ3BDLHVCQUF1QjtFQUN2QixxQkFBcUI7RUFDckIsMkJBQXNDO0VBQ3RDLHlCQUF5QjtFQUN6Qix1QkFBdUI7RUFDdkIsNEJBQXVDO0VBQ3ZDLDBCQUEwQjtFQUMxQix3QkFBd0I7RUFDeEIsMEJBQXFDO0VBQ3JDLHdCQUF3QjtFQUN4QixzQkFBc0I7RUFDdEIsNEJBQTRCO0VBQzVCLDJCQUEyQjtFQUMzQiwyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLDRCQUE0QixFQUFBO0FBRTVCO0lBQ0UsWUFBWTtJQUNaLGlCQUFpQixFQUFBO0FBR25CO0lBQ0Usb0JBQWE7SUFBYixvQkFBYTtJQUFiLGFBQWE7SUFDYix5QkFBbUI7UUFBbkIsc0JBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQix3QkFBdUI7UUFBdkIscUJBQXVCO1lBQXZCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2QsZUFBZTtJQUNmLGtCQUFrQjtJQUNsQixxQkhsQ1U7SUdtQ1YsbUNBQTJCO0lBQTNCLDJCQUEyQjtJQUMzQix1Q0FBK0I7WUFBL0IsK0JBQStCO0lBQy9CLG9DQUFvQztJQUNwQyxtQ0FBbUM7SUFDbkMsY0g1QmdCLEVBQUE7QUc4QmhCO01OUkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsNkZGL1RrRDtjRStUbEQscUZGL1RrRCxFQUFBO0FHaEM5QztNTlpKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLDZGRi9Ua0Q7Y0UrVGxELHFGRi9Ua0QsRUFBQTtBRzVCOUM7TU5oQkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsNkZGL1RrRDtjRStUbEQscUZGL1RrRCxFQUFBO0FHeEI5QztNTnBCSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSw2RkYvVGtEO2NFK1RsRCxxRkYvVGtELEVBQUE7QUdwQjlDO01OeEJKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLDZGRi9Ua0Q7Y0UrVGxELHFGRi9Ua0QsRUFBQTtBR2hCOUM7TURpUkosNkJIakM2QjtNRytGN0IsNkZGL1RrRDtjRStUbEQscUZGL1RrRDtNR2I1QyxjSDVEVyxFQUFBO0FHMkVmO0lBQ0UsbUJBQTBDLEVBQUE7QUFHeEM7TUFDRSwyRkR5Rm9EO01DekZwRCw2RER5Rm9ELEVBQUE7QUN2RnREO01BQ0UsMkZEc0ZvRDtNQ3RGcEQsNkREc0ZvRCxFQUFBO0FDcEZ0RDtNQUNFLDJGRG1Gb0Q7TUNuRnBELDZERG1Gb0QsRUFBQTtBQ2pGdEQ7TUFDRSwyRkRnRm9EO01DaEZwRCw2RERnRm9ELEVBQUE7QUM5RXREO01BQ0UsMkZENkVvRDtNQzdFcEQsNkRENkVvRCxFQUFBO0FDM0V0RDtNQUNFLDZHRDBFb0Q7TUMxRXBELCtFRDBFb0QsRUFBQTtBQ3JFMUQ7SUFDRSxjSHJHYSxFQUFBO0FHdUdiO01BQ0UsY0h4R1csRUFBQTtBRzBHWDtRQUNFLHdCQUFnQjtnQkFBaEIsZ0JBQWdCO1FBQ2hCLG1HQUFxRTtRQUFyRSxxRUFBcUUsRUFBQTtBQUd2RTtRQUNFLHVCQUF1QixFQUFBO0FBSTNCO01BQ0UsY0hySFcsRUFBQTtBR3lIZjtJQUNFLG9CQUFhO0lBQWIsb0JBQWE7SUFBYixhQUFhO0lBQ2IsNEJBQXNCO0lBQXRCLDZCQUFzQjtRQUF0QiwwQkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLHdCQUF1QjtRQUF2QixxQkFBdUI7WUFBdkIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFHWixrQ0FBa0MsRUFBQTtBUDA1QnBDO01DOXVCRSwyQk05SzJDLEVBQUE7QVA4NUI3QztNQ2h2QkUsMkJNN0syQyxFQUFBO0FBRzVDO0lBQ0UsY0FBYztJQUNkLG1CQUFrQjtJQUNsQixxQkFBcUIsRUFBQTtBQUV4QjtJQUNFLGdCQzNIZTtJRDRIZixjQUFjO0lBQ2QsZ0JKeklpQjtJSTBJakIsY0gxSXFCO0lHMklyQixxQkFBcUIsRUFBQTtBQUd2QjtJQUNFLGVBQWU7SUFDZixnQkpuSmtCO0lJb0psQix5QkFBeUI7SUFDekIsY0huSmEsRUFBQTtBTGtHZjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQys5QkM7QU83a0NIO0VBQ0UsOEJBQW1CO0VBQW5CLDZCQUFtQjtNQUFuQix1QkFBbUI7VUFBbkIsbUJBQW1CO0VBQ25CLHlCQUFtQjtNQUFuQixzQkFBbUI7VUFBbkIsbUJBQW1CO0VBQ25CLFdBQVc7RUFDWCxXQUFXO0VBQ1gsZ0JBQWdCO0VBSWhCLHlDSjJVbUI7VUkzVW5CLGlDSjJVbUI7RUl6VW5CLHlCQUF5QjtFQUN6Qix5QkFBb0M7RUFDcEMsdUJBQXVCO0VBQ3ZCLHFCQUFxQjtFQUNyQiwyQkFBc0M7RUFDdEMseUJBQXlCO0VBQ3pCLHVCQUF1QjtFQUN2Qiw0QkFBdUM7RUFDdkMsMEJBQTBCO0VBQzFCLHdCQUF3QjtFQUN4QiwwQkFBcUM7RUFDckMsd0JBQXdCO0VBQ3hCLHNCQUFzQjtFQUN0Qiw0QkFBNEI7RUFDNUIsMkJBQTJCO0VBQzNCLDJCQUEyQjtFQUMzQiw0QkFBNEI7RUFDNUIsNEJBQTRCLEVBQUE7QUFFNUI7SUFDRSxZQUFZO0lBQ1osaUJBQWlCLEVBQUE7QUFHbkI7SUFDRSxvQkFBYTtJQUFiLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHlCQUFtQjtRQUFuQixzQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLHdCQUF1QjtRQUF2QixxQkFBdUI7WUFBdkIsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLHNCRnZCVztJRXdCWCxtQ0FBMkI7SUFBM0IsMkJBQTJCO0lBQzNCLHVDQUErQjtZQUEvQiwrQkFBK0I7SUFDL0Isb0NBQW9DO0lBQ3BDLG1DQUFtQztJQUNuQyxjSk5nQixFQUFBO0FJUWhCO01OUkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsdURBNVBvRTtjQTRQcEUsK0NBNVBvRSxFQUFBO0FDbkdoRTtNTlpKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLHVEQXhQb0U7Y0F3UHBFLCtDQXhQb0UsRUFBQTtBQ25HaEU7TU5oQkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsdURBaFA4RDtjQWdQOUQsK0NBaFA4RCxFQUFBO0FDdkcxRDtNTnBCSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSx1REFwUG9FO2NBb1BwRSwrQ0FwUG9FLEVBQUE7QUMvRmhFO01OeEJKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLHVEQTVPa0U7Y0E0T2xFLCtDQTVPa0UsRUFBQTtBQ25HOUQ7TURpUkoseUJEelR5QjtNQ3VYekIsb0RBeE80RTtjQXdPNUUsNENBeE80RTtNQ3BHdEUsY0p4Q1csRUFBQTtBSTRDWDtNQU1FLHdCQUFnQjtjQUFoQixnQkFBZ0IsRUFBQTtBQUt0QjtJQUNFLGlCQUEwQyxFQUFBO0FBR3hDO01BQ0UsMkZEeUZvRDtNQ3pGcEQsNkREeUZvRCxFQUFBO0FDdkZ0RDtNQUNFLDJGRHNGb0Q7TUN0RnBELDZERHNGb0QsRUFBQTtBQ3BGdEQ7TUFDRSwyRkRtRm9EO01DbkZwRCw2RERtRm9ELEVBQUE7QUNqRnREO01BQ0UsMkZEZ0ZvRDtNQ2hGcEQsNkREZ0ZvRCxFQUFBO0FDOUV0RDtNQUNFLDJGRDZFb0Q7TUM3RXBELDZERDZFb0QsRUFBQTtBQzNFdEQ7TUFDRSwyRkQwRW9EO01DMUVwRCw2REQwRW9ELEVBQUE7QUNyRTFEO0lBQ0UsY0pqRmEsRUFBQTtBSW1GYjtNQUNFLGNKcEZXLEVBQUE7QUlzRlg7UUFDRSx3QkFBZ0I7Z0JBQWhCLGdCQUFnQjtRQUNoQixtR0FBcUU7UUFBckUscUVBQXFFLEVBQUE7QUFHdkU7UUFDRSx1QkFBdUIsRUFBQTtBQUkzQjtNQUNFLGNKakdXLEVBQUE7QUlxR2Y7SUFDRSxvQkFBYTtJQUFiLG9CQUFhO0lBQWIsYUFBYTtJQUNiLDRCQUFzQjtJQUF0Qiw2QkFBc0I7UUFBdEIsMEJBQXNCO1lBQXRCLHNCQUFzQjtJQUN0Qix3QkFBdUI7UUFBdkIscUJBQXVCO1lBQXZCLHVCQUF1QjtJQUN2QixZQUFZO0lBR1osa0NBQWtDLEVBQUE7QVAraENwQztNQ24zQkUsMkJNOUsyQyxFQUFBO0FQbWlDN0M7TUNyM0JFLDJCTTdLMkMsRUFBQTtBQUc1QztJQUNFLGNBQWM7SUFDZCxtQkFBa0I7SUFDbEIscUJBQXFCLEVBQUE7QUFFeEI7SUFDRSxtQkM3R2tCO0lEOEdsQixjQUFjO0lBQ2QsZ0JKeklpQjtJSTBJakIsY0YxSXFCO0lFMklyQixxQkFBcUIsRUFBQTtBQUd2QjtJQUNFLGVBQWU7SUFDZixnQkpuSmtCO0lJb0psQix5QkFBeUI7SUFDekIsY0ovSGEsRUFBQTtBSXVJYjtFQUNFLFlBQVksRUFBQTtBQVFwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SVBrakNJIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi9zdGF0dXMtY2FyZC9zdGF0dXMtY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuXG4vKipcbiAqIFRoaXMgaXMgYSBzdGFydGluZyBwb2ludCB3aGVyZSB3ZSBkZWNsYXJlIHRoZSBtYXBzIG9mIHRoZW1lcyBhbmQgZ2xvYmFsbHkgYXZhaWxhYmxlIGZ1bmN0aW9ucy9taXhpbnNcbiAqL1xuXG5AaW1wb3J0ICdjb3JlL21peGlucyc7XG5AaW1wb3J0ICdjb3JlL2Z1bmN0aW9ucyc7XG5cbiRuYi1lbmFibGVkLXRoZW1lczogKCkgIWdsb2JhbDtcbiRuYi1lbmFibGUtY3NzLXZhcmlhYmxlczogZmFsc2UgIWdsb2JhbDtcblxuJG5iLXRoZW1lczogKCkgIWdsb2JhbDtcbiRuYi10aGVtZXMtbm9uLXByb2Nlc3NlZDogKCkgIWdsb2JhbDtcbiRuYi10aGVtZXMtZXhwb3J0OiAoKSAhZ2xvYmFsO1xuXG5AZnVuY3Rpb24gbmItdGhlbWUoJGtleSkge1xuICBAcmV0dXJuIG1hcC1nZXQoJHRoZW1lLCAka2V5KTtcbn1cblxuQGZ1bmN0aW9uIG5iLWdldC12YWx1ZSgkdGhlbWUsICRrZXksICR2YWx1ZSkge1xuICBAaWYgKHR5cGUtb2YoJHZhbHVlKSA9PSAnc3RyaW5nJykge1xuICAgICR0bXA6IG1hcC1nZXQoJHRoZW1lLCAkdmFsdWUpO1xuXG4gICAgQGlmICgkdG1wICE9IG51bGwpIHtcbiAgICAgIEByZXR1cm4gbmItZ2V0LXZhbHVlKCR0aGVtZSwgJHZhbHVlLCAkdG1wKTtcbiAgICB9XG4gIH1cblxuICBAcmV0dXJuIG1hcC1nZXQoJHRoZW1lLCAka2V5KTtcbn1cblxuQGZ1bmN0aW9uIGNvbnZlcnQtdG8tY3NzLXZhcmlhYmxlcygkdmFyaWFibGVzKSB7XG4gICRyZXN1bHQ6ICgpO1xuICBAZWFjaCAkdmFyLCAkdmFsdWUgaW4gJHZhcmlhYmxlcyB7XG4gICAgJHJlc3VsdDogbWFwLXNldCgkcmVzdWx0LCAkdmFyLCAnLS12YXIoI3skdmFyfSknKTtcbiAgfVxuXG4gIEBkZWJ1ZyAkcmVzdWx0O1xuICBAcmV0dXJuICRyZXN1bHQ7XG59XG5cbkBmdW5jdGlvbiBzZXQtZ2xvYmFsLXRoZW1lLXZhcnMoJHRoZW1lLCAkdGhlbWUtbmFtZSkge1xuICAkdGhlbWU6ICR0aGVtZSAhZ2xvYmFsO1xuICAkdGhlbWUtbmFtZTogJHRoZW1lLW5hbWUgIWdsb2JhbDtcbiAgQGlmICgkbmItZW5hYmxlLWNzcy12YXJpYWJsZXMpIHtcbiAgICAkdGhlbWU6IGNvbnZlcnQtdG8tY3NzLXZhcmlhYmxlcygkdGhlbWUpICFnbG9iYWw7XG4gIH1cbiAgQHJldHVybiAkdGhlbWU7XG59XG5cbkBmdW5jdGlvbiBuYi1yZWdpc3Rlci10aGVtZSgkdGhlbWUsICRuYW1lLCAkZGVmYXVsdDogbnVsbCkge1xuXG4gICR0aGVtZS1kYXRhOiAoKTtcblxuXG4gIEBpZiAoJGRlZmF1bHQgIT0gbnVsbCkge1xuXG4gICAgJHRoZW1lOiBtYXAtbWVyZ2UobWFwLWdldCgkbmItdGhlbWVzLW5vbi1wcm9jZXNzZWQsICRkZWZhdWx0KSwgJHRoZW1lKTtcbiAgICAkbmItdGhlbWVzLW5vbi1wcm9jZXNzZWQ6IG1hcC1zZXQoJG5iLXRoZW1lcy1ub24tcHJvY2Vzc2VkLCAkbmFtZSwgJHRoZW1lKSAhZ2xvYmFsO1xuXG4gICAgJHRoZW1lLWRhdGE6IG1hcC1zZXQoJHRoZW1lLWRhdGEsIGRhdGEsICR0aGVtZSk7XG4gICAgJG5iLXRoZW1lcy1leHBvcnQ6IG1hcC1zZXQoJG5iLXRoZW1lcy1leHBvcnQsICRuYW1lLCBtYXAtc2V0KCR0aGVtZS1kYXRhLCBwYXJlbnQsICRkZWZhdWx0KSkgIWdsb2JhbDtcblxuICB9IEBlbHNlIHtcbiAgICAkbmItdGhlbWVzLW5vbi1wcm9jZXNzZWQ6IG1hcC1zZXQoJG5iLXRoZW1lcy1ub24tcHJvY2Vzc2VkLCAkbmFtZSwgJHRoZW1lKSAhZ2xvYmFsO1xuXG4gICAgJHRoZW1lLWRhdGE6IG1hcC1zZXQoJHRoZW1lLWRhdGEsIGRhdGEsICR0aGVtZSk7XG4gICAgJG5iLXRoZW1lcy1leHBvcnQ6IG1hcC1zZXQoJG5iLXRoZW1lcy1leHBvcnQsICRuYW1lLCBtYXAtc2V0KCR0aGVtZS1kYXRhLCBwYXJlbnQsIG51bGwpKSAhZ2xvYmFsO1xuICB9XG5cbiAgJHRoZW1lLXBhcnNlZDogKCk7XG4gIEBlYWNoICRrZXksICR2YWx1ZSBpbiAkdGhlbWUge1xuICAgICR0aGVtZS1wYXJzZWQ6IG1hcC1zZXQoJHRoZW1lLXBhcnNlZCwgJGtleSwgbmItZ2V0LXZhbHVlKCR0aGVtZSwgJGtleSwgJHZhbHVlKSk7XG4gIH1cblxuICAvLyBlbmFibGUgcmlnaHQgYXdheSB3aGVuIGluc3RhbGxlZFxuICAkdGhlbWUtcGFyc2VkOiBzZXQtZ2xvYmFsLXRoZW1lLXZhcnMoJHRoZW1lLXBhcnNlZCwgJG5hbWUpO1xuICBAcmV0dXJuIG1hcC1zZXQoJG5iLXRoZW1lcywgJG5hbWUsICR0aGVtZS1wYXJzZWQpO1xufVxuXG5AZnVuY3Rpb24gZ2V0LWVuYWJsZWQtdGhlbWVzKCkge1xuICAkdGhlbWVzLXRvLWluc3RhbGw6ICgpO1xuXG4gIEBpZiAobGVuZ3RoKCRuYi1lbmFibGVkLXRoZW1lcykgPiAwKSB7XG4gICAgQGVhY2ggJHRoZW1lLW5hbWUgaW4gJG5iLWVuYWJsZWQtdGhlbWVzIHtcbiAgICAgICR0aGVtZXMtdG8taW5zdGFsbDogbWFwLXNldCgkdGhlbWVzLXRvLWluc3RhbGwsICR0aGVtZS1uYW1lLCBtYXAtZ2V0KCRuYi10aGVtZXMsICR0aGVtZS1uYW1lKSk7XG4gICAgfVxuICB9IEBlbHNlIHtcbiAgICAkdGhlbWVzLXRvLWluc3RhbGw6ICRuYi10aGVtZXM7XG4gIH1cblxuICBAcmV0dXJuICR0aGVtZXMtdG8taW5zdGFsbDtcbn1cblxuQG1peGluIGluc3RhbGwtY3NzLXZhcmlhYmxlcygkdGhlbWUtbmFtZSwgJHZhcmlhYmxlcykge1xuICAubmItdGhlbWUtI3skdGhlbWUtbmFtZX0ge1xuICAgIEBlYWNoICR2YXIsICR2YWx1ZSBpbiAkdmFyaWFibGVzIHtcbiAgICAgIC0tI3skdmFyfTogJHZhbHVlO1xuICAgIH1cbiAgfVxufVxuXG4vLyBUT0RPOiB3ZSBoaWRlIDpob3N0IGluc2lkZSBvZiBpdCB3aGljaCBpcyBub3Qgb2J2aW91c1xuQG1peGluIG5iLWluc3RhbGwtY29tcG9uZW50KCkge1xuXG4gICR0aGVtZXMtdG8taW5zdGFsbDogZ2V0LWVuYWJsZWQtdGhlbWVzKCk7XG5cbiAgQGVhY2ggJHRoZW1lLW5hbWUsICR0aGVtZSBpbiAkdGhlbWVzLXRvLWluc3RhbGwge1xuICAgIC8qXG4gICAgICA6aG9zdCBjYW4gYmUgcHJlZml4ZWRcbiAgICAgIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi84ZDBlZTM0OTM5ZjE0YzA3ODc2ZDIyMmMyNWI0MDVlZDQ1OGEzNGQzL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDFcblxuICAgICAgV2UgaGF2ZSB0byB1c2UgOmhvc3QgaW5zdGVkIG9mIDpob3N0LWNvbnRleHQoJHRoZW1lKSwgdG8gYmUgYWJsZSB0byBwcmVmaXggdGhlbWUgY2xhc3NcbiAgICAgIHdpdGggc29tZXRoaW5nIGRlZmluZWQgaW5zaWRlIG9mIEBjb250ZW50LCBieSBwcmVmaXhpbmcgJi5cbiAgICAgIEZvciBleGFtcGxlIHRoaXMgc2NzcyBjb2RlOlxuICAgICAgICAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLnNvbWUtc2VsZWN0b3IgJiB7XG4gICAgICAgICAgICAuLi5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIFdpbGwgcmVzdWx0IGluIG5leHQgY3NzOlxuICAgICAgICAuc29tZS1zZWxlY3RvciAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLi4uXG4gICAgICAgIH1cblxuICAgICAgSXQgZG9lc24ndCB3b3JrIHdpdGggOmhvc3QtY29udGV4dCBiZWNhdXNlIGFuZ3VsYXIgc3BsaXR0aW5nIGl0IGluIHR3byBzZWxlY3RvcnMgYW5kIHJlbW92ZXNcbiAgICAgIHByZWZpeCBpbiBvbmUgb2YgdGhlIHNlbGVjdG9ycy5cbiAgICAqL1xuICAgIC5uYi10aGVtZS0jeyR0aGVtZS1uYW1lfSA6aG9zdCB7XG4gICAgICAkdGhlbWU6IHNldC1nbG9iYWwtdGhlbWUtdmFycygkdGhlbWUsICR0aGVtZS1uYW1lKTtcbiAgICAgIEBjb250ZW50O1xuICAgIH1cbiAgfVxufVxuXG5AbWl4aW4gbmItZm9yLXRoZW1lKCRuYW1lKSB7XG4gIEBpZiAoJHRoZW1lLW5hbWUgPT0gJG5hbWUpIHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5AbWl4aW4gbmItZXhjZXB0LXRoZW1lKCRuYW1lKSB7XG4gIEBpZiAoJHRoZW1lLW5hbWUgIT0gJG5hbWUpIHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG4vLyBUT0RPOiBhbm90aGVyIG1peGluZyBmb3IgdGhlIGFsbW9zdCBzYW1lIHRoaW5nXG5AbWl4aW4gbmItaW5zdGFsbC1yb290LWNvbXBvbmVudCgpIHtcbiAgQHdhcm4gJ2BuYi1pbnN0YWxsLXJvb3QtY29tcG9uZW50YCBpcyBkZXByaWNhdGVkLCByZXBsYWNlIHdpdGggYG5iLWluc3RhbGwtY29tcG9uZW50YCwgYXMgYGJvZHlgIGlzIHJvb3QgZWxlbWVudCBub3cnO1xuXG4gIEBpbmNsdWRlIG5iLWluc3RhbGwtY29tcG9uZW50KCkge1xuICAgIEBjb250ZW50O1xuICB9XG59XG5cbkBtaXhpbiBuYi1pbnN0YWxsLWdsb2JhbCgpIHtcbiAgJHRoZW1lcy10by1pbnN0YWxsOiBnZXQtZW5hYmxlZC10aGVtZXMoKTtcblxuICBAZWFjaCAkdGhlbWUtbmFtZSwgJHRoZW1lIGluICR0aGVtZXMtdG8taW5zdGFsbCB7XG4gICAgLm5iLXRoZW1lLSN7JHRoZW1lLW5hbWV9IHtcbiAgICAgICR0aGVtZTogc2V0LWdsb2JhbC10aGVtZS12YXJzKCR0aGVtZSwgJHRoZW1lLW5hbWUpO1xuICAgICAgQGNvbnRlbnQ7XG4gICAgfVxuICB9XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWt2ZW8uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuIFNlZSBMaWNlbnNlLnR4dCBpbiB0aGUgcHJvamVjdCByb290IGZvciBsaWNlbnNlIGluZm9ybWF0aW9uLlxuICovXG4vKipcbiAqIFRoaXMgaXMgYSBzdGFydGluZyBwb2ludCB3aGVyZSB3ZSBkZWNsYXJlIHRoZSBtYXBzIG9mIHRoZW1lcyBhbmQgZ2xvYmFsbHkgYXZhaWxhYmxlIGZ1bmN0aW9ucy9taXhpbnNcbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuLypcblxuQWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uIChodHRwczovL3d3dy53My5vcmcvVFIvY3NzLXNjb3BpbmctMS8jaG9zdC1zZWxlY3Rvcilcbjpob3N0IGFuZCA6aG9zdC1jb250ZXh0IGFyZSBwc2V1ZG8tY2xhc3Nlcy4gU28gd2UgYXNzdW1lIHRoZXkgY291bGQgYmUgY29tYmluZWQsXG5saWtlIG90aGVyIHBzZXVkby1jbGFzc2VzLCBldmVuIHNhbWUgb25lcy5cbkZvciBleGFtcGxlOiAnOm50aC1vZi10eXBlKDJuKTpudGgtb2YtdHlwZShldmVuKScuXG5cbklkZWFsIHNvbHV0aW9uIHdvdWxkIGJlIHRvIHByZXBlbmQgYW55IHNlbGVjdG9yIHdpdGggOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pLlxuVGhlbiBuZWJ1bGFyIGNvbXBvbmVudHMgd2lsbCBiZWhhdmUgYXMgYW4gaHRtbCBlbGVtZW50IGFuZCByZXNwb25kIHRvIFtkaXJdIGF0dHJpYnV0ZSBvbiBhbnkgbGV2ZWwsXG5zbyBkaXJlY3Rpb24gY291bGQgYmUgb3ZlcnJpZGRlbiBvbiBhbnkgY29tcG9uZW50IGxldmVsLlxuXG5JbXBsZW1lbnRhdGlvbiBjb2RlOlxuXG5AbWl4aW4gbmItcnRsKCkge1xuICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgQGF0LXJvb3Qge3NlbGVjdG9yLWFwcGVuZCgnOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pJywgJil9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5BbmQgd2hlbiB3ZSBjYWxsIGl0IHNvbWV3aGVyZTpcblxuOmhvc3Qge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG46aG9zdC1jb250ZXh0KC4uLikge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG5cblJlc3VsdCB3aWxsIGxvb2sgbGlrZTpcblxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuXG4qXG4gIFNpZGUgbm90ZTpcbiAgOmhvc3QtY29udGV4dCgpOmhvc3Qgc2VsZWN0b3IgYXJlIHZhbGlkLiBodHRwczovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LXN0eWxlLzIwMTVGZWIvMDMwNS5odG1sXG5cbiAgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIHNob3VsZCBtYXRjaCBhbnkgcGVybXV0YXRpb24sXG4gIHNvIG9yZGVyIGlzIG5vdCBpbXBvcnRhbnQuXG4qXG5cblxuQ3VycmVudGx5LCB0aGVyZSdyZSB0d28gcHJvYmxlbXMgd2l0aCB0aGlzIGFwcHJvYWNoOlxuXG5GaXJzdCwgaXMgdGhhdCB3ZSBjYW4ndCBjb21iaW5lIDpob3N0LCA6aG9zdC1jb250ZXh0LiBBbmd1bGFyIGJ1Z3MgIzE0MzQ5LCAjMTkxOTkuXG5Gb3IgdGhlIG1vbWVudCBvZiB3cml0aW5nLCB0aGUgb25seSBwb3NzaWJsZSB3YXkgaXM6XG46aG9zdCB7XG4gIDpob3N0LWNvbnRleHQoLi4uKSB7XG4gICAgLi4uXG4gIH1cbn1cbkl0IGRvZXNuJ3Qgd29yayBmb3IgdXMgYmVjYXVzZSBtaXhpbiBjb3VsZCBiZSBjYWxsZWQgc29tZXdoZXJlIGRlZXBlciwgbGlrZTpcbjpob3N0IHtcbiAgcCB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkgeyAuLi4gfVxuICB9XG59XG5XZSBhcmUgbm90IGFibGUgdG8gZ28gdXAgdG8gOmhvc3QgbGV2ZWwgdG8gcGxhY2UgY29udGVudCBwYXNzZWQgdG8gbWl4aW4uXG5cblRoZSBzZWNvbmQgcHJvYmxlbSBpcyB0aGF0IHdlIG9ubHkgY2FuIGJlIHN1cmUgdGhhdCB3ZSBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIGFub3RoZXJcbjpob3N0Lzpob3N0LWNvbnRleHQgcHNldWRvLWNsYXNzIHdoZW4gY2FsbGVkIGluIHRoZW1lIGZpbGVzICgqLnRoZW1lLnNjc3MpLlxuICAqXG4gICAgU2lkZSBub3RlOlxuICAgIEN1cnJlbnRseSwgbmItaW5zdGFsbC1jb21wb25lbnQgdXNlcyBhbm90aGVyIGFwcHJvYWNoIHdoZXJlIDpob3N0IHByZXBlbmRlZCB3aXRoIHRoZSB0aGVtZSBuYW1lXG4gICAgKGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi81Yjk2MDc4NjI0YjBhNDc2MGYyZGJjZjZmZGYwYmQ2Mjc5MWJlNWJiL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDEpLFxuICAgIGJ1dCBpdCB3YXMgbWFkZSB0byBiZSBhYmxlIHRvIHVzZSBjdXJyZW50IHJlYWxpemF0aW9uIG9mIHJ0bCBhbmQgaXQgY2FuIGJlIHJld3JpdHRlbiBiYWNrIHRvXG4gICAgOmhvc3QtY29udGV4dCgkdGhlbWUpIG9uY2Ugd2Ugd2lsbCBiZSBhYmxlIHRvIHVzZSBtdWx0aXBsZSBzaGFkb3cgc2VsZWN0b3JzLlxuICAqXG5CdXQgd2hlbiBpdCdzIGNhbGxlZCBpbiAqLmNvbXBvbmVudC5zY3NzIHdlIGNhbid0IGJlIHN1cmUsIHRoYXQgc2VsZWN0b3Igc3RhcnRzIHdpdGggOmhvc3QvOmhvc3QtY29udGV4dCxcbmJlY2F1c2UgYW5ndWxhciBhbGxvd3Mgb21pdHRpbmcgcHNldWRvLWNsYXNzZXMgaWYgd2UgZG9uJ3QgbmVlZCB0byBzdHlsZSA6aG9zdCBjb21wb25lbnQgaXRzZWxmLlxuV2UgY2FuIGJyZWFrIHN1Y2ggc2VsZWN0b3JzLCBieSBqdXN0IGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gdGhlbS5cbiAgKioqXG4gICAgUG9zc2libGUgc29sdXRpb25cbiAgICBjaGVjayBpZiB3ZSBpbiB0aGVtZSBieSBzb21lIHRoZW1lIHZhcmlhYmxlcyBhbmQgaWYgc28gYXBwZW5kLCBvdGhlcndpc2UgbmVzdCBsaWtlXG4gICAgQGF0LXJvb3QgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHtcbiAgICAgIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gICAgICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgICAgIHsmfSB7XG4gICAgICAgIEBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBXaGF0IGlmIDpob3N0IHNwZWNpZmllZD8gQ2FuIHdlIGFkZCBzcGFjZSBpbiA6aG9zdC1jb250ZXh0KC4uLikgOmhvc3Q/XG4gICAgT3IgbWF5YmUgYWRkIDpob3N0IHNlbGVjdG9yIGFueXdheT8gSWYgbXVsdGlwbGUgOmhvc3Qgc2VsZWN0b3JzIGFyZSBhbGxvd2VkXG4gICoqKlxuXG5cblByb2JsZW1zIHdpdGggdGhlIGN1cnJlbnQgYXBwcm9hY2guXG5cbjEuIERpcmVjdGlvbiBjYW4gYmUgYXBwbGllZCBvbmx5IG9uIGRvY3VtZW50IGxldmVsLCBiZWNhdXNlIG1peGluIHByZXBlbmRzIHRoZW1lIGNsYXNzLFxud2hpY2ggcGxhY2VkIG9uIHRoZSBib2R5LlxuMi4gKi5jb21wb25lbnQuc2NzcyBzdHlsZXMgc2hvdWxkIGJlIGluIDpob3N0IHNlbGVjdG9yLiBPdGhlcndpc2UgYW5ndWxhciB3aWxsIGFkZCBob3N0XG5hdHRyaWJ1dGUgdG8gW2Rpcj1ydGxdIGF0dHJpYnV0ZSBhcyB3ZWxsLlxuXG5cbkdlbmVyYWwgcHJvYmxlbXMuXG5cbkx0ciBpcyBkZWZhdWx0IGRvY3VtZW50IGRpcmVjdGlvbiwgYnV0IGZvciBwcm9wZXIgd29yayBvZiBuYi1sdHIgKG1lYW5zIGx0ciBvbmx5KSxcbltkaXI9bHRyXSBzaG91bGQgYmUgc3BlY2lmaWVkIGF0IGxlYXN0IHNvbWV3aGVyZS4gJzpub3QoW2Rpcj1ydGxdJyBub3QgYXBwbGljYWJsZSBoZXJlLFxuYmVjYXVzZSBpdCdzIHNhdGlzZnkgYW55IHBhcmVudCwgdGhhdCBkb24ndCBoYXZlIFtkaXI9cnRsXSBhdHRyaWJ1dGUuXG5QcmV2aW91cyBhcHByb2FjaCB3YXMgdG8gdXNlIHNpbmdsZSBydGwgbWl4aW4gYW5kIHJlc2V0IGx0ciBwcm9wZXJ0aWVzIHRvIGluaXRpYWwgdmFsdWUuXG5CdXQgc29tZXRpbWVzIGl0J3MgaGFyZCB0byBmaW5kLCB3aGF0IHRoZSBwcmV2aW91cyB2YWx1ZSBzaG91bGQgYmUuIEFuZCBzdWNoIG1peGluIGNhbGwgbG9va3MgdG9vIHZlcmJvc2UuXG4qL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuLypcblxuQWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uIChodHRwczovL3d3dy53My5vcmcvVFIvY3NzLXNjb3BpbmctMS8jaG9zdC1zZWxlY3Rvcilcbjpob3N0IGFuZCA6aG9zdC1jb250ZXh0IGFyZSBwc2V1ZG8tY2xhc3Nlcy4gU28gd2UgYXNzdW1lIHRoZXkgY291bGQgYmUgY29tYmluZWQsXG5saWtlIG90aGVyIHBzZXVkby1jbGFzc2VzLCBldmVuIHNhbWUgb25lcy5cbkZvciBleGFtcGxlOiAnOm50aC1vZi10eXBlKDJuKTpudGgtb2YtdHlwZShldmVuKScuXG5cbklkZWFsIHNvbHV0aW9uIHdvdWxkIGJlIHRvIHByZXBlbmQgYW55IHNlbGVjdG9yIHdpdGggOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pLlxuVGhlbiBuZWJ1bGFyIGNvbXBvbmVudHMgd2lsbCBiZWhhdmUgYXMgYW4gaHRtbCBlbGVtZW50IGFuZCByZXNwb25kIHRvIFtkaXJdIGF0dHJpYnV0ZSBvbiBhbnkgbGV2ZWwsXG5zbyBkaXJlY3Rpb24gY291bGQgYmUgb3ZlcnJpZGRlbiBvbiBhbnkgY29tcG9uZW50IGxldmVsLlxuXG5JbXBsZW1lbnRhdGlvbiBjb2RlOlxuXG5AbWl4aW4gbmItcnRsKCkge1xuICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgQGF0LXJvb3Qge3NlbGVjdG9yLWFwcGVuZCgnOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pJywgJil9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5BbmQgd2hlbiB3ZSBjYWxsIGl0IHNvbWV3aGVyZTpcblxuOmhvc3Qge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG46aG9zdC1jb250ZXh0KC4uLikge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG5cblJlc3VsdCB3aWxsIGxvb2sgbGlrZTpcblxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuXG4qXG4gIFNpZGUgbm90ZTpcbiAgOmhvc3QtY29udGV4dCgpOmhvc3Qgc2VsZWN0b3IgYXJlIHZhbGlkLiBodHRwczovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LXN0eWxlLzIwMTVGZWIvMDMwNS5odG1sXG5cbiAgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIHNob3VsZCBtYXRjaCBhbnkgcGVybXV0YXRpb24sXG4gIHNvIG9yZGVyIGlzIG5vdCBpbXBvcnRhbnQuXG4qXG5cblxuQ3VycmVudGx5LCB0aGVyZSdyZSB0d28gcHJvYmxlbXMgd2l0aCB0aGlzIGFwcHJvYWNoOlxuXG5GaXJzdCwgaXMgdGhhdCB3ZSBjYW4ndCBjb21iaW5lIDpob3N0LCA6aG9zdC1jb250ZXh0LiBBbmd1bGFyIGJ1Z3MgIzE0MzQ5LCAjMTkxOTkuXG5Gb3IgdGhlIG1vbWVudCBvZiB3cml0aW5nLCB0aGUgb25seSBwb3NzaWJsZSB3YXkgaXM6XG46aG9zdCB7XG4gIDpob3N0LWNvbnRleHQoLi4uKSB7XG4gICAgLi4uXG4gIH1cbn1cbkl0IGRvZXNuJ3Qgd29yayBmb3IgdXMgYmVjYXVzZSBtaXhpbiBjb3VsZCBiZSBjYWxsZWQgc29tZXdoZXJlIGRlZXBlciwgbGlrZTpcbjpob3N0IHtcbiAgcCB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkgeyAuLi4gfVxuICB9XG59XG5XZSBhcmUgbm90IGFibGUgdG8gZ28gdXAgdG8gOmhvc3QgbGV2ZWwgdG8gcGxhY2UgY29udGVudCBwYXNzZWQgdG8gbWl4aW4uXG5cblRoZSBzZWNvbmQgcHJvYmxlbSBpcyB0aGF0IHdlIG9ubHkgY2FuIGJlIHN1cmUgdGhhdCB3ZSBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIGFub3RoZXJcbjpob3N0Lzpob3N0LWNvbnRleHQgcHNldWRvLWNsYXNzIHdoZW4gY2FsbGVkIGluIHRoZW1lIGZpbGVzICgqLnRoZW1lLnNjc3MpLlxuICAqXG4gICAgU2lkZSBub3RlOlxuICAgIEN1cnJlbnRseSwgbmItaW5zdGFsbC1jb21wb25lbnQgdXNlcyBhbm90aGVyIGFwcHJvYWNoIHdoZXJlIDpob3N0IHByZXBlbmRlZCB3aXRoIHRoZSB0aGVtZSBuYW1lXG4gICAgKGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi81Yjk2MDc4NjI0YjBhNDc2MGYyZGJjZjZmZGYwYmQ2Mjc5MWJlNWJiL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDEpLFxuICAgIGJ1dCBpdCB3YXMgbWFkZSB0byBiZSBhYmxlIHRvIHVzZSBjdXJyZW50IHJlYWxpemF0aW9uIG9mIHJ0bCBhbmQgaXQgY2FuIGJlIHJld3JpdHRlbiBiYWNrIHRvXG4gICAgOmhvc3QtY29udGV4dCgkdGhlbWUpIG9uY2Ugd2Ugd2lsbCBiZSBhYmxlIHRvIHVzZSBtdWx0aXBsZSBzaGFkb3cgc2VsZWN0b3JzLlxuICAqXG5CdXQgd2hlbiBpdCdzIGNhbGxlZCBpbiAqLmNvbXBvbmVudC5zY3NzIHdlIGNhbid0IGJlIHN1cmUsIHRoYXQgc2VsZWN0b3Igc3RhcnRzIHdpdGggOmhvc3QvOmhvc3QtY29udGV4dCxcbmJlY2F1c2UgYW5ndWxhciBhbGxvd3Mgb21pdHRpbmcgcHNldWRvLWNsYXNzZXMgaWYgd2UgZG9uJ3QgbmVlZCB0byBzdHlsZSA6aG9zdCBjb21wb25lbnQgaXRzZWxmLlxuV2UgY2FuIGJyZWFrIHN1Y2ggc2VsZWN0b3JzLCBieSBqdXN0IGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gdGhlbS5cbiAgKioqXG4gICAgUG9zc2libGUgc29sdXRpb25cbiAgICBjaGVjayBpZiB3ZSBpbiB0aGVtZSBieSBzb21lIHRoZW1lIHZhcmlhYmxlcyBhbmQgaWYgc28gYXBwZW5kLCBvdGhlcndpc2UgbmVzdCBsaWtlXG4gICAgQGF0LXJvb3QgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHtcbiAgICAgIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gICAgICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgICAgIHsmfSB7XG4gICAgICAgIEBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBXaGF0IGlmIDpob3N0IHNwZWNpZmllZD8gQ2FuIHdlIGFkZCBzcGFjZSBpbiA6aG9zdC1jb250ZXh0KC4uLikgOmhvc3Q/XG4gICAgT3IgbWF5YmUgYWRkIDpob3N0IHNlbGVjdG9yIGFueXdheT8gSWYgbXVsdGlwbGUgOmhvc3Qgc2VsZWN0b3JzIGFyZSBhbGxvd2VkXG4gICoqKlxuXG5cblByb2JsZW1zIHdpdGggdGhlIGN1cnJlbnQgYXBwcm9hY2guXG5cbjEuIERpcmVjdGlvbiBjYW4gYmUgYXBwbGllZCBvbmx5IG9uIGRvY3VtZW50IGxldmVsLCBiZWNhdXNlIG1peGluIHByZXBlbmRzIHRoZW1lIGNsYXNzLFxud2hpY2ggcGxhY2VkIG9uIHRoZSBib2R5LlxuMi4gKi5jb21wb25lbnQuc2NzcyBzdHlsZXMgc2hvdWxkIGJlIGluIDpob3N0IHNlbGVjdG9yLiBPdGhlcndpc2UgYW5ndWxhciB3aWxsIGFkZCBob3N0XG5hdHRyaWJ1dGUgdG8gW2Rpcj1ydGxdIGF0dHJpYnV0ZSBhcyB3ZWxsLlxuXG5cbkdlbmVyYWwgcHJvYmxlbXMuXG5cbkx0ciBpcyBkZWZhdWx0IGRvY3VtZW50IGRpcmVjdGlvbiwgYnV0IGZvciBwcm9wZXIgd29yayBvZiBuYi1sdHIgKG1lYW5zIGx0ciBvbmx5KSxcbltkaXI9bHRyXSBzaG91bGQgYmUgc3BlY2lmaWVkIGF0IGxlYXN0IHNvbWV3aGVyZS4gJzpub3QoW2Rpcj1ydGxdJyBub3QgYXBwbGljYWJsZSBoZXJlLFxuYmVjYXVzZSBpdCdzIHNhdGlzZnkgYW55IHBhcmVudCwgdGhhdCBkb24ndCBoYXZlIFtkaXI9cnRsXSBhdHRyaWJ1dGUuXG5QcmV2aW91cyBhcHByb2FjaCB3YXMgdG8gdXNlIHNpbmdsZSBydGwgbWl4aW4gYW5kIHJlc2V0IGx0ciBwcm9wZXJ0aWVzIHRvIGluaXRpYWwgdmFsdWUuXG5CdXQgc29tZXRpbWVzIGl0J3MgaGFyZCB0byBmaW5kLCB3aGF0IHRoZSBwcmV2aW91cyB2YWx1ZSBzaG91bGQgYmUuIEFuZCBzdWNoIG1peGluIGNhbGwgbG9va3MgdG9vIHZlcmJvc2UuXG4qL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuLypcblxuQWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uIChodHRwczovL3d3dy53My5vcmcvVFIvY3NzLXNjb3BpbmctMS8jaG9zdC1zZWxlY3Rvcilcbjpob3N0IGFuZCA6aG9zdC1jb250ZXh0IGFyZSBwc2V1ZG8tY2xhc3Nlcy4gU28gd2UgYXNzdW1lIHRoZXkgY291bGQgYmUgY29tYmluZWQsXG5saWtlIG90aGVyIHBzZXVkby1jbGFzc2VzLCBldmVuIHNhbWUgb25lcy5cbkZvciBleGFtcGxlOiAnOm50aC1vZi10eXBlKDJuKTpudGgtb2YtdHlwZShldmVuKScuXG5cbklkZWFsIHNvbHV0aW9uIHdvdWxkIGJlIHRvIHByZXBlbmQgYW55IHNlbGVjdG9yIHdpdGggOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pLlxuVGhlbiBuZWJ1bGFyIGNvbXBvbmVudHMgd2lsbCBiZWhhdmUgYXMgYW4gaHRtbCBlbGVtZW50IGFuZCByZXNwb25kIHRvIFtkaXJdIGF0dHJpYnV0ZSBvbiBhbnkgbGV2ZWwsXG5zbyBkaXJlY3Rpb24gY291bGQgYmUgb3ZlcnJpZGRlbiBvbiBhbnkgY29tcG9uZW50IGxldmVsLlxuXG5JbXBsZW1lbnRhdGlvbiBjb2RlOlxuXG5AbWl4aW4gbmItcnRsKCkge1xuICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgQGF0LXJvb3Qge3NlbGVjdG9yLWFwcGVuZCgnOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pJywgJil9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5BbmQgd2hlbiB3ZSBjYWxsIGl0IHNvbWV3aGVyZTpcblxuOmhvc3Qge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG46aG9zdC1jb250ZXh0KC4uLikge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG5cblJlc3VsdCB3aWxsIGxvb2sgbGlrZTpcblxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuXG4qXG4gIFNpZGUgbm90ZTpcbiAgOmhvc3QtY29udGV4dCgpOmhvc3Qgc2VsZWN0b3IgYXJlIHZhbGlkLiBodHRwczovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LXN0eWxlLzIwMTVGZWIvMDMwNS5odG1sXG5cbiAgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIHNob3VsZCBtYXRjaCBhbnkgcGVybXV0YXRpb24sXG4gIHNvIG9yZGVyIGlzIG5vdCBpbXBvcnRhbnQuXG4qXG5cblxuQ3VycmVudGx5LCB0aGVyZSdyZSB0d28gcHJvYmxlbXMgd2l0aCB0aGlzIGFwcHJvYWNoOlxuXG5GaXJzdCwgaXMgdGhhdCB3ZSBjYW4ndCBjb21iaW5lIDpob3N0LCA6aG9zdC1jb250ZXh0LiBBbmd1bGFyIGJ1Z3MgIzE0MzQ5LCAjMTkxOTkuXG5Gb3IgdGhlIG1vbWVudCBvZiB3cml0aW5nLCB0aGUgb25seSBwb3NzaWJsZSB3YXkgaXM6XG46aG9zdCB7XG4gIDpob3N0LWNvbnRleHQoLi4uKSB7XG4gICAgLi4uXG4gIH1cbn1cbkl0IGRvZXNuJ3Qgd29yayBmb3IgdXMgYmVjYXVzZSBtaXhpbiBjb3VsZCBiZSBjYWxsZWQgc29tZXdoZXJlIGRlZXBlciwgbGlrZTpcbjpob3N0IHtcbiAgcCB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkgeyAuLi4gfVxuICB9XG59XG5XZSBhcmUgbm90IGFibGUgdG8gZ28gdXAgdG8gOmhvc3QgbGV2ZWwgdG8gcGxhY2UgY29udGVudCBwYXNzZWQgdG8gbWl4aW4uXG5cblRoZSBzZWNvbmQgcHJvYmxlbSBpcyB0aGF0IHdlIG9ubHkgY2FuIGJlIHN1cmUgdGhhdCB3ZSBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIGFub3RoZXJcbjpob3N0Lzpob3N0LWNvbnRleHQgcHNldWRvLWNsYXNzIHdoZW4gY2FsbGVkIGluIHRoZW1lIGZpbGVzICgqLnRoZW1lLnNjc3MpLlxuICAqXG4gICAgU2lkZSBub3RlOlxuICAgIEN1cnJlbnRseSwgbmItaW5zdGFsbC1jb21wb25lbnQgdXNlcyBhbm90aGVyIGFwcHJvYWNoIHdoZXJlIDpob3N0IHByZXBlbmRlZCB3aXRoIHRoZSB0aGVtZSBuYW1lXG4gICAgKGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi81Yjk2MDc4NjI0YjBhNDc2MGYyZGJjZjZmZGYwYmQ2Mjc5MWJlNWJiL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDEpLFxuICAgIGJ1dCBpdCB3YXMgbWFkZSB0byBiZSBhYmxlIHRvIHVzZSBjdXJyZW50IHJlYWxpemF0aW9uIG9mIHJ0bCBhbmQgaXQgY2FuIGJlIHJld3JpdHRlbiBiYWNrIHRvXG4gICAgOmhvc3QtY29udGV4dCgkdGhlbWUpIG9uY2Ugd2Ugd2lsbCBiZSBhYmxlIHRvIHVzZSBtdWx0aXBsZSBzaGFkb3cgc2VsZWN0b3JzLlxuICAqXG5CdXQgd2hlbiBpdCdzIGNhbGxlZCBpbiAqLmNvbXBvbmVudC5zY3NzIHdlIGNhbid0IGJlIHN1cmUsIHRoYXQgc2VsZWN0b3Igc3RhcnRzIHdpdGggOmhvc3QvOmhvc3QtY29udGV4dCxcbmJlY2F1c2UgYW5ndWxhciBhbGxvd3Mgb21pdHRpbmcgcHNldWRvLWNsYXNzZXMgaWYgd2UgZG9uJ3QgbmVlZCB0byBzdHlsZSA6aG9zdCBjb21wb25lbnQgaXRzZWxmLlxuV2UgY2FuIGJyZWFrIHN1Y2ggc2VsZWN0b3JzLCBieSBqdXN0IGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gdGhlbS5cbiAgKioqXG4gICAgUG9zc2libGUgc29sdXRpb25cbiAgICBjaGVjayBpZiB3ZSBpbiB0aGVtZSBieSBzb21lIHRoZW1lIHZhcmlhYmxlcyBhbmQgaWYgc28gYXBwZW5kLCBvdGhlcndpc2UgbmVzdCBsaWtlXG4gICAgQGF0LXJvb3QgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHtcbiAgICAgIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gICAgICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgICAgIHsmfSB7XG4gICAgICAgIEBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBXaGF0IGlmIDpob3N0IHNwZWNpZmllZD8gQ2FuIHdlIGFkZCBzcGFjZSBpbiA6aG9zdC1jb250ZXh0KC4uLikgOmhvc3Q/XG4gICAgT3IgbWF5YmUgYWRkIDpob3N0IHNlbGVjdG9yIGFueXdheT8gSWYgbXVsdGlwbGUgOmhvc3Qgc2VsZWN0b3JzIGFyZSBhbGxvd2VkXG4gICoqKlxuXG5cblByb2JsZW1zIHdpdGggdGhlIGN1cnJlbnQgYXBwcm9hY2guXG5cbjEuIERpcmVjdGlvbiBjYW4gYmUgYXBwbGllZCBvbmx5IG9uIGRvY3VtZW50IGxldmVsLCBiZWNhdXNlIG1peGluIHByZXBlbmRzIHRoZW1lIGNsYXNzLFxud2hpY2ggcGxhY2VkIG9uIHRoZSBib2R5LlxuMi4gKi5jb21wb25lbnQuc2NzcyBzdHlsZXMgc2hvdWxkIGJlIGluIDpob3N0IHNlbGVjdG9yLiBPdGhlcndpc2UgYW5ndWxhciB3aWxsIGFkZCBob3N0XG5hdHRyaWJ1dGUgdG8gW2Rpcj1ydGxdIGF0dHJpYnV0ZSBhcyB3ZWxsLlxuXG5cbkdlbmVyYWwgcHJvYmxlbXMuXG5cbkx0ciBpcyBkZWZhdWx0IGRvY3VtZW50IGRpcmVjdGlvbiwgYnV0IGZvciBwcm9wZXIgd29yayBvZiBuYi1sdHIgKG1lYW5zIGx0ciBvbmx5KSxcbltkaXI9bHRyXSBzaG91bGQgYmUgc3BlY2lmaWVkIGF0IGxlYXN0IHNvbWV3aGVyZS4gJzpub3QoW2Rpcj1ydGxdJyBub3QgYXBwbGljYWJsZSBoZXJlLFxuYmVjYXVzZSBpdCdzIHNhdGlzZnkgYW55IHBhcmVudCwgdGhhdCBkb24ndCBoYXZlIFtkaXI9cnRsXSBhdHRyaWJ1dGUuXG5QcmV2aW91cyBhcHByb2FjaCB3YXMgdG8gdXNlIHNpbmdsZSBydGwgbWl4aW4gYW5kIHJlc2V0IGx0ciBwcm9wZXJ0aWVzIHRvIGluaXRpYWwgdmFsdWUuXG5CdXQgc29tZXRpbWVzIGl0J3MgaGFyZCB0byBmaW5kLCB3aGF0IHRoZSBwcmV2aW91cyB2YWx1ZSBzaG91bGQgYmUuIEFuZCBzdWNoIG1peGluIGNhbGwgbG9va3MgdG9vIHZlcmJvc2UuXG4qL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuLypcblxuQWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uIChodHRwczovL3d3dy53My5vcmcvVFIvY3NzLXNjb3BpbmctMS8jaG9zdC1zZWxlY3Rvcilcbjpob3N0IGFuZCA6aG9zdC1jb250ZXh0IGFyZSBwc2V1ZG8tY2xhc3Nlcy4gU28gd2UgYXNzdW1lIHRoZXkgY291bGQgYmUgY29tYmluZWQsXG5saWtlIG90aGVyIHBzZXVkby1jbGFzc2VzLCBldmVuIHNhbWUgb25lcy5cbkZvciBleGFtcGxlOiAnOm50aC1vZi10eXBlKDJuKTpudGgtb2YtdHlwZShldmVuKScuXG5cbklkZWFsIHNvbHV0aW9uIHdvdWxkIGJlIHRvIHByZXBlbmQgYW55IHNlbGVjdG9yIHdpdGggOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pLlxuVGhlbiBuZWJ1bGFyIGNvbXBvbmVudHMgd2lsbCBiZWhhdmUgYXMgYW4gaHRtbCBlbGVtZW50IGFuZCByZXNwb25kIHRvIFtkaXJdIGF0dHJpYnV0ZSBvbiBhbnkgbGV2ZWwsXG5zbyBkaXJlY3Rpb24gY291bGQgYmUgb3ZlcnJpZGRlbiBvbiBhbnkgY29tcG9uZW50IGxldmVsLlxuXG5JbXBsZW1lbnRhdGlvbiBjb2RlOlxuXG5AbWl4aW4gbmItcnRsKCkge1xuICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgQGF0LXJvb3Qge3NlbGVjdG9yLWFwcGVuZCgnOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pJywgJil9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5BbmQgd2hlbiB3ZSBjYWxsIGl0IHNvbWV3aGVyZTpcblxuOmhvc3Qge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG46aG9zdC1jb250ZXh0KC4uLikge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG5cblJlc3VsdCB3aWxsIGxvb2sgbGlrZTpcblxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuXG4qXG4gIFNpZGUgbm90ZTpcbiAgOmhvc3QtY29udGV4dCgpOmhvc3Qgc2VsZWN0b3IgYXJlIHZhbGlkLiBodHRwczovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LXN0eWxlLzIwMTVGZWIvMDMwNS5odG1sXG5cbiAgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIHNob3VsZCBtYXRjaCBhbnkgcGVybXV0YXRpb24sXG4gIHNvIG9yZGVyIGlzIG5vdCBpbXBvcnRhbnQuXG4qXG5cblxuQ3VycmVudGx5LCB0aGVyZSdyZSB0d28gcHJvYmxlbXMgd2l0aCB0aGlzIGFwcHJvYWNoOlxuXG5GaXJzdCwgaXMgdGhhdCB3ZSBjYW4ndCBjb21iaW5lIDpob3N0LCA6aG9zdC1jb250ZXh0LiBBbmd1bGFyIGJ1Z3MgIzE0MzQ5LCAjMTkxOTkuXG5Gb3IgdGhlIG1vbWVudCBvZiB3cml0aW5nLCB0aGUgb25seSBwb3NzaWJsZSB3YXkgaXM6XG46aG9zdCB7XG4gIDpob3N0LWNvbnRleHQoLi4uKSB7XG4gICAgLi4uXG4gIH1cbn1cbkl0IGRvZXNuJ3Qgd29yayBmb3IgdXMgYmVjYXVzZSBtaXhpbiBjb3VsZCBiZSBjYWxsZWQgc29tZXdoZXJlIGRlZXBlciwgbGlrZTpcbjpob3N0IHtcbiAgcCB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkgeyAuLi4gfVxuICB9XG59XG5XZSBhcmUgbm90IGFibGUgdG8gZ28gdXAgdG8gOmhvc3QgbGV2ZWwgdG8gcGxhY2UgY29udGVudCBwYXNzZWQgdG8gbWl4aW4uXG5cblRoZSBzZWNvbmQgcHJvYmxlbSBpcyB0aGF0IHdlIG9ubHkgY2FuIGJlIHN1cmUgdGhhdCB3ZSBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIGFub3RoZXJcbjpob3N0Lzpob3N0LWNvbnRleHQgcHNldWRvLWNsYXNzIHdoZW4gY2FsbGVkIGluIHRoZW1lIGZpbGVzICgqLnRoZW1lLnNjc3MpLlxuICAqXG4gICAgU2lkZSBub3RlOlxuICAgIEN1cnJlbnRseSwgbmItaW5zdGFsbC1jb21wb25lbnQgdXNlcyBhbm90aGVyIGFwcHJvYWNoIHdoZXJlIDpob3N0IHByZXBlbmRlZCB3aXRoIHRoZSB0aGVtZSBuYW1lXG4gICAgKGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi81Yjk2MDc4NjI0YjBhNDc2MGYyZGJjZjZmZGYwYmQ2Mjc5MWJlNWJiL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDEpLFxuICAgIGJ1dCBpdCB3YXMgbWFkZSB0byBiZSBhYmxlIHRvIHVzZSBjdXJyZW50IHJlYWxpemF0aW9uIG9mIHJ0bCBhbmQgaXQgY2FuIGJlIHJld3JpdHRlbiBiYWNrIHRvXG4gICAgOmhvc3QtY29udGV4dCgkdGhlbWUpIG9uY2Ugd2Ugd2lsbCBiZSBhYmxlIHRvIHVzZSBtdWx0aXBsZSBzaGFkb3cgc2VsZWN0b3JzLlxuICAqXG5CdXQgd2hlbiBpdCdzIGNhbGxlZCBpbiAqLmNvbXBvbmVudC5zY3NzIHdlIGNhbid0IGJlIHN1cmUsIHRoYXQgc2VsZWN0b3Igc3RhcnRzIHdpdGggOmhvc3QvOmhvc3QtY29udGV4dCxcbmJlY2F1c2UgYW5ndWxhciBhbGxvd3Mgb21pdHRpbmcgcHNldWRvLWNsYXNzZXMgaWYgd2UgZG9uJ3QgbmVlZCB0byBzdHlsZSA6aG9zdCBjb21wb25lbnQgaXRzZWxmLlxuV2UgY2FuIGJyZWFrIHN1Y2ggc2VsZWN0b3JzLCBieSBqdXN0IGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gdGhlbS5cbiAgKioqXG4gICAgUG9zc2libGUgc29sdXRpb25cbiAgICBjaGVjayBpZiB3ZSBpbiB0aGVtZSBieSBzb21lIHRoZW1lIHZhcmlhYmxlcyBhbmQgaWYgc28gYXBwZW5kLCBvdGhlcndpc2UgbmVzdCBsaWtlXG4gICAgQGF0LXJvb3QgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHtcbiAgICAgIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gICAgICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgICAgIHsmfSB7XG4gICAgICAgIEBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBXaGF0IGlmIDpob3N0IHNwZWNpZmllZD8gQ2FuIHdlIGFkZCBzcGFjZSBpbiA6aG9zdC1jb250ZXh0KC4uLikgOmhvc3Q/XG4gICAgT3IgbWF5YmUgYWRkIDpob3N0IHNlbGVjdG9yIGFueXdheT8gSWYgbXVsdGlwbGUgOmhvc3Qgc2VsZWN0b3JzIGFyZSBhbGxvd2VkXG4gICoqKlxuXG5cblByb2JsZW1zIHdpdGggdGhlIGN1cnJlbnQgYXBwcm9hY2guXG5cbjEuIERpcmVjdGlvbiBjYW4gYmUgYXBwbGllZCBvbmx5IG9uIGRvY3VtZW50IGxldmVsLCBiZWNhdXNlIG1peGluIHByZXBlbmRzIHRoZW1lIGNsYXNzLFxud2hpY2ggcGxhY2VkIG9uIHRoZSBib2R5LlxuMi4gKi5jb21wb25lbnQuc2NzcyBzdHlsZXMgc2hvdWxkIGJlIGluIDpob3N0IHNlbGVjdG9yLiBPdGhlcndpc2UgYW5ndWxhciB3aWxsIGFkZCBob3N0XG5hdHRyaWJ1dGUgdG8gW2Rpcj1ydGxdIGF0dHJpYnV0ZSBhcyB3ZWxsLlxuXG5cbkdlbmVyYWwgcHJvYmxlbXMuXG5cbkx0ciBpcyBkZWZhdWx0IGRvY3VtZW50IGRpcmVjdGlvbiwgYnV0IGZvciBwcm9wZXIgd29yayBvZiBuYi1sdHIgKG1lYW5zIGx0ciBvbmx5KSxcbltkaXI9bHRyXSBzaG91bGQgYmUgc3BlY2lmaWVkIGF0IGxlYXN0IHNvbWV3aGVyZS4gJzpub3QoW2Rpcj1ydGxdJyBub3QgYXBwbGljYWJsZSBoZXJlLFxuYmVjYXVzZSBpdCdzIHNhdGlzZnkgYW55IHBhcmVudCwgdGhhdCBkb24ndCBoYXZlIFtkaXI9cnRsXSBhdHRyaWJ1dGUuXG5QcmV2aW91cyBhcHByb2FjaCB3YXMgdG8gdXNlIHNpbmdsZSBydGwgbWl4aW4gYW5kIHJlc2V0IGx0ciBwcm9wZXJ0aWVzIHRvIGluaXRpYWwgdmFsdWUuXG5CdXQgc29tZXRpbWVzIGl0J3MgaGFyZCB0byBmaW5kLCB3aGF0IHRoZSBwcmV2aW91cyB2YWx1ZSBzaG91bGQgYmUuIEFuZCBzdWNoIG1peGluIGNhbGwgbG9va3MgdG9vIHZlcmJvc2UuXG4qL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuLypcblxuQWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uIChodHRwczovL3d3dy53My5vcmcvVFIvY3NzLXNjb3BpbmctMS8jaG9zdC1zZWxlY3Rvcilcbjpob3N0IGFuZCA6aG9zdC1jb250ZXh0IGFyZSBwc2V1ZG8tY2xhc3Nlcy4gU28gd2UgYXNzdW1lIHRoZXkgY291bGQgYmUgY29tYmluZWQsXG5saWtlIG90aGVyIHBzZXVkby1jbGFzc2VzLCBldmVuIHNhbWUgb25lcy5cbkZvciBleGFtcGxlOiAnOm50aC1vZi10eXBlKDJuKTpudGgtb2YtdHlwZShldmVuKScuXG5cbklkZWFsIHNvbHV0aW9uIHdvdWxkIGJlIHRvIHByZXBlbmQgYW55IHNlbGVjdG9yIHdpdGggOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pLlxuVGhlbiBuZWJ1bGFyIGNvbXBvbmVudHMgd2lsbCBiZWhhdmUgYXMgYW4gaHRtbCBlbGVtZW50IGFuZCByZXNwb25kIHRvIFtkaXJdIGF0dHJpYnV0ZSBvbiBhbnkgbGV2ZWwsXG5zbyBkaXJlY3Rpb24gY291bGQgYmUgb3ZlcnJpZGRlbiBvbiBhbnkgY29tcG9uZW50IGxldmVsLlxuXG5JbXBsZW1lbnRhdGlvbiBjb2RlOlxuXG5AbWl4aW4gbmItcnRsKCkge1xuICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgQGF0LXJvb3Qge3NlbGVjdG9yLWFwcGVuZCgnOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pJywgJil9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5BbmQgd2hlbiB3ZSBjYWxsIGl0IHNvbWV3aGVyZTpcblxuOmhvc3Qge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG46aG9zdC1jb250ZXh0KC4uLikge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG5cblJlc3VsdCB3aWxsIGxvb2sgbGlrZTpcblxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuXG4qXG4gIFNpZGUgbm90ZTpcbiAgOmhvc3QtY29udGV4dCgpOmhvc3Qgc2VsZWN0b3IgYXJlIHZhbGlkLiBodHRwczovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LXN0eWxlLzIwMTVGZWIvMDMwNS5odG1sXG5cbiAgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIHNob3VsZCBtYXRjaCBhbnkgcGVybXV0YXRpb24sXG4gIHNvIG9yZGVyIGlzIG5vdCBpbXBvcnRhbnQuXG4qXG5cblxuQ3VycmVudGx5LCB0aGVyZSdyZSB0d28gcHJvYmxlbXMgd2l0aCB0aGlzIGFwcHJvYWNoOlxuXG5GaXJzdCwgaXMgdGhhdCB3ZSBjYW4ndCBjb21iaW5lIDpob3N0LCA6aG9zdC1jb250ZXh0LiBBbmd1bGFyIGJ1Z3MgIzE0MzQ5LCAjMTkxOTkuXG5Gb3IgdGhlIG1vbWVudCBvZiB3cml0aW5nLCB0aGUgb25seSBwb3NzaWJsZSB3YXkgaXM6XG46aG9zdCB7XG4gIDpob3N0LWNvbnRleHQoLi4uKSB7XG4gICAgLi4uXG4gIH1cbn1cbkl0IGRvZXNuJ3Qgd29yayBmb3IgdXMgYmVjYXVzZSBtaXhpbiBjb3VsZCBiZSBjYWxsZWQgc29tZXdoZXJlIGRlZXBlciwgbGlrZTpcbjpob3N0IHtcbiAgcCB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkgeyAuLi4gfVxuICB9XG59XG5XZSBhcmUgbm90IGFibGUgdG8gZ28gdXAgdG8gOmhvc3QgbGV2ZWwgdG8gcGxhY2UgY29udGVudCBwYXNzZWQgdG8gbWl4aW4uXG5cblRoZSBzZWNvbmQgcHJvYmxlbSBpcyB0aGF0IHdlIG9ubHkgY2FuIGJlIHN1cmUgdGhhdCB3ZSBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIGFub3RoZXJcbjpob3N0Lzpob3N0LWNvbnRleHQgcHNldWRvLWNsYXNzIHdoZW4gY2FsbGVkIGluIHRoZW1lIGZpbGVzICgqLnRoZW1lLnNjc3MpLlxuICAqXG4gICAgU2lkZSBub3RlOlxuICAgIEN1cnJlbnRseSwgbmItaW5zdGFsbC1jb21wb25lbnQgdXNlcyBhbm90aGVyIGFwcHJvYWNoIHdoZXJlIDpob3N0IHByZXBlbmRlZCB3aXRoIHRoZSB0aGVtZSBuYW1lXG4gICAgKGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi81Yjk2MDc4NjI0YjBhNDc2MGYyZGJjZjZmZGYwYmQ2Mjc5MWJlNWJiL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDEpLFxuICAgIGJ1dCBpdCB3YXMgbWFkZSB0byBiZSBhYmxlIHRvIHVzZSBjdXJyZW50IHJlYWxpemF0aW9uIG9mIHJ0bCBhbmQgaXQgY2FuIGJlIHJld3JpdHRlbiBiYWNrIHRvXG4gICAgOmhvc3QtY29udGV4dCgkdGhlbWUpIG9uY2Ugd2Ugd2lsbCBiZSBhYmxlIHRvIHVzZSBtdWx0aXBsZSBzaGFkb3cgc2VsZWN0b3JzLlxuICAqXG5CdXQgd2hlbiBpdCdzIGNhbGxlZCBpbiAqLmNvbXBvbmVudC5zY3NzIHdlIGNhbid0IGJlIHN1cmUsIHRoYXQgc2VsZWN0b3Igc3RhcnRzIHdpdGggOmhvc3QvOmhvc3QtY29udGV4dCxcbmJlY2F1c2UgYW5ndWxhciBhbGxvd3Mgb21pdHRpbmcgcHNldWRvLWNsYXNzZXMgaWYgd2UgZG9uJ3QgbmVlZCB0byBzdHlsZSA6aG9zdCBjb21wb25lbnQgaXRzZWxmLlxuV2UgY2FuIGJyZWFrIHN1Y2ggc2VsZWN0b3JzLCBieSBqdXN0IGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gdGhlbS5cbiAgKioqXG4gICAgUG9zc2libGUgc29sdXRpb25cbiAgICBjaGVjayBpZiB3ZSBpbiB0aGVtZSBieSBzb21lIHRoZW1lIHZhcmlhYmxlcyBhbmQgaWYgc28gYXBwZW5kLCBvdGhlcndpc2UgbmVzdCBsaWtlXG4gICAgQGF0LXJvb3QgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHtcbiAgICAgIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gICAgICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgICAgIHsmfSB7XG4gICAgICAgIEBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBXaGF0IGlmIDpob3N0IHNwZWNpZmllZD8gQ2FuIHdlIGFkZCBzcGFjZSBpbiA6aG9zdC1jb250ZXh0KC4uLikgOmhvc3Q/XG4gICAgT3IgbWF5YmUgYWRkIDpob3N0IHNlbGVjdG9yIGFueXdheT8gSWYgbXVsdGlwbGUgOmhvc3Qgc2VsZWN0b3JzIGFyZSBhbGxvd2VkXG4gICoqKlxuXG5cblByb2JsZW1zIHdpdGggdGhlIGN1cnJlbnQgYXBwcm9hY2guXG5cbjEuIERpcmVjdGlvbiBjYW4gYmUgYXBwbGllZCBvbmx5IG9uIGRvY3VtZW50IGxldmVsLCBiZWNhdXNlIG1peGluIHByZXBlbmRzIHRoZW1lIGNsYXNzLFxud2hpY2ggcGxhY2VkIG9uIHRoZSBib2R5LlxuMi4gKi5jb21wb25lbnQuc2NzcyBzdHlsZXMgc2hvdWxkIGJlIGluIDpob3N0IHNlbGVjdG9yLiBPdGhlcndpc2UgYW5ndWxhciB3aWxsIGFkZCBob3N0XG5hdHRyaWJ1dGUgdG8gW2Rpcj1ydGxdIGF0dHJpYnV0ZSBhcyB3ZWxsLlxuXG5cbkdlbmVyYWwgcHJvYmxlbXMuXG5cbkx0ciBpcyBkZWZhdWx0IGRvY3VtZW50IGRpcmVjdGlvbiwgYnV0IGZvciBwcm9wZXIgd29yayBvZiBuYi1sdHIgKG1lYW5zIGx0ciBvbmx5KSxcbltkaXI9bHRyXSBzaG91bGQgYmUgc3BlY2lmaWVkIGF0IGxlYXN0IHNvbWV3aGVyZS4gJzpub3QoW2Rpcj1ydGxdJyBub3QgYXBwbGljYWJsZSBoZXJlLFxuYmVjYXVzZSBpdCdzIHNhdGlzZnkgYW55IHBhcmVudCwgdGhhdCBkb24ndCBoYXZlIFtkaXI9cnRsXSBhdHRyaWJ1dGUuXG5QcmV2aW91cyBhcHByb2FjaCB3YXMgdG8gdXNlIHNpbmdsZSBydGwgbWl4aW4gYW5kIHJlc2V0IGx0ciBwcm9wZXJ0aWVzIHRvIGluaXRpYWwgdmFsdWUuXG5CdXQgc29tZXRpbWVzIGl0J3MgaGFyZCB0byBmaW5kLCB3aGF0IHRoZSBwcmV2aW91cyB2YWx1ZSBzaG91bGQgYmUuIEFuZCBzdWNoIG1peGluIGNhbGwgbG9va3MgdG9vIHZlcmJvc2UuXG4qL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuLypcblxuQWNjb3JkaW5nIHRvIHRoZSBzcGVjaWZpY2F0aW9uIChodHRwczovL3d3dy53My5vcmcvVFIvY3NzLXNjb3BpbmctMS8jaG9zdC1zZWxlY3Rvcilcbjpob3N0IGFuZCA6aG9zdC1jb250ZXh0IGFyZSBwc2V1ZG8tY2xhc3Nlcy4gU28gd2UgYXNzdW1lIHRoZXkgY291bGQgYmUgY29tYmluZWQsXG5saWtlIG90aGVyIHBzZXVkby1jbGFzc2VzLCBldmVuIHNhbWUgb25lcy5cbkZvciBleGFtcGxlOiAnOm50aC1vZi10eXBlKDJuKTpudGgtb2YtdHlwZShldmVuKScuXG5cbklkZWFsIHNvbHV0aW9uIHdvdWxkIGJlIHRvIHByZXBlbmQgYW55IHNlbGVjdG9yIHdpdGggOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pLlxuVGhlbiBuZWJ1bGFyIGNvbXBvbmVudHMgd2lsbCBiZWhhdmUgYXMgYW4gaHRtbCBlbGVtZW50IGFuZCByZXNwb25kIHRvIFtkaXJdIGF0dHJpYnV0ZSBvbiBhbnkgbGV2ZWwsXG5zbyBkaXJlY3Rpb24gY291bGQgYmUgb3ZlcnJpZGRlbiBvbiBhbnkgY29tcG9uZW50IGxldmVsLlxuXG5JbXBsZW1lbnRhdGlvbiBjb2RlOlxuXG5AbWl4aW4gbmItcnRsKCkge1xuICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgQGF0LXJvb3Qge3NlbGVjdG9yLWFwcGVuZCgnOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pJywgJil9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5BbmQgd2hlbiB3ZSBjYWxsIGl0IHNvbWV3aGVyZTpcblxuOmhvc3Qge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG46aG9zdC1jb250ZXh0KC4uLikge1xuICAuc29tZS1jbGFzcyB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkge1xuICAgICAgLi4uXG4gICAgfVxuICB9XG59XG5cblJlc3VsdCB3aWxsIGxvb2sgbGlrZTpcblxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuXG4qXG4gIFNpZGUgbm90ZTpcbiAgOmhvc3QtY29udGV4dCgpOmhvc3Qgc2VsZWN0b3IgYXJlIHZhbGlkLiBodHRwczovL2xpc3RzLnczLm9yZy9BcmNoaXZlcy9QdWJsaWMvd3d3LXN0eWxlLzIwMTVGZWIvMDMwNS5odG1sXG5cbiAgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIHNob3VsZCBtYXRjaCBhbnkgcGVybXV0YXRpb24sXG4gIHNvIG9yZGVyIGlzIG5vdCBpbXBvcnRhbnQuXG4qXG5cblxuQ3VycmVudGx5LCB0aGVyZSdyZSB0d28gcHJvYmxlbXMgd2l0aCB0aGlzIGFwcHJvYWNoOlxuXG5GaXJzdCwgaXMgdGhhdCB3ZSBjYW4ndCBjb21iaW5lIDpob3N0LCA6aG9zdC1jb250ZXh0LiBBbmd1bGFyIGJ1Z3MgIzE0MzQ5LCAjMTkxOTkuXG5Gb3IgdGhlIG1vbWVudCBvZiB3cml0aW5nLCB0aGUgb25seSBwb3NzaWJsZSB3YXkgaXM6XG46aG9zdCB7XG4gIDpob3N0LWNvbnRleHQoLi4uKSB7XG4gICAgLi4uXG4gIH1cbn1cbkl0IGRvZXNuJ3Qgd29yayBmb3IgdXMgYmVjYXVzZSBtaXhpbiBjb3VsZCBiZSBjYWxsZWQgc29tZXdoZXJlIGRlZXBlciwgbGlrZTpcbjpob3N0IHtcbiAgcCB7XG4gICAgQGluY2x1ZGUgbmItcnRsKCkgeyAuLi4gfVxuICB9XG59XG5XZSBhcmUgbm90IGFibGUgdG8gZ28gdXAgdG8gOmhvc3QgbGV2ZWwgdG8gcGxhY2UgY29udGVudCBwYXNzZWQgdG8gbWl4aW4uXG5cblRoZSBzZWNvbmQgcHJvYmxlbSBpcyB0aGF0IHdlIG9ubHkgY2FuIGJlIHN1cmUgdGhhdCB3ZSBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIGFub3RoZXJcbjpob3N0Lzpob3N0LWNvbnRleHQgcHNldWRvLWNsYXNzIHdoZW4gY2FsbGVkIGluIHRoZW1lIGZpbGVzICgqLnRoZW1lLnNjc3MpLlxuICAqXG4gICAgU2lkZSBub3RlOlxuICAgIEN1cnJlbnRseSwgbmItaW5zdGFsbC1jb21wb25lbnQgdXNlcyBhbm90aGVyIGFwcHJvYWNoIHdoZXJlIDpob3N0IHByZXBlbmRlZCB3aXRoIHRoZSB0aGVtZSBuYW1lXG4gICAgKGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi81Yjk2MDc4NjI0YjBhNDc2MGYyZGJjZjZmZGYwYmQ2Mjc5MWJlNWJiL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDEpLFxuICAgIGJ1dCBpdCB3YXMgbWFkZSB0byBiZSBhYmxlIHRvIHVzZSBjdXJyZW50IHJlYWxpemF0aW9uIG9mIHJ0bCBhbmQgaXQgY2FuIGJlIHJld3JpdHRlbiBiYWNrIHRvXG4gICAgOmhvc3QtY29udGV4dCgkdGhlbWUpIG9uY2Ugd2Ugd2lsbCBiZSBhYmxlIHRvIHVzZSBtdWx0aXBsZSBzaGFkb3cgc2VsZWN0b3JzLlxuICAqXG5CdXQgd2hlbiBpdCdzIGNhbGxlZCBpbiAqLmNvbXBvbmVudC5zY3NzIHdlIGNhbid0IGJlIHN1cmUsIHRoYXQgc2VsZWN0b3Igc3RhcnRzIHdpdGggOmhvc3QvOmhvc3QtY29udGV4dCxcbmJlY2F1c2UgYW5ndWxhciBhbGxvd3Mgb21pdHRpbmcgcHNldWRvLWNsYXNzZXMgaWYgd2UgZG9uJ3QgbmVlZCB0byBzdHlsZSA6aG9zdCBjb21wb25lbnQgaXRzZWxmLlxuV2UgY2FuIGJyZWFrIHN1Y2ggc2VsZWN0b3JzLCBieSBqdXN0IGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gdGhlbS5cbiAgKioqXG4gICAgUG9zc2libGUgc29sdXRpb25cbiAgICBjaGVjayBpZiB3ZSBpbiB0aGVtZSBieSBzb21lIHRoZW1lIHZhcmlhYmxlcyBhbmQgaWYgc28gYXBwZW5kLCBvdGhlcndpc2UgbmVzdCBsaWtlXG4gICAgQGF0LXJvb3QgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHtcbiAgICAgIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gICAgICAvLyBpdCB3b3JrcyBpbiBjb21tZW50cyBhbmQgd2UgY2FuJ3QgdXNlIGl0IGhlcmVcbiAgICAgIHsmfSB7XG4gICAgICAgIEBjb250ZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBXaGF0IGlmIDpob3N0IHNwZWNpZmllZD8gQ2FuIHdlIGFkZCBzcGFjZSBpbiA6aG9zdC1jb250ZXh0KC4uLikgOmhvc3Q/XG4gICAgT3IgbWF5YmUgYWRkIDpob3N0IHNlbGVjdG9yIGFueXdheT8gSWYgbXVsdGlwbGUgOmhvc3Qgc2VsZWN0b3JzIGFyZSBhbGxvd2VkXG4gICoqKlxuXG5cblByb2JsZW1zIHdpdGggdGhlIGN1cnJlbnQgYXBwcm9hY2guXG5cbjEuIERpcmVjdGlvbiBjYW4gYmUgYXBwbGllZCBvbmx5IG9uIGRvY3VtZW50IGxldmVsLCBiZWNhdXNlIG1peGluIHByZXBlbmRzIHRoZW1lIGNsYXNzLFxud2hpY2ggcGxhY2VkIG9uIHRoZSBib2R5LlxuMi4gKi5jb21wb25lbnQuc2NzcyBzdHlsZXMgc2hvdWxkIGJlIGluIDpob3N0IHNlbGVjdG9yLiBPdGhlcndpc2UgYW5ndWxhciB3aWxsIGFkZCBob3N0XG5hdHRyaWJ1dGUgdG8gW2Rpcj1ydGxdIGF0dHJpYnV0ZSBhcyB3ZWxsLlxuXG5cbkdlbmVyYWwgcHJvYmxlbXMuXG5cbkx0ciBpcyBkZWZhdWx0IGRvY3VtZW50IGRpcmVjdGlvbiwgYnV0IGZvciBwcm9wZXIgd29yayBvZiBuYi1sdHIgKG1lYW5zIGx0ciBvbmx5KSxcbltkaXI9bHRyXSBzaG91bGQgYmUgc3BlY2lmaWVkIGF0IGxlYXN0IHNvbWV3aGVyZS4gJzpub3QoW2Rpcj1ydGxdJyBub3QgYXBwbGljYWJsZSBoZXJlLFxuYmVjYXVzZSBpdCdzIHNhdGlzZnkgYW55IHBhcmVudCwgdGhhdCBkb24ndCBoYXZlIFtkaXI9cnRsXSBhdHRyaWJ1dGUuXG5QcmV2aW91cyBhcHByb2FjaCB3YXMgdG8gdXNlIHNpbmdsZSBydGwgbWl4aW4gYW5kIHJlc2V0IGx0ciBwcm9wZXJ0aWVzIHRvIGluaXRpYWwgdmFsdWUuXG5CdXQgc29tZXRpbWVzIGl0J3MgaGFyZCB0byBmaW5kLCB3aGF0IHRoZSBwcmV2aW91cyB2YWx1ZSBzaG91bGQgYmUuIEFuZCBzdWNoIG1peGluIGNhbGwgbG9va3MgdG9vIHZlcmJvc2UuXG4qL1xuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLypcbiAgICAgIDpob3N0IGNhbiBiZSBwcmVmaXhlZFxuICAgICAgaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9ibG9iLzhkMGVlMzQ5MzlmMTRjMDc4NzZkMjIyYzI1YjQwNWVkNDU4YTM0ZDMvcGFja2FnZXMvY29tcGlsZXIvc3JjL3NoYWRvd19jc3MudHMjTDQ0MVxuXG4gICAgICBXZSBoYXZlIHRvIHVzZSA6aG9zdCBpbnN0ZWQgb2YgOmhvc3QtY29udGV4dCgkdGhlbWUpLCB0byBiZSBhYmxlIHRvIHByZWZpeCB0aGVtZSBjbGFzc1xuICAgICAgd2l0aCBzb21ldGhpbmcgZGVmaW5lZCBpbnNpZGUgb2YgQGNvbnRlbnQsIGJ5IHByZWZpeGluZyAmLlxuICAgICAgRm9yIGV4YW1wbGUgdGhpcyBzY3NzIGNvZGU6XG4gICAgICAgIC5uYi10aGVtZS1kZWZhdWx0IHtcbiAgICAgICAgICAuc29tZS1zZWxlY3RvciAmIHtcbiAgICAgICAgICAgIC4uLlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgV2lsbCByZXN1bHQgaW4gbmV4dCBjc3M6XG4gICAgICAgIC5zb21lLXNlbGVjdG9yIC5uYi10aGVtZS1kZWZhdWx0IHtcbiAgICAgICAgICAuLi5cbiAgICAgICAgfVxuXG4gICAgICBJdCBkb2Vzbid0IHdvcmsgd2l0aCA6aG9zdC1jb250ZXh0IGJlY2F1c2UgYW5ndWxhciBzcGxpdHRpbmcgaXQgaW4gdHdvIHNlbGVjdG9ycyBhbmQgcmVtb3Zlc1xuICAgICAgcHJlZml4IGluIG9uZSBvZiB0aGUgc2VsZWN0b3JzLlxuICAgICovXG4ubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkIHtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgaGVpZ2h0OiA4MCU7XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2hhZG93OiAwIDAgMCAwICNkYmRiZGIsIG5vbmU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkNWRiZTA7XG4gIGJvcmRlci10b3AtY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci10b3Atc3R5bGU6IHNvbGlkO1xuICBib3JkZXItdG9wLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1yaWdodC1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLXJpZ2h0LXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXJpZ2h0LXdpZHRoOiAxcHg7XG4gIGJvcmRlci1ib3R0b20tY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItbGVmdC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1sZWZ0LXdpZHRoOiAxcHg7XG4gIGJvcmRlci1pbWFnZS1zb3VyY2U6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1zbGljZTogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLXdpZHRoOiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2Utb3V0c2V0OiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2UtcmVwZWF0OiBpbml0aWFsOyB9XG4gIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmljb24tY29udGFpbmVyIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcGFkZGluZzogMC42MjVyZW07IH1cbiAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHdpZHRoOiAyLjI1cmVtO1xuICAgIGhlaWdodDogMi43NXJlbTtcbiAgICBmb250LXNpemU6IDEuMjVyZW07XG4gICAgYm9yZGVyLXJhZGl1czogMC4zNzVyZW07XG4gICAgdHJhbnNpdGlvbjogd2lkdGggMC40cyBlYXNlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xuICAgIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgIGNvbG9yOiAjZmZmZmZmOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbi5wcmltYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2I1N2ZmZiwgIzhhN2ZmZik7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICM4OTZkZGIsIDAgMCAwIDAgIzlmN2ZmZjsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmljb24uc3VjY2VzcyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0MGRjYjIsICM0MGRjN2UpO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDAgMCAjMzdiZDgzLCAwIDAgMCAwICM0MGRjOTg7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkIC5pY29uLmluZm8ge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNGNjNGZmLCAjNGNhNmZmKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgIzQxOWNkYiwgMCAwIDAgMCAjNGNiNWZmOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbi53YXJuaW5nIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmY2MwMCwgI2ZmYTEwMCk7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICNkYjlkMDAsIDAgMCAwIDAgI2ZmYjYwMDsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmljb24uZGFuZ2VyIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmNGNhNiwgI2ZmNGM2YSk7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICNkYjQxNzUsIDAgMCAwIDAgI2ZmNGM4ODsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgYm94LXNoYWRvdzogMCAwIDAgMCAjYmJiZWM2LCAwIDAgMCAwICNkYWRkZTY7XG4gICAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24ucHJpbWFyeSB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNiZjkxZmYsICM5YTkxZmYpOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zdWNjZXNzIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzViZTFiZCwgIzViZTE5MCk7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLmluZm8ge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNjVjY2ZmLCAjNjViMmZmKTsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24ud2FybmluZyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmQzMjQsICNmZmFlMjQpOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5kYW5nZXIge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmY2NWIyLCAjZmY2NTdmKTsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2RmZTBlYSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE0KSk7IH1cbiAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYge1xuICAgIGNvbG9yOiAjYTRhYmIzOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ge1xuICAgICAgY29sb3I6ICNhNGFiYjM7IH1cbiAgICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLnByaW1hcnksIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLnN1Y2Nlc3MsIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLmluZm8sIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLndhcm5pbmcsIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLmRhbmdlciB7XG4gICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgdHJhbnNwYXJlbnQsIHRyYW5zcGFyZW50KTsgfVxuICAgICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkLm9mZiAudGl0bGUge1xuICAgICAgY29sb3I6ICNhNGFiYjM7IH1cbiAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHRyYW5zcGFyZW50OyB9XG4gICAgW2Rpcj1sdHJdIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgICAgcGFkZGluZzogMCAwLjVyZW0gMCAwLjc1cmVtOyB9XG4gICAgW2Rpcj1ydGxdIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgICAgcGFkZGluZzogMCAwLjc1cmVtIDAgMC41cmVtOyB9XG4gIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgbGFiZWwge1xuICAgIGZvbnQtc2l6ZTogNzAlO1xuICAgIGxpbmUtaGVpZ2h0OiAwLjFyZW07XG4gICAgd29yZC13cmFwOiBicmVhay13b3JkOyB9XG4gIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLnRpdGxlIHtcbiAgICBmb250LWZhbWlseTogUm9ib3RvO1xuICAgIGZvbnQtc2l6ZTogODUlO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgY29sb3I6ICMyYTJhMmE7XG4gICAgd29yZC13cmFwOiBicmVhay13b3JkOyB9XG4gIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLnN0YXR1cyB7XG4gICAgZm9udC1zaXplOiAxMDAlO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICBjb2xvcjogI2E0YWJiMzsgfVxuXG4vKlxuICAgICAgOmhvc3QgY2FuIGJlIHByZWZpeGVkXG4gICAgICBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvOGQwZWUzNDkzOWYxNGMwNzg3NmQyMjJjMjViNDA1ZWQ0NThhMzRkMy9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxXG5cbiAgICAgIFdlIGhhdmUgdG8gdXNlIDpob3N0IGluc3RlZCBvZiA6aG9zdC1jb250ZXh0KCR0aGVtZSksIHRvIGJlIGFibGUgdG8gcHJlZml4IHRoZW1lIGNsYXNzXG4gICAgICB3aXRoIHNvbWV0aGluZyBkZWZpbmVkIGluc2lkZSBvZiBAY29udGVudCwgYnkgcHJlZml4aW5nICYuXG4gICAgICBGb3IgZXhhbXBsZSB0aGlzIHNjc3MgY29kZTpcbiAgICAgICAgLm5iLXRoZW1lLWRlZmF1bHQge1xuICAgICAgICAgIC5zb21lLXNlbGVjdG9yICYge1xuICAgICAgICAgICAgLi4uXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICBXaWxsIHJlc3VsdCBpbiBuZXh0IGNzczpcbiAgICAgICAgLnNvbWUtc2VsZWN0b3IgLm5iLXRoZW1lLWRlZmF1bHQge1xuICAgICAgICAgIC4uLlxuICAgICAgICB9XG5cbiAgICAgIEl0IGRvZXNuJ3Qgd29yayB3aXRoIDpob3N0LWNvbnRleHQgYmVjYXVzZSBhbmd1bGFyIHNwbGl0dGluZyBpdCBpbiB0d28gc2VsZWN0b3JzIGFuZCByZW1vdmVzXG4gICAgICBwcmVmaXggaW4gb25lIG9mIHRoZSBzZWxlY3RvcnMuXG4gICAgKi9cbi5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCB7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogODAlO1xuICB3aWR0aDogMTAwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm94LXNoYWRvdzogMCAzcHggMCAwICMzNDJmNmUsIDAgNHB4IDEwcHggMCByZ2JhKDMzLCA3LCA3NywgMC41KTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2Q1ZGJlMDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLXRvcC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci10b3Atd2lkdGg6IDFweDtcbiAgYm9yZGVyLXJpZ2h0LWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItcmlnaHQtc3R5bGU6IHNvbGlkO1xuICBib3JkZXItcmlnaHQtd2lkdGg6IDFweDtcbiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDFweDtcbiAgYm9yZGVyLWxlZnQtY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci1sZWZ0LXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLWxlZnQtd2lkdGg6IDFweDtcbiAgYm9yZGVyLWltYWdlLXNvdXJjZTogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLXNsaWNlOiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2Utd2lkdGg6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1vdXRzZXQ6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1yZXBlYXQ6IGluaXRpYWw7IH1cbiAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uLWNvbnRhaW5lciB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHBhZGRpbmc6IDAuNjI1cmVtOyB9XG4gIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuaWNvbiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHdpZHRoOiAyLjI1cmVtO1xuICAgIGhlaWdodDogMi43NXJlbTtcbiAgICBmb250LXNpemU6IDEuMjVyZW07XG4gICAgYm9yZGVyLXJhZGl1czogMC41cmVtO1xuICAgIHRyYW5zaXRpb246IHdpZHRoIDAuNHMgZWFzZTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xuICAgIC13ZWJraXQtdHJhbnNmb3JtLXN0eWxlOiBwcmVzZXJ2ZS0zZDtcbiAgICAtd2Via2l0LWJhY2tmYWNlLXZpc2liaWxpdHk6IGhpZGRlbjtcbiAgICBjb2xvcjogI2ZmZmZmZjsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuaWNvbi5wcmltYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2FkNTlmZiwgIzc2NTlmZik7XG4gICAgICBib3gtc2hhZG93OiAwIDNweCAwIDAgIzdlNGRkYiwgMCAycHggOHB4IDAgIzkyNTlmZiwgMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uLnN1Y2Nlc3Mge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMDBkOWJmLCAjMDBkOTc3KTtcbiAgICAgIGJveC1zaGFkb3c6IDAgM3B4IDAgMCAjMDBiYjg1LCAwIDJweCA4cHggMCAjMDBkOTliLCAwIDRweCAxMHB4IDAgcmdiYSgzMywgNywgNzcsIDAuNSk7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLmljb24uaW5mbyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMwMGIzZmYsICMwMDg4ZmYpO1xuICAgICAgYm94LXNoYWRvdzogMCAzcHggMCAwICMwMDg3ZGIsIDAgMnB4IDhweCAwICMwMDlkZmYsIDAgNHB4IDEwcHggMCByZ2JhKDMzLCA3LCA3NywgMC41KTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuaWNvbi53YXJuaW5nIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmY2MwMCwgI2ZmYTEwMCk7XG4gICAgICBib3gtc2hhZG93OiAwIDNweCAwIDAgI2RiOWQwMCwgMCAycHggOHB4IDAgI2ZmYjYwMCwgMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uLmRhbmdlciB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZjM4YWMsICNmZjM4NmEpO1xuICAgICAgYm94LXNoYWRvdzogMCAzcHggMCAwICNkYjMwNzgsIDAgMnB4IDhweCAwICNmZjM4OGIsIDAgNHB4IDEwcHggMCByZ2JhKDMzLCA3LCA3NywgMC41KTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICBib3gtc2hhZG93OiAwIDNweCAwIDAgIzdlNGRkYiwgMCAycHggOHB4IDAgIzkyNTlmZiwgMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpO1xuICAgICAgY29sb3I6ICNhMWExZTU7IH1cbiAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjNDYzZjkyOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjYjk3MGZmLCAjODk3MGZmKTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zdWNjZXNzIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzI0ZGVjOCwgIzI0ZGU4YSk7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24uaW5mbyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMyNGJkZmYsICMyNDk5ZmYpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZkMzI0LCAjZmZhZTI0KTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5kYW5nZXIge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmY1NGI4LCAjZmY1NDdmKTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjYjk3MGZmLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTQpKTsgfVxuICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQub2ZmIHtcbiAgICBjb2xvcjogI2ExYTFlNTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ge1xuICAgICAgY29sb3I6ICNhMWExZTU7IH1cbiAgICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ucHJpbWFyeSwgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5zdWNjZXNzLCAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLmluZm8sIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ud2FybmluZywgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5kYW5nZXIge1xuICAgICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIHRyYW5zcGFyZW50LCB0cmFuc3BhcmVudCk7IH1cbiAgICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQub2ZmIC50aXRsZSB7XG4gICAgICBjb2xvcjogI2ExYTFlNTsgfVxuICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCB0cmFuc3BhcmVudDsgfVxuICAgIFtkaXI9bHRyXSAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgICAgcGFkZGluZzogMCAwLjVyZW0gMCAwLjc1cmVtOyB9XG4gICAgW2Rpcj1ydGxdIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgICBwYWRkaW5nOiAwIDAuNzVyZW0gMCAwLjVyZW07IH1cbiAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIGxhYmVsIHtcbiAgICBmb250LXNpemU6IDcwJTtcbiAgICBsaW5lLWhlaWdodDogMC4xcmVtO1xuICAgIHdvcmQtd3JhcDogYnJlYWstd29yZDsgfVxuICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLnRpdGxlIHtcbiAgICBmb250LWZhbWlseTogRXhvO1xuICAgIGZvbnQtc2l6ZTogODUlO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgY29sb3I6ICNmZmZmZmY7XG4gICAgd29yZC13cmFwOiBicmVhay13b3JkOyB9XG4gIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuc3RhdHVzIHtcbiAgICBmb250LXNpemU6IDEwMCU7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgIGNvbG9yOiAjYTFhMWU1OyB9XG5cbi8qXG4gICAgICA6aG9zdCBjYW4gYmUgcHJlZml4ZWRcbiAgICAgIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi84ZDBlZTM0OTM5ZjE0YzA3ODc2ZDIyMmMyNWI0MDVlZDQ1OGEzNGQzL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDFcblxuICAgICAgV2UgaGF2ZSB0byB1c2UgOmhvc3QgaW5zdGVkIG9mIDpob3N0LWNvbnRleHQoJHRoZW1lKSwgdG8gYmUgYWJsZSB0byBwcmVmaXggdGhlbWUgY2xhc3NcbiAgICAgIHdpdGggc29tZXRoaW5nIGRlZmluZWQgaW5zaWRlIG9mIEBjb250ZW50LCBieSBwcmVmaXhpbmcgJi5cbiAgICAgIEZvciBleGFtcGxlIHRoaXMgc2NzcyBjb2RlOlxuICAgICAgICAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLnNvbWUtc2VsZWN0b3IgJiB7XG4gICAgICAgICAgICAuLi5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIFdpbGwgcmVzdWx0IGluIG5leHQgY3NzOlxuICAgICAgICAuc29tZS1zZWxlY3RvciAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLi4uXG4gICAgICAgIH1cblxuICAgICAgSXQgZG9lc24ndCB3b3JrIHdpdGggOmhvc3QtY29udGV4dCBiZWNhdXNlIGFuZ3VsYXIgc3BsaXR0aW5nIGl0IGluIHR3byBzZWxlY3RvcnMgYW5kIHJlbW92ZXNcbiAgICAgIHByZWZpeCBpbiBvbmUgb2YgdGhlIHNlbGVjdG9ycy5cbiAgICAqL1xuLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIHtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgaGVpZ2h0OiA4MCU7XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2hhZG93OiAwIDAgMCAwICNkYmRiZGIsIG5vbmU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkNWRiZTA7XG4gIGJvcmRlci10b3AtY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci10b3Atc3R5bGU6IHNvbGlkO1xuICBib3JkZXItdG9wLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1yaWdodC1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLXJpZ2h0LXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXJpZ2h0LXdpZHRoOiAxcHg7XG4gIGJvcmRlci1ib3R0b20tY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItbGVmdC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1sZWZ0LXdpZHRoOiAxcHg7XG4gIGJvcmRlci1pbWFnZS1zb3VyY2U6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1zbGljZTogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLXdpZHRoOiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2Utb3V0c2V0OiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2UtcmVwZWF0OiBpbml0aWFsOyB9XG4gIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi1jb250YWluZXIge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBwYWRkaW5nOiAwLjYyNXJlbTsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogMi4yNXJlbTtcbiAgICBoZWlnaHQ6IDIuNzVyZW07XG4gICAgZm9udC1zaXplOiAxLjI1cmVtO1xuICAgIGJvcmRlci1yYWRpdXM6IDAuMTdyZW07XG4gICAgdHJhbnNpdGlvbjogd2lkdGggMC40cyBlYXNlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xuICAgIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgIGNvbG9yOiAjZmZmZmZmOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNzNhMWZmLCAjNzNhMWZmKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgIzYzOGFkYiwgMCAwIDIwcHggMCAjNzNhMWZmOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLnN1Y2Nlc3Mge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNWRjZmUzLCAjNWRjZmUzKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgIzUwYjJjMywgMCAwIDIwcHggMCAjNWRjZmUzOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLmluZm8ge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjYmE3ZmVjLCAjYmE3ZmVjKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgI2EwNmRjYiwgMCAwIDIwcHggMCAjYmE3ZmVjOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMzZiLCAjZmZhMzZiKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgI2RiOGM1YywgMCAwIDIwcHggMCAjZmZhMzZiOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLmRhbmdlciB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZjZiODMsICNmZjZiODMpO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDAgMCAjZGI1YzcxLCAwIDAgMjBweCAwICNmZjZiODM7IH1cbiAgICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlZGYyZjU7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICNjY2QwZDMsIDAgMCAwIDAgI2VkZjJmNTtcbiAgICAgIGNvbG9yOiAjYTRhYmIzOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLnByaW1hcnksIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi5zdWNjZXNzLCAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24uaW5mbywgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLndhcm5pbmcsIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi5kYW5nZXIsIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYm94LXNoYWRvdzogbm9uZTsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQ6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6IHdoaXRlOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjODdhZWZmLCAjODdhZWZmKTsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zdWNjZXNzIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzc0ZDZlNywgIzc0ZDZlNyk7IH1cbiAgICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24uaW5mbyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNjNDkxZWYsICNjNDkxZWYpOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZiMDgwLCAjZmZiMDgwKTsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5kYW5nZXIge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmY4MDk0LCAjZmY4MDk0KTsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZjBmNGY2LCAjZjBmNGY2KTsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQub2ZmIHtcbiAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ge1xuICAgICAgY29sb3I6ICNhNGFiYjM7IH1cbiAgICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ucHJpbWFyeSwgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5zdWNjZXNzLCAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLmluZm8sIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ud2FybmluZywgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5kYW5nZXIge1xuICAgICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIHRyYW5zcGFyZW50LCB0cmFuc3BhcmVudCk7IH1cbiAgICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IH1cbiAgICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQub2ZmIC50aXRsZSB7XG4gICAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCB0cmFuc3BhcmVudDsgfVxuICAgIFtkaXI9bHRyXSAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgICAgcGFkZGluZzogMCAwLjVyZW0gMCAwLjc1cmVtOyB9XG4gICAgW2Rpcj1ydGxdIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgICBwYWRkaW5nOiAwIDAuNzVyZW0gMCAwLjVyZW07IH1cbiAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIGxhYmVsIHtcbiAgICBmb250LXNpemU6IDcwJTtcbiAgICBsaW5lLWhlaWdodDogMC4xcmVtO1xuICAgIHdvcmQtd3JhcDogYnJlYWstd29yZDsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLnRpdGxlIHtcbiAgICBmb250LWZhbWlseTogUm9ib3RvO1xuICAgIGZvbnQtc2l6ZTogODUlO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgY29sb3I6ICMxODE4MTg7XG4gICAgd29yZC13cmFwOiBicmVhay13b3JkOyB9XG4gIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuc3RhdHVzIHtcbiAgICBmb250LXNpemU6IDEwMCU7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgIGNvbG9yOiAjYTRhYmIzOyB9XG5cbi5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi1jb250YWluZXIge1xuICBoZWlnaHQ6IGF1dG87IH1cblxuLyogIEBpbmNsdWRlIG5iLWZvci10aGVtZShjb3NtaWMpIHtcclxuICAgIG5iLWNhcmQge1xyXG4gICAgICAmLm9mZiAuaWNvbi1jb250YWluZXIge1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLWx0cihib3JkZXItcmlnaHQsIDFweCBzb2xpZCBuYi10aGVtZShzZXBhcmF0b3IpKTtcclxuICAgICAgICBAaW5jbHVkZSBuYi1ydGwoYm9yZGVyLWxlZnQsIDFweCBzb2xpZCBuYi10aGVtZShzZXBhcmF0b3IpKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuZGV0YWlscyB7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItbHRyKHBhZGRpbmctbGVmdCwgMS4yNXJlbSk7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItcnRsKHBhZGRpbmctcmlnaHQsIDEuMjVyZW0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuaWNvbiB7XHJcbiAgICAgICAgd2lkdGg6IDdyZW07XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogNC41cmVtO1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLWx0cihib3JkZXItcmFkaXVzLCBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpIDAgMCBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpKTtcclxuICAgICAgICBAaW5jbHVkZSBuYi1ydGwoYm9yZGVyLXJhZGl1cywgMCBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpIG5iLXRoZW1lKGNhcmQtYm9yZGVyLXJhZGl1cykgMCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50aXRsZSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IG5iLXRoZW1lKGZvbnQtd2VpZ2h0LWJvbGRlcik7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5zdGF0dXMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBuYi10aGVtZShmb250LXdlaWdodC1saWdodCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9Ki9cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuQG1peGluIG5iLXNjcm9sbGJhcnMoJGZnLCAkYmcsICRzaXplLCAkYm9yZGVyLXJhZGl1czogJHNpemUgLyAyKSB7XG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICAgIHdpZHRoOiAkc2l6ZTtcbiAgICBoZWlnaHQ6ICRzaXplO1xuICB9XG5cbiAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XG4gICAgYmFja2dyb3VuZDogJGZnO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiAkYm9yZGVyLXJhZGl1cztcbiAgfVxuXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xuICAgIGJhY2tncm91bmQ6ICRiZztcbiAgfVxuXG4gIC8vIFRPRE86IHJlbW92ZVxuICAvLyBGb3IgSW50ZXJuZXQgRXhwbG9yZXJcbiAgc2Nyb2xsYmFyLWZhY2UtY29sb3I6ICRmZztcbiAgc2Nyb2xsYmFyLXRyYWNrLWNvbG9yOiAkYmc7XG59XG5cbkBtaXhpbiBuYi1yYWRpYWwtZ3JhZGllbnQoJGNvbG9yLTEsICRjb2xvci0yLCAkY29sb3ItMykge1xuICBiYWNrZ3JvdW5kOiAkY29sb3ItMjsgLyogT2xkIGJyb3dzZXJzICovXG4gIGJhY2tncm91bmQ6IC1tb3otcmFkaWFsLWdyYWRpZW50KGJvdHRvbSwgZWxsaXBzZSBjb3ZlciwgJGNvbG9yLTEgMCUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJGNvbG9yLTIgNDUlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICRjb2xvci0zIDEwMCUpOyAvKiBGRjMuNi0xNSAqL1xuICBiYWNrZ3JvdW5kOiAtd2Via2l0LXJhZGlhbC1ncmFkaWVudChib3R0b20sIGVsbGlwc2UgY292ZXIsICRjb2xvci0xIDAlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICRjb2xvci0yIDQ1JSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAkY29sb3ItMyAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cbiAgYmFja2dyb3VuZDogcmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgYm90dG9tLCAkY29sb3ItMSAwJSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAkY29sb3ItMiA0NSUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJGNvbG9yLTMgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xuICBmaWx0ZXI6IHByb2dpZDpkeGltYWdldHJhbnNmb3JtLm1pY3Jvc29mdC5ncmFkaWVudChzdGFydENvbG9yc3RyPSckY29sb3ItMScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZENvbG9yc3RyPSckY29sb3ItMycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyYWRpZW50VHlwZT0xKTsgLyogSUU2LTkgZmFsbGJhY2sgb24gaG9yaXpvbnRhbCBncmFkaWVudCAqL1xufVxuXG5AbWl4aW4gbmItcmlnaHQtZ3JhZGllbnQoJGxlZnQtY29sb3IsICRyaWdodC1jb2xvcikge1xuICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICRsZWZ0LWNvbG9yLCAkcmlnaHQtY29sb3IpO1xufVxuXG5AbWl4aW4gbmItaGVhZGluZ3MoJGZyb206IDEsICR0bzogNikge1xuICBAZm9yICRpIGZyb20gJGZyb20gdGhyb3VnaCAkdG8ge1xuICAgIGgjeyRpfSB7XG4gICAgICBtYXJnaW46IDA7XG4gICAgfVxuICB9XG59XG5cbkBtaXhpbiBob3Zlci1mb2N1cy1hY3RpdmUge1xuICAmOmZvY3VzLFxuICAmOmFjdGl2ZSxcbiAgJjpob3ZlciB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQG1peGluIGNlbnRlci1ob3Jpem9udGFsLWFic29sdXRlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAwKTtcbiAgbGVmdDogNTAlO1xufVxuXG5AbWl4aW4gaW5zdGFsbC10aHVtYigpIHtcbiAgJHRodW1iLXNlbGVjdG9yczogKFxuICAgICc6Oi13ZWJraXQtc2xpZGVyLXRodW1iJ1xuICAgICc6Oi1tb3otcmFuZ2UtdGh1bWInXG4gICAgJzo6LW1zLXRodW1iJ1xuICApO1xuXG4gIEBlYWNoICRzZWxlY3RvciBpbiAkdGh1bWItc2VsZWN0b3JzIHtcbiAgICAmI3skc2VsZWN0b3J9IHtcbiAgICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcbiAgICAgIC1tb3otYXBwZWFyYW5jZTogbm9uZTtcbiAgICAgIEBjb250ZW50O1xuICAgIH1cbiAgfVxufVxuXG5AbWl4aW4gaW5zdGFsbC10cmFjaygpIHtcbiAgJHRodW1iLXNlbGVjdG9yczogKFxuICAgICc6Oi13ZWJraXQtc2xpZGVyLXJ1bm5hYmxlLXRyYWNrJ1xuICAgICc6Oi1tb3otcmFuZ2UtdHJhY2snXG4gICAgJzo6LW1zLXRyYWNrJ1xuICApO1xuXG4gIEBlYWNoICRzZWxlY3RvciBpbiAkdGh1bWItc2VsZWN0b3JzIHtcbiAgICAmI3skc2VsZWN0b3J9IHtcbiAgICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcbiAgICAgIC1tb3otYXBwZWFyYW5jZTogbm9uZTtcbiAgICAgIEBjb250ZW50O1xuICAgIH1cbiAgfVxufVxuXG5AbWl4aW4gaW5zdGFsbC1wbGFjZWhvbGRlcigkY29sb3IsICRmb250LXNpemUpIHtcbiAgJHBsYWNlaG9sZGVyLXNlbGVjdG9yczogKFxuICAgICc6Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXInXG4gICAgJzo6LW1vei1wbGFjZWhvbGRlcidcbiAgICAnOi1tb3otcGxhY2Vob2xkZXInXG4gICAgJzotbXMtaW5wdXQtcGxhY2Vob2xkZXInXG4gICk7XG5cbiAgJjo6cGxhY2Vob2xkZXIge1xuICAgIEBpbmNsdWRlIHBsYWNlaG9sZGVyKCRjb2xvciwgJGZvbnQtc2l6ZSk7XG4gIH1cblxuICBAZWFjaCAkc2VsZWN0b3IgaW4gJHBsYWNlaG9sZGVyLXNlbGVjdG9ycyB7XG4gICAgJiN7JHNlbGVjdG9yfSB7XG4gICAgICBAaW5jbHVkZSBwbGFjZWhvbGRlcigkY29sb3IsICRmb250LXNpemUpO1xuICAgIH1cblxuICAgICY6Zm9jdXMjeyRzZWxlY3Rvcn0ge1xuICAgICAgQGluY2x1ZGUgcGxhY2Vob2xkZXItZm9jdXMoKTtcbiAgICB9XG4gIH1cbn1cblxuQG1peGluIHBsYWNlaG9sZGVyKCRjb2xvciwgJGZvbnQtc2l6ZSkge1xuICBjb2xvcjogJGNvbG9yO1xuICBmb250LXNpemU6ICRmb250LXNpemU7XG4gIG9wYWNpdHk6IDE7XG4gIHRyYW5zaXRpb246IG9wYWNpdHkgMC4zcyBlYXNlO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbn1cblxuQG1peGluIHBsYWNlaG9sZGVyLWZvY3VzKCkge1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuM3MgZWFzZTtcbn1cblxuQG1peGluIGFuaW1hdGlvbigkYW5pbWF0ZS4uLikge1xuICAkbWF4OiBsZW5ndGgoJGFuaW1hdGUpO1xuICAkYW5pbWF0aW9uczogJyc7XG5cbiAgQGZvciAkaSBmcm9tIDEgdGhyb3VnaCAkbWF4IHtcbiAgICAkYW5pbWF0aW9uczogI3skYW5pbWF0aW9ucyArIG50aCgkYW5pbWF0ZSwgJGkpfTtcblxuICAgIEBpZiAkaSA8ICRtYXgge1xuICAgICAgJGFuaW1hdGlvbnM6ICN7JGFuaW1hdGlvbnMgKyAnLCAnfTtcbiAgICB9XG4gIH1cbiAgLXdlYmtpdC1hbmltYXRpb246ICRhbmltYXRpb25zO1xuICAtbW96LWFuaW1hdGlvbjogICAgJGFuaW1hdGlvbnM7XG4gIC1vLWFuaW1hdGlvbjogICAgICAkYW5pbWF0aW9ucztcbiAgYW5pbWF0aW9uOiAgICAgICAgICRhbmltYXRpb25zO1xufVxuXG5AbWl4aW4ga2V5ZnJhbWVzKCRhbmltYXRpb25OYW1lKSB7XG4gIEAtd2Via2l0LWtleWZyYW1lcyAjeyRhbmltYXRpb25OYW1lfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbiAgQC1tb3ota2V5ZnJhbWVzICN7JGFuaW1hdGlvbk5hbWV9IHtcbiAgICBAY29udGVudDtcbiAgfVxuICBALW8ta2V5ZnJhbWVzICN7JGFuaW1hdGlvbk5hbWV9IHtcbiAgICBAY29udGVudDtcbiAgfVxuICBAa2V5ZnJhbWVzICN7JGFuaW1hdGlvbk5hbWV9IHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG4vKipcbiAqIFRoaXMgbWl4aW4gZ2VuZXJhdGVzIGtleWZhbWVzLlxuICogQmVjYXVzZSBvZiBhbGwga2V5ZnJhbWVzIGNhbid0IGJlIHNjb3BlZCxcbiAqIHdlIG5lZWQgdG8gcHV0cyB1bmlxdWUgbmFtZSBpbiBlYWNoIGJ0bi1wdWxzZSBjYWxsLlxuICovXG5AbWl4aW4gYnRuLXB1bHNlKCRuYW1lLCAkY29sb3IpIHtcbiAgJi5idG4tcHVsc2Uge1xuICAgIEBpbmNsdWRlIGFuaW1hdGlvbihidG4tI3skbmFtZX0tcHVsc2UgMS41cyBpbmZpbml0ZSk7XG4gIH1cblxuICBAaW5jbHVkZSBrZXlmcmFtZXMoYnRuLSN7JG5hbWV9LXB1bHNlKSB7XG4gICAgMCUge1xuICAgICAgYm94LXNoYWRvdzogbm9uZTtcbiAgICAgIG9wYWNpdHk6IG5iLXRoZW1lKGJ0bi1kaXNhYmxlZC1vcGFjaXR5KTtcbiAgICB9XG4gICAgNTAlIHtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAxcmVtIDAgJGNvbG9yO1xuICAgICAgb3BhY2l0eTogMC44O1xuICAgIH1cbiAgICAxMDAlIHtcbiAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgICBvcGFjaXR5OiBuYi10aGVtZShidG4tZGlzYWJsZWQtb3BhY2l0eSk7XG4gICAgfVxuICB9XG59XG5cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cblxuQG1peGluIF9wcmVwZW5kLXdpdGgtc2VsZWN0b3IoJHNlbGVjdG9yLCAkcHJvcDogbnVsbCwgJHZhbHVlOiBudWxsKSB7XG4gICN7JHNlbGVjdG9yfSAmIHtcbiAgICBAaWYgJHByb3AgIT0gbnVsbCB7XG4gICAgICAjeyRwcm9wfTogJHZhbHVlO1xuICAgIH1cblxuICAgIEBjb250ZW50O1xuICB9XG59XG5cbkBtaXhpbiBuYi1sdHIoJHByb3A6IG51bGwsICR2YWx1ZTogbnVsbCkge1xuICBAaW5jbHVkZSBfcHJlcGVuZC13aXRoLXNlbGVjdG9yKCdbZGlyPWx0cl0nLCAkcHJvcCwgJHZhbHVlKSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQG1peGluIG5iLXJ0bCgkcHJvcDogbnVsbCwgJHZhbHVlOiBudWxsKSB7XG4gIEBpbmNsdWRlIF9wcmVwZW5kLXdpdGgtc2VsZWN0b3IoJ1tkaXI9cnRsXScsICRwcm9wLCAkdmFsdWUpIHtcbiAgICBAY29udGVudDtcbiAgfTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuLy8vIFNsaWdodGx5IGxpZ2h0ZW4gYSBjb2xvclxuLy8vIEBhY2Nlc3MgcHVibGljXG4vLy8gQHBhcmFtIHtDb2xvcn0gJGNvbG9yIC0gY29sb3IgdG8gdGludFxuLy8vIEBwYXJhbSB7TnVtYmVyfSAkcGVyY2VudGFnZSAtIHBlcmNlbnRhZ2Ugb2YgYCRjb2xvcmAgaW4gcmV0dXJuZWQgY29sb3Jcbi8vLyBAcmV0dXJuIHtDb2xvcn1cbkBmdW5jdGlvbiB0aW50KCRjb2xvciwgJHBlcmNlbnRhZ2UpIHtcbiAgQHJldHVybiBtaXgod2hpdGUsICRjb2xvciwgJHBlcmNlbnRhZ2UpO1xufVxuXG4vLy8gU2xpZ2h0bHkgZGFya2VuIGEgY29sb3Jcbi8vLyBAYWNjZXNzIHB1YmxpY1xuLy8vIEBwYXJhbSB7Q29sb3J9ICRjb2xvciAtIGNvbG9yIHRvIHNoYWRlXG4vLy8gQHBhcmFtIHtOdW1iZXJ9ICRwZXJjZW50YWdlIC0gcGVyY2VudGFnZSBvZiBgJGNvbG9yYCBpbiByZXR1cm5lZCBjb2xvclxuLy8vIEByZXR1cm4ge0NvbG9yfVxuQGZ1bmN0aW9uIHNoYWRlKCRjb2xvciwgJHBlcmNlbnRhZ2UpIHtcbiAgQHJldHVybiBtaXgoYmxhY2ssICRjb2xvciwgJHBlcmNlbnRhZ2UpO1xufVxuXG5AZnVuY3Rpb24gbWFwLXNldCgkbWFwLCAka2V5LCAkdmFsdWU6IG51bGwpIHtcbiAgJG5ldzogKCRrZXk6ICR2YWx1ZSk7XG4gIEByZXR1cm4gbWFwLW1lcmdlKCRtYXAsICRuZXcpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuXG5AaW1wb3J0ICcuLi9jb3JlL2Z1bmN0aW9ucyc7XG5AaW1wb3J0ICcuLi9jb3JlL21peGlucyc7XG5cbiR0aGVtZTogKFxuICBmb250LW1haW46IHVucXVvdGUoJ1wiU2Vnb2UgVUlcIiwgUm9ib3RvLCBcIkhlbHZldGljYSBOZXVlXCIsIEFyaWFsLCBzYW5zLXNlcmlmJyksXG4gIGZvbnQtc2Vjb25kYXJ5OiBmb250LW1haW4sXG5cbiAgZm9udC13ZWlnaHQtdGhpbjogMjAwLFxuICBmb250LXdlaWdodC1saWdodDogMzAwLFxuICBmb250LXdlaWdodC1ub3JtYWw6IDQwMCxcbiAgZm9udC13ZWlnaHQtYm9sZGVyOiA1MDAsXG4gIGZvbnQtd2VpZ2h0LWJvbGQ6IDYwMCxcbiAgZm9udC13ZWlnaHQtdWx0cmEtYm9sZDogODAwLFxuXG4gIC8vIFRPRE86IHVzZSBpdCBhcyBhIGRlZmF1bHQgZm9udC1zaXplXG4gIGJhc2UtZm9udC1zaXplOiAxNnB4LFxuXG4gIGZvbnQtc2l6ZS14bGc6IDEuMjVyZW0sXG4gIGZvbnQtc2l6ZS1sZzogMS4xMjVyZW0sXG4gIGZvbnQtc2l6ZTogMXJlbSxcbiAgZm9udC1zaXplLXNtOiAwLjg3NXJlbSxcbiAgZm9udC1zaXplLXhzOiAwLjc1cmVtLFxuXG4gIHJhZGl1czogMC4zNzVyZW0sXG4gIHBhZGRpbmc6IDEuMjVyZW0sXG4gIG1hcmdpbjogMS41cmVtLFxuICBsaW5lLWhlaWdodDogMS4yNSxcblxuICBjb2xvci1iZzogI2ZmZmZmZixcbiAgY29sb3ItYmctYWN0aXZlOiAjZTllZGYyLFxuICBjb2xvci1mZzogI2E0YWJiMyxcbiAgY29sb3ItZmctaGVhZGluZzogIzJhMmEyYSxcbiAgY29sb3ItZmctdGV4dDogIzRiNGI0YixcbiAgY29sb3ItZmctaGlnaGxpZ2h0OiAjNDBkYzdlLFxuXG4gIHNlcGFyYXRvcjogI2ViZWVmMixcblxuICBjb2xvci1ncmF5OiByZ2JhKDgxLCAxMTMsIDE2NSwgMC4xNSksXG4gIGNvbG9yLW5ldXRyYWw6IHRyYW5zcGFyZW50LFxuICBjb2xvci13aGl0ZTogI2ZmZmZmZixcbiAgY29sb3ItZGlzYWJsZWQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC40KSxcblxuICBjb2xvci1wcmltYXJ5OiAjOGE3ZmZmLFxuICBjb2xvci1zdWNjZXNzOiAjNDBkYzdlLFxuICBjb2xvci1pbmZvOiAjNGNhNmZmLFxuICBjb2xvci13YXJuaW5nOiAjZmZhMTAwLFxuICBjb2xvci1kYW5nZXI6ICNmZjRjNmEsXG5cbiAgLy8gVE9ETzogbW92ZSB0byBjb25zdGFudHNcbiAgc29jaWFsLWNvbG9yLWZhY2Vib29rOiAjM2I1OTk4LFxuICBzb2NpYWwtY29sb3ItdHdpdHRlcjogIzU1YWNlZSxcbiAgc29jaWFsLWNvbG9yLWdvb2dsZTogI2RkNGIzOSxcbiAgc29jaWFsLWNvbG9yLWxpbmtlZGluOiAjMDE3N2I1LFxuICBzb2NpYWwtY29sb3ItZ2l0aHViOiAjNmI2YjZiLFxuICBzb2NpYWwtY29sb3Itc3RhY2tvdmVyZmxvdzogIzJmOTZlOCxcbiAgc29jaWFsLWNvbG9yLWRyaWJibGU6ICNmMjY3OTgsXG4gIHNvY2lhbC1jb2xvci1iZWhhbmNlOiAjMDA5M2ZhLFxuXG4gIGJvcmRlci1jb2xvcjogY29sb3ItZ3JheSxcbiAgc2hhZG93OiAwIDJweCAxMnB4IDAgI2RmZTNlYixcblxuICBsaW5rLWNvbG9yOiAjM2RjYzZkLFxuICBsaW5rLWNvbG9yLWhvdmVyOiAjMmVlNTZiLFxuICBsaW5rLWNvbG9yLXZpc2l0ZWQ6IGxpbmstY29sb3IsXG5cbiAgc2Nyb2xsYmFyLWZnOiAjZGFkYWRhLFxuICBzY3JvbGxiYXItYmc6ICNmMmYyZjIsXG4gIHNjcm9sbGJhci13aWR0aDogNXB4LFxuICBzY3JvbGxiYXItdGh1bWItcmFkaXVzOiAyLjVweCxcblxuICByYWRpYWwtZ3JhZGllbnQ6IG5vbmUsXG4gIGxpbmVhci1ncmFkaWVudDogbm9uZSxcblxuICBjYXJkLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBjYXJkLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgY2FyZC1mb250LXdlaWdodDogZm9udC13ZWlnaHQtbm9ybWFsLFxuICBjYXJkLWZnOiBjb2xvci1mZywgLy8gVE9ETzogbm90IHVzZWRcbiAgY2FyZC1mZy10ZXh0OiBjb2xvci1mZy10ZXh0LFxuICBjYXJkLWZnLWhlYWRpbmc6IGNvbG9yLWZnLWhlYWRpbmcsIC8vIFRPRE86IG5vdCB1c2VkXG4gIGNhcmQtYmc6IGNvbG9yLWJnLFxuICBjYXJkLWhlaWdodC14eHNtYWxsOiA5NnB4LFxuICBjYXJkLWhlaWdodC14c21hbGw6IDIxNnB4LFxuICBjYXJkLWhlaWdodC1zbWFsbDogMzM2cHgsXG4gIGNhcmQtaGVpZ2h0LW1lZGl1bTogNDU2cHgsXG4gIGNhcmQtaGVpZ2h0LWxhcmdlOiA1NzZweCxcbiAgY2FyZC1oZWlnaHQteGxhcmdlOiA2OTZweCxcbiAgY2FyZC1oZWlnaHQteHhsYXJnZTogODE2cHgsXG4gIGNhcmQtc2hhZG93OiBzaGFkb3csXG4gIGNhcmQtYm9yZGVyLXdpZHRoOiAwLFxuICBjYXJkLWJvcmRlci10eXBlOiBzb2xpZCxcbiAgY2FyZC1ib3JkZXItY29sb3I6IGNvbG9yLWJnLFxuICBjYXJkLWJvcmRlci1yYWRpdXM6IHJhZGl1cyxcbiAgY2FyZC1wYWRkaW5nOiBwYWRkaW5nLFxuICBjYXJkLW1hcmdpbjogbWFyZ2luLFxuICBjYXJkLWhlYWRlci1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIGNhcmQtaGVhZGVyLWZvbnQtc2l6ZTogZm9udC1zaXplLWxnLFxuICBjYXJkLWhlYWRlci1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZCxcbiAgY2FyZC1zZXBhcmF0b3I6IHNlcGFyYXRvcixcbiAgY2FyZC1oZWFkZXItZmc6IGNvbG9yLWZnLCAvLyBUT0RPOiBub3QgdXNlZFxuICBjYXJkLWhlYWRlci1mZy1oZWFkaW5nOiBjb2xvci1mZy1oZWFkaW5nLFxuICBjYXJkLWhlYWRlci1hY3RpdmUtYmc6IGNvbG9yLWZnLFxuICBjYXJkLWhlYWRlci1hY3RpdmUtZmc6IGNvbG9yLWJnLFxuICBjYXJkLWhlYWRlci1kaXNhYmxlZC1iZzogY29sb3ItZGlzYWJsZWQsXG4gIGNhcmQtaGVhZGVyLXByaW1hcnktYmc6IGNvbG9yLXByaW1hcnksXG4gIGNhcmQtaGVhZGVyLWluZm8tYmc6IGNvbG9yLWluZm8sXG4gIGNhcmQtaGVhZGVyLXN1Y2Nlc3MtYmc6IGNvbG9yLXN1Y2Nlc3MsXG4gIGNhcmQtaGVhZGVyLXdhcm5pbmctYmc6IGNvbG9yLXdhcm5pbmcsXG4gIGNhcmQtaGVhZGVyLWRhbmdlci1iZzogY29sb3ItZGFuZ2VyLFxuICBjYXJkLWhlYWRlci1ib3JkZXItd2lkdGg6IDFweCxcbiAgY2FyZC1oZWFkZXItYm9yZGVyLXR5cGU6IHNvbGlkLFxuICBjYXJkLWhlYWRlci1ib3JkZXItY29sb3I6IGNhcmQtc2VwYXJhdG9yLFxuXG4gIGhlYWRlci1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIGhlYWRlci1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgaGVhZGVyLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgaGVhZGVyLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBoZWFkZXItYmc6IGNvbG9yLWJnLFxuICBoZWFkZXItaGVpZ2h0OiA0Ljc1cmVtLFxuICBoZWFkZXItcGFkZGluZzogMS4yNXJlbSxcbiAgaGVhZGVyLXNoYWRvdzogc2hhZG93LFxuXG4gIGZvb3Rlci1oZWlnaHQ6IDQuNzI1cmVtLFxuICBmb290ZXItcGFkZGluZzogMS4yNXJlbSxcbiAgZm9vdGVyLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBmb290ZXItZmctaGlnaGxpZ2h0OiBjb2xvci1mZy1oZWFkaW5nLFxuICBmb290ZXItYmc6IGNvbG9yLWJnLFxuICBmb290ZXItc2VwYXJhdG9yOiBzZXBhcmF0b3IsXG4gIGZvb3Rlci1zaGFkb3c6IHNoYWRvdyxcblxuICBsYXlvdXQtZm9udC1mYW1pbHk6IGZvbnQtbWFpbixcbiAgbGF5b3V0LWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBsYXlvdXQtbGluZS1oZWlnaHQ6IGxpbmUtaGVpZ2h0LFxuICBsYXlvdXQtZmc6IGNvbG9yLWZnLFxuICBsYXlvdXQtYmc6ICNlYmVmZjUsXG4gIGxheW91dC1taW4taGVpZ2h0OiAxMDB2aCxcbiAgbGF5b3V0LWNvbnRlbnQtd2lkdGg6IDkwMHB4LFxuICBsYXlvdXQtd2luZG93LW1vZGUtbWluLXdpZHRoOiAzMDBweCxcbiAgbGF5b3V0LXdpbmRvdy1tb2RlLW1heC13aWR0aDogMTkyMHB4LFxuICBsYXlvdXQtd2luZG93LW1vZGUtYmc6IGxheW91dC1iZyxcbiAgbGF5b3V0LXdpbmRvdy1tb2RlLXBhZGRpbmctdG9wOiA0Ljc1cmVtLFxuICBsYXlvdXQtd2luZG93LXNoYWRvdzogc2hhZG93LFxuICBsYXlvdXQtcGFkZGluZzogMi4yNXJlbSAyLjI1cmVtIDAuNzVyZW0sXG4gIGxheW91dC1tZWRpdW0tcGFkZGluZzogMS41cmVtIDEuNXJlbSAwLjVyZW0sXG4gIGxheW91dC1zbWFsbC1wYWRkaW5nOiAxcmVtIDFyZW0gMCxcblxuICBzaWRlYmFyLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBzaWRlYmFyLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgc2lkZWJhci1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgc2lkZWJhci1iZzogY29sb3ItYmcsXG4gIHNpZGViYXItaGVpZ2h0OiAxMDB2aCxcbiAgc2lkZWJhci13aWR0aDogMTZyZW0sXG4gIHNpZGViYXItd2lkdGgtY29tcGFjdDogMy41cmVtLFxuICBzaWRlYmFyLXBhZGRpbmc6IHBhZGRpbmcsXG4gIHNpZGViYXItaGVhZGVyLWhlaWdodDogMy41cmVtLFxuICBzaWRlYmFyLWZvb3Rlci1oZWlnaHQ6IDMuNXJlbSxcbiAgc2lkZWJhci1zaGFkb3c6IHNoYWRvdyxcblxuICBtZW51LWZvbnQtZmFtaWx5OiBmb250LXNlY29uZGFyeSxcbiAgbWVudS1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgbWVudS1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZGVyLFxuICBtZW51LWZnOiBjb2xvci1mZy10ZXh0LFxuICBtZW51LWJnOiBjb2xvci1iZyxcbiAgbWVudS1hY3RpdmUtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIG1lbnUtYWN0aXZlLWJnOiBjb2xvci1iZyxcbiAgbWVudS1hY3RpdmUtZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LWJvbGQsXG5cbiAgbWVudS1zdWJtZW51LWJnOiBjb2xvci1iZyxcbiAgbWVudS1zdWJtZW51LWZnOiBjb2xvci1mZy10ZXh0LFxuICBtZW51LXN1Ym1lbnUtYWN0aXZlLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBtZW51LXN1Ym1lbnUtYWN0aXZlLWJnOiBjb2xvci1iZyxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1ib3JkZXItY29sb3I6IGNvbG9yLWZnLWhpZ2hsaWdodCxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1zaGFkb3c6IG5vbmUsXG4gIG1lbnUtc3VibWVudS1ob3Zlci1mZzogbWVudS1zdWJtZW51LWFjdGl2ZS1mZyxcbiAgbWVudS1zdWJtZW51LWhvdmVyLWJnOiBtZW51LXN1Ym1lbnUtYmcsXG4gIG1lbnUtc3VibWVudS1pdGVtLWJvcmRlci13aWR0aDogMC4xMjVyZW0sXG4gIG1lbnUtc3VibWVudS1pdGVtLWJvcmRlci1yYWRpdXM6IHJhZGl1cyxcbiAgbWVudS1zdWJtZW51LWl0ZW0tcGFkZGluZzogMC41cmVtIDFyZW0sXG4gIG1lbnUtc3VibWVudS1pdGVtLWNvbnRhaW5lci1wYWRkaW5nOiAwIDEuMjVyZW0sXG4gIG1lbnUtc3VibWVudS1wYWRkaW5nOiAwLjVyZW0sXG5cbiAgbWVudS1ncm91cC1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZGVyLFxuICBtZW51LWdyb3VwLWZvbnQtc2l6ZTogMC44NzVyZW0sXG4gIG1lbnUtZ3JvdXAtZmc6IGNvbG9yLWZnLFxuICBtZW51LWdyb3VwLXBhZGRpbmc6IDFyZW0gMS4yNXJlbSxcbiAgbWVudS1pdGVtLXBhZGRpbmc6IDAuNjc1cmVtIDAuNzVyZW0sXG4gIG1lbnUtaXRlbS1zZXBhcmF0b3I6IHNlcGFyYXRvcixcbiAgbWVudS1pY29uLWZvbnQtc2l6ZTogMi41cmVtLFxuICBtZW51LWljb24tbWFyZ2luOiAwIDAuMjVyZW0gMCxcbiAgbWVudS1pY29uLWNvbG9yOiBjb2xvci1mZyxcbiAgbWVudS1pY29uLWFjdGl2ZS1jb2xvcjogY29sb3ItZmctaGVhZGluZyxcblxuICB0YWJzLWZvbnQtZmFtaWx5OiBmb250LXNlY29uZGFyeSxcbiAgdGFicy1mb250LXNpemU6IGZvbnQtc2l6ZS1sZyxcbiAgdGFicy1jb250ZW50LWZvbnQtZmFtaWx5OiBmb250LW1haW4sXG4gIHRhYnMtY29udGVudC1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgdGFicy1hY3RpdmUtYmc6IHRyYW5zcGFyZW50LFxuICB0YWJzLWFjdGl2ZS1mb250LXdlaWdodDogY2FyZC1oZWFkZXItZm9udC13ZWlnaHQsXG4gIHRhYnMtcGFkZGluZzogcGFkZGluZyxcbiAgdGFicy1jb250ZW50LXBhZGRpbmc6IDAsXG4gIHRhYnMtaGVhZGVyLWJnOiB0cmFuc3BhcmVudCxcbiAgdGFicy1zZXBhcmF0b3I6IHNlcGFyYXRvcixcbiAgdGFicy1mZzogY29sb3ItZmcsXG4gIHRhYnMtZmctdGV4dDogY29sb3ItZmctdGV4dCxcbiAgdGFicy1mZy1oZWFkaW5nOiBjb2xvci1mZy1oZWFkaW5nLFxuICB0YWJzLWJnOiB0cmFuc3BhcmVudCxcbiAgdGFicy1zZWxlY3RlZDogY29sb3Itc3VjY2VzcyxcblxuICByb3V0ZS10YWJzLWZvbnQtZmFtaWx5OiBmb250LXNlY29uZGFyeSxcbiAgcm91dGUtdGFicy1mb250LXNpemU6IGZvbnQtc2l6ZS1sZyxcbiAgcm91dGUtdGFicy1hY3RpdmUtYmc6IHRyYW5zcGFyZW50LFxuICByb3V0ZS10YWJzLWFjdGl2ZS1mb250LXdlaWdodDogY2FyZC1oZWFkZXItZm9udC13ZWlnaHQsXG4gIHJvdXRlLXRhYnMtcGFkZGluZzogcGFkZGluZyxcbiAgcm91dGUtdGFicy1oZWFkZXItYmc6IHRyYW5zcGFyZW50LFxuICByb3V0ZS10YWJzLXNlcGFyYXRvcjogc2VwYXJhdG9yLFxuICByb3V0ZS10YWJzLWZnOiBjb2xvci1mZyxcbiAgcm91dGUtdGFicy1mZy1oZWFkaW5nOiBjb2xvci1mZy1oZWFkaW5nLFxuICByb3V0ZS10YWJzLWJnOiB0cmFuc3BhcmVudCxcbiAgcm91dGUtdGFicy1zZWxlY3RlZDogY29sb3Itc3VjY2VzcyxcblxuICB1c2VyLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICB1c2VyLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgdXNlci1iZzogY29sb3ItYmcsXG4gIHVzZXItZmc6IGNvbG9yLWZnLFxuICB1c2VyLWZnLWhpZ2hsaWdodDogI2JjYzNjYyxcbiAgdXNlci1mb250LWZhbWlseS1zZWNvbmRhcnk6IGZvbnQtc2Vjb25kYXJ5LFxuICB1c2VyLXNpemUtc21hbGw6IDEuNXJlbSxcbiAgdXNlci1zaXplLW1lZGl1bTogMi41cmVtLFxuICB1c2VyLXNpemUtbGFyZ2U6IDMuMjVyZW0sXG4gIHVzZXItc2l6ZS14bGFyZ2U6IDRyZW0sXG5cbiAgcG9wb3Zlci1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgcG9wb3Zlci1iZzogY29sb3ItYmcsXG4gIHBvcG92ZXItYm9yZGVyOiBjb2xvci1zdWNjZXNzLFxuICBwb3BvdmVyLXNoYWRvdzogbm9uZSxcblxuICBjb250ZXh0LW1lbnUtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIGNvbnRleHQtbWVudS1hY3RpdmUtZmc6IGNvbG9yLXdoaXRlLFxuICBjb250ZXh0LW1lbnUtYWN0aXZlLWJnOiBjb2xvci1zdWNjZXNzLFxuXG4gIGFjdGlvbnMtZm9udC1zaXplOiBmb250LXNpemUsXG4gIGFjdGlvbnMtZm9udC1mYW1pbHk6IGZvbnQtc2Vjb25kYXJ5LFxuICBhY3Rpb25zLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgYWN0aW9ucy1mZzogY29sb3ItZmcsXG4gIGFjdGlvbnMtYmc6IGNvbG9yLWJnLFxuICBhY3Rpb25zLXNlcGFyYXRvcjogc2VwYXJhdG9yLFxuICBhY3Rpb25zLXBhZGRpbmc6IHBhZGRpbmcsXG4gIGFjdGlvbnMtc2l6ZS1zbWFsbDogMS41cmVtLFxuICBhY3Rpb25zLXNpemUtbWVkaXVtOiAyLjI1cmVtLFxuICBhY3Rpb25zLXNpemUtbGFyZ2U6IDMuNXJlbSxcblxuICBzZWFyY2gtYnRuLW9wZW4tZmc6IGNvbG9yLWZnLFxuICBzZWFyY2gtYnRuLWNsb3NlLWZnOlx0Y29sb3ItZmcsXG4gIHNlYXJjaC1iZzogbGF5b3V0LWJnLFxuICBzZWFyY2gtYmctc2Vjb25kYXJ5OiBjb2xvci1mZyxcbiAgc2VhcmNoLXRleHQ6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIHNlYXJjaC1pbmZvOiBjb2xvci1mZyxcbiAgc2VhcmNoLWRhc2g6IGNvbG9yLWZnLFxuICBzZWFyY2gtcGxhY2Vob2xkZXI6IGNvbG9yLWZnLFxuXG4gIHNtYXJ0LXRhYmxlLWhlYWRlci1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIHNtYXJ0LXRhYmxlLWhlYWRlci1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgc21hcnQtdGFibGUtaGVhZGVyLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkLFxuICBzbWFydC10YWJsZS1oZWFkZXItbGluZS1oZWlnaHQ6IGxpbmUtaGVpZ2h0LFxuICBzbWFydC10YWJsZS1oZWFkZXItZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIHNtYXJ0LXRhYmxlLWhlYWRlci1iZzogY29sb3ItYmcsXG5cbiAgc21hcnQtdGFibGUtZm9udC1mYW1pbHk6IGZvbnQtbWFpbixcbiAgc21hcnQtdGFibGUtZm9udC1zaXplOiBmb250LXNpemUsXG4gIHNtYXJ0LXRhYmxlLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ub3JtYWwsXG4gIHNtYXJ0LXRhYmxlLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgc21hcnQtdGFibGUtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIHNtYXJ0LXRhYmxlLWJnOiBjb2xvci1iZyxcblxuICBzbWFydC10YWJsZS1iZy1ldmVuOiAjZjVmN2ZjLFxuICBzbWFydC10YWJsZS1mZy1zZWNvbmRhcnk6IGNvbG9yLWZnLFxuICBzbWFydC10YWJsZS1iZy1hY3RpdmU6ICNlNmYzZmYsXG4gIHNtYXJ0LXRhYmxlLXBhZGRpbmc6IDAuODc1cmVtIDEuMjVyZW0sXG4gIHNtYXJ0LXRhYmxlLWZpbHRlci1wYWRkaW5nOiAwLjM3NXJlbSAwLjVyZW0sXG4gIHNtYXJ0LXRhYmxlLXNlcGFyYXRvcjogc2VwYXJhdG9yLFxuICBzbWFydC10YWJsZS1ib3JkZXItcmFkaXVzOiByYWRpdXMsXG5cbiAgc21hcnQtdGFibGUtcGFnaW5nLWJvcmRlci1jb2xvcjogc2VwYXJhdG9yLFxuICBzbWFydC10YWJsZS1wYWdpbmctYm9yZGVyLXdpZHRoOiAxcHgsXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1mZy1hY3RpdmU6ICNmZmZmZmYsXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1iZy1hY3RpdmU6IGNvbG9yLXN1Y2Nlc3MsXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1ob3ZlcjogcmdiYSgwLCAwLCAwLCAwLjA1KSxcblxuICB0b2FzdGVyLWJnOiBjb2xvci1wcmltYXJ5LFxuICB0b2FzdGVyLWZnLWRlZmF1bHQ6IGNvbG9yLWludmVyc2UsXG4gIHRvYXN0ZXItYnRuLWNsb3NlLWJnOiB0cmFuc3BhcmVudCxcbiAgdG9hc3Rlci1idG4tY2xvc2UtZmc6IHRvYXN0ZXItZmctZGVmYXVsdCxcbiAgdG9hc3Rlci1zaGFkb3c6IHNoYWRvdyxcblxuICB0b2FzdGVyLWZnOiBjb2xvci13aGl0ZSxcbiAgdG9hc3Rlci1zdWNjZXNzOiBjb2xvci1zdWNjZXNzLFxuICB0b2FzdGVyLWluZm86IGNvbG9yLWluZm8sXG4gIHRvYXN0ZXItd2FybmluZzogY29sb3Itd2FybmluZyxcbiAgdG9hc3Rlci13YWl0OiBjb2xvci1wcmltYXJ5LFxuICB0b2FzdGVyLWVycm9yOiBjb2xvci1kYW5nZXIsXG5cbiAgYnRuLWZnOiBjb2xvci13aGl0ZSxcbiAgYnRuLWZvbnQtZmFtaWx5OiBmb250LXNlY29uZGFyeSxcbiAgYnRuLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgYnRuLWRpc2FibGVkLW9wYWNpdHk6IDAuMyxcbiAgYnRuLWN1cnNvcjogZGVmYXVsdCxcblxuICBidG4tcHJpbWFyeS1iZzogY29sb3ItcHJpbWFyeSxcbiAgYnRuLXNlY29uZGFyeS1iZzogdHJhbnNwYXJlbnQsXG4gIGJ0bi1pbmZvLWJnOiBjb2xvci1pbmZvLFxuICBidG4tc3VjY2Vzcy1iZzogY29sb3Itc3VjY2VzcyxcbiAgYnRuLXdhcm5pbmctYmc6IGNvbG9yLXdhcm5pbmcsXG4gIGJ0bi1kYW5nZXItYmc6IGNvbG9yLWRhbmdlcixcblxuICBidG4tc2Vjb25kYXJ5LWJvcmRlcjogI2RhZGZlNixcbiAgYnRuLXNlY29uZGFyeS1ib3JkZXItd2lkdGg6IDJweCxcblxuICBidG4tcGFkZGluZy15LWxnOiAwLjg3NXJlbSxcbiAgYnRuLXBhZGRpbmcteC1sZzogMS43NXJlbSxcbiAgYnRuLWZvbnQtc2l6ZS1sZzogZm9udC1zaXplLWxnLFxuXG4gIC8vIGRlZmF1bHQgc2l6ZVxuICBidG4tcGFkZGluZy15LW1kOiAwLjc1cmVtLFxuICBidG4tcGFkZGluZy14LW1kOiAxLjVyZW0sXG4gIGJ0bi1mb250LXNpemUtbWQ6IDFyZW0sXG5cbiAgYnRuLXBhZGRpbmcteS1zbTogMC42MjVyZW0sXG4gIGJ0bi1wYWRkaW5nLXgtc206IDEuNXJlbSxcbiAgYnRuLWZvbnQtc2l6ZS1zbTogMC44NzVyZW0sXG5cbiAgYnRuLXBhZGRpbmcteS10bjogMC41cmVtLFxuICBidG4tcGFkZGluZy14LXRuOiAxLjI1cmVtLFxuICBidG4tZm9udC1zaXplLXRuOiAwLjc1cmVtLFxuXG4gIGJ0bi1ib3JkZXItcmFkaXVzOiByYWRpdXMsXG4gIGJ0bi1yZWN0YW5nbGUtYm9yZGVyLXJhZGl1czogMC4yNXJlbSxcbiAgYnRuLXNlbWktcm91bmQtYm9yZGVyLXJhZGl1czogMC43NXJlbSxcbiAgYnRuLXJvdW5kLWJvcmRlci1yYWRpdXM6IDEuNXJlbSxcblxuICBidG4taGVyby1zaGFkb3c6IG5vbmUsXG4gIGJ0bi1oZXJvLXRleHQtc2hhZG93OiBub25lLFxuICBidG4taGVyby1iZXZlbC1zaXplOiAwIDAgMCAwLFxuICBidG4taGVyby1nbG93LXNpemU6IDAgMCAwIDAsXG4gIGJ0bi1oZXJvLXByaW1hcnktZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXN1Y2Nlc3MtZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXdhcm5pbmctZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLWluZm8tZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLWRhbmdlci1nbG93LXNpemU6IGJ0bi1oZXJvLWdsb3ctc2l6ZSxcbiAgYnRuLWhlcm8tc2Vjb25kYXJ5LWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1kZWdyZWU6IDIwZGVnLFxuICBidG4taGVyby1wcmltYXJ5LWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby1zdWNjZXNzLWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby13YXJuaW5nLWRlZ3JlZTogMTBkZWcsXG4gIGJ0bi1oZXJvLWluZm8tZGVncmVlOiAtMTBkZWcsXG4gIGJ0bi1oZXJvLWRhbmdlci1kZWdyZWU6IC0yMGRlZyxcbiAgYnRuLWhlcm8tc2Vjb25kYXJ5LWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby1ib3JkZXItcmFkaXVzOiByYWRpdXMsXG5cbiAgYnRuLW91dGxpbmUtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIGJ0bi1vdXRsaW5lLWhvdmVyLWZnOiAjZmZmZmZmLFxuICBidG4tb3V0bGluZS1mb2N1cy1mZzogY29sb3ItZmctaGVhZGluZyxcblxuICBidG4tZ3JvdXAtYmc6IGxheW91dC1iZyxcbiAgYnRuLWdyb3VwLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBidG4tZ3JvdXAtc2VwYXJhdG9yOiAjZGFkZmU2LFxuXG4gIGZvcm0tY29udHJvbC10ZXh0LXByaW1hcnktY29sb3I6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIGZvcm0tY29udHJvbC10ZXh0LXNlY29uZGFyeS1jb2xvcjogY29sb3ItZmcsXG4gIGZvcm0tY29udHJvbC1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIGZvcm0tY29udHJvbC1iZzogY29sb3ItYmcsXG4gIGZvcm0tY29udHJvbC1mb2N1cy1iZzogY29sb3ItYmcsXG5cbiAgZm9ybS1jb250cm9sLWJvcmRlci13aWR0aDogMnB4LFxuICBmb3JtLWNvbnRyb2wtYm9yZGVyLXR5cGU6IHNvbGlkLFxuICBmb3JtLWNvbnRyb2wtYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuICBmb3JtLWNvbnRyb2wtYm9yZGVyLWNvbG9yOiAjZGFkZmU2LFxuICBmb3JtLWNvbnRyb2wtc2VsZWN0ZWQtYm9yZGVyLWNvbG9yOiBjb2xvci1zdWNjZXNzLFxuXG4gIGZvcm0tY29udHJvbC1pbmZvLWJvcmRlci1jb2xvcjogY29sb3ItaW5mbyxcbiAgZm9ybS1jb250cm9sLXN1Y2Nlc3MtYm9yZGVyLWNvbG9yOiBjb2xvci1zdWNjZXNzLFxuICBmb3JtLWNvbnRyb2wtZGFuZ2VyLWJvcmRlci1jb2xvcjogY29sb3ItZGFuZ2VyLFxuICBmb3JtLWNvbnRyb2wtd2FybmluZy1ib3JkZXItY29sb3I6IGNvbG9yLXdhcm5pbmcsXG5cbiAgZm9ybS1jb250cm9sLXBsYWNlaG9sZGVyLWNvbG9yOiBjb2xvci1mZyxcbiAgZm9ybS1jb250cm9sLXBsYWNlaG9sZGVyLWZvbnQtc2l6ZTogMXJlbSxcblxuICBmb3JtLWNvbnRyb2wtZm9udC1zaXplOiAxcmVtLFxuICBmb3JtLWNvbnRyb2wtc20tZm9udC1zaXplOiBmb250LXNpemUtc20sXG4gIGZvcm0tY29udHJvbC1zbS1wYWRkaW5nOiAwLjM3NXJlbSAxLjEyNXJlbSxcbiAgZm9ybS1jb250cm9sLWxnLWZvbnQtc2l6ZTogZm9udC1zaXplLWxnLFxuICBmb3JtLWNvbnRyb2wtbGctcGFkZGluZzogMS4xMjVyZW0sXG5cbiAgZm9ybS1jb250cm9sLWxhYmVsLWZvbnQtd2VpZ2h0OiA0MDAsXG5cbiAgZm9ybS1jb250cm9sLWZlZWRiYWNrLWZvbnQtc2l6ZTogMC44NzVyZW0sXG4gIGZvcm0tY29udHJvbC1mZWVkYmFjay1mb250LXdlaWdodDogZm9udC13ZWlnaHQtbm9ybWFsLFxuXG4gIGNoZWNrYm94LWJnOiB0cmFuc3BhcmVudCxcbiAgY2hlY2tib3gtc2l6ZTogMS4yNXJlbSxcbiAgY2hlY2tib3gtYm9yZGVyLXNpemU6IDJweCxcbiAgY2hlY2tib3gtYm9yZGVyLWNvbG9yOiBmb3JtLWNvbnRyb2wtYm9yZGVyLWNvbG9yLFxuICBjaGVja2JveC1jaGVja21hcms6IHRyYW5zcGFyZW50LFxuXG4gIGNoZWNrYm94LWNoZWNrZWQtYmc6IHRyYW5zcGFyZW50LFxuICBjaGVja2JveC1jaGVja2VkLXNpemU6IDEuMjVyZW0sXG4gIGNoZWNrYm94LWNoZWNrZWQtYm9yZGVyLXNpemU6IDJweCxcbiAgY2hlY2tib3gtY2hlY2tlZC1ib3JkZXItY29sb3I6IGNvbG9yLXN1Y2Nlc3MsXG4gIGNoZWNrYm94LWNoZWNrZWQtY2hlY2ttYXJrOiBjb2xvci1mZy1oZWFkaW5nLFxuXG4gIGNoZWNrYm94LWRpc2FibGVkLWJnOiB0cmFuc3BhcmVudCxcbiAgY2hlY2tib3gtZGlzYWJsZWQtc2l6ZTogMS4yNXJlbSxcbiAgY2hlY2tib3gtZGlzYWJsZWQtYm9yZGVyLXNpemU6IDJweCxcbiAgY2hlY2tib3gtZGlzYWJsZWQtYm9yZGVyLWNvbG9yOiBjb2xvci1mZy1oZWFkaW5nLFxuICBjaGVja2JveC1kaXNhYmxlZC1jaGVja21hcms6IGNvbG9yLWZnLWhlYWRpbmcsXG5cbiAgcmFkaW8tZmc6IGNvbG9yLXN1Y2Nlc3MsXG5cbiAgbW9kYWwtZm9udC1zaXplOiBmb250LXNpemUsXG4gIG1vZGFsLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgbW9kYWwtZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LW5vcm1hbCxcbiAgbW9kYWwtZmc6IGNvbG9yLWZnLXRleHQsXG4gIG1vZGFsLWZnLWhlYWRpbmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIG1vZGFsLWJnOiBjb2xvci1iZyxcbiAgbW9kYWwtYm9yZGVyOiB0cmFuc3BhcmVudCxcbiAgbW9kYWwtYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuICBtb2RhbC1wYWRkaW5nOiBwYWRkaW5nLFxuICBtb2RhbC1oZWFkZXItZm9udC1mYW1pbHk6IGZvbnQtc2Vjb25kYXJ5LFxuICBtb2RhbC1oZWFkZXItZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LWJvbGRlcixcbiAgbW9kYWwtaGVhZGVyLWZvbnQtc2l6ZTogZm9udC1zaXplLWxnLFxuICBtb2RhbC1ib2R5LWZvbnQtZmFtaWx5OiBmb250LW1haW4sXG4gIG1vZGFsLWJvZHktZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LW5vcm1hbCxcbiAgbW9kYWwtYm9keS1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgbW9kYWwtc2VwYXJhdG9yOiBzZXBhcmF0b3IsXG5cbiAgYmFkZ2UtZmctdGV4dDogY29sb3Itd2hpdGUsXG4gIGJhZGdlLXByaW1hcnktYmctY29sb3I6IGNvbG9yLXByaW1hcnksXG4gIGJhZGdlLXN1Y2Nlc3MtYmctY29sb3I6IGNvbG9yLXN1Y2Nlc3MsXG4gIGJhZGdlLWluZm8tYmctY29sb3I6IGNvbG9yLWluZm8sXG4gIGJhZGdlLXdhcm5pbmctYmctY29sb3I6IGNvbG9yLXdhcm5pbmcsXG4gIGJhZGdlLWRhbmdlci1iZy1jb2xvcjogY29sb3ItZGFuZ2VyLFxuXG4gIHByb2dyZXNzLWJhci1oZWlnaHQteGxnOiAxLjc1cmVtLFxuICBwcm9ncmVzcy1iYXItaGVpZ2h0LWxnOiAxLjVyZW0sXG4gIHByb2dyZXNzLWJhci1oZWlnaHQ6IDEuMzc1cmVtLFxuICBwcm9ncmVzcy1iYXItaGVpZ2h0LXNtOiAxLjI1cmVtLFxuICBwcm9ncmVzcy1iYXItaGVpZ2h0LXhzOiAxcmVtLFxuICBwcm9ncmVzcy1iYXItYW5pbWF0aW9uLWR1cmF0aW9uOiA0MDBtcyxcbiAgcHJvZ3Jlc3MtYmFyLWZvbnQtc2l6ZS14bGc6IGZvbnQtc2l6ZS14bGcsXG4gIHByb2dyZXNzLWJhci1mb250LXNpemUtbGc6IGZvbnQtc2l6ZS1sZyxcbiAgcHJvZ3Jlc3MtYmFyLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBwcm9ncmVzcy1iYXItZm9udC1zaXplLXNtOiBmb250LXNpemUtc20sXG4gIHByb2dyZXNzLWJhci1mb250LXNpemUteHM6IGZvbnQtc2l6ZS14cyxcbiAgcHJvZ3Jlc3MtYmFyLXJhZGl1czogcmFkaXVzLFxuICBwcm9ncmVzcy1iYXItYmc6IGxheW91dC1iZyxcbiAgcHJvZ3Jlc3MtYmFyLWZvbnQtY29sb3I6IGNvbG9yLXdoaXRlLFxuICBwcm9ncmVzcy1iYXItZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LWJvbGQsXG4gIHByb2dyZXNzLWJhci1kZWZhdWx0LWJnOiBjb2xvci1pbmZvLFxuICBwcm9ncmVzcy1iYXItcHJpbWFyeS1iZzogY29sb3ItcHJpbWFyeSxcbiAgcHJvZ3Jlc3MtYmFyLXN1Y2Nlc3MtYmc6IGNvbG9yLXN1Y2Nlc3MsXG4gIHByb2dyZXNzLWJhci1pbmZvLWJnOiBjb2xvci1pbmZvLFxuICBwcm9ncmVzcy1iYXItd2FybmluZy1iZzogY29sb3Itd2FybmluZyxcbiAgcHJvZ3Jlc3MtYmFyLWRhbmdlci1iZzogY29sb3ItZGFuZ2VyLFxuXG4gIGFsZXJ0LWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBhbGVydC1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIGFsZXJ0LWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkLFxuICBhbGVydC1mZzogY29sb3Itd2hpdGUsXG4gIGFsZXJ0LWJnOiBjb2xvci1iZyxcbiAgYWxlcnQtYWN0aXZlLWJnOiBjb2xvci1mZyxcbiAgYWxlcnQtZGlzYWJsZWQtYmc6IGNvbG9yLWRpc2FibGVkLFxuICBhbGVydC1kaXNhYmxlZC1mZzogY29sb3ItZmcsXG4gIGFsZXJ0LXByaW1hcnktYmc6IGNvbG9yLXByaW1hcnksXG4gIGFsZXJ0LWluZm8tYmc6IGNvbG9yLWluZm8sXG4gIGFsZXJ0LXN1Y2Nlc3MtYmc6IGNvbG9yLXN1Y2Nlc3MsXG4gIGFsZXJ0LXdhcm5pbmctYmc6IGNvbG9yLXdhcm5pbmcsXG4gIGFsZXJ0LWRhbmdlci1iZzogY29sb3ItZGFuZ2VyLFxuICBhbGVydC1oZWlnaHQteHhzbWFsbDogNTJweCxcbiAgYWxlcnQtaGVpZ2h0LXhzbWFsbDogNzJweCxcbiAgYWxlcnQtaGVpZ2h0LXNtYWxsOiA5MnB4LFxuICBhbGVydC1oZWlnaHQtbWVkaXVtOiAxMTJweCxcbiAgYWxlcnQtaGVpZ2h0LWxhcmdlOiAxMzJweCxcbiAgYWxlcnQtaGVpZ2h0LXhsYXJnZTogMTUycHgsXG4gIGFsZXJ0LWhlaWdodC14eGxhcmdlOiAxNzJweCxcbiAgYWxlcnQtc2hhZG93OiBub25lLFxuICBhbGVydC1ib3JkZXItcmFkaXVzOiByYWRpdXMsXG4gIGFsZXJ0LXBhZGRpbmc6IDFyZW0gMS4xMjVyZW0sXG4gIGFsZXJ0LWNsb3NhYmxlLXBhZGRpbmc6IDNyZW0sXG4gIGFsZXJ0LWJ1dHRvbi1wYWRkaW5nOiAzcmVtLFxuICBhbGVydC1tYXJnaW46IG1hcmdpbixcbik7XG5cbi8vIHJlZ2lzdGVyIHRoZSB0aGVtZVxuJG5iLXRoZW1lczogbmItcmVnaXN0ZXItdGhlbWUoJHRoZW1lLCBkZWZhdWx0KTtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuQGltcG9ydCAnLi4vY29yZS9mdW5jdGlvbnMnO1xuQGltcG9ydCAnLi4vY29yZS9taXhpbnMnO1xuQGltcG9ydCAnZGVmYXVsdCc7XG5cbi8vIGRlZmF1bHQgdGhlIGJhc2UgdGhlbWVcbiR0aGVtZTogKFxuICByYWRpdXM6IDAuNXJlbSxcblxuICBjb2xvci1iZzogIzNkMzc4MCxcbiAgY29sb3ItYmctYWN0aXZlOiAjNDk0Mjk5LFxuICBjb2xvci1mZzogI2ExYTFlNSxcbiAgY29sb3ItZmctaGVhZGluZzogI2ZmZmZmZixcbiAgY29sb3ItZmctdGV4dDogI2QxZDFmZixcbiAgY29sb3ItZmctaGlnaGxpZ2h0OiAjMDBmOWE2LFxuXG4gIGNvbG9yLWdyYXk6IHJnYmEoODEsIDExMywgMTY1LCAwLjE1KSxcbiAgY29sb3ItbmV1dHJhbDogdHJhbnNwYXJlbnQsXG4gIGNvbG9yLXdoaXRlOiAjZmZmZmZmLFxuICBjb2xvci1kaXNhYmxlZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjQpLFxuXG4gIGNvbG9yLXByaW1hcnk6ICM3NjU5ZmYsXG4gIGNvbG9yLXN1Y2Nlc3M6ICMwMGQ5NzcsXG4gIGNvbG9yLWluZm86ICMwMDg4ZmYsXG4gIGNvbG9yLXdhcm5pbmc6ICNmZmExMDAsXG4gIGNvbG9yLWRhbmdlcjogI2ZmMzg2YSxcblxuICBsaW5rLWNvbG9yOiAjMDBmOWE2LFxuICBsaW5rLWNvbG9yLWhvdmVyOiAjMTRmZmJlLFxuXG4gIHNlcGFyYXRvcjogIzM0MmU3MyxcbiAgc2hhZG93OiAwIDhweCAyMHB4IDAgcmdiYSg0MCwgMzcsIDg5LCAwLjYpLFxuXG4gIGNhcmQtaGVhZGVyLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkZXIsXG5cbiAgbGF5b3V0LWJnOiAjMmYyOTZiLFxuXG4gIHNjcm9sbGJhci1mZzogIzU1NGRiMyxcbiAgc2Nyb2xsYmFyLWJnOiAjMzMyZTczLFxuXG4gIHJhZGlhbC1ncmFkaWVudDogcmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA1MCUgNTAlLCAjNDIzZjhjLCAjMzAyYzZlKSxcbiAgbGluZWFyLWdyYWRpZW50OiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMxNzE3NDksICM0MTM3ODkpLFxuXG4gIHNpZGViYXItZmc6IGNvbG9yLXNlY29uZGFyeSxcbiAgc2lkZWJhci1iZzogY29sb3ItYmcsXG5cbiAgaGVhZGVyLWZnOiBjb2xvci13aGl0ZSxcbiAgaGVhZGVyLWJnOiBjb2xvci1iZyxcblxuICBmb290ZXItZmc6IGNvbG9yLWZnLFxuICBmb290ZXItYmc6IGNvbG9yLWJnLFxuXG4gIGFjdGlvbnMtZmc6IGNvbG9yLWZnLFxuICBhY3Rpb25zLWJnOiBjb2xvci1iZyxcblxuICB1c2VyLWZnOiBjb2xvci1iZyxcbiAgdXNlci1iZzogY29sb3ItZmcsXG4gIHVzZXItZmctaGlnaGxpZ2h0OiBjb2xvci1mZy1oaWdobGlnaHQsXG5cbiAgcG9wb3Zlci1ib3JkZXI6IGNvbG9yLXByaW1hcnksXG4gIHBvcG92ZXItc2hhZG93OiBzaGFkb3csXG5cbiAgY29udGV4dC1tZW51LWFjdGl2ZS1iZzogY29sb3ItcHJpbWFyeSxcblxuICBmb290ZXItaGVpZ2h0OiBoZWFkZXItaGVpZ2h0LFxuXG4gIHNpZGViYXItd2lkdGg6IDE2LjI1cmVtLFxuICBzaWRlYmFyLXdpZHRoLWNvbXBhY3Q6IDMuNDVyZW0sXG5cbiAgbWVudS1mZzogY29sb3ItZmcsXG4gIG1lbnUtYmc6IGNvbG9yLWJnLFxuICBtZW51LWFjdGl2ZS1mZzogY29sb3Itd2hpdGUsXG4gIG1lbnUtZ3JvdXAtZmc6IGNvbG9yLXdoaXRlLFxuICBtZW51LWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ub3JtYWwsXG4gIG1lbnUtYWN0aXZlLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkZXIsXG4gIG1lbnUtc3VibWVudS1iZzogbGF5b3V0LWJnLFxuICBtZW51LXN1Ym1lbnUtZmc6IGNvbG9yLWZnLFxuICBtZW51LXN1Ym1lbnUtYWN0aXZlLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBtZW51LXN1Ym1lbnUtYWN0aXZlLWJnOiByZ2JhKDAsIDI1NSwgMTcwLCAwLjI1KSxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1ib3JkZXItY29sb3I6IGNvbG9yLWZnLWhpZ2hsaWdodCxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1zaGFkb3c6IDAgMnB4IDEycHggMCByZ2JhKDAsIDI1NSwgMTcwLCAwLjI1KSxcbiAgbWVudS1pdGVtLXBhZGRpbmc6IDAuMjVyZW0gMC43NXJlbSxcbiAgbWVudS1pdGVtLXNlcGFyYXRvcjogdHJhbnNwYXJlbnQsXG5cbiAgYnRuLWhlcm8tc2hhZG93OiAwIDRweCAxMHB4IDAgcmdiYSgzMywgNywgNzcsIDAuNSksXG4gIGJ0bi1oZXJvLXRleHQtc2hhZG93OiAwIDFweCAzcHggcmdiYSgwLCAwLCAwLCAwLjMpLFxuICBidG4taGVyby1iZXZlbC1zaXplOiAwIDNweCAwIDAsXG4gIGJ0bi1oZXJvLWdsb3ctc2l6ZTogMCAycHggOHB4IDAsXG4gIGJ0bi1oZXJvLXByaW1hcnktZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXN1Y2Nlc3MtZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXdhcm5pbmctZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLWluZm8tZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLWRhbmdlci1nbG93LXNpemU6IGJ0bi1oZXJvLWdsb3ctc2l6ZSxcbiAgYnRuLWhlcm8tc2Vjb25kYXJ5LWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4tc2Vjb25kYXJ5LWJvcmRlcjogY29sb3ItcHJpbWFyeSxcbiAgYnRuLW91dGxpbmUtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIGJ0bi1vdXRsaW5lLWhvdmVyLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBidG4tb3V0bGluZS1mb2N1cy1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgYnRuLWdyb3VwLWJnOiAjMzczMjczLFxuICBidG4tZ3JvdXAtc2VwYXJhdG9yOiAjMzEyYzY2LFxuXG4gIGZvcm0tY29udHJvbC1iZzogIzM3MzE3YSxcbiAgZm9ybS1jb250cm9sLWZvY3VzLWJnOiBzZXBhcmF0b3IsXG4gIGZvcm0tY29udHJvbC1ib3JkZXItY29sb3I6IHNlcGFyYXRvcixcbiAgZm9ybS1jb250cm9sLXNlbGVjdGVkLWJvcmRlci1jb2xvcjogY29sb3ItcHJpbWFyeSxcblxuICBjaGVja2JveC1iZzogdHJhbnNwYXJlbnQsXG4gIGNoZWNrYm94LXNpemU6IDEuMjVyZW0sXG4gIGNoZWNrYm94LWJvcmRlci1zaXplOiAycHgsXG4gIGNoZWNrYm94LWJvcmRlci1jb2xvcjogY29sb3ItZmcsXG4gIGNoZWNrYm94LWNoZWNrbWFyazogdHJhbnNwYXJlbnQsXG5cbiAgY2hlY2tib3gtY2hlY2tlZC1iZzogdHJhbnNwYXJlbnQsXG4gIGNoZWNrYm94LWNoZWNrZWQtc2l6ZTogMS4yNXJlbSxcbiAgY2hlY2tib3gtY2hlY2tlZC1ib3JkZXItc2l6ZTogMnB4LFxuICBjaGVja2JveC1jaGVja2VkLWJvcmRlci1jb2xvcjogY29sb3Itc3VjY2VzcyxcbiAgY2hlY2tib3gtY2hlY2tlZC1jaGVja21hcms6IGNvbG9yLWZnLWhlYWRpbmcsXG5cbiAgY2hlY2tib3gtZGlzYWJsZWQtYmc6IHRyYW5zcGFyZW50LFxuICBjaGVja2JveC1kaXNhYmxlZC1zaXplOiAxLjI1cmVtLFxuICBjaGVja2JveC1kaXNhYmxlZC1ib3JkZXItc2l6ZTogMnB4LFxuICBjaGVja2JveC1kaXNhYmxlZC1ib3JkZXItY29sb3I6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIGNoZWNrYm94LWRpc2FibGVkLWNoZWNrbWFyazogY29sb3ItZmctaGVhZGluZyxcblxuICBzZWFyY2gtYmc6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzE3MTc0OSwgIzQxMzc4OSksXG5cbiAgc21hcnQtdGFibGUtaGVhZGVyLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ub3JtYWwsXG4gIHNtYXJ0LXRhYmxlLWhlYWRlci1iZzogY29sb3ItYmctYWN0aXZlLFxuICBzbWFydC10YWJsZS1iZy1ldmVuOiAjM2EzNDdhLFxuICBzbWFydC10YWJsZS1iZy1hY3RpdmU6IGNvbG9yLWJnLWFjdGl2ZSxcblxuICBzbWFydC10YWJsZS1wYWdpbmctYm9yZGVyLWNvbG9yOiBjb2xvci1wcmltYXJ5LFxuICBzbWFydC10YWJsZS1wYWdpbmctYm9yZGVyLXdpZHRoOiAycHgsXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1mZy1hY3RpdmU6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1iZy1hY3RpdmU6IGNvbG9yLXByaW1hcnksXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1ob3ZlcjogcmdiYSgwLCAwLCAwLCAwLjIpLFxuXG4gIGJhZGdlLWZnLXRleHQ6IGNvbG9yLXdoaXRlLFxuICBiYWRnZS1wcmltYXJ5LWJnLWNvbG9yOiBjb2xvci1wcmltYXJ5LFxuICBiYWRnZS1zdWNjZXNzLWJnLWNvbG9yOiBjb2xvci1zdWNjZXNzLFxuICBiYWRnZS1pbmZvLWJnLWNvbG9yOiBjb2xvci1pbmZvLFxuICBiYWRnZS13YXJuaW5nLWJnLWNvbG9yOiBjb2xvci13YXJuaW5nLFxuICBiYWRnZS1kYW5nZXItYmctY29sb3I6IGNvbG9yLWRhbmdlcixcbik7XG5cbi8vIHJlZ2lzdGVyIHRoZSB0aGVtZVxuJG5iLXRoZW1lczogbmItcmVnaXN0ZXItdGhlbWUoJHRoZW1lLCBjb3NtaWMsIGRlZmF1bHQpO1xuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuXG5AaW1wb3J0ICcuLi9jb3JlL2Z1bmN0aW9ucyc7XG5AaW1wb3J0ICcuLi9jb3JlL21peGlucyc7XG5AaW1wb3J0ICdkZWZhdWx0JztcblxuLy8gZGVmYXVsdCB0aGUgYmFzZSB0aGVtZVxuJHRoZW1lOiAoXG4gIGhlYWRlci1mZzogI2Y3ZmFmYixcbiAgaGVhZGVyLWJnOiAjMTExMjE4LFxuXG4gIGxheW91dC1iZzogI2YxZjVmOCxcblxuICBjb2xvci1mZy1oZWFkaW5nOiAjMTgxODE4LFxuICBjb2xvci1mZy10ZXh0OiAjNGI0YjRiLFxuICBjb2xvci1mZy1oaWdobGlnaHQ6IGNvbG9yLWZnLFxuXG4gIHNlcGFyYXRvcjogI2NkZDVkYyxcblxuICByYWRpdXM6IDAuMTdyZW0sXG5cbiAgc2Nyb2xsYmFyLWJnOiAjZTNlOWVlLFxuXG4gIGNvbG9yLXByaW1hcnk6ICM3M2ExZmYsXG4gIGNvbG9yLXN1Y2Nlc3M6ICM1ZGNmZTMsXG4gIGNvbG9yLWluZm86ICNiYTdmZWMsXG4gIGNvbG9yLXdhcm5pbmc6ICNmZmEzNmIsXG4gIGNvbG9yLWRhbmdlcjogI2ZmNmI4MyxcblxuICBidG4tc2Vjb25kYXJ5LWJnOiAjZWRmMmY1LFxuICBidG4tc2Vjb25kYXJ5LWJvcmRlcjogI2VkZjJmNSxcblxuICBhY3Rpb25zLWZnOiAjZDNkYmU1LFxuICBhY3Rpb25zLWJnOiBjb2xvci1iZyxcblxuICBzaWRlYmFyLWJnOiAjZTNlOWVlLFxuXG4gIGJvcmRlci1jb2xvcjogI2U3ZWNlZixcblxuICBtZW51LWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkZXIsXG4gIG1lbnUtZmc6IGNvbG9yLWZnLXRleHQsXG4gIG1lbnUtYmc6ICNlM2U5ZWUsXG4gIG1lbnUtYWN0aXZlLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBtZW51LWFjdGl2ZS1iZzogbWVudS1iZyxcblxuICBtZW51LXN1Ym1lbnUtYmc6IG1lbnUtYmcsXG4gIG1lbnUtc3VibWVudS1mZzogY29sb3ItZmctdGV4dCxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1iZzogI2NkZDVkYyxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1ib3JkZXItY29sb3I6IG1lbnUtc3VibWVudS1hY3RpdmUtYmcsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtc2hhZG93OiBub25lLFxuICBtZW51LXN1Ym1lbnUtaG92ZXItZmc6IG1lbnUtc3VibWVudS1hY3RpdmUtZmcsXG4gIG1lbnUtc3VibWVudS1ob3Zlci1iZzogbWVudS1iZyxcbiAgbWVudS1zdWJtZW51LWl0ZW0tYm9yZGVyLXdpZHRoOiAwLjEyNXJlbSxcbiAgbWVudS1zdWJtZW51LWl0ZW0tYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuICBtZW51LXN1Ym1lbnUtaXRlbS1wYWRkaW5nOiAwLjVyZW0gMXJlbSxcbiAgbWVudS1zdWJtZW51LWl0ZW0tY29udGFpbmVyLXBhZGRpbmc6IDAgMS4yNXJlbSxcbiAgbWVudS1zdWJtZW51LXBhZGRpbmc6IDAuNXJlbSxcblxuICBidG4tYm9yZGVyLXJhZGl1czogYnRuLXNlbWktcm91bmQtYm9yZGVyLXJhZGl1cyxcblxuICBidG4taGVyby1kZWdyZWU6IDBkZWcsXG4gIGJ0bi1oZXJvLXByaW1hcnktZGVncmVlOiBidG4taGVyby1kZWdyZWUsXG4gIGJ0bi1oZXJvLXN1Y2Nlc3MtZGVncmVlOiBidG4taGVyby1kZWdyZWUsXG4gIGJ0bi1oZXJvLXdhcm5pbmctZGVncmVlOiBidG4taGVyby1kZWdyZWUsXG4gIGJ0bi1oZXJvLWluZm8tZGVncmVlOiBidG4taGVyby1kZWdyZWUsXG4gIGJ0bi1oZXJvLWRhbmdlci1kZWdyZWU6IGJ0bi1oZXJvLWRlZ3JlZSxcbiAgYnRuLWhlcm8tc2Vjb25kYXJ5LWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby1nbG93LXNpemU6IDAgMCAyMHB4IDAsXG4gIGJ0bi1oZXJvLXByaW1hcnktZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXN1Y2Nlc3MtZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXdhcm5pbmctZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLWluZm8tZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLWRhbmdlci1nbG93LXNpemU6IGJ0bi1oZXJvLWdsb3ctc2l6ZSxcbiAgYnRuLWhlcm8tc2Vjb25kYXJ5LWdsb3ctc2l6ZTogMCAwIDAgMCxcbiAgYnRuLWhlcm8tYm9yZGVyLXJhZGl1czogYnRuLWJvcmRlci1yYWRpdXMsXG5cbiAgY2FyZC1zaGFkb3c6IG5vbmUsXG4gIGNhcmQtYm9yZGVyLXdpZHRoOiAxcHgsXG4gIGNhcmQtYm9yZGVyLWNvbG9yOiBib3JkZXItY29sb3IsXG4gIGNhcmQtaGVhZGVyLWJvcmRlci13aWR0aDogMCxcblxuICBsaW5rLWNvbG9yOiAjNWRjZmUzLFxuICBsaW5rLWNvbG9yLWhvdmVyOiAjN2RjZmUzLFxuICBsaW5rLWNvbG9yLXZpc2l0ZWQ6IGxpbmstY29sb3IsXG5cbiAgYWN0aW9ucy1zZXBhcmF0b3I6ICNmMWY0ZjUsXG5cbiAgbW9kYWwtc2VwYXJhdG9yOiBib3JkZXItY29sb3IsXG5cbiAgdGFicy1zZWxlY3RlZDogY29sb3ItcHJpbWFyeSxcbiAgdGFicy1zZXBhcmF0b3I6ICNlYmVjZWUsXG5cbiAgc21hcnQtdGFibGUtcGFnaW5nLWJnLWFjdGl2ZTogY29sb3ItcHJpbWFyeSxcblxuICByb3V0ZS10YWJzLXNlbGVjdGVkOiBjb2xvci1wcmltYXJ5LFxuXG4gIHBvcG92ZXItYm9yZGVyOiBjb2xvci1wcmltYXJ5LFxuXG4gIGZvb3Rlci1zaGFkb3c6IG5vbmUsXG4gIGZvb3Rlci1zZXBhcmF0b3I6IGJvcmRlci1jb2xvcixcbiAgZm9vdGVyLWZnLWhpZ2hsaWdodDogIzJhMmEyYSxcbik7XG5cbi8vIHJlZ2lzdGVyIHRoZSB0aGVtZVxuJG5iLXRoZW1lczogbmItcmVnaXN0ZXItdGhlbWUoJHRoZW1lLCBjb3Jwb3JhdGUsIGRlZmF1bHQpO1xuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuXG5AbWl4aW4gYnRuLWhlcm8oKSB7XG4gIC5idG4uYnRuLWhlcm8tcHJpbWFyeSB7XG4gICAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeSgpO1xuICB9XG5cbiAgLmJ0bi5idG4taGVyby1zdWNjZXNzIHtcbiAgICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzKCk7XG4gIH1cblxuICAuYnRuLmJ0bi1oZXJvLXdhcm5pbmcge1xuICAgIEBpbmNsdWRlIGJ0bi1oZXJvLXdhcm5pbmcoKTtcbiAgfVxuXG4gIC5idG4uYnRuLWhlcm8taW5mbyB7XG4gICAgQGluY2x1ZGUgYnRuLWhlcm8taW5mbygpO1xuICB9XG5cbiAgLmJ0bi5idG4taGVyby1kYW5nZXIge1xuICAgIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlcigpO1xuICB9XG5cbiAgLmJ0bi5idG4taGVyby1zZWNvbmRhcnkge1xuICAgIEBpbmNsdWRlIGJ0bi1oZXJvLXNlY29uZGFyeSgpO1xuICB9XG59XG5cbkBtaXhpbiBidG4taGVyby1wcmltYXJ5KCkge1xuICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWdyYWRpZW50KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXByaW1hcnktYmV2ZWwtZ2xvdy1zaGFkb3coKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYm9yZGVyLXJhZGl1cygpO1xuICBAaW5jbHVkZSBidG4taGVyby10ZXh0KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXByaW1hcnktZm9jdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeS1ob3ZlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWFjdGl2ZSgpO1xuICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWJvcmRlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1kaXNhYmxlZCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1saW5lLWhlaWdodCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LXB1bHNlKCk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zdWNjZXNzKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLWdyYWRpZW50KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXN1Y2Nlc3MtYmV2ZWwtZ2xvdy1zaGFkb3coKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYm9yZGVyLXJhZGl1cygpO1xuICBAaW5jbHVkZSBidG4taGVyby10ZXh0KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXN1Y2Nlc3MtZm9jdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1ob3ZlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLWFjdGl2ZSgpO1xuICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLWJvcmRlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1kaXNhYmxlZCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1saW5lLWhlaWdodCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLXB1bHNlKCk7XG59XG5cbkBtaXhpbiBidG4taGVyby13YXJuaW5nKCkge1xuICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWdyYWRpZW50KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXdhcm5pbmctYmV2ZWwtZ2xvdy1zaGFkb3coKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYm9yZGVyLXJhZGl1cygpO1xuICBAaW5jbHVkZSBidG4taGVyby10ZXh0KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXdhcm5pbmctZm9jdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8td2FybmluZy1ob3ZlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWFjdGl2ZSgpO1xuICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWJvcmRlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1kaXNhYmxlZCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1saW5lLWhlaWdodCgpO1xuICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLXB1bHNlKCk7XG59XG5cbkBtaXhpbiBidG4taGVyby1pbmZvKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1pbmZvLWdyYWRpZW50KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWluZm8tYmV2ZWwtZ2xvdy1zaGFkb3coKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYm9yZGVyLXJhZGl1cygpO1xuICBAaW5jbHVkZSBidG4taGVyby10ZXh0KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWluZm8tZm9jdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taW5mby1ob3ZlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1pbmZvLWFjdGl2ZSgpO1xuICBAaW5jbHVkZSBidG4taGVyby1pbmZvLWJvcmRlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1kaXNhYmxlZCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1saW5lLWhlaWdodCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1pbmZvLXB1bHNlKCk7XG59XG5cbkBtaXhpbiBidG4taGVyby1kYW5nZXIoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlci1ncmFkaWVudCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItYmV2ZWwtZ2xvdy1zaGFkb3coKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYm9yZGVyLXJhZGl1cygpO1xuICBAaW5jbHVkZSBidG4taGVyby10ZXh0KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlci1mb2N1cygpO1xuICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItaG92ZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGFuZ2VyLWFjdGl2ZSgpO1xuICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItYm9yZGVyKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWRpc2FibGVkKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlci1wdWxzZSgpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc2Vjb25kYXJ5KCkge1xuICBjb2xvcjogbmItdGhlbWUoYnRuLW91dGxpbmUtZmcpO1xuICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnktYmcoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWJldmVsLWdsb3ctc2hhZG93KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tdGV4dCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnktZm9jdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWhvdmVyKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXNlY29uZGFyeS1hY3RpdmUoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWJvcmRlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1kaXNhYmxlZCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnktcHVsc2UoKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQoJGNvbG9yLCAkZGVncmVlczogMjBkZWcpIHtcbiAgQHJldHVybiBhZGp1c3QtaHVlKCRjb2xvciwgJGRlZ3JlZXMpO1xufVxuXG4vLyBGdW5jdGlvbnMgZm9yIGJveC1zaGFkb3dcbkBmdW5jdGlvbiBidG4taGVyby1iZXZlbCgkY29sb3IpIHtcbiAgQHJldHVybiBuYi10aGVtZShidG4taGVyby1iZXZlbC1zaXplKSBzaGFkZSgkY29sb3IsIDE0JSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1nbG93KCRoZXJvLWdsb3ctc2l6ZSwgJGNvbG9yKSB7XG4gIEByZXR1cm4gbmItdGhlbWUoJGhlcm8tZ2xvdy1zaXplKSAkY29sb3I7XG59XG5cbi8vIExlZnQgY29sb3JzXG5AZnVuY3Rpb24gYnRuLWhlcm8tcHJpbWFyeS1sZWZ0LWNvbG9yKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQobmItdGhlbWUoYnRuLXByaW1hcnktYmcpLCBuYi10aGVtZShidG4taGVyby1wcmltYXJ5LWRlZ3JlZSkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tc3VjY2Vzcy1sZWZ0LWNvbG9yKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQobmItdGhlbWUoYnRuLXN1Y2Nlc3MtYmcpLCBuYi10aGVtZShidG4taGVyby1zdWNjZXNzLWRlZ3JlZSkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8td2FybmluZy1sZWZ0LWNvbG9yKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQobmItdGhlbWUoYnRuLXdhcm5pbmctYmcpLCBuYi10aGVtZShidG4taGVyby13YXJuaW5nLWRlZ3JlZSkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8taW5mby1sZWZ0LWNvbG9yKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQobmItdGhlbWUoYnRuLWluZm8tYmcpLCBuYi10aGVtZShidG4taGVyby1pbmZvLWRlZ3JlZSkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tZGFuZ2VyLWxlZnQtY29sb3IoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tZ3JhZGllbnQtbGVmdChuYi10aGVtZShidG4tZGFuZ2VyLWJnKSwgbmItdGhlbWUoYnRuLWhlcm8tZGFuZ2VyLWRlZ3JlZSkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tc2Vjb25kYXJ5LWxlZnQtY29sb3IoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tZ3JhZGllbnQtbGVmdChuYi10aGVtZShidG4tc2Vjb25kYXJ5LWJvcmRlciksIG5iLXRoZW1lKGJ0bi1oZXJvLXNlY29uZGFyeS1kZWdyZWUpKTtcbn1cblxuLy8gTWlkZGxlIGNvbG9yc1xuQGZ1bmN0aW9uIGJ0bi1oZXJvLXByaW1hcnktbWlkZGxlLWNvbG9yKCkge1xuICBAcmV0dXJuIG1peChidG4taGVyby1wcmltYXJ5LWxlZnQtY29sb3IoKSwgbmItdGhlbWUoYnRuLXByaW1hcnktYmcpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXN1Y2Nlc3MtbWlkZGxlLWNvbG9yKCkge1xuICBAcmV0dXJuIG1peChidG4taGVyby1zdWNjZXNzLWxlZnQtY29sb3IoKSwgbmItdGhlbWUoYnRuLXN1Y2Nlc3MtYmcpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXdhcm5pbmctbWlkZGxlLWNvbG9yKCkge1xuICBAcmV0dXJuIG1peChidG4taGVyby13YXJuaW5nLWxlZnQtY29sb3IoKSwgbmItdGhlbWUoYnRuLXdhcm5pbmctYmcpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWluZm8tbWlkZGxlLWNvbG9yKCkge1xuICBAcmV0dXJuIG1peChidG4taGVyby1pbmZvLWxlZnQtY29sb3IoKSwgbmItdGhlbWUoYnRuLWluZm8tYmcpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWRhbmdlci1taWRkbGUtY29sb3IoKSB7XG4gIEByZXR1cm4gbWl4KGJ0bi1oZXJvLWRhbmdlci1sZWZ0LWNvbG9yKCksIG5iLXRoZW1lKGJ0bi1kYW5nZXItYmcpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXNlY29uZGFyeS1taWRkbGUtY29sb3IoKSB7XG4gIEByZXR1cm4gbWl4KGJ0bi1oZXJvLXNlY29uZGFyeS1sZWZ0LWNvbG9yKCksIG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYm9yZGVyKSk7XG59XG5cbi8vIGxpZ2h0IGdyYWRpZW50c1xuXG5AZnVuY3Rpb24gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCkge1xuICAkY29sb3ItbGVmdDogdGludCgkY29sb3ItbGVmdCwgMTQlKTtcbiAgJGNvbG9yLXJpZ2h0OiB0aW50KCRjb2xvci1yaWdodCwgMTQlKTtcblxuICBAcmV0dXJuIGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1wcmltYXJ5LWxpZ2h0LWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1wcmltYXJ5LWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXByaW1hcnktbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zdWNjZXNzLWxpZ2h0LWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1zdWNjZXNzLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXN1Y2Nlc3MtbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby13YXJuaW5nLWxpZ2h0LWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi13YXJuaW5nLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXdhcm5pbmctbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1pbmZvLWxpZ2h0LWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1pbmZvLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLWluZm8tbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1kYW5nZXItbGlnaHQtZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLWRhbmdlci1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1kYW5nZXItbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zZWNvbmRhcnktbGlnaHQtZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLXNlY29uZGFyeS1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1zZWNvbmRhcnktbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tbGlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbi8vIGRhcmsgZ3JhZGllbnRzXG5cbkBmdW5jdGlvbiBidG4taGVyby1kYXJrLWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpIHtcbiAgJGNvbG9yLWxlZnQ6IHNoYWRlKCRjb2xvci1sZWZ0LCAxNCUpO1xuICAkY29sb3ItcmlnaHQ6IHNoYWRlKCRjb2xvci1yaWdodCwgMTQlKTtcblxuICBAcmV0dXJuIGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1wcmltYXJ5LWRhcmstZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLXByaW1hcnktYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8tcHJpbWFyeS1sZWZ0LWNvbG9yKCk7XG5cbiAgQHJldHVybiBidG4taGVyby1kYXJrLWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tc3VjY2Vzcy1kYXJrLWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1zdWNjZXNzLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXN1Y2Nlc3MtbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tZGFyay1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXdhcm5pbmctZGFyay1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4td2FybmluZy1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby13YXJuaW5nLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWRhcmstZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1pbmZvLWRhcmstZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLWluZm8tYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8taW5mby1sZWZ0LWNvbG9yKCk7XG5cbiAgQHJldHVybiBidG4taGVyby1kYXJrLWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tZGFuZ2VyLWRhcmstZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLWRhbmdlci1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1kYW5nZXItbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tZGFyay1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cbi8vIEVuZCBmdW5jdGlvbnNcblxuLy8gSGVscCBtaXhpbnNcbkBtaXhpbiBidG4taGVyby10ZXh0KCkge1xuICB0ZXh0LXNoYWRvdzogbmItdGhlbWUoYnRuLWhlcm8tdGV4dC1zaGFkb3cpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taG92ZXIoJGxpZ2h0LWdyYWRpZW50KSB7XG4gICY6aG92ZXIsXG4gIC5ob3ZlciB7XG4gICAgYmFja2dyb3VuZC1pbWFnZTogJGxpZ2h0LWdyYWRpZW50O1xuICB9XG59XG5cbkBtaXhpbiBidG4taGVyby1mb2N1cygkbGlnaHQtZ3JhZGllbnQpIHtcbiAgJjpmb2N1cyxcbiAgLmZvY3VzIHtcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiAkbGlnaHQtZ3JhZGllbnQ7XG4gIH1cbn1cblxuQG1peGluIGJ0bi1oZXJvLWFjdGl2ZSgkZGFyay1ncmFkaWVudCkge1xuICAmOmFjdGl2ZSxcbiAgLmFjdGl2ZSB7XG4gICAgYmFja2dyb3VuZC1pbWFnZTogJGRhcmstZ3JhZGllbnQ7XG4gICAgYm94LXNoYWRvdzogbm9uZTtcbiAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG59XG5cbkBtaXhpbiBidG4taGVyby1ib3JkZXItcmFkaXVzKCkge1xuICBib3JkZXItcmFkaXVzOiBuYi10aGVtZShidG4taGVyby1ib3JkZXItcmFkaXVzKTtcbn1cbi8vIEVuZCBoZWxwIG1peGluc1xuXG5cbi8vIEdyYWRpZW50XG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4tcHJpbWFyeS1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1wcmltYXJ5LWxlZnQtY29sb3IoKTtcblxuICBAaW5jbHVkZSBuYi1yaWdodC1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLXN1Y2Nlc3MtYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8tc3VjY2Vzcy1sZWZ0LWNvbG9yKCk7XG5cbiAgQGluY2x1ZGUgbmItcmlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBtaXhpbiBidG4taGVyby13YXJuaW5nLWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi13YXJuaW5nLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXdhcm5pbmctbGVmdC1jb2xvcigpO1xuXG4gIEBpbmNsdWRlIG5iLXJpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mby1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4taW5mby1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1pbmZvLWxlZnQtY29sb3IoKTtcblxuICBAaW5jbHVkZSBuYi1yaWdodC1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWRhbmdlci1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4tZGFuZ2VyLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLWRhbmdlci1sZWZ0LWNvbG9yKCk7XG5cbiAgQGluY2x1ZGUgbmItcmlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktYmcoKSB7XG4gIGJhY2tncm91bmQtY29sb3I6IG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYmcpO1xufVxuXG5cbi8vIEJldmVsXG5AZnVuY3Rpb24gYnRuLWhlcm8tcHJpbWFyeS1iZXZlbCgpIHtcbiAgQHJldHVybiBidG4taGVyby1iZXZlbChidG4taGVyby1wcmltYXJ5LW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXN1Y2Nlc3MtYmV2ZWwoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tYmV2ZWwoYnRuLWhlcm8tc3VjY2Vzcy1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby13YXJuaW5nLWJldmVsKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWJldmVsKGJ0bi1oZXJvLXdhcm5pbmctbWlkZGxlLWNvbG9yKCkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8taW5mby1iZXZlbCgpIHtcbiAgQHJldHVybiBidG4taGVyby1iZXZlbChidG4taGVyby1pbmZvLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWRhbmdlci1iZXZlbCgpIHtcbiAgQHJldHVybiBidG4taGVyby1iZXZlbChidG4taGVyby1kYW5nZXItbWlkZGxlLWNvbG9yKCkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tc2Vjb25kYXJ5LWJldmVsKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWJldmVsKGJ0bi1oZXJvLXNlY29uZGFyeS1taWRkbGUtY29sb3IoKSk7XG59XG5cblxuLy8gR2xvd1xuQGZ1bmN0aW9uIGJ0bi1oZXJvLXByaW1hcnktZ2xvdygpIHtcbiAgQHJldHVybiBidG4taGVyby1nbG93KGJ0bi1oZXJvLXByaW1hcnktZ2xvdy1zaXplLCBidG4taGVyby1wcmltYXJ5LW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXN1Y2Nlc3MtZ2xvdygpIHtcbiAgQHJldHVybiBidG4taGVyby1nbG93KGJ0bi1oZXJvLXN1Y2Nlc3MtZ2xvdy1zaXplLCBidG4taGVyby1zdWNjZXNzLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXdhcm5pbmctZ2xvdygpIHtcbiAgQHJldHVybiBidG4taGVyby1nbG93KGJ0bi1oZXJvLXdhcm5pbmctZ2xvdy1zaXplLCBidG4taGVyby13YXJuaW5nLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWluZm8tZ2xvdygpIHtcbiAgQHJldHVybiBidG4taGVyby1nbG93KGJ0bi1oZXJvLWluZm8tZ2xvdy1zaXplLCBidG4taGVyby1pbmZvLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWRhbmdlci1nbG93KCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdsb3coYnRuLWhlcm8tZGFuZ2VyLWdsb3ctc2l6ZSwgYnRuLWhlcm8tZGFuZ2VyLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXNlY29uZGFyeS1nbG93KCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdsb3coYnRuLWhlcm8tc2Vjb25kYXJ5LWdsb3ctc2l6ZSwgYnRuLWhlcm8tc2Vjb25kYXJ5LW1pZGRsZS1jb2xvcigpKTtcbn1cblxuXG4vLyBCZXZlbC1nbG93LXNoYWRvd1xuQG1peGluIGJ0bi1oZXJvLWJldmVsLWdsb3ctc2hhZG93KCRiZXZlbCwgJGdsb3csICRzaGFkb3cpIHtcbiAgJGJveC1zaGFkb3c6ICRiZXZlbCwgJGdsb3c7XG4gIEBpZiAoJHNoYWRvdyAhPSAnbm9uZScpIHtcbiAgICAkYm94LXNoYWRvdzogJGJveC1zaGFkb3csICRzaGFkb3c7XG4gIH1cbiAgYm94LXNoYWRvdzogJGJveC1zaGFkb3c7XG59XG5cbkBtaXhpbiBidG4taGVyby1wcmltYXJ5LWJldmVsLWdsb3ctc2hhZG93KCkge1xuICAkYmV2ZWw6IGJ0bi1oZXJvLXByaW1hcnktYmV2ZWwoKTtcbiAgJGdsb3c6IGJ0bi1oZXJvLXByaW1hcnktZ2xvdygpO1xuICAkc2hhZG93OiBuYi10aGVtZShidG4taGVyby1zaGFkb3cpO1xuXG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJldmVsLWdsb3ctc2hhZG93KCRiZXZlbCwgJGdsb3csICRzaGFkb3cpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc3VjY2Vzcy1iZXZlbC1nbG93LXNoYWRvdygpIHtcbiAgJGJldmVsOiBidG4taGVyby1zdWNjZXNzLWJldmVsKCk7XG4gICRnbG93OiBidG4taGVyby1zdWNjZXNzLWdsb3coKTtcbiAgJHNoYWRvdzogbmItdGhlbWUoYnRuLWhlcm8tc2hhZG93KTtcblxuICBAaW5jbHVkZSBidG4taGVyby1iZXZlbC1nbG93LXNoYWRvdygkYmV2ZWwsICRnbG93LCAkc2hhZG93KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXdhcm5pbmctYmV2ZWwtZ2xvdy1zaGFkb3coKSB7XG4gICRiZXZlbDogYnRuLWhlcm8td2FybmluZy1iZXZlbCgpO1xuICAkZ2xvdzogYnRuLWhlcm8td2FybmluZy1nbG93KCk7XG4gICRzaGFkb3c6IG5iLXRoZW1lKGJ0bi1oZXJvLXNoYWRvdyk7XG5cbiAgQGluY2x1ZGUgYnRuLWhlcm8tYmV2ZWwtZ2xvdy1zaGFkb3coJGJldmVsLCAkZ2xvdywgJHNoYWRvdyk7XG59XG5cbkBtaXhpbiBidG4taGVyby1pbmZvLWJldmVsLWdsb3ctc2hhZG93KCkge1xuICAkYmV2ZWw6IGJ0bi1oZXJvLWluZm8tYmV2ZWwoKTtcbiAgJGdsb3c6IGJ0bi1oZXJvLWluZm8tZ2xvdygpO1xuICAkc2hhZG93OiBuYi10aGVtZShidG4taGVyby1zaGFkb3cpO1xuXG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJldmVsLWdsb3ctc2hhZG93KCRiZXZlbCwgJGdsb3csICRzaGFkb3cpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tZGFuZ2VyLWJldmVsLWdsb3ctc2hhZG93KCkge1xuICAkYmV2ZWw6IGJ0bi1oZXJvLWRhbmdlci1iZXZlbCgpO1xuICAkZ2xvdzogYnRuLWhlcm8tZGFuZ2VyLWdsb3coKTtcbiAgJHNoYWRvdzogbmItdGhlbWUoYnRuLWhlcm8tc2hhZG93KTtcblxuICBAaW5jbHVkZSBidG4taGVyby1iZXZlbC1nbG93LXNoYWRvdygkYmV2ZWwsICRnbG93LCAkc2hhZG93KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXNlY29uZGFyeS1iZXZlbC1nbG93LXNoYWRvdygpIHtcbiAgJGJldmVsOiBidG4taGVyby1zZWNvbmRhcnktYmV2ZWwoKTtcbiAgJGdsb3c6IGJ0bi1oZXJvLXNlY29uZGFyeS1nbG93KCk7XG4gICRzaGFkb3c6IG5iLXRoZW1lKGJ0bi1oZXJvLXNoYWRvdyk7XG5cbiAgQGluY2x1ZGUgYnRuLWhlcm8tYmV2ZWwtZ2xvdy1zaGFkb3coJGJldmVsLCAkZ2xvdywgJHNoYWRvdyk7XG59XG5cblxuLy8gQm9yZGVyXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1ib3JkZXIoKSB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtYm9yZGVyKCkge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbkBtaXhpbiBidG4taGVyby13YXJuaW5nLWJvcmRlcigpIHtcbiAgYm9yZGVyOiBub25lO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mby1ib3JkZXIoKSB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWRhbmdlci1ib3JkZXIoKSB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXNlY29uZGFyeS1ib3JkZXIoKSB7XG4gIGJvcmRlcjogMnB4IHNvbGlkIG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYm9yZGVyKTtcblxuICBAaW5jbHVkZSBuYi1mb3ItdGhlbWUoY29ycG9yYXRlKSB7XG4gICAgYm9yZGVyOiBub25lO1xuICB9XG59XG5cblxuLy8gSG92ZXJcbkBtaXhpbiBidG4taGVyby1wcmltYXJ5LWhvdmVyKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1ob3ZlcihidG4taGVyby1wcmltYXJ5LWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc3VjY2Vzcy1ob3ZlcigpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taG92ZXIoYnRuLWhlcm8tc3VjY2Vzcy1saWdodC1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXdhcm5pbmctaG92ZXIoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWhvdmVyKGJ0bi1oZXJvLXdhcm5pbmctbGlnaHQtZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1pbmZvLWhvdmVyKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1ob3ZlcihidG4taGVyby1pbmZvLWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tZGFuZ2VyLWhvdmVyKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1ob3ZlcihidG4taGVyby1kYW5nZXItbGlnaHQtZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktaG92ZXIoKSB7XG4gICY6aG92ZXIsXG4gIC5ob3ZlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYShuYi10aGVtZShidG4tc2Vjb25kYXJ5LWJvcmRlciksIDAuMik7XG4gIH1cbn1cblxuLy8gRm9jdXNcbkBtaXhpbiBidG4taGVyby1wcmltYXJ5LWZvY3VzKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1mb2N1cyhidG4taGVyby1wcmltYXJ5LWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc3VjY2Vzcy1mb2N1cygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZm9jdXMoYnRuLWhlcm8tc3VjY2Vzcy1saWdodC1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXdhcm5pbmctZm9jdXMoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWZvY3VzKGJ0bi1oZXJvLXdhcm5pbmctbGlnaHQtZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1pbmZvLWZvY3VzKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1mb2N1cyhidG4taGVyby1pbmZvLWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tZGFuZ2VyLWZvY3VzKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1mb2N1cyhidG4taGVyby1kYW5nZXItbGlnaHQtZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktZm9jdXMoKSB7XG4gICRjb2xvcjogbmItdGhlbWUoYnRuLXNlY29uZGFyeS1ib3JkZXIpO1xuXG4gICY6Zm9jdXMsXG4gIC5mb2N1cyB7XG4gICAgYm9yZGVyLWNvbG9yOiB0aW50KCRjb2xvciwgMTQlKTtcbiAgfVxufVxuXG4vLyBBY3RpdmVcbkBtaXhpbiBidG4taGVyby1wcmltYXJ5LWFjdGl2ZSgpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYWN0aXZlKGJ0bi1oZXJvLXByaW1hcnktZGFyay1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtYWN0aXZlKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1hY3RpdmUoYnRuLWhlcm8tc3VjY2Vzcy1kYXJrLWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8td2FybmluZy1hY3RpdmUoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWFjdGl2ZShidG4taGVyby13YXJuaW5nLWRhcmstZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1pbmZvLWFjdGl2ZSgpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYWN0aXZlKGJ0bi1oZXJvLWluZm8tZGFyay1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWRhbmdlci1hY3RpdmUoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWFjdGl2ZShidG4taGVyby1kYW5nZXItZGFyay1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXNlY29uZGFyeS1hY3RpdmUoKSB7XG4gICRjb2xvcjogbmItdGhlbWUoYnRuLXNlY29uZGFyeS1ib3JkZXIpO1xuXG4gICY6YWN0aXZlLFxuICAuYWN0aXZlIHtcbiAgICBib3JkZXItY29sb3I6IHNoYWRlKCRjb2xvciwgMTQlKTtcbiAgICBib3gtc2hhZG93OiBub25lO1xuICAgIGJhY2tncm91bmQ6IG5vbmU7XG4gIH1cbn1cblxuXG4vLyBEaXNhYmxlZFxuQG1peGluIGJ0bi1oZXJvLWRpc2FibGVkKCkge1xuICAmOmRpc2FibGVkIHtcbiAgICBvcGFjaXR5OiBuYi10aGVtZShidG4tZGlzYWJsZWQtb3BhY2l0eSk7XG4gICAgYm94LXNoYWRvdzogbm9uZTtcbiAgfVxufVxuXG4vLyBMaW5lIGhlaWdodFxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0KCRmb250LXNpemUpIHtcbiAgQHJldHVybiBjYWxjKCgjeyRmb250LXNpemV9ICogMS4yNSkgKyA0cHgpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tbGluZS1oZWlnaHQtbGcoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tbGluZS1oZWlnaHQobmItdGhlbWUoYnRuLWZvbnQtc2l6ZS1sZykpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tbGluZS1oZWlnaHQtbWQoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tbGluZS1oZWlnaHQobmItdGhlbWUoYnRuLWZvbnQtc2l6ZS1tZCkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tbGluZS1oZWlnaHQtc20oKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tbGluZS1oZWlnaHQobmItdGhlbWUoYnRuLWZvbnQtc2l6ZS1zbSkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tbGluZS1oZWlnaHQtdG4oKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tbGluZS1oZWlnaHQobmItdGhlbWUoYnRuLWZvbnQtc2l6ZS10bikpO1xufVxuXG5cbkBtaXhpbiBidG4taGVyby1saW5lLWhlaWdodCgpIHtcblxuICBsaW5lLWhlaWdodDogYnRuLWhlcm8tbGluZS1oZWlnaHQtbWQoKTtcblxuICAmLmJ0bi5idG4tbGcge1xuICAgIGxpbmUtaGVpZ2h0OiBidG4taGVyby1saW5lLWhlaWdodC1sZygpO1xuICB9XG5cbiAgJi5idG4uYnRuLW1kIHtcbiAgICBsaW5lLWhlaWdodDogYnRuLWhlcm8tbGluZS1oZWlnaHQtbWQoKTtcbiAgfVxuXG4gICYuYnRuLmJ0bi1zbSB7XG4gICAgbGluZS1oZWlnaHQ6IGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LXNtKCk7XG4gIH1cblxuICAmLmJ0bi5idG4tdG4ge1xuICAgIGxpbmUtaGVpZ2h0OiBidG4taGVyby1saW5lLWhlaWdodC10bigpO1xuICB9XG59XG5cbi8vIFB1bHNlXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1wdWxzZSgpIHtcbiAgQGluY2x1ZGUgYnRuLXB1bHNlKGhlcm8tcHJpbWFyeSwgbmItdGhlbWUoY29sb3ItcHJpbWFyeSkpO1xufVxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtcHVsc2UoKSB7XG4gIEBpbmNsdWRlIGJ0bi1wdWxzZShoZXJvLXN1Y2Nlc3MsIG5iLXRoZW1lKGNvbG9yLXN1Y2Nlc3MpKTtcbn1cbkBtaXhpbiBidG4taGVyby1kYW5nZXItcHVsc2UoKSB7XG4gIEBpbmNsdWRlIGJ0bi1wdWxzZShoZXJvLWRhbmdlciwgbmItdGhlbWUoY29sb3ItZGFuZ2VyKSk7XG59XG5AbWl4aW4gYnRuLWhlcm8taW5mby1wdWxzZSgpIHtcbiAgQGluY2x1ZGUgYnRuLXB1bHNlKGhlcm8taW5mbywgbmItdGhlbWUoY29sb3ItaW5mbykpO1xufVxuQG1peGluIGJ0bi1oZXJvLXdhcm5pbmctcHVsc2UoKSB7XG4gIEBpbmNsdWRlIGJ0bi1wdWxzZShoZXJvLXdhcm5pbmcsIG5iLXRoZW1lKGNvbG9yLXdhcm5pbmcpKTtcbn1cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktcHVsc2UoKSB7XG4gIEBpbmNsdWRlICBidG4tcHVsc2UoaGVyby1zZWNvbmRhcnksIG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYm9yZGVyKSk7XG59XG4iLCJAaW1wb3J0ICcuLi8uLi8uLi9AdGhlbWUvc3R5bGVzL3RoZW1lcyc7XHJcbkBpbXBvcnQgJ35AbmVidWxhci90aGVtZS9zdHlsZXMvZ2xvYmFsL2Jvb3RzdHJhcC9oZXJvLWJ1dHRvbnMnO1xyXG5cclxuQGluY2x1ZGUgbmItaW5zdGFsbC1jb21wb25lbnQoKSB7XHJcbiAgbmItY2FyZCB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGhlaWdodDogODAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG5cclxuICAgICRiZXZlbDogYnRuLWhlcm8tYmV2ZWwobmItdGhlbWUoY2FyZC1iZykpO1xyXG4gICAgJHNoYWRvdzogbmItdGhlbWUoYnRuLWhlcm8tc2hhZG93KTtcclxuICAgIGJveC1zaGFkb3c6ICRiZXZlbCwgJHNoYWRvdztcclxuXHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZDVkYmUwO1xyXG4gICAgYm9yZGVyLXRvcC1jb2xvcjogcmdiKDIxMywgMjE5LCAyMjQpO1xyXG4gICAgYm9yZGVyLXRvcC1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItdG9wLXdpZHRoOiAxcHg7XHJcbiAgICBib3JkZXItcmlnaHQtY29sb3I6IHJnYigyMTMsIDIxOSwgMjI0KTtcclxuICAgIGJvcmRlci1yaWdodC1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItcmlnaHQtd2lkdGg6IDFweDtcclxuICAgIGJvcmRlci1ib3R0b20tY29sb3I6IHJnYigyMTMsIDIxOSwgMjI0KTtcclxuICAgIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xyXG4gICAgYm9yZGVyLWxlZnQtY29sb3I6IHJnYigyMTMsIDIxOSwgMjI0KTtcclxuICAgIGJvcmRlci1sZWZ0LXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci1sZWZ0LXdpZHRoOiAxcHg7XHJcbiAgICBib3JkZXItaW1hZ2Utc291cmNlOiBpbml0aWFsO1xyXG4gICAgYm9yZGVyLWltYWdlLXNsaWNlOiBpbml0aWFsO1xyXG4gICAgYm9yZGVyLWltYWdlLXdpZHRoOiBpbml0aWFsO1xyXG4gICAgYm9yZGVyLWltYWdlLW91dHNldDogaW5pdGlhbDtcclxuICAgIGJvcmRlci1pbWFnZS1yZXBlYXQ6IGluaXRpYWw7XHJcbiAgICBcclxuICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgcGFkZGluZzogMC42MjVyZW07XHJcbiAgICB9XHJcblxyXG4gICAgLmljb24ge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgd2lkdGg6IDIuMjVyZW07XHJcbiAgICAgIGhlaWdodDogMi43NXJlbTtcclxuICAgICAgZm9udC1zaXplOiAxLjI1cmVtO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpO1xyXG4gICAgICB0cmFuc2l0aW9uOiB3aWR0aCAwLjRzIGVhc2U7XHJcbiAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XHJcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtLXN0eWxlOiBwcmVzZXJ2ZS0zZDtcclxuICAgICAgLXdlYmtpdC1iYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAgIGNvbG9yOiBuYi10aGVtZShjb2xvci13aGl0ZSk7XHJcblxyXG4gICAgICAmLnByaW1hcnkge1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLXByaW1hcnktZ3JhZGllbnQoKTtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWJldmVsLWdsb3ctc2hhZG93KCk7XHJcbiAgICAgIH1cclxuICAgICAgJi5zdWNjZXNzIHtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLWdyYWRpZW50KCk7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1iZXZlbC1nbG93LXNoYWRvdygpO1xyXG4gICAgICB9XHJcbiAgICAgICYuaW5mbyB7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8taW5mby1ncmFkaWVudCgpO1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLWluZm8tYmV2ZWwtZ2xvdy1zaGFkb3coKTtcclxuICAgICAgfVxyXG4gICAgICAmLndhcm5pbmcge1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLXdhcm5pbmctZ3JhZGllbnQoKTtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWJldmVsLWdsb3ctc2hhZG93KCk7XHJcbiAgICAgIH1cclxuICAgICAgJi5kYW5nZXIge1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlci1ncmFkaWVudCgpO1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlci1iZXZlbC1nbG93LXNoYWRvdygpO1xyXG4gICAgICB9XHJcbiAgICAgICYuc2Vjb25kYXJ5IHtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnktYmcoKTtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnktYmV2ZWwtZ2xvdy1zaGFkb3coKTtcclxuICAgICAgICBjb2xvcjogbmItdGhlbWUoY2FyZC1mZyk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIEBpbmNsdWRlIG5iLWZvci10aGVtZShjb3Jwb3JhdGUpIHtcclxuICAgICAgICAmLnByaW1hcnksXHJcbiAgICAgICAgJi5zdWNjZXNzLFxyXG4gICAgICAgICYuaW5mbyxcclxuICAgICAgICAmLndhcm5pbmcsXHJcbiAgICAgICAgJi5kYW5nZXIsXHJcbiAgICAgICAgJi5zZWNvbmRhcnkge1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgYmFja2dyb3VuZDogbGlnaHRlbihuYi10aGVtZShjYXJkLWJnKSwgNSUpO1xyXG5cclxuICAgICAgLmljb24ge1xyXG4gICAgICAgICYucHJpbWFyeSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBidG4taGVyby1wcmltYXJ5LWxpZ2h0LWdyYWRpZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYuc3VjY2VzcyB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBidG4taGVyby1zdWNjZXNzLWxpZ2h0LWdyYWRpZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYuaW5mbyB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBidG4taGVyby1pbmZvLWxpZ2h0LWdyYWRpZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYud2FybmluZyB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBidG4taGVyby13YXJuaW5nLWxpZ2h0LWdyYWRpZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYuZGFuZ2VyIHtcclxuICAgICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGJ0bi1oZXJvLWRhbmdlci1saWdodC1ncmFkaWVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLnNlY29uZGFyeSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBidG4taGVyby1zZWNvbmRhcnktbGlnaHQtZ3JhZGllbnQoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAmLm9mZiB7XHJcbiAgICAgIGNvbG9yOiBuYi10aGVtZShjYXJkLWZnKTtcclxuXHJcbiAgICAgIC5pY29uIHtcclxuICAgICAgICBjb2xvcjogbmItdGhlbWUoY2FyZC1mZyk7XHJcblxyXG4gICAgICAgICYucHJpbWFyeSwgJi5zdWNjZXNzLCAmLmluZm8sICYud2FybmluZywgJi5kYW5nZXIge1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgdHJhbnNwYXJlbnQsIHRyYW5zcGFyZW50KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICYuc2Vjb25kYXJ5IHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLnRpdGxlIHtcclxuICAgICAgICBjb2xvcjogbmItdGhlbWUoY2FyZC1mZyk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAuZGV0YWlscyB7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgIEBpbmNsdWRlIG5iLWx0cihwYWRkaW5nLCAwIDAuNXJlbSAwIDAuNzVyZW0pO1xyXG4gICAgICBAaW5jbHVkZSBuYi1ydGwocGFkZGluZywgMCAwLjc1cmVtIDAgMC41cmVtKTtcclxuICAgICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgIH1cclxuICAgICBsYWJlbHtcclxuICAgICAgIGZvbnQtc2l6ZTogNzAlO1xyXG4gICAgICAgbGluZS1oZWlnaHQ6MC4xcmVtO1xyXG4gICAgICAgd29yZC13cmFwOiBicmVhay13b3JkO1xyXG4gICAgIH1cclxuICAgIC50aXRsZSB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBuYi10aGVtZShmb250LXNlY29uZGFyeSk7XHJcbiAgICAgIGZvbnQtc2l6ZTogODUlO1xyXG4gICAgICBmb250LXdlaWdodDogbmItdGhlbWUoZm9udC13ZWlnaHQtYm9sZCk7XHJcbiAgICAgIGNvbG9yOiBuYi10aGVtZShjYXJkLWZnLWhlYWRpbmcpO1xyXG4gICAgICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLnN0YXR1cyB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTAwJTtcclxuICAgICAgZm9udC13ZWlnaHQ6IG5iLXRoZW1lKGZvbnQtd2VpZ2h0LWxpZ2h0KTtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgY29sb3I6IG5iLXRoZW1lKGNhcmQtZmcpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG5cclxuICBAaW5jbHVkZSBuYi1mb3ItdGhlbWUoY29ycG9yYXRlKSB7XHJcbiAgICBuYi1jYXJkIHtcclxuICAgICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcblxyXG5cclxuLyogIEBpbmNsdWRlIG5iLWZvci10aGVtZShjb3NtaWMpIHtcclxuICAgIG5iLWNhcmQge1xyXG4gICAgICAmLm9mZiAuaWNvbi1jb250YWluZXIge1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLWx0cihib3JkZXItcmlnaHQsIDFweCBzb2xpZCBuYi10aGVtZShzZXBhcmF0b3IpKTtcclxuICAgICAgICBAaW5jbHVkZSBuYi1ydGwoYm9yZGVyLWxlZnQsIDFweCBzb2xpZCBuYi10aGVtZShzZXBhcmF0b3IpKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuZGV0YWlscyB7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItbHRyKHBhZGRpbmctbGVmdCwgMS4yNXJlbSk7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItcnRsKHBhZGRpbmctcmlnaHQsIDEuMjVyZW0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuaWNvbiB7XHJcbiAgICAgICAgd2lkdGg6IDdyZW07XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogNC41cmVtO1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLWx0cihib3JkZXItcmFkaXVzLCBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpIDAgMCBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpKTtcclxuICAgICAgICBAaW5jbHVkZSBuYi1ydGwoYm9yZGVyLXJhZGl1cywgMCBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpIG5iLXRoZW1lKGNhcmQtYm9yZGVyLXJhZGl1cykgMCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50aXRsZSB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IG5iLXRoZW1lKGZvbnQtd2VpZ2h0LWJvbGRlcik7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5zdGF0dXMge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBuYi10aGVtZShmb250LXdlaWdodC1saWdodCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9Ki8iLCIvLyBAbmVidWxhciB0aGVtaW5nIGZyYW1ld29ya1xyXG5AaW1wb3J0ICd+QG5lYnVsYXIvdGhlbWUvc3R5bGVzL3RoZW1pbmcnO1xyXG4vLyBAbmVidWxhciBvdXQgb2YgdGhlIGJveCB0aGVtZXNcclxuQGltcG9ydCAnfkBuZWJ1bGFyL3RoZW1lL3N0eWxlcy90aGVtZXMnO1xyXG5cclxuLy8gd2hpY2ggdGhlbWVzIHlvdSB3aGF0IHRvIGVuYWJsZSAoZW1wdHkgdG8gZW5hYmxlIGFsbClcclxuJG5iLWVuYWJsZWQtdGhlbWVzOiAoKTtcclxuXHJcbiRuYi10aGVtZXM6IG5iLXJlZ2lzdGVyLXRoZW1lKChcclxuIC8vIGFwcCB3aXNlIHZhcmlhYmxlcyBmb3IgZWFjaCB0aGVtZVxyXG4gIHNpZGViYXItaGVhZGVyLWdhcDogMnJlbSxcclxuICBzaWRlYmFyLWhlYWRlci1oZWlnaHQ6IGluaXRpYWwsXHJcbiAgbGF5b3V0LWNvbnRlbnQtd2lkdGg6IDE0MDBweCxcclxuXHJcbiAgZm9udC1tYWluOiBSb2JvdG8sXHJcbiAgZm9udC1zZWNvbmRhcnk6IFJvYm90byxcclxuXHJcbiAgc3dpdGNoZXItYmFja2dyb3VuZDogI2ViZWZmNSxcclxuICBzd2l0Y2hlci1iYWNrZ3JvdW5kLXBlcmNlbnRhZ2U6IDUwJSxcclxuICBkcm9wcy1pY29uLWxpbmUtZ2FkaWVudDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoIzAxZGJiNSwgIzBiYmI3OSksXHJcbiksIGRlZmF1bHQsIGRlZmF1bHQpO1xyXG5cclxuJG5iLXRoZW1lczogbmItcmVnaXN0ZXItdGhlbWUoKFxyXG4gIC8vIGFwcCB3aXNlIHZhcmlhYmxlcyBmb3IgZWFjaCB0aGVtZVxyXG4gIHNpZGViYXItaGVhZGVyLWdhcDogMnJlbSxcclxuICBzaWRlYmFyLWhlYWRlci1oZWlnaHQ6IGluaXRpYWwsXHJcbiAgbGF5b3V0LWNvbnRlbnQtd2lkdGg6IDE0MDBweCxcclxuXHJcbiAgZm9udC1tYWluOiBSb2JvdG8sXHJcbiAgZm9udC1zZWNvbmRhcnk6IEV4byxcclxuXHJcbiAgc3dpdGNoZXItYmFja2dyb3VuZDogIzRlNDFhNSxcclxuICBzd2l0Y2hlci1iYWNrZ3JvdW5kLXBlcmNlbnRhZ2U6IDE0JSxcclxuICBkcm9wcy1pY29uLWxpbmUtZ2FkaWVudDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoI2EyNThmZSwgIzc5NThmYSksXHJcbiksIGNvc21pYywgY29zbWljKTtcclxuXHJcbiRuYi10aGVtZXM6IG5iLXJlZ2lzdGVyLXRoZW1lKChcclxuICAvLyBhcHAgd2lzZSB2YXJpYWJsZXMgZm9yIGVhY2ggdGhlbWVcclxuICBzaWRlYmFyLWhlYWRlci1nYXA6IDJyZW0sXHJcbiAgc2lkZWJhci1oZWFkZXItaGVpZ2h0OiBpbml0aWFsLFxyXG4gIGxheW91dC1jb250ZW50LXdpZHRoOiAxNDAwcHgsXHJcblxyXG4gIGZvbnQtbWFpbjogUm9ib3RvLFxyXG4gIGZvbnQtc2Vjb25kYXJ5OiBSb2JvdG8sXHJcblxyXG4gIHN3aXRjaGVyLWJhY2tncm91bmQ6ICMyYjJkMzQsXHJcbiAgc3dpdGNoZXItYmFja2dyb3VuZC1wZXJjZW50YWdlOiAxNCUsXHJcbiAgZHJvcHMtaWNvbi1saW5lLWdhZGllbnQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KCNlOWU4ZWIsICNhN2EyYmUpLFxyXG4pLCBjb3Jwb3JhdGUsIGNvcnBvcmF0ZSk7XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/pages/mobileperf/status-card/status-card.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/mobileperf/status-card/status-card.component.ts ***!
  \***********************************************************************/
/*! exports provided: StatusCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusCardComponent", function() { return StatusCardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var StatusCardComponent = /** @class */ (function () {
    function StatusCardComponent() {
        this.on = true;
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], StatusCardComponent.prototype, "title", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], StatusCardComponent.prototype, "type", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "on", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "value", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "value2", void 0);
    StatusCardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-status-card',
            template: __webpack_require__(/*! ./status-card.component.html */ "./src/app/pages/mobileperf/status-card/status-card.component.html"),
            styles: [__webpack_require__(/*! ./status-card.component.scss */ "./src/app/pages/mobileperf/status-card/status-card.component.scss")]
        })
    ], StatusCardComponent);
    return StatusCardComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/test-runs/test-runs.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/pages/mobileperf/test-runs/test-runs.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <div class=\"col-md-12\">\n    <span class=\"fRight\" matTooltip=\"Ux Profiler Mobile\" matTooltipPosition=\"below\">\n      <img class=\"logosize\" src=\"assets\\images\\ux_logo.png\" />\n    </span>\n  </div>\n</div>\n<div class=\"row justify-content-center\">\n  <div class=\"col-md-12\">\n    <h3 class=\"header\">Run Summary</h3>\n  </div>\n</div>\n<br/>\n<div id='tabbg' class=\"mat-elevation-z8\">\n  <div class=\"row\">\n    <div class=\"col-md-1\">\n    </div>\n        <div class=\"col-md-3\">\n        <mat-form-field>\n            <mat-label>Search</mat-label>\n            <input matInput (keyup)=\"applyFilter($event)\" placeholder=\"Ex. Mia\">\n        </mat-form-field>\n    </div>\n    <div class=\"col-md-12\">\n      <table table-bordered table-hover mat-table [dataSource]=\"dataSource\" matSort width=\"100%\">\n        <ng-container matColumnDef=\"runid\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header><h6>Run ID</h6></th>\n          <td mat-cell *matCellDef=\"let element\"> \n            <a [routerLink]=\"['/pages/uxmob/analysis/',element.objectid,element.devicetype=='iOS'?'Ios':'Android']\"\n              routerLinkActive=\"active\">{{element.runid}}</a></td>\n        </ng-container>\n\n        <ng-container matColumnDef=\"deviceos\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header> <h6>Device OS</h6>  </th>\n          <td mat-cell *matCellDef=\"let element\">{{element.deviceos}}  </td>\n        </ng-container>\n        <ng-container matColumnDef=\"devicetype\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header> <h6>Device Type</h6>  </th>\n          <td mat-cell *matCellDef=\"let element\">{{element.devicetype}}  </td>\n        </ng-container>\n        <ng-container matColumnDef=\"devicename\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header><h6> Device Name </h6></th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.devicename}}\n          </td>\n        </ng-container>\n        <ng-container matColumnDef=\"packagename\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>  <h6>Package Name</h6> </th>\n          <td mat-cell *matCellDef=\"let element\">{{element.packagename}}\n\n          </td>\n        </ng-container>\n        <ng-container matColumnDef=\"creationdate\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>  <h6>Timestamp</h6> </th>\n          <td mat-cell *matCellDef=\"let element\">{{element.creationdate}}\n\n          </td>\n        </ng-container>\n       <!--  <ng-container matColumnDef=\"userid\">\n          <th mat-header-cell *matHeaderCellDef mat-sort-header><h6>User Id</h6> </th>\n          <td mat-cell *matCellDef=\"let element\"> {{element.userid}}\n\n          </td>\n        </ng-container> -->\n          <ng-container matColumnDef=\"slamet\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header>  <h6>SLA Goal</h6> </th>\n            <td mat-cell *matCellDef=\"let element\">\n              <mat-icon\n              [ngClass]=\"{'greenColor': element.slamet, 'redColor': !element.slamet}\">\n              fiber_manual_record</mat-icon>\n            </td>\n          </ng-container>\n          <tr mat-header-row *matHeaderRowDef=\"displayedcolumns\"></tr>\n          <tr mat-row class=\"rowclick\" (click)=\"viewanalysis(row)\" *matRowDef=\"let row; columns: displayedcolumns;\"></tr>\n      </table>\n\n      <mat-paginator [pageSizeOptions]=\"[5, 10, 25, 100]\" showFirstLastButtons></mat-paginator>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/pages/mobileperf/test-runs/test-runs.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/pages/mobileperf/test-runs/test-runs.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".redColor {\n  color: red; }\n\n.greenColor {\n  color: green; }\n\n.yellowColor {\n  color: yellow; }\n\n.header {\n  text-align: center;\n  /*  color:green; */\n  font-weight: bold; }\n\n#tabbg {\n  background-color: white; }\n\nh5 {\n  font-weight: normal;\n  text-align: center; }\n\n.lPadding50px {\n  padding-left: 50px; }\n\n.rowclick {\n  cursor: pointer; }\n\n.fRight {\n  float: right; }\n\n:host ::ng-deep .mat-sort-header-container {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-weight: bold; }\n\nh6 {\n  font-weight: bold; }\n\nth.mat-header-cell, td.mat-cell {\n  text-align: center; }\n\n.logosize {\n  width: 50px !important;\n  height: 50px !important; }\n\n.fRight {\n  float: right; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar {\n  width: 10px !important;\n  height: 5px; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar-thumb {\n  background: #a8a6a6 !important;\n  cursor: pointer;\n  border-radius: 5px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi90ZXN0LXJ1bnMvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxwYWdlc1xcbW9iaWxlcGVyZlxcdGVzdC1ydW5zXFx0ZXN0LXJ1bnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxVQUFVLEVBQUE7O0FBRWQ7RUFDSSxZQUFZLEVBQUE7O0FBRWhCO0VBQ0ksYUFBYSxFQUFBOztBQUVqQjtFQUNJLGtCQUFrQjtFQUNuQixrQkFBQTtFQUNDLGlCQUFpQixFQUFBOztBQUVyQjtFQUNJLHVCQUF1QixFQUFBOztBQUUzQjtFQUNJLG1CQUFtQjtFQUNuQixrQkFBa0IsRUFBQTs7QUFHdEI7RUFDSSxrQkFBa0IsRUFBQTs7QUFFdEI7RUFDSSxlQUFlLEVBQUE7O0FBRW5CO0VBQ0ksWUFBWSxFQUFBOztBQUVoQjtFQUNJLG9CQUFhO0VBQWIsb0JBQWE7RUFBYixhQUFhO0VBQ2Isd0JBQXVCO01BQXZCLHFCQUF1QjtVQUF2Qix1QkFBdUI7RUFDdkIsaUJBQWlCLEVBQUE7O0FBR3JCO0VBQ0ksaUJBQWlCLEVBQUE7O0FBRXJCO0VBQ0ksa0JBQWtCLEVBQUE7O0FBS3RCO0VBQ0ksc0JBQXNCO0VBQ3RCLHVCQUF1QixFQUFBOztBQUczQjtFQUNJLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxzQkFBc0I7RUFDdEIsV0FBVyxFQUFBOztBQUdmO0VBQ0ksOEJBQThCO0VBQzlCLGVBQWU7RUFDZiw2QkFBNkIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21vYmlsZXBlcmYvdGVzdC1ydW5zL3Rlc3QtcnVucy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ucmVkQ29sb3J7XHJcbiAgICBjb2xvcjogcmVkO1xyXG59XHJcbi5ncmVlbkNvbG9ye1xyXG4gICAgY29sb3I6IGdyZWVuO1xyXG59XHJcbi55ZWxsb3dDb2xvcntcclxuICAgIGNvbG9yOiB5ZWxsb3c7XHJcbn1cclxuLmhlYWRlcntcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgLyogIGNvbG9yOmdyZWVuOyAqL1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuI3RhYmJne1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuaDV7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4ubFBhZGRpbmc1MHB4e1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1MHB4O1xyXG59XHJcbi5yb3djbGlja3tcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4uZlJpZ2h0e1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcbjpob3N0IDo6bmctZGVlcCAgLm1hdC1zb3J0LWhlYWRlci1jb250YWluZXIgeyBcclxuICAgIGRpc3BsYXk6IGZsZXg7ICBcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyOyBcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgXHJcbn1cclxuaDZ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG50aC5tYXQtaGVhZGVyLWNlbGwsIHRkLm1hdC1jZWxsIHsgXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IFxyXG4gICBcclxufVxyXG5cclxuXHJcbi5sb2dvc2l6ZSB7XHJcbiAgICB3aWR0aDogNTBweCAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiA1MHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5mUmlnaHR7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbn1cclxuXHJcbi9kZWVwLyAubmItdGhlbWUtZGVmYXVsdCBuYi1sYXlvdXQgOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICB3aWR0aDogMTBweCAhaW1wb3J0YW50OyAvLzVweDtcclxuICAgIGhlaWdodDogNXB4O1xyXG59XHJcblxyXG4vZGVlcC8gLm5iLXRoZW1lLWRlZmF1bHQgbmItbGF5b3V0IDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgYmFja2dyb3VuZDogI2E4YTZhNiAhaW1wb3J0YW50OyAvLyNkYWRhZGE7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHggIWltcG9ydGFudDsgLy8yLjVweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/mobileperf/test-runs/test-runs.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/mobileperf/test-runs/test-runs.component.ts ***!
  \*******************************************************************/
/*! exports provided: TestRunsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestRunsComponent", function() { return TestRunsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var TestRunsComponent = /** @class */ (function () {
    function TestRunsComponent(router, data, sidebarService) {
        this.router = router;
        this.data = data;
        this.sidebarService = sidebarService;
        this.testrunstabledata = [];
        this.JsonArray = [];
        this.displayedcolumns = [
            'runid', 'deviceos', 'devicename', 'devicetype', 'packagename', 'creationdate', /* 'userid', */ 'slamet'
        ];
        this.sidebarService.expand('menu-sidebar');
        this.sidebarService.toggle(true, 'menu-sidebar');
    }
    TestRunsComponent.prototype.ngOnInit = function () {
        var _this = this;
        //console.log(localStorage.getItem('appid'))
        this.data.gettestruns().subscribe(function (data) {
            _this.JsonArray = data;
            for (var i = 0; i < _this.JsonArray.length; i++) {
                //console.log(this.JsonArray[i])
                if (_this.JsonArray[i].hasOwnProperty('SLAMet')) {
                    //console.log(this.JsonArray[i].hasOwnProperty('SLAMet'))
                    if (_this.JsonArray[i]["SLAMet"].toLowerCase() == "pass") {
                        _this.slamet = true;
                    }
                    else {
                        _this.slamet = false;
                    }
                }
                var devicetype = void 0;
                if (_this.JsonArray[i]["DeviceType"] == "Ios") {
                    devicetype = "iOS";
                }
                if (_this.JsonArray[i]["DeviceType"] == "Android") {
                    devicetype = "Android";
                }
                _this.testrunstabledata.push({
                    objectid: _this.JsonArray[i]["_id"],
                    runid: _this.JsonArray[i]["RunId"],
                    deviceos: _this.JsonArray[i]["DeviceOS"],
                    devicetype: devicetype,
                    devicename: _this.JsonArray[i]["DeviceName"],
                    packagename: _this.JsonArray[i]["PackageName"],
                    userid: _this.JsonArray[i]["UserId"],
                    slamet: _this.slamet,
                    creationdate: _this.JsonArray[i]["CreationDate"],
                });
            }
            _this.testrunstabledata.sort(_this.sorter);
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.testrunstabledata);
            _this.dataSource.sort = _this.sort;
            _this.dataSource.paginator = _this.paginator;
        });
    };
    TestRunsComponent.prototype.applyFilter = function (event) {
        var filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    };
    TestRunsComponent.prototype.viewanalysis = function (row) {
        if (row["devicetype"] == "iOS") {
            console.log("in");
            row["devicetype"] = "Ios";
        }
        this.router.navigate(['/pages/uxmob/analysis/', row["objectid"], row["devicetype"]]);
    };
    TestRunsComponent.prototype.sorter = function (a, b) {
        // Use toUpperCase() to ignore character casing
        var t1 = a.runid;
        var t2 = b.runid;
        var comparison = 0;
        if (t1 < t2) {
            comparison = 1;
        }
        else if (t1 > t2) {
            comparison = -1;
        }
        return comparison;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"])
    ], TestRunsComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"])
    ], TestRunsComponent.prototype, "sort", void 0);
    TestRunsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: './test-runs.component',
            template: __webpack_require__(/*! ./test-runs.component.html */ "./src/app/pages/mobileperf/test-runs/test-runs.component.html"),
            changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
            styles: [__webpack_require__(/*! ./test-runs.component.scss */ "./src/app/pages/mobileperf/test-runs/test-runs.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_3__["MobilePerfService"],
            _nebular_theme__WEBPACK_IMPORTED_MODULE_4__["NbSidebarService"]])
    ], TestRunsComponent);
    return TestRunsComponent;
}());



/***/ }),

/***/ "./src/app/pages/mobileperf/waterfallchart/waterfallchart.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/mobileperf/waterfallchart/waterfallchart.component.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "div {\n  overflow: auto;\n  height: 380px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi93YXRlcmZhbGxjaGFydC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxtb2JpbGVwZXJmXFx3YXRlcmZhbGxjaGFydFxcd2F0ZXJmYWxsY2hhcnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFjO0VBQ2QsYUFBWSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9iaWxlcGVyZi93YXRlcmZhbGxjaGFydC93YXRlcmZhbGxjaGFydC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImRpdntcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgaGVpZ2h0OjM4MHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/mobileperf/waterfallchart/waterfallchart.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/mobileperf/waterfallchart/waterfallchart.component.ts ***!
  \*****************************************************************************/
/*! exports provided: WaterfallchartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterfallchartComponent", function() { return WaterfallchartComponent; });
/* harmony import */ var _assets_modules_perfcascade_ts_main__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../assets/modules/perfcascade/ts/main */ "./src/assets/modules/perfcascade/ts/main.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../mobileperf-data.service */ "./src/app/pages/mobileperf/mobileperf-data.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var WaterfallchartComponent = /** @class */ (function () {
    function WaterfallchartComponent(renderer, changeDetectorRefs, elRef, data) {
        this.renderer = renderer;
        this.changeDetectorRefs = changeDetectorRefs;
        this.elRef = elRef;
        this.data = data;
        this.waterfallChart = this.data.waterfallChartData;
        this.initializeValue();
    }
    WaterfallchartComponent.prototype.initializeValue = function () {
        var _this = this;
        this.data.getharfile(this.data.waterfallChartData["transaction"]).subscribe(function (data) {
            if (data["log"]["entries"].length == 0) {
                //console.log("Error")
            }
            else {
                var googlechartdata = data;
                // let perfCascadeSvg = perfCascade.fromJson(googlechartdata);
                var perfCascadeSvg = _assets_modules_perfcascade_ts_main__WEBPACK_IMPORTED_MODULE_0__["fromHar"](googlechartdata);
                var div = _this.renderer.createElement('div');
                _this.renderer.appendChild(div, perfCascadeSvg);
                //this.renderer.setAttribute(this.elRef.nativeElement, 'addClassForChart');
                _this.renderer.appendChild(_this.elRef.nativeElement, div);
                _this.changeDetectorRefs.markForCheck();
            }
        });
    };
    WaterfallchartComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'waterfallchart',
            template: '',
            styles: [__webpack_require__(/*! ./waterfallchart.component.scss */ "./src/app/pages/mobileperf/waterfallchart/waterfallchart.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _mobileperf_data_service__WEBPACK_IMPORTED_MODULE_2__["MobilePerfService"]])
    ], WaterfallchartComponent);
    return WaterfallchartComponent;
}());



/***/ })

}]);
//# sourceMappingURL=default~app-pages-pages-module~mobileperf-mobileperf-module.js.map