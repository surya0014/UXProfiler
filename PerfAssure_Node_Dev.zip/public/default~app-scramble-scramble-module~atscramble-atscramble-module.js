(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~app-scramble-scramble-module~atscramble-atscramble-module"],{

/***/ "./src/app/pages/accessibility/accessibility-data.service.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/accessibility/accessibility-data.service.ts ***!
  \*******************************************************************/
/*! exports provided: AccessibilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessibilityService", function() { return AccessibilityService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_add_operator_timeout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/timeout */ "./node_modules/rxjs-compat/_esm5/add/operator/timeout.js");
/* harmony import */ var rxjs_add_operator_take__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/take */ "./node_modules/rxjs-compat/_esm5/add/operator/take.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AccessibilityService = /** @class */ (function () {
    //private url: string = 'http://ec2-52-52-49-127.us-west-1.compute.amazonaws.com';
    //private url: string = 'http://ec2-13-233-83-221.ap-south-1.compute.amazonaws.com:1000';//Fastest
    // private url: string = 'http://ec2-13-234-166-85.ap-south-1.compute.amazonaws.com'; //AWS Dev 3
    function AccessibilityService(http) {
        this.http = http;
        /*
        toolURIs = JSON.parse(localStorage.getItem("toolURIs"));
        MobilePerf = this.toolURIs.find((x) => { return (x.toolName == "MobilePerf"); });
        private url: string = this.MobilePerf.URI;//dynamically fetching URIs
         */
        this.url = ''; //Production
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        this.waterfallChartData = {};
    }
    AccessibilityService.prototype.geturl = function () {
        return this.url;
    };
    AccessibilityService.prototype.getscenariolist = function () {
        var appid = localStorage.getItem('appid');
        return this.http.get(this.url + '/accessibility/getscenariolist?appid=' + appid);
    };
    AccessibilityService.prototype.createscenario = function (temp) {
        var appid = localStorage.getItem('appid');
        return this.http.post(this.url + "/accessibility/savescenario?appid=" + appid, temp);
    };
    AccessibilityService.prototype.updatescenario = function (temp) {
        var appid = localStorage.getItem('appid');
        return this.http.post(this.url + "/accessibility/updatescenario?appid=" + appid, temp);
    };
    AccessibilityService.prototype.executescenario = function (scenarioname, appurl, scriptid, type, applicationname) {
        var appid = localStorage.getItem('appid');
        var body = { scenarioname: scenarioname, appurl: appurl, scriptid: scriptid, type: type, applicationname: applicationname };
        return this.http.post(this.url + "/accessibility/executescenario?appid=" + appid, body);
    };
    AccessibilityService.prototype.savedesignscenario = function (postvalue, tabledata) {
        var appid = localStorage.getItem('appid');
        var body = { postvalue: postvalue, tabledata: tabledata };
        return this.http.post(this.url + "/accessibility/savescenariodesign?appid=" + appid, body);
    };
    AccessibilityService.prototype.updatedesignscenario = function (postvalue, tabledata) {
        var appid = localStorage.getItem('appid');
        var body = { postvalue: postvalue, tabledata: tabledata };
        console.log("heloo");
        return this.http.post(this.url + "/accessibility/updatescenariodesign?appid=" + appid, body);
    };
    AccessibilityService.prototype.getapplicationname = function () {
        //console.log("ha")
        var appid = localStorage.getItem('appid');
        return this.http.get(this.url + "/userAPI/getApplicationNameByID?appid=" + appid);
    };
    AccessibilityService.prototype.gettestruns = function () {
        var appid = localStorage.getItem('appid');
        return this.http.get(this.url + '/accessibility/getTestDetails?appid=' + appid); //.timeout(5000);
    };
    AccessibilityService.prototype.startmlanalysis = function (row) {
        //console.log("h")
        var appid = localStorage.getItem('appid');
        var body = { row: row };
        return this.http.post(this.url + "/accessibility/startmlanalysis?appid=" + appid, body);
    };
    AccessibilityService.prototype.gettestrunsbyId = function (objectid) {
        return this.http.get(this.url + '/accessibility/getTestDetailsByID?objectid=' + objectid); //.timeout(5000);
    };
    AccessibilityService.prototype.getmlrecords = function (objectid) {
        return this.http.get(this.url + '/accessibility/getmlrecords?objectid=' + objectid); //.timeout(5000);
    };
    AccessibilityService.prototype.getDetailedAnalysis = function (objectid) {
        return this.http.get(this.url + '/accessibility/detailedAnalysisForXlsx?runId=' + objectid); //.timeout(5000);
    };
    // scramble Api 
    AccessibilityService.prototype.getScrambleForATScramble = function () {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/scrambleAT/getScramble", httpOptions);
    };
    AccessibilityService.prototype.gettestrunsbyIdForATScramble = function (objectid) {
        return this.http.get(this.url + '/scrambleAT/getTestDetailsByID?objectid=' + objectid); //.timeout(5000);
    };
    AccessibilityService.prototype.getmlrecordsForATScramble = function (objectid) {
        return this.http.get(this.url + '/scrambleAT/getmlrecords?objectid=' + objectid); //.timeout(5000);
    };
    AccessibilityService.prototype.getmergedruns = function (runid) {
        var body = { runid: runid };
        var appid = localStorage.getItem('appid');
        return this.http.post(this.url + "/accessibility/getmergedruns?appid=" + appid, body);
    };
    AccessibilityService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], AccessibilityService);
    return AccessibilityService;
}());



/***/ }),

/***/ "./src/app/scramble/atscramble/analysis/analysis.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/scramble/atscramble/analysis/analysis.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-accordion multi>\n  <mat-expansion-panel expanded=\"true\">\n    <mat-expansion-panel-header>\n      <mat-panel-title>\n        <b>Overall Summary</b>\n      </mat-panel-title>\n    </mat-expansion-panel-header>\n    <div class=\"row\">\n      <!-- <ngx-charts-number-card [view]=\"view\" [scheme]=\"colorScheme\" [results]=\"single\" [cardColor]=\"cardColor\"\n      (select)=\"onSelect($event)\">\n    </ngx-charts-number-card> -->\n      <mat-card class=\"col-3\">\n        <br>\n        <b style=\"color:white;font-size:32px;\">{{summaryhighissuescount}} </b><label id=\"labelissues\">High\n          Issues</label>\n        <br>\n        <br>\n        <b style=\"color:white;font-size:32px;\">{{summarymediumissuescount}} </b><label id=\"labelissues\"> Medium\n          Issues</label>\n        <br>\n        <br>\n        <b style=\"color:white;font-size:32px;\">{{summarylowissuescount}} </b><label id=\"labelissues\"> Low Issues</label>\n      </mat-card>\n      <ngx-charts-bar-vertical class=\"col-9\" [view]=\"view2\" [scheme]=\"colorScheme2\" [results]=\"multi\"\n        [gradient]=\"gradient\" [xAxis]=\"showXAxis\" [yAxis]=\"showYAxis\" [showXAxisLabel]=\"showXAxisLabel\"\n        [showYAxisLabel]=\"showYAxisLabel\" [xAxisLabel]=\"xAxisLabel\" [yAxisLabel]=\"yAxisLabel\">\n      </ngx-charts-bar-vertical>\n    </div>\n  </mat-expansion-panel>\n  <mat-expansion-panel>\n    <mat-expansion-panel-header>\n      <mat-panel-title>\n        <b> Detailed Analysis</b>\n      </mat-panel-title>\n    </mat-expansion-panel-header>\n    <div class=\"row \">\n      <div class=\"col-4\">\n        <mat-form-field>\n          <mat-label>Select a Transaction:</mat-label>\n          <mat-select color=\"primary\" (selectionChange)=\"changetransaction()\" [(ngModel)]=\"transactionname\">\n            <mat-option *ngFor=\"let transaction of transactionnamelist\" [value]=\"transaction\">\n              {{transaction}}\n            </mat-option>\n          </mat-select>\n        </mat-form-field>\n      </div>\n      <div class=\"col-8 \">\n        <div>\n          <table class=\"transtable\">\n            <tr>\n              <th>\n                High Issues\n              </th>\n              <th>\n                Medium Issues\n              </th>\n              <th>\n                Low Issues\n              </th>\n            </tr>\n            <tr>\n              <td><b>{{individualtransactionscount[\"highissues\"]}}</b></td>\n              <td><b>{{individualtransactionscount[\"mediumissues\"]}}</b></td>\n              <td><b>{{individualtransactionscount[\"lowissues\"]}}</b></td>\n            </tr>\n          </table>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"col-3 \">\n        <div class=\"nav\">\n          <ul>\n\n            <a (click)=\"gettabledata(violations)\" *ngFor=\"let violations of violationslist\" class=\"nav-link  \">\n              <li style=\"list-style-type:none;text-align: left;\">\n                {{violations}}\n              </li>\n            </a>\n          </ul>\n        </div>\n      </div>\n\n      <div id=\"main\" class=\"col-9 \">\n        <div class=\"row justify-content-center\">\n          <br><br>\n          <h5 *ngIf=\"tabledata.length==0\" style=\"text-align:center;color: red;\">No Data found!</h5>\n        </div>\n        <table *ngIf=\"tabledata.length!=0\" class=\"table1\" #sort=\"matSort\" matSort mat-table [dataSource]=\"dataSource\">\n          <div>\n            <ng-container matColumnDef=\"Attribute\" sticky>\n              <th mat-header-cell mat-sort-header *matHeaderCellDef>\n                <h6>Violation</h6>\n              </th>\n              <td mat-cell *matCellDef=\"let element\">\n                <h6>{{element.Attribute}}</h6>\n              </td>\n            </ng-container>\n          </div>\n          <div>\n            <ng-container matColumnDef=\"Violation\">\n              <th mat-header-cell mat-sort-header *matHeaderCellDef>\n                <h6>Description</h6>\n              </th>\n              <td mat-cell *matCellDef=\"let element\">\n                <a *ngIf=\"element.Attribute=='Sources'\" (click)=\"openpopup(dataSource.data)\" style=\"float:center;color:#1e3c72;\n                  ;font-size: 13px;text-decoration: underline;\">View Sources</a>\n                <div *ngIf=\"element.Attribute!='Sources'\">{{element.Violation}}</div>\n              </td>\n            </ng-container>\n          </div>\n\n          <tr mat-row *matRowDef=\"let row; columns:displayedColumns;\"></tr>\n        </table>\n        <br>\n        <mat-paginator #paginator [hidePageSize]=\"true\" [pageSizeOptions]=\"[7]\"></mat-paginator>\n        <!-- <mat-form-field  *ngIf=\"!tabledata.length==0\" class=\"sources\">\n          <mat-label>Sources</mat-label>\n          <textarea class=\"example-full-width\" [(ngModel)]=\"sources\" class=\"sources\"  matInput>\n\n</textarea>\n        </mat-form-field>  -->\n      </div>\n\n    </div>\n  </mat-expansion-panel>\n\n\n  <mat-expansion-panel *ngIf=\"!mldisabledtemporary\">\n    <mat-expansion-panel-header>\n      <mat-panel-title>\n        <b> ML Analysis</b>\n      </mat-panel-title>\n    </mat-expansion-panel-header>\n    <label *ngIf=\"tabledata2==null\">\n      U havent run Machine Learning Analysis yet for this test!!\n    </label>\n    <div *ngIf=\"tabledata2!=null\">\n      <div class=\"row \">\n        <div class=\"col-4\">\n          <mat-form-field>\n            <mat-label>Select a Transaction:</mat-label>\n            <mat-select color=\"primary\" (selectionChange)=\"changetransactionml()\" [(ngModel)]=\"transactionname2\">\n              <mat-option *ngFor=\"let transaction of transactionnamelist\" [value]=\"transaction\">\n                {{transaction}}\n              </mat-option>\n            </mat-select>\n          </mat-form-field>\n        </div>\n        <div class=\"col-4\">\n          <mat-form-field>\n            <mat-label>Search</mat-label>\n            <input [(ngModel)]=\"filter2\" matInput (keyup)=\"applyFilter2($event)\">\n          </mat-form-field>\n        </div>\n      </div>\n      <table class=\"table2\" #sort2=\"matSort\" matSort mat-table [dataSource]=\"dataSource2\">\n        <div>\n          <ng-container matColumnDef=\"imagename\" sticky>\n            <th style=\"width:20%;\" mat-header-cell mat-sort-header *matHeaderCellDef>\n              <h6>Image</h6>\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n              <img class=\"thumbnail\" [src]=\"this.url+element.imagename\">\n            </td>\n          </ng-container>\n        </div>\n        <div>\n          <ng-container matColumnDef=\"imageurl\" sticky>\n            <th style=\"width:40%;padding: 1.75rem !important;\" mat-header-cell mat-sort-header *matHeaderCellDef>\n              <h6>Image Url</h6>\n            </th>\n            <td style=\"padding-right:7%;\" mat-cell *matCellDef=\"let element\">\n              <a (click)=\"openurl(element.imageurl)\" style=\"color:#1e3c72\">{{element.imageurl}}</a>\n            </td>\n          </ng-container>\n        </div>\n        <div>\n          <ng-container matColumnDef=\"imagealt\" sticky>\n            <th style=\"width:25%;\" mat-header-cell mat-sort-header *matHeaderCellDef>\n              <h6>Image Alt</h6>\n            </th>\n            <td style=\"padding-right:5%;word-wrap:break-word;\" mat-cell *matCellDef=\"let element\">\n              {{element.imagealt}}\n            </td>\n          </ng-container>\n        </div>\n\n        <div>\n          <ng-container matColumnDef=\"imageanalysis\" sticky>\n            <th mat-header-cell mat-sort-header *matHeaderCellDef>\n              <h6>Result</h6>\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n              <a [title]=\"element.awsalt\" style=\"color:#1e3c72\">\n                {{element.imageanalysis}}</a>\n            </td>\n          </ng-container>\n        </div>\n\n\n        <!-- <div>\n        <ng-container matColumnDef=\"awsalt\" sticky>\n          <th mat-header-cell mat-sort-header *matHeaderCellDef>\n            <h6>Aws Alt Text</h6>\n          </th>\n          <td mat-cell *ngFor=\"let item of element.data\">\n            <h6>{{item.awsalt}}</h6>\n          </td>\n        </ng-container>\n      </div>\n      <div>\n        <ng-container matColumnDef=\"result\" sticky>\n          <th mat-header-cell mat-sort-header *matHeaderCellDef>\n            <h6>Result based on ML</h6>\n          </th>\n          <td mat-cell *ngFor=\"let item of element.data\">\n            <h6>{{element.result}}</h6>\n          </td>\n        </ng-container>\n      </div> -->\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns2\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns:displayedColumns2;\"></tr>\n      </table>\n      <mat-paginator #paginator2 [pageSizeOptions]=\"[5]\"></mat-paginator>\n    </div>\n  </mat-expansion-panel>\n\n\n</mat-accordion>"

/***/ }),

/***/ "./src/app/scramble/atscramble/analysis/analysis.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/scramble/atscramble/analysis/analysis.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".nav {\n  top: 30;\n  height: auto;\n  background-image: -webkit-gradient(linear, left bottom, left top, from(#1e3c72), color-stop(1%, #1e3c72), to(#2a5298)) !important;\n  background-image: linear-gradient(to top, #1e3c72 0%, #1e3c72 1%, #2a5298 100%) !important;\n  /* Black */ }\n\na:hover {\n  cursor: pointer; }\n\nmat-card {\n  background-color: #1e3c72; }\n\n.link {\n  color: #1e3c72; }\n\n.table2 {\n  width: 100%;\n  table-layout: fixed;\n  word-break: break-all;\n  word-wrap: break-word; }\n\na {\n  font-weight: bold;\n  color: white; }\n\n#labelissues {\n  font-size: 11px;\n  color: white; }\n\n#labelissues2 {\n  font-size: 10px;\n  color: black; }\n\nli::before {\n  content: \"\\27A2\";\n  font-size: 20px; }\n\nli {\n  color: white; }\n\n#main {\n  background-image: -webkit-gradient(linear, left bottom, left top, from(white), color-stop(1%, white), to(white)) !important;\n  background-image: linear-gradient(to top, white 0%, white 1%, white 100%) !important;\n  /* Black */ }\n\n.table1 {\n  table-layout: fixed;\n  width: 100%;\n  word-wrap: break-word; }\n\n.mat-column-Attribute {\n  word-wrap: break-word !important;\n  white-space: unset !important;\n  -webkit-box-flex: 0 !important;\n      -ms-flex: 0 0 28% !important;\n          flex: 0 0 28% !important;\n  width: 28% !important;\n  overflow-wrap: break-word;\n  word-wrap: break-word;\n  word-break: break-word;\n  -ms-hyphens: auto;\n  -webkit-hyphens: auto;\n  hyphens: auto; }\n\n.mat-column-Violations {\n  word-wrap: break-word !important;\n  white-space: unset !important;\n  -webkit-box-flex: 0 !important;\n      -ms-flex: 0 0 72% !important;\n          flex: 0 0 72% !important;\n  width: 72% !important;\n  overflow-wrap: break-word;\n  word-wrap: break-word;\n  word-break: break-word;\n  -ms-hyphens: auto;\n  -webkit-hyphens: auto;\n  hyphens: auto; }\n\n.sources {\n  width: 100%;\n  height: 250px; }\n\n.transtable {\n  background-color: #1e3c72;\n  font-family: arial, sans-serif;\n  border-collapse: collapse;\n  width: 100%;\n  text-align: left;\n  color: white; }\n\n.transtable td, .transtable th {\n    text-align: left;\n    color: white;\n    padding: 8px; }\n\n::ng-deep .mat-paginator-range-label {\n  display: none; }\n\n.thumbnail {\n  height: 10%;\n  width: 50%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NyYW1ibGUvYXRzY3JhbWJsZS9hbmFseXNpcy9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHNjcmFtYmxlXFxhdHNjcmFtYmxlXFxhbmFseXNpc1xcYW5hbHlzaXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxPQUFNO0VBQ04sWUFBVztFQUVYLGlJQUF5RjtFQUF6RiwwRkFBeUY7RUFBRSxVQUFBLEVBQVc7O0FBRXhHO0VBQ0UsZUFBZSxFQUFBOztBQUVuQjtFQUNFLHlCQUF3QixFQUFBOztBQUUxQjtFQUNFLGNBQWEsRUFBQTs7QUFFZjtFQUNFLFdBQVU7RUFDVixtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLHFCQUFxQixFQUFBOztBQUV2QjtFQUNJLGlCQUFpQjtFQUNqQixZQUNKLEVBQUE7O0FBQ0E7RUFDSSxlQUFlO0VBQ2YsWUFBVyxFQUFBOztBQUVmO0VBQ0UsZUFBZTtFQUNmLFlBQVcsRUFBQTs7QUFFYjtFQUNJLGdCQUFnQjtFQUNoQixlQUFjLEVBQUE7O0FBRWxCO0VBQ0ksWUFBVyxFQUFBOztBQUdmO0VBQ0ksMkhBQW1GO0VBQW5GLG9GQUFtRjtFQUFFLFVBQUEsRUFBVzs7QUFFcEc7RUFDRSxtQkFBbUI7RUFDbkIsV0FBVTtFQUNWLHFCQUFxQixFQUFBOztBQUd2QjtFQUNJLGdDQUFnQztFQUNoQyw2QkFBNkI7RUFDN0IsOEJBQXdCO01BQXhCLDRCQUF3QjtVQUF4Qix3QkFBd0I7RUFDeEIscUJBQXFCO0VBQ3JCLHlCQUF5QjtFQUN6QixxQkFBcUI7RUFFckIsc0JBQXNCO0VBRXRCLGlCQUFpQjtFQUVqQixxQkFBcUI7RUFDckIsYUFBYSxFQUFBOztBQUVmO0VBQ0UsZ0NBQWdDO0VBQ2hDLDZCQUE2QjtFQUM3Qiw4QkFBd0I7TUFBeEIsNEJBQXdCO1VBQXhCLHdCQUF3QjtFQUN4QixxQkFBcUI7RUFDckIseUJBQXlCO0VBQ3pCLHFCQUFxQjtFQUVyQixzQkFBc0I7RUFFdEIsaUJBQWlCO0VBRWpCLHFCQUFxQjtFQUNyQixhQUFhLEVBQUE7O0FBR2Y7RUFDRSxXQUFXO0VBQ1gsYUFBWSxFQUFBOztBQUVkO0VBRUUseUJBQXdCO0VBQ3RCLDhCQUE4QjtFQUM5Qix5QkFBeUI7RUFDekIsV0FBVztFQUNYLGdCQUFnQjtFQUNsQixZQUFXLEVBQUE7O0FBUGI7SUFTSSxnQkFBZ0I7SUFDaEIsWUFBVztJQUNYLFlBQVksRUFBQTs7QUFHaEI7RUFDRSxhQUFZLEVBQUE7O0FBRWQ7RUFDRSxXQUFVO0VBQ1YsVUFBUyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvc2NyYW1ibGUvYXRzY3JhbWJsZS9hbmFseXNpcy9hbmFseXNpcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uYXYge1xyXG4gICAgdG9wOjMwO1xyXG4gICAgaGVpZ2h0OmF1dG87XHJcblxyXG4gICAgYmFja2dyb3VuZC1pbWFnZTpsaW5lYXItZ3JhZGllbnQodG8gdG9wLCAjMWUzYzcyIDAlLCAjMWUzYzcyIDElLCAjMmE1Mjk4IDEwMCUpICFpbXBvcnRhbnQ7IC8qIEJsYWNrICovXHJcbiAgfVxyXG4gIGE6aG92ZXIge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbm1hdC1jYXJke1xyXG4gIGJhY2tncm91bmQtY29sb3I6IzFlM2M3MjtcclxufVxyXG4ubGlua3tcclxuICBjb2xvcjojMWUzYzcyO1xyXG59XHJcbi50YWJsZTJ7XHJcbiAgd2lkdGg6MTAwJTtcclxuICB0YWJsZS1sYXlvdXQ6IGZpeGVkO1xyXG4gIHdvcmQtYnJlYWs6IGJyZWFrLWFsbDtcclxuICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcbn1cclxuYXtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6d2hpdGVcclxufVxyXG4jbGFiZWxpc3N1ZXN7XHJcbiAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICBjb2xvcjp3aGl0ZTtcclxufVxyXG4jbGFiZWxpc3N1ZXMye1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxuICBjb2xvcjpibGFjaztcclxufVxyXG5saTo6YmVmb3JleyBcclxuICAgIGNvbnRlbnQ6IFwiXFwyN0EyXCI7IFxyXG4gICAgZm9udC1zaXplOjIwcHg7XHJcbn0gXHJcbmxpe1xyXG4gICAgY29sb3I6d2hpdGU7XHJcbn1cclxuXHJcbiNtYWlue1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTpsaW5lYXItZ3JhZGllbnQodG8gdG9wLCB3aGl0ZSAwJSwgd2hpdGUgMSUsIHdoaXRlIDEwMCUpICFpbXBvcnRhbnQ7IC8qIEJsYWNrICovXHJcbn1cclxuLnRhYmxlMXtcclxuICB0YWJsZS1sYXlvdXQ6IGZpeGVkO1xyXG4gIHdpZHRoOjEwMCU7XHJcbiAgd29yZC13cmFwOiBicmVhay13b3JkO1xyXG59XHJcblxyXG4ubWF0LWNvbHVtbi1BdHRyaWJ1dGUge1xyXG4gICAgd29yZC13cmFwOiBicmVhay13b3JkICFpbXBvcnRhbnQ7XHJcbiAgICB3aGl0ZS1zcGFjZTogdW5zZXQgIWltcG9ydGFudDtcclxuICAgIGZsZXg6IDAgMCAyOCUgIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiAyOCUgIWltcG9ydGFudDtcclxuICAgIG92ZXJmbG93LXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgXHJcbiAgICB3b3JkLWJyZWFrOiBicmVhay13b3JkO1xyXG4gIFxyXG4gICAgLW1zLWh5cGhlbnM6IGF1dG87XHJcbiAgICAtbW96LWh5cGhlbnM6IGF1dG87XHJcbiAgICAtd2Via2l0LWh5cGhlbnM6IGF1dG87XHJcbiAgICBoeXBoZW5zOiBhdXRvO1xyXG4gIH1cclxuICAubWF0LWNvbHVtbi1WaW9sYXRpb25zIHtcclxuICAgIHdvcmQtd3JhcDogYnJlYWstd29yZCAhaW1wb3J0YW50O1xyXG4gICAgd2hpdGUtc3BhY2U6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICBmbGV4OiAwIDAgNzIlICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogNzIlICFpbXBvcnRhbnQ7XHJcbiAgICBvdmVyZmxvdy13cmFwOiBicmVhay13b3JkO1xyXG4gICAgd29yZC13cmFwOiBicmVhay13b3JkO1xyXG4gIFxyXG4gICAgd29yZC1icmVhazogYnJlYWstd29yZDtcclxuICBcclxuICAgIC1tcy1oeXBoZW5zOiBhdXRvO1xyXG4gICAgLW1vei1oeXBoZW5zOiBhdXRvO1xyXG4gICAgLXdlYmtpdC1oeXBoZW5zOiBhdXRvO1xyXG4gICAgaHlwaGVuczogYXV0bztcclxuICB9XHJcbiBcclxuICAuc291cmNlcyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDoyNTBweDtcclxuICB9XHJcbiAgLnRyYW5zdGFibGV7XHJcbiAgICBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IzFlM2M3MjtcclxuICAgICAgZm9udC1mYW1pbHk6IGFyaWFsLCBzYW5zLXNlcmlmO1xyXG4gICAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGNvbG9yOndoaXRlO1xyXG4gICAgdGQsIHRoIHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICAgIHBhZGRpbmc6IDhweDtcclxuICAgIH1cclxuICB9XHJcbiAgOjpuZy1kZWVwIC5tYXQtcGFnaW5hdG9yLXJhbmdlLWxhYmVse1xyXG4gICAgZGlzcGxheTpub25lO1xyXG4gIH1cclxuICAudGh1bWJuYWlse1xyXG4gICAgaGVpZ2h0OjEwJTtcclxuICAgIHdpZHRoOjUwJTtcclxuICB9XHJcbiAiXX0= */"

/***/ }),

/***/ "./src/app/scramble/atscramble/analysis/analysis.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/scramble/atscramble/analysis/analysis.component.ts ***!
  \********************************************************************/
/*! exports provided: AnalysisComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AnalysisComponent", function() { return AnalysisComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_accessibility_accessibility_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../pages/accessibility/accessibility-data.service */ "./src/app/pages/accessibility/accessibility-data.service.ts");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/esm5/paginator.es5.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _sourcespopup_sourcespopup_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sourcespopup/sourcespopup.component */ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var simple_crypto_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! simple-crypto-js */ "./node_modules/simple-crypto-js/build/SimpleCrypto.js");
/* harmony import */ var simple_crypto_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(simple_crypto_js__WEBPACK_IMPORTED_MODULE_9__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};










var AnalysisComponent = /** @class */ (function () {
    function AnalysisComponent(activatedRoute, popup, data, sanitizer) {
        this.activatedRoute = activatedRoute;
        this.popup = popup;
        this.data = data;
        this.sanitizer = sanitizer;
        this.mldisabledtemporary = true;
        this.panelOpenState = true;
        this.view2 = [700, 200];
        this.multi = [];
        this.cardColor = '#1e3c72';
        this.summaryjson = [];
        this.tablejson = [];
        this.summaryhighissuescount = 0;
        this.summarymediumissuescount = 0;
        this.summarylowissuescount = 0;
        this.cognitivecount = 0;
        this.mobilitycount = 0;
        this.blindnesscount = 0;
        this.hearingcount = 0;
        this.sources = "";
        this.displayedColumns = ['Attribute', 'Violation'];
        this.displayedColumns2 = ['imagename', 'imageurl', 'imagealt', 'imageanalysis'];
        this.transactionnamelist = [];
        this.violationslist = [];
        this.violationslisttemp = [];
        this.tabledata = [];
        this.tabledata2 = [];
        this.individualtransactionscount = {};
        // options-batcharts
        this.showXAxis = true;
        this.showYAxis = true;
        this.gradient = false;
        this.showLegend = true;
        this.showXAxisLabel = true;
        this.xAxisLabel = 'Impacted Disability types';
        this.showYAxisLabel = true;
        this.sampleobj = [];
        this.yAxisLabel = 'Defects Count';
        this.colorScheme2 = {
            domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
        };
        this.colorjson = [];
        this.url = this.data.geturl() + "/uploads/";
        this.scrambledURL = "";
        this.scrambled = [];
        this.pageindex = 0;
        this.currentindex = 0;
    }
    //url = ""
    AnalysisComponent.prototype.decryptScrambledURL = function (chiperedText) {
        //console.log(" chiperedText : " + chiperedText);
        var simpleCrypto = new simple_crypto_js__WEBPACK_IMPORTED_MODULE_9___default.a(this.scrambledSecretKey);
        // this.decipherText = simpleCrypto.decrypt(chiperedText);
        // console.log(" decipherText : " + this.decipherText);
        // return this.decipherText;
        var cText = String(simpleCrypto.decrypt(chiperedText));
        //var cTextSplit = cText.split("&&");
        this.objectid = cText;
        //this.objectid = cTextSplit[0];
        // localStorage.setItem('customerID', this.customerId);
        // localStorage.setItem('applicationID', this.appid);
    };
    AnalysisComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.data.getScrambleForATScramble().take(1).subscribe(function (resdata) {
            //console.log(resdata);
            var scramble = JSON.parse(JSON.stringify(resdata));
            _this.scrambled = scramble;
            _this.scrambledServer = _this.scrambled["URI"];
            _this.scrambledSecretKey = _this.scrambled["secretKey"];
            _this.activatedRoute.params.take(1).subscribe(function (params) {
                if (params.hasOwnProperty('objectid')) {
                    _this._id = params.objectid;
                    //console.log(this._id);
                    _this.decryptScrambledURL(_this._id);
                    _this.data.gettestrunsbyIdForATScramble(_this.objectid).subscribe(function (data) {
                        _this.tablejson = data['detail1'];
                        _this.summaryjson = data['detail2'][0][0];
                        if (data.hasOwnProperty('detail3')) {
                            _this.colorjson = data['detail3'];
                        }
                        _this.transactionname = _this.tablejson[0][0]["pagename"]["pagenames"];
                        ////console.log(this.transactionname)
                        _this.transactionname2 = _this.tablejson[0][0]["pagename"]["pagenames"];
                        _this.changetransaction();
                        _this.dropdownchangetableinsert();
                        for (var i = 0; i < _this.summaryjson["rundetails"].length; i++) {
                            ////////console.log(this.summaryjson["rundetails"][i]["High"]);
                            _this.summaryhighissuescount += _this.summaryjson["rundetails"][i]["High"];
                            _this.summarymediumissuescount += _this.summaryjson["rundetails"][i]["Medium"];
                            _this.summarylowissuescount += _this.summaryjson["rundetails"][i]["Low"];
                            //this.transactionname=this.summaryjson["rundetails"][i]["PageName"];
                            _this.cognitivecount += _this.summaryjson["rundetails"][i]["Cognitive"];
                            _this.mobilitycount += _this.summaryjson["rundetails"][i]["Mobility"];
                            _this.hearingcount += _this.summaryjson["rundetails"][i]["Deafblindness"];
                            _this.blindnesscount += _this.summaryjson["rundetails"][i]["Blindness"];
                        }
                        for (var i = 0; i < _this.tablejson.length; i++) {
                            _this.transactionnamelist.push(_this.tablejson[i][0]["pagename"]["pagenames"]);
                        }
                        _this.multi = [
                            {
                                "name": "Visual Impairments",
                                "value": _this.blindnesscount
                            },
                            {
                                "name": "Mobility",
                                "value": _this.mobilitycount
                            },
                            {
                                "name": "Auditory",
                                "value": _this.hearingcount
                            },
                            {
                                "name": "Cognitive",
                                "value": _this.cognitivecount
                            }
                        ];
                        _this.data.getmlrecordsForATScramble(_this.objectid).subscribe(function (data) {
                            _this.tabledata2 = data;
                            if (_this.tabledata2 != null) {
                                _this.loadmldata(_this.tabledata2["data"]);
                            }
                        });
                    });
                }
                else {
                    console.log('Test analysis Parameter ID does not exists');
                }
            });
        });
    };
    AnalysisComponent.prototype.openurl = function (url) {
        window.open(url);
    };
    AnalysisComponent.prototype.changetransactionml = function () {
        this.loadmldata(this.tabledata2["data"]);
    };
    AnalysisComponent.prototype.applyFilter2 = function (event) {
        var filterValue = this.filter2;
        this.dataSource2.filter = filterValue.trim().toLowerCase();
        if (this.dataSource2.paginator) {
            this.dataSource2.paginator.firstPage();
        }
    };
    AnalysisComponent.prototype.loadmldata = function (data) {
        var _this = this;
        this.dataSource2 = [];
        ////console.log(data)
        var mldatasource = [];
        data.forEach(function (element) {
            if (element["transactionname"] == _this.transactionname2) {
                ////console.log("bay")
                element["data"].forEach(function (element2) {
                    var passcount = 0;
                    var imageanalysis;
                    var awsalt = "";
                    ////console.log(element2["data"])
                    element2["data"].forEach(function (element3) {
                        if (element3["probability"] == "pass") {
                            passcount++;
                        }
                        awsalt += element3["awsalt"] + "\n";
                    });
                    ////console.log(passcount)
                    if (passcount > 0) {
                        imageanalysis = "Pass";
                    }
                    if (passcount <= 0) {
                        imageanalysis = "Fail";
                    }
                    ////console.log(imageanalysis)
                    ////console.log(element2["imagepath"], element2["imageurl"], element2["imagealt"], awsalt)
                    mldatasource.push({
                        imagename: element2["imagepath"],
                        imageurl: element2["imageurl"],
                        imagealt: element2["imagealt"],
                        imageanalysis: imageanalysis,
                        awsalt: awsalt
                    });
                });
            }
        });
        this.dataSource2 = new _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"](mldatasource);
        this.dataSource2.paginator = this.paginator2;
        this.paginator2.firstPage();
        this.dataSource2.sort = this.sort2;
        ////console.log(mldatasource)
    };
    AnalysisComponent.prototype.changetransaction = function () {
        var _this = this;
        this.individualtransactionscount = {};
        this.violationslist = [];
        this.violationslisttemp = [];
        this.dataSource = [];
        this.tabledata = [];
        this.sources = "";
        ////console.log(this.transactionname)
        for (var i = 0; i < this.summaryjson["rundetails"].length; i++) {
            if (this.summaryjson["rundetails"][i]["PageName"] == this.transactionname) {
                this.individualtransactionscount["highissues"] = 0;
                this.individualtransactionscount["mediumissues"] = 0;
                this.individualtransactionscount["lowissues"] = 0;
            }
        }
        var uniqs2 = [];
        this.tablejson.forEach(function (element) {
            //////console.log(element)
            if (element[0]["pagename"]["pagenames"] == _this.transactionname) {
                ////console.log(element)
                var temp = [];
                for (var j = 1; j < element.length; j++) {
                    ////console.log(element[j])
                    for (var key in element[j]) {
                        if (element[j].hasOwnProperty(key)) {
                            temp.push(element[j][key]["GuidelineNo"]);
                            if (element[j][key]["Impact"] == "High") {
                                _this.individualtransactionscount["highissues"] = _this.individualtransactionscount["highissues"] + 1;
                            }
                            else if (element[j][key]["Impact"] == "Medium") {
                                _this.individualtransactionscount["mediumissues"] = _this.individualtransactionscount["mediumissues"] + 1;
                            }
                            if (element[j][key]["Impact"] == "Low") {
                                _this.individualtransactionscount["lowissues"] = _this.individualtransactionscount["lowissues"] + 1;
                            }
                        }
                    }
                }
                //////console.log(temp)
                var uniqs = temp.reduce(function (acc, val) {
                    acc[val] = acc[val] === undefined ? 1 : acc[val] += 1;
                    return acc;
                }, {});
                for (var key in uniqs) {
                    if (uniqs.hasOwnProperty(key)) {
                        uniqs2.push({ "name": key, "count": uniqs[key] });
                    }
                }
            }
            // element.forEach(element2 => {
            //   if(element2["pagename"]["pagenames"]==this.transactionname){
            //     ////console.log(element2)
            //   }
            // });
        });
        ////console.log(uniqs2)
        uniqs2.forEach(function (element) {
            ////console.log(element)
            _this.violationslist.push(element.name + " (" + element.count + ")");
            _this.violationslist.sort();
            _this.violationslisttemp.push(element.name);
            _this.violationslisttemp.sort();
        });
        if (this.colorjson != []) {
            this.violationslist.push("WCAG 1.4.3 Color Contrast");
        }
        this.dropdownchangetableinsert();
    };
    AnalysisComponent.prototype.gettabledata = function (violationname) {
        this.dataSource = [];
        this.tabledata = [];
        this.sources = "";
        this.guidelinechangetableinsert(violationname);
    };
    AnalysisComponent.prototype.guidelinechangetableinsert = function (violationname) {
        var _this = this;
        if (violationname == "WCAG 1.4.3 Color Contrast") {
            this.loadcolorjson();
        }
        else {
            violationname = violationname.substr(0, violationname.lastIndexOf(' '));
            //////console.log(violationname + " sd")
            ////////console.log("hi" + violationname + "hi")
            for (var i = 0; i < this.tablejson.length; i++) {
                //////////console.log(this.tablejson[i][0]["pagename"]["pagenames"])
                if (this.tablejson[i][0]["pagename"]["pagenames"] == this.transactionname) {
                    ////////console.log(this.transactionname)
                    for (var j = 1; j < this.tablejson[i].length; j++) {
                        var temp = this.tablejson[i][j];
                        for (var key in temp) {
                            //////console.log(temp[key]["GuidelineNo"])
                            var count = 0;
                            if (temp.hasOwnProperty(key) && temp[key]["GuidelineNo"].includes(violationname)) {
                                ////console.log("hel" + temp[key]["GuidelineNo"]);
                                count++;
                                temp[key]["Sources"].forEach(function (element) {
                                    if (element != undefined) {
                                        _this.sources += element + "\n";
                                    }
                                });
                                this.tabledata.push({
                                    Attribute: 'Impact', Violation: temp[key]["Impact"]
                                }, {
                                    Attribute: 'Violation', Violation: temp[key]["Violation"]
                                }, {
                                    Attribute: 'Suggestion', Violation: temp[key]["Suggestion"]
                                }, {
                                    Attribute: 'Description', Violation: temp[key]["IssueDescription"]
                                }, {
                                    Attribute: 'Affected Users', Violation: temp[key]["AffectedUsers"]
                                }, {
                                    Attribute: 'Standard', Violation: temp[key]["Standard"]
                                }, {
                                    Attribute: 'Sources', Violation: ""
                                });
                            }
                        }
                    }
                }
            }
        }
        //////console.log(this.paginator.getNumberOfPages())
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"](this.tabledata);
        this.dataSource.paginator = this.paginator;
        this.paginator.firstPage();
        this.dataSource.sort = this.sort;
    };
    AnalysisComponent.prototype.dropdownchangetableinsert = function () {
        var _this = this;
        ////////console.log(this.transactionname + "1")
        for (var i = 0; i < this.tablejson.length; i++) {
            //////////console.log(this.tablejson[i][0]["pagename"]["pagenames"])
            if (this.tablejson[i][0]["pagename"]["pagenames"] == this.transactionname) {
                for (var j = 1; j < this.tablejson[i].length; j++) {
                    //////////console.log(this.tablejson[i][j])
                    ////////console.log(this.transactionname + "2")
                    var temp = this.tablejson[i][j];
                    for (var key in temp) {
                        if (temp.hasOwnProperty(key) && temp[key]["GuidelineNo"].includes(this.violationslisttemp[0])) {
                            ////////console.log(temp[key]["Violation"]
                            temp[key]["Sources"].forEach(function (element) {
                                if (element != undefined) {
                                    _this.sources += element + "\n";
                                }
                            });
                            this.tabledata.push({
                                Attribute: 'Impact', Violation: temp[key]["Impact"]
                            }, {
                                Attribute: 'Violation', Violation: temp[key]["Violation"]
                            }, {
                                Attribute: 'Suggestion', Violation: temp[key]["Suggestion"]
                            }, {
                                Attribute: 'Description', Violation: temp[key]["IssueDescription"]
                            }, {
                                Attribute: 'Affected Users', Violation: temp[key]["AffectedUsers"]
                            }, {
                                Attribute: 'Standard', Violation: temp[key]["Standard"]
                            }, {
                                Attribute: 'Sources', Violation: ""
                            });
                        }
                    }
                }
            }
        }
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"](this.tabledata);
        this.paginator.firstPage();
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    };
    AnalysisComponent.prototype.loadcolorjson = function () {
        var _this = this;
        this.tabledata = [];
        this.sources = "";
        ////console.log(this.colorjson)
        for (var key in this.colorjson) {
            if (this.colorjson.hasOwnProperty(key)) {
                if (this.transactionname == key) {
                    ////console.log("in")
                    //////console.log(this.colorjson[key]);
                    this.colorjson[key].forEach(function (element) {
                        var obj = JSON.parse(element);
                        ////console.log(obj["outerhtmls"]);
                        _this.sources += obj["outerhtmls"] + "\n";
                    });
                    this.tabledata.push({
                        Attribute: 'Impact', Violation: "High"
                    }, {
                        Attribute: 'Violation', Violation: "Elements must have sufficient color contrast"
                    }, {
                        Attribute: 'Suggestion', Violation: "Ensure color contrast of at least 4.5:1 for small text or 3:1 for large text, even if text is part of an image. Large text has been defined in the requirements as 18pt (24 CSS pixels) or 14pt bold (19 CSS pixels). Note: Elements found to have a 1:1 ratio are considered 'incomplete' and require a manual review."
                    }, {
                        Attribute: 'Description', Violation: "Ensures the contrast between foreground and background colors meets WCAG 2 AA contrast ratio thresholds"
                    }, {
                        Attribute: 'Affected Users', Violation: "Visual impairments, Hearing impairments"
                    }, {
                        Attribute: 'Standard', Violation: "1.4.3"
                    }, {
                        Attribute: 'Sources', Violation: ""
                    });
                }
            }
        }
    };
    AnalysisComponent.prototype.sanitizeImageUrl = function (imageUrl) {
        return this.sanitizer.bypassSecurityTrustUrl(imageUrl);
    };
    AnalysisComponent.prototype.openpopup = function (e) {
        var _this = this;
        var skip = this.paginator.pageSize * this.paginator.pageIndex;
        var pagedData = e.filter(function (u, i) { return i >= skip; })
            .filter(function (u, i) { return i < _this.paginator.pageSize; });
        ////console.log(pagedData);
        if ((pagedData[1]["Violation"] == "Elements must have sufficient color contrast")
            && (pagedData[2]["Violation"] == "Ensure color contrast of at least 4.5:1 for small text or 3:1 for large text, even if text is part of an image. Large text has been defined in the requirements as 18pt (24 CSS pixels) or 14pt bold (19 CSS pixels). Note: Elements found to have a 1:1 ratio are considered 'incomplete' and require a manual review.")
            && (pagedData[3]["Violation"] == "Ensures the contrast between foreground and background colors meets WCAG 2 AA contrast ratio thresholds")
            && (pagedData[4]["Violation"] == "Visual impairments, Hearing impairments")) {
            this.popup.open(_sourcespopup_sourcespopup_component__WEBPACK_IMPORTED_MODULE_7__["SourcespopupComponent"], {
                height: '75%',
                width: '60%',
                data: [pagedData, this.colorjson, this.transactionname, "color"]
            });
        }
        else {
            this.popup.open(_sourcespopup_sourcespopup_component__WEBPACK_IMPORTED_MODULE_7__["SourcespopupComponent"], {
                height: '75%',
                width: '60%',
                data: [pagedData, this.tablejson, this.transactionname, "guideline"]
            });
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('paginator'),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"])
    ], AnalysisComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('paginator2'),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"])
    ], AnalysisComponent.prototype, "paginator2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('sort'),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__["MatSort"])
    ], AnalysisComponent.prototype, "sort", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('sort2'),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_5__["MatSort"])
    ], AnalysisComponent.prototype, "sort2", void 0);
    AnalysisComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'analysis',
            template: __webpack_require__(/*! ./analysis.component.html */ "./src/app/scramble/atscramble/analysis/analysis.component.html"),
            styles: [__webpack_require__(/*! ./analysis.component.scss */ "./src/app/scramble/atscramble/analysis/analysis.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"],
            _pages_accessibility_accessibility_data_service__WEBPACK_IMPORTED_MODULE_2__["AccessibilityService"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__["DomSanitizer"]])
    ], AnalysisComponent);
    return AnalysisComponent;
}());



/***/ }),

/***/ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.html":
/*!***************************************************************************************!*\
  !*** ./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n      <mat-icon  id=\"closebutton\" style=\"margin-left:95%;cursor: pointer;\"  (click)=\"onNoClick()\" >close</mat-icon>\n  </div>\n<p *ngFor=\"let item of source;let i=index\">\n   <b>Issue {{i+1}}</b><br> {{item}} <br>\n</p>\n"

/***/ }),

/***/ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.scss":
/*!***************************************************************************************!*\
  !*** ./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#closebutton {\n  outline: none; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NyYW1ibGUvYXRzY3JhbWJsZS9hbmFseXNpcy9zb3VyY2VzcG9wdXAvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxzY3JhbWJsZVxcYXRzY3JhbWJsZVxcYW5hbHlzaXNcXHNvdXJjZXNwb3B1cFxcc291cmNlc3BvcHVwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvc2NyYW1ibGUvYXRzY3JhbWJsZS9hbmFseXNpcy9zb3VyY2VzcG9wdXAvc291cmNlc3BvcHVwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2Nsb3NlYnV0dG9ue1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.ts ***!
  \*************************************************************************************/
/*! exports provided: SourcespopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SourcespopupComponent", function() { return SourcespopupComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};


var SourcespopupComponent = /** @class */ (function () {
    function SourcespopupComponent(data, dialogRef) {
        this.data = data;
        this.dialogRef = dialogRef;
        this.source = [];
    }
    SourcespopupComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log(this.data);
        if (this.data[3] == "guideline") {
            for (var i = 0; i < this.data[1].length; i++) {
                //////console.log(this.tablejson[i][0]["pagename"]["pagenames"])
                if (this.data[1][i][0]["pagename"]["pagenames"] == this.data[2]) {
                    console.log(this.data[2]);
                    for (var j = 1; j < this.data[1][i].length; j++) {
                        console.log(this.data[1][i][j]);
                        var temp = this.data[1][i][j];
                        var _loop_1 = function () {
                            console.log(temp[key]["Violation"], this_1.data[0][1]["Violation"]);
                            if (temp.hasOwnProperty(key) && temp[key]["Violation"].includes(this_1.data[0][1]["Violation"])
                                && temp[key]["Suggestion"].includes(this_1.data[0][2]["Violation"])
                                && temp[key]["IssueDescription"].includes(this_1.data[0][3]["Violation"])
                                && temp[key]["AffectedUsers"].includes(this_1.data[0][4]["Violation"])) {
                                var issuecount_1 = 0;
                                temp[key]["Sources"].forEach(function (element) {
                                    console.log(element);
                                    if (element != undefined) {
                                        _this.source[issuecount_1] = element;
                                    }
                                    issuecount_1++;
                                });
                            }
                        };
                        var this_1 = this;
                        for (var key in temp) {
                            _loop_1();
                        }
                    }
                }
            }
        }
        else if (this.data[3] == "color") {
            var _loop_2 = function () {
                if (this_2.data[1].hasOwnProperty(key)) {
                    if (this_2.data[2] == key) {
                        console.log("in");
                        var issuecount_2 = 0;
                        this_2.data[1][key].forEach(function (element) {
                            if (element != undefined) {
                                var obj = JSON.parse(element);
                                _this.source[issuecount_2] = obj["outerhtmls"];
                            }
                            issuecount_2++;
                        });
                    }
                }
            };
            var this_2 = this;
            for (var key in (this.data[1])) {
                _loop_2();
            }
        }
    };
    SourcespopupComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    SourcespopupComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'sourcespopup',
            template: __webpack_require__(/*! ./sourcespopup.component.html */ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.html"),
            styles: [__webpack_require__(/*! ./sourcespopup.component.scss */ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.scss")]
        }),
        __param(0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [Object, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]])
    ], SourcespopupComponent);
    return SourcespopupComponent;
}());



/***/ }),

/***/ "./src/app/scramble/atscramble/atscramble-routing.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/scramble/atscramble/atscramble-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: ATScrambleRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ATScrambleRoutingModule", function() { return ATScrambleRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _analysis_analysis_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./analysis/analysis.component */ "./src/app/scramble/atscramble/analysis/analysis.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: 'analysis/:objectid',
        component: _analysis_analysis_component__WEBPACK_IMPORTED_MODULE_2__["AnalysisComponent"]
    }
];
var ATScrambleRoutingModule = /** @class */ (function () {
    function ATScrambleRoutingModule() {
    }
    ATScrambleRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], ATScrambleRoutingModule);
    return ATScrambleRoutingModule;
}());



/***/ }),

/***/ "./src/app/scramble/atscramble/atscramble.component.html":
/*!***************************************************************!*\
  !*** ./src/app/scramble/atscramble/atscramble.component.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  atscramble works!\n</p>\n"

/***/ }),

/***/ "./src/app/scramble/atscramble/atscramble.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/scramble/atscramble/atscramble.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NjcmFtYmxlL2F0c2NyYW1ibGUvYXRzY3JhbWJsZS5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/scramble/atscramble/atscramble.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/scramble/atscramble/atscramble.component.ts ***!
  \*************************************************************/
/*! exports provided: ATScrambleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ATScrambleComponent", function() { return ATScrambleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ATScrambleComponent = /** @class */ (function () {
    function ATScrambleComponent() {
    }
    ATScrambleComponent.prototype.ngOnInit = function () {
    };
    ATScrambleComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'atscramble',
            template: __webpack_require__(/*! ./atscramble.component.html */ "./src/app/scramble/atscramble/atscramble.component.html"),
            styles: [__webpack_require__(/*! ./atscramble.component.scss */ "./src/app/scramble/atscramble/atscramble.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], ATScrambleComponent);
    return ATScrambleComponent;
}());



/***/ }),

/***/ "./src/app/scramble/atscramble/atscramble.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/scramble/atscramble/atscramble.module.ts ***!
  \**********************************************************/
/*! exports provided: ATScrambleModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ATScrambleModule", function() { return ATScrambleModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @swimlane/ngx-charts */ "./node_modules/@swimlane/ngx-charts/release/index.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _atscramble_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./atscramble.component */ "./src/app/scramble/atscramble/atscramble.component.ts");
/* harmony import */ var _atscramble_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./atscramble-routing.module */ "./src/app/scramble/atscramble/atscramble-routing.module.ts");
/* harmony import */ var _analysis_analysis_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./analysis/analysis.component */ "./src/app/scramble/atscramble/analysis/analysis.component.ts");
/* harmony import */ var _analysis_sourcespopup_sourcespopup_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./analysis/sourcespopup/sourcespopup.component */ "./src/app/scramble/atscramble/analysis/sourcespopup/sourcespopup.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var ATScrambleModule = /** @class */ (function () {
    function ATScrambleModule() {
    }
    ATScrambleModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbAlertModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbPopoverModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["ReactiveFormsModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_5__["NgxChartsModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbCardModule"],
                _atscramble_routing_module__WEBPACK_IMPORTED_MODULE_8__["ATScrambleRoutingModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_3__["NbTabsetModule"],
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_4__["CdkTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatAutocompleteModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatBadgeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatBottomSheetModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatButtonToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatChipsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDatepickerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDialogModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatDividerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatGridListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatNativeDateModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatProgressBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatProgressSpinnerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatRippleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSliderModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSlideToggleModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSnackBarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatStepperModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTabsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTooltipModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_6__["MatTreeModule"]
            ],
            declarations: [_analysis_analysis_component__WEBPACK_IMPORTED_MODULE_9__["AnalysisComponent"], _analysis_sourcespopup_sourcespopup_component__WEBPACK_IMPORTED_MODULE_10__["SourcespopupComponent"], _atscramble_component__WEBPACK_IMPORTED_MODULE_7__["ATScrambleComponent"]],
            //providers :[MobilePerfService],
            entryComponents: [_analysis_analysis_component__WEBPACK_IMPORTED_MODULE_9__["AnalysisComponent"], _analysis_sourcespopup_sourcespopup_component__WEBPACK_IMPORTED_MODULE_10__["SourcespopupComponent"]]
        })
    ], ATScrambleModule);
    return ATScrambleModule;
}());



/***/ })

}]);
//# sourceMappingURL=default~app-scramble-scramble-module~atscramble-atscramble-module.js.map