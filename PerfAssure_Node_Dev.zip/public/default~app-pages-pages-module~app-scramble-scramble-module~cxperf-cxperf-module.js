(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~app-pages-pages-module~app-scramble-scramble-module~cxperf-cxperf-module"],{

/***/ "./src/app/pages/cxperf/cxperf.service.ts":
/*!************************************************!*\
  !*** ./src/app/pages/cxperf/cxperf.service.ts ***!
  \************************************************/
/*! exports provided: CxperfService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CxperfService", function() { return CxperfService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CxperfService = /** @class */ (function () {
    function CxperfService(http) {
        this.http = http;
        /*
          toolURIs = JSON.parse(localStorage.getItem("toolURIs"));
        
          CxPerf = this.toolURIs.find((x) => { return (x.toolName == "CxPerf"); });
        
          private url: string = this.CxPerf.URI;//dynamically fetching URIs
         */
        this.url = ''; //Production
        //private url: string = 'http://ec2-52-52-49-127.us-west-1.compute.amazonaws.com';
        this.appName = ''; //= 'cognizanthomepage';
        this.customerName = ''; // = 'Cognizant';
        /*******  services for testresult ********/
        this.waterfallChartData = {};
    }
    /*******  services for testrun ********/
    CxperfService.prototype.getTestRunDocument = function (applicationId) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/testrun/getTestRun?appid=" + applicationId, httpOptions);
    };
    CxperfService.prototype.deleteTestRunDoc = function (RunId) {
        return this.http.delete(this.url + "/cxperf/testrun/deleteTestRunDocument?runId=" + RunId);
    };
    /*******  services for testsummary ********/
    CxperfService.prototype.getTestSummaryDocument = function (applicationId, runId) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/testrun/getTestSummary?appid=" + applicationId + "&runId=" + runId, httpOptions);
    };
    CxperfService.prototype.getPageResultForTransaction = function (applicationId, runId, transactionId) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/testrun/getTestResultForTransList?appid=" + applicationId + "&runId=" + runId + "&transactionId=" + transactionId, httpOptions);
    };
    CxperfService.prototype.getPageResultForIteration = function (applicationId, runId, transactionId) {
        return this.http.get(this.url + "/cxperf/testrun/getTestResultForIteration?appid=" + applicationId + "&runId=" + runId + "&transactionId=" + transactionId);
    };
    CxperfService.prototype.getPageStatusForTestRun = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num)
        };
        return this.http.get(this.url + "/cxperf/testrun/getPageStatus", options);
    };
    CxperfService.prototype.getWaterfallChartData = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num).set('transactionName', parameter.transactionName)
        };
        return this.http.get(this.url + "/cxperf/testrun/getHarData", options);
    };
    CxperfService.prototype.getRecommendationsData = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num)
        };
        return this.http.get(this.url + "/cxperf/testrun/getRecommendation", options);
    };
    CxperfService.prototype.getPageLoadTimingChart = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num)
        };
        return this.http.get(this.url + "/cxperf/testrun/getPageLoadTimings", options);
    };
    /*******  services for scriptpage ********/
    // get  all  application for  one  customer
    CxperfService.prototype.getScriptPage = function (applicationId) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/script/getScriptPageDetails?applicationID=" + applicationId, httpOptions);
    };
    CxperfService.prototype.deletescriptpagedata = function (applicationId, scriptId) {
        return this.http.delete(this.url + "/cxperf/script/deleteScript?applicationId=" + applicationId + "&scriptId=" + scriptId);
    };
    CxperfService.prototype.getValidationForCxPerf = function (component, op) {
        var users = 1;
        return this.http.get(this.url + "/license/LicenseValidatorApi?component=" + component + "&users=" + users + "&op=" + op);
    };
    CxperfService.prototype.startservice = function (id) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/worker/startscript?id=" + id, httpOptions);
    };
    CxperfService.prototype.stopservice = function (id) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/worker/stopscript?id=" + id, httpOptions);
    };
    // to get  regions  for  deopdown in script and UI script designing form
    CxperfService.prototype.getRegions = function () {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/script/getRegions", httpOptions);
    };
    CxperfService.prototype.newscriptpagedata = function (temp, applicationId) {
        //let headers: HttpHeaders = new HttpHeaders();
        // headers = headers.append('Accept', 'application/json');
        return this.http.post(this.url + "/cxperf/script/addScripts?applicationId=" + applicationId, temp);
    };
    CxperfService.prototype.updatescriptpagedata = function (temp, applicationId, scriptId) {
        //console.log(temp);
        return this.http.post(this.url + "/cxperf/script/updateExistingScript?applicationId=" + applicationId + "&scriptId=" + scriptId, temp);
    };
    CxperfService.prototype.updatescriptdatawithoutfile = function (applicationId, scriptId, temp) {
        return this.http.post(this.url + "/cxperf/script/updateExistingScriptWithoutFile?applicationId=" + applicationId + "&scriptId=" + scriptId, temp);
    };
    CxperfService.prototype.newScriptDesignPageData = function (temp, applicationId) {
        //console.log(temp);
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'multipart/form-data' })
        };
        return this.http.post(this.url + "/cxperf/script/addScriptDesignData?applicationId=" + applicationId, temp /* ,httpOptions */);
    };
    CxperfService.prototype.updateScriptDesignPageData = function (scriptformdata, applicationId, scriptId) {
        //console.log(scriptformdata);
        //console.log(applicationId);
        //console.log();
        return this.http.post(this.url + "/cxperf/script/updateScriptDesignData?applicationId=" + applicationId + "&scriptId=" + scriptId, scriptformdata);
    };
    CxperfService.prototype.addDuplicateData = function (scripts, applicationId) {
        return this.http.post(this.url + "/cxperf/script/addDuplicateScripts?applicationId=" + applicationId, scripts);
    };
    CxperfService.prototype.getAppAccessLevelByID = function (appID) {
        return this.http.get(this.url + '/userAPI/getAppAccessLevelByID?appID=' + appID);
    };
    /*  Scrambled API  */
    CxperfService.prototype.getScrambleForUxPerfWeb = function () {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/scrambleAPI/getScramble", httpOptions);
    };
    CxperfService.prototype.getPageResultForTransactionScrambled = function (applicationId, runId, transactionId) {
        var httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        return this.http.get(this.url + "/cxperf/scrambleAPI/getTestResultForTransList?appid=" + applicationId + "&runId=" + runId + "&transactionId=" + transactionId, httpOptions);
    };
    CxperfService.prototype.getPageResultForIterationScrambled = function (applicationId, runId, transactionId) {
        return this.http.get(this.url + "/cxperf/scrambleAPI/getTestResultForIteration?appid=" + applicationId + "&runId=" + runId + "&transactionId=" + transactionId);
    };
    CxperfService.prototype.getPageStatusForTestRunScrambled = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num)
        };
        return this.http.get(this.url + "/cxperf/scrambleAPI/getPageStatus", options);
    };
    CxperfService.prototype.getWaterfallChartDataScrambled = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('customerID', parameter.customerId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num).set('transactionName', parameter.transactionName)
        };
        return this.http.get(this.url + "/cxperf/scrambleAPI/getHarData", options);
    };
    CxperfService.prototype.getRecommendationsDataScrambled = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num)
        };
        return this.http.get(this.url + "/cxperf/scrambleAPI/getRecommendation", options);
    };
    CxperfService.prototype.getPageLoadTimingChartScrambled = function (parameter) {
        var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('runId', parameter.runId).set('customerID', parameter.customerId).set('appid', parameter.appid).set('transactionId', parameter.transactionId).set('Iteration_num', parameter.Iteration_num)
        };
        return this.http.get(this.url + "/cxperf/scrambleAPI/getPageLoadTimings", options);
    };
    CxperfService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], CxperfService);
    return CxperfService;
}());



/***/ })

}]);
//# sourceMappingURL=default~app-pages-pages-module~app-scramble-scramble-module~cxperf-cxperf-module.js.map