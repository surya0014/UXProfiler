(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-auth-auth-module"],{

/***/ "./src/app/auth/auth-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/*! exports provided: routes, NgxAuthRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxAuthRoutingModule", function() { return NgxAuthRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @nebular/auth */ "./node_modules/@nebular/auth/index.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login/login.component */ "./src/app/auth/login/login.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



 // <---
var routes = [
    {
        path: '',
        component: _nebular_auth__WEBPACK_IMPORTED_MODULE_2__["NbAuthComponent"],
        children: [
            {
                path: 'login',
                component: _login_login_component__WEBPACK_IMPORTED_MODULE_3__["NgxLoginComponent"],
            },
        ],
    },
];
var NgxAuthRoutingModule = /** @class */ (function () {
    function NgxAuthRoutingModule() {
    }
    NgxAuthRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
        })
    ], NgxAuthRoutingModule);
    return NgxAuthRoutingModule;
}());



/***/ }),

/***/ "./src/app/auth/auth.module.ts":
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/*! exports provided: NgxAuthModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxAuthModule", function() { return NgxAuthModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth-routing.module */ "./src/app/auth/auth-routing.module.ts");
/* harmony import */ var _nebular_auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @nebular/auth */ "./node_modules/@nebular/auth/index.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login/login.component */ "./src/app/auth/login/login.component.ts");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var NgxAuthModule = /** @class */ (function () {
    function NgxAuthModule() {
    }
    NgxAuthModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_7__["NbAlertModule"],
                //NbInputModule,
                //NbButtonModule,
                _nebular_theme__WEBPACK_IMPORTED_MODULE_7__["NbCheckboxModule"],
                _auth_routing_module__WEBPACK_IMPORTED_MODULE_4__["NgxAuthRoutingModule"],
                _nebular_auth__WEBPACK_IMPORTED_MODULE_5__["NbAuthModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatRadioModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatCheckboxModule"],
            ],
            declarations: [
                _login_login_component__WEBPACK_IMPORTED_MODULE_6__["NgxLoginComponent"],
            ],
        })
    ], NgxAuthModule);
    return NgxAuthModule;
}());



/***/ }),

/***/ "./src/app/auth/login/login.component.html":
/*!*************************************************!*\
  !*** ./src/app/auth/login/login.component.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n  <div class=\"col-md-offset-1 col-md-11\">\r\n    <nb-auth-block>\r\n      <div class=\"row\">\r\n        <div class=\"col-md-10 authBlock\">\r\n          <h2 class=\"title \"><img src=\"assets\\images\\Cognizant_Logo.png\" width=\"120px\" height=\"60px\"> NFT Assure</h2>\r\n          <small class=\"form-text sub-title \">Sign in with your email</small>\r\n          <form (ngSubmit)=\"login()\" #form=\"ngForm\" autocomplete=\"nope\">\r\n            <div *ngIf=\"showMessages.error && errors && errors.length > 0 && !submitted\" class=\"alert alert-danger\"\r\n              role=\"alert\">\r\n              <div><strong>Error !</strong></div>\r\n              <div *ngFor=\"let error of errors\">{{ error }}</div>\r\n            </div>\r\n            <div *ngIf=\"showMessages.success && messages && messages.length > 0 && !submitted\"\r\n              class=\"alert alert-success\" role=\"alert\">\r\n              <div><strong>Successful !</strong></div>\r\n              <div *ngFor=\"let message of messages\">{{ message }}</div>\r\n            </div>\r\n            <div class=\"form-group marginBottom\">\r\n              <mat-form-field class=\"form-element width100p\">\r\n                <input autocomplete=\"off\" matInput type=\"text\" width=\"100%\" name=\"email\" [(ngModel)]=\"user.email\"\r\n                  id=\"input-email\" pattern=\".+@.+\\..+\" placeholder=\"Email address\" #email=\"ngModel\"\r\n                  [class.form-control-danger]=\"email.invalid && email.touched\" autofocus\r\n                  [required]=\"getConfigValue('forms.validation.email.required')\">\r\n              </mat-form-field>\r\n              <!-- <label for=\"input-email\" class=\"sr-only\">Email address</label>\r\n          <input autocomplete=\"off\" name=\"email\" [(ngModel)]=\"user.email\" id=\"input-email\" pattern=\".+@.+\\..+\"\r\n            class=\"form-control\" placeholder=\"Email address\" #email=\"ngModel\"\r\n            [class.form-control-danger]=\"email.invalid && email.touched\" autofocus\r\n            [required]=\"getConfigValue('forms.validation.email.required')\"> -->\r\n              <small class=\"form-text error\" *ngIf=\"email.invalid && email.touched && email.errors?.required\">\r\n                Email is required!\r\n              </small>\r\n              <small class=\"form-text error\" *ngIf=\"email.invalid && email.touched && email.errors?.pattern\">\r\n                Email should be the real one!\r\n              </small>\r\n            </div>\r\n            <div class=\"form-group marginBottom\">\r\n              <mat-form-field class=\"form-element width100p\">\r\n                <input autocomplete=\"off\" matInput name=\"password\" [(ngModel)]=\"user.password\" type=\"password\"\r\n                  id=\"input-password\" placeholder=\"Password\" #password=\"ngModel\"\r\n                  [class.form-control-danger]=\"password.invalid && password.touched\"\r\n                  [required]=\"getConfigValue('forms.validation.password.required')\"\r\n                  [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\r\n                  [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\">\r\n              </mat-form-field>\r\n              <!-- <label for=\"input-password\" class=\"sr-only\">Password</label>\r\n          <input autocomplete=\"off\" name=\"password\" [(ngModel)]=\"user.password\" type=\"password\" id=\"input-password\"\r\n            class=\"form-control\" placeholder=\"Password\" #password=\"ngModel\"\r\n            [class.form-control-danger]=\"password.invalid && password.touched\"\r\n            [required]=\"getConfigValue('forms.validation.password.required')\"\r\n            [minlength]=\"getConfigValue('forms.validation.password.minLength')\"\r\n            [maxlength]=\"getConfigValue('forms.validation.password.maxLength')\"> -->\r\n              <small class=\"form-text error\" *ngIf=\"password.invalid && password.touched && password.errors?.required\">\r\n                Password is required!\r\n              </small>\r\n              <small class=\"form-text error\"\r\n                *ngIf=\"password.invalid && password.touched && (password.errors?.minlength || password.errors?.maxlength)\">\r\n                Password should contains\r\n                from {{ getConfigValue('forms.validation.password.minLength') }}\r\n                to {{ getConfigValue('forms.validation.password.maxLength') }}\r\n                characters\r\n              </small>\r\n            </div>\r\n\r\n            <!-- <div class=\"form-group marginBottom\">\r\n              <label for=\"auth-type\"> </label>\r\n              <mat-radio-group [(ngModel)]=\"user.option\" id=\"auth-type\" name=\"authType\" color=\"primary\"\r\n                class=\"matRadioGroup\">\r\n                <mat-radio-button *ngFor=\"let option of options\" [value]=\"option.value\" [disabled]=\"option.disabled\"\r\n                  color=\"primary\"> {{ option.label }} </mat-radio-button>\r\n              </mat-radio-group>\r\n            </div> -->\r\n            <div class=\"form-group accept-group col-sm-12 marginBottom\">\r\n              <mat-checkbox color=\"primary\" name=\"rememberMe\" [(ngModel)]=\"user.rememberMe\">Remember me</mat-checkbox>\r\n              <!-- <nb-checkbox name=\"rememberMe\" [(ngModel)]=\"user.rememberMe\">Remember me</nb-checkbox> -->\r\n              <!-- <a class=\"forgot-password\" routerLink=\"../request-password\">Forgot Password?</a> -->\r\n            </div>\r\n            <!-- <button [disabled]=\"submitted || !form.valid\" class=\"btn btn-block btn-hero-success\"\r\n              [class.btn-pulse]=\"submitted\">\r\n              Sign In\r\n            </button> -->\r\n            <button mat-raised-button color=\"primary\" [disabled]=\"submitted || !form.valid\"\r\n              [class.btn-pulse]=\"submitted\" class=\"width100p\">Sign In</button>\r\n          </form>\r\n          <!-- <div class=\"links\">\r\n            <ng-container *ngIf=\"socialLinks && socialLinks.length > 0\">\r\n              <small class=\"form-text\">Or connect with:</small>\r\n              <div class=\"socials\">\r\n                <ng-container *ngFor=\"let socialLink of socialLinks\">\r\n                  <a *ngIf=\"socialLink.link\" [routerLink]=\"socialLink.link\" [attr.target]=\"socialLink.target\"\r\n                    [attr.class]=\"socialLink.icon\" [class.with-icon]=\"socialLink.icon\">{{ socialLink.title }}</a>\r\n                  <a *ngIf=\"socialLink.url\" [attr.href]=\"socialLink.url\" [attr.target]=\"socialLink.target\"\r\n                    [attr.class]=\"socialLink.icon\" [class.with-icon]=\"socialLink.icon\">{{ socialLink.title }}</a>\r\n                </ng-container>\r\n              </div>\r\n            </ng-container>\r\n            <small class=\"form-text\">\r\n            Don't have an account? <a routerLink=\"../register\"><strong>Sign Up</strong></a>\r\n          </small>\r\n          </div> -->\r\n          <br>\r\n        </div>\r\n      </div>\r\n    </nb-auth-block>\r\n  </div>\r\n</div>\r\n<div class=\"row\">\r\n  <div class=\"col-md-12\">\r\n    <div class=\"footer\">\r\n      <p><span> Copyright &copy; Cognizant {{currentYear}}, All rights reserved</span></p>\r\n    </div>\r\n  </div>\r\n</div>"

/***/ }),

/***/ "./src/app/auth/login/login.component.scss":
/*!*************************************************!*\
  !*** ./src/app/auth/login/login.component.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* /deep/ nb-card, /deep/ nb-layout-column{\r\n    background-image: url('/assets/images/Cognizant_BG.jpeg') !important;\r\n} */\n/deep/ div > nb-layout-column > nb-card {\n  background-image: url(\"/assets/images/Cognizant_BG.jpeg\") !important;\n  background-position: center !important;\n  background-repeat: no-repeat !important;\n  background-size: 100% 100% !important;\n  background-position: fixed !important; }\n.marginBottom {\n  margin-top: 0 !important;\n  margin-bottom: 0 !important; }\n.footer {\n  position: fixed;\n  left: 0;\n  bottom: 0;\n  width: 100%;\n  color: black;\n  text-align: center; }\n.mat-form-w200 {\n  /*display: block;*/\n  position: relative;\n  -webkit-box-flex: 1;\n      -ms-flex: auto;\n          flex: auto;\n  min-width: 0;\n  width: 200px; }\n.authBlock {\n  background-color: white; }\n.width100p {\n  position: relative;\n  -webkit-box-flex: 1;\n      -ms-flex: auto;\n          flex: auto;\n  min-width: 0;\n  width: 100% !important; }\n.matRadioGroup {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXV0aC9sb2dpbi9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXGF1dGhcXGxvZ2luXFxsb2dpbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvYXV0aC9sb2dpbi9sb2dpbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTs7R0NBRztBREdIO0VBQ0ksb0VBQW9FO0VBQ3BFLHNDQUFzQztFQUN0Qyx1Q0FBdUM7RUFDdkMscUNBQXFDO0VBQ3JDLHFDQUFxQyxFQUFBO0FBR3pDO0VBQ0ksd0JBQXdCO0VBQ3hCLDJCQUEyQixFQUFBO0FBRS9CO0VBQ0ksZUFBZTtFQUNmLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0IsRUFBQTtBQUl0QjtFQUNJLGtCQUFBO0VBQ0Esa0JBQWtCO0VBQ2xCLG1CQUFVO01BQVYsY0FBVTtVQUFWLFVBQVU7RUFDVixZQUFZO0VBQ1osWUFBWSxFQUFBO0FBRWhCO0VBQ0ksdUJBQXVCLEVBQUE7QUFHM0I7RUFDSSxrQkFBa0I7RUFDbEIsbUJBQVU7TUFBVixjQUFVO1VBQVYsVUFBVTtFQUNWLFlBQVk7RUFDWixzQkFBc0IsRUFBQTtBQUcxQjtFQUNJLG9CQUFhO0VBQWIsb0JBQWE7RUFBYixhQUFhO0VBQ2IsV0FBVztFQUNYLHdCQUF1QjtNQUF2QixxQkFBdUI7VUFBdkIsdUJBQXVCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9hdXRoL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy9sYXlvdXQtYmc6IHVybChpbWFnZS91cmwvaW1hZ2UucG5nKSxcclxuXHJcbi8qIC9kZWVwLyBuYi1jYXJkLCAvZGVlcC8gbmItbGF5b3V0LWNvbHVtbntcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnL2Fzc2V0cy9pbWFnZXMvQ29nbml6YW50X0JHLmpwZWcnKSAhaW1wb3J0YW50O1xyXG59ICovXHJcbi9kZWVwLyBkaXYgPiBuYi1sYXlvdXQtY29sdW1uID4gbmItY2FyZHtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi9hc3NldHMvaW1hZ2VzL0NvZ25pemFudF9CRy5qcGVnXCIpICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBmaXhlZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWFyZ2luQm90dG9te1xyXG4gICAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMCAhaW1wb3J0YW50O1xyXG59XHJcbi5mb290ZXIge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgbGVmdDogMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gfVxyXG5cclxuIFxyXG4ubWF0LWZvcm0tdzIwMHtcclxuICAgIC8qZGlzcGxheTogYmxvY2s7Ki9cclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGZsZXg6IGF1dG87XHJcbiAgICBtaW4td2lkdGg6IDA7XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbn1cclxuLmF1dGhCbG9ja3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ud2lkdGgxMDBwe1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZmxleDogYXV0bztcclxuICAgIG1pbi13aWR0aDogMDtcclxuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYXRSYWRpb0dyb3Vwe1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn0iLCIvKiAvZGVlcC8gbmItY2FyZCwgL2RlZXAvIG5iLWxheW91dC1jb2x1bW57XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy9hc3NldHMvaW1hZ2VzL0NvZ25pemFudF9CRy5qcGVnJykgIWltcG9ydGFudDtcclxufSAqL1xuL2RlZXAvIGRpdiA+IG5iLWxheW91dC1jb2x1bW4gPiBuYi1jYXJkIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiL2Fzc2V0cy9pbWFnZXMvQ29nbml6YW50X0JHLmpwZWdcIikgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCUgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogZml4ZWQgIWltcG9ydGFudDsgfVxuXG4ubWFyZ2luQm90dG9tIHtcbiAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xuICBtYXJnaW4tYm90dG9tOiAwICFpbXBvcnRhbnQ7IH1cblxuLmZvb3RlciB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IGJsYWNrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7IH1cblxuLm1hdC1mb3JtLXcyMDAge1xuICAvKmRpc3BsYXk6IGJsb2NrOyovXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZmxleDogYXV0bztcbiAgbWluLXdpZHRoOiAwO1xuICB3aWR0aDogMjAwcHg7IH1cblxuLmF1dGhCbG9jayB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlOyB9XG5cbi53aWR0aDEwMHAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZsZXg6IGF1dG87XG4gIG1pbi13aWR0aDogMDtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDsgfVxuXG4ubWF0UmFkaW9Hcm91cCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgfVxuIl19 */"

/***/ }),

/***/ "./src/app/auth/login/login.component.ts":
/*!***********************************************!*\
  !*** ./src/app/auth/login/login.component.ts ***!
  \***********************************************/
/*! exports provided: NgxLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxLoginComponent", function() { return NgxLoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _nebular_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nebular/auth */ "./node_modules/@nebular/auth/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var NgxLoginComponent = /** @class */ (function (_super) {
    __extends(NgxLoginComponent, _super);
    function NgxLoginComponent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.currentYear = new Date().getFullYear();
        _this.options = [
            { value: 'local', label: 'Local ' },
            { value: 'SSO', label: 'Single Sign-On ', disabled: true },
        ];
        return _this;
    }
    NgxLoginComponent.prototype.ngOnInit = function () {
        this.user.option = 'local';
    };
    NgxLoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/auth/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.scss */ "./src/app/auth/login/login.component.scss")]
        })
    ], NgxLoginComponent);
    return NgxLoginComponent;
}(_nebular_auth__WEBPACK_IMPORTED_MODULE_1__["NbLoginComponent"]));



/***/ })

}]);
//# sourceMappingURL=app-auth-auth-module.js.map