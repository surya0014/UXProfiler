(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-pages-pages-module"],{

/***/ "./node_modules/ng-circle-progress/fesm5/ng-circle-progress.js":
/*!*********************************************************************!*\
  !*** ./node_modules/ng-circle-progress/fesm5/ng-circle-progress.js ***!
  \*********************************************************************/
/*! exports provided: CircleProgressComponent, CircleProgressOptions, NgCircleProgressModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CircleProgressComponent", function() { return CircleProgressComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CircleProgressOptions", function() { return CircleProgressOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgCircleProgressModule", function() { return NgCircleProgressModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");





var CircleProgressOptions = /** @class */ (function () {
    function CircleProgressOptions() {
        this.class = '';
        this.backgroundGradient = false;
        this.backgroundColor = 'transparent';
        this.backgroundGradientStopColor = 'transparent';
        this.backgroundOpacity = 1;
        this.backgroundStroke = 'transparent';
        this.backgroundStrokeWidth = 0;
        this.backgroundPadding = 5;
        this.percent = 0;
        this.radius = 90;
        this.space = 4;
        this.toFixed = 0;
        this.maxPercent = 1000;
        this.renderOnClick = true;
        this.units = '%';
        this.unitsFontSize = '10';
        this.unitsFontWeight = 'normal';
        this.unitsColor = '#444444';
        this.outerStrokeGradient = false;
        this.outerStrokeWidth = 8;
        this.outerStrokeColor = '#78C000';
        this.outerStrokeGradientStopColor = 'transparent';
        this.outerStrokeLinecap = 'round';
        this.innerStrokeColor = '#C7E596';
        this.innerStrokeWidth = 4;
        this.titleFormat = undefined;
        this.title = 'auto';
        this.titleColor = '#444444';
        this.titleFontSize = '20';
        this.titleFontWeight = 'normal';
        this.subtitleFormat = undefined;
        this.subtitle = 'progress';
        this.subtitleColor = '#A9A9A9';
        this.subtitleFontSize = '10';
        this.subtitleFontWeight = 'normal';
        this.imageSrc = undefined;
        this.imageHeight = undefined;
        this.imageWidth = undefined;
        this.animation = true;
        this.animateTitle = true;
        this.animateSubtitle = false;
        this.animationDuration = 500;
        this.showTitle = true;
        this.showSubtitle = true;
        this.showUnits = true;
        this.showImage = false;
        this.showBackground = true;
        this.showInnerStroke = true;
        this.clockwise = true;
        this.responsive = false;
        this.startFromZero = true;
        this.showZeroOuterStroke = true;
        this.lazy = false;
    }
    return CircleProgressOptions;
}());
/** @dynamic Prevent compiling error when using type `Document` https://github.com/angular/angular/issues/20351 */
var CircleProgressComponent = /** @class */ (function () {
    function CircleProgressComponent(defaultOptions, elRef, document) {
        var _this = this;
        this.elRef = elRef;
        this.document = document;
        this.onClick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        // <svg> of component
        this.svgElement = null;
        // whether <svg> is in viewport
        this.isInViewport = false;
        // event for notifying viewport change caused by scrolling or resizing
        this.onViewportChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"];
        this._viewportChangedSubscriber = null;
        this.options = new CircleProgressOptions();
        this.defaultOptions = new CircleProgressOptions();
        this._lastPercent = 0;
        this._gradientUUID = null;
        this.render = function () {
            _this.applyOptions();
            if (_this.options.lazy) {
                // Draw svg if it doesn't exist
                _this.svgElement === null && _this.draw(_this._lastPercent);
                // Draw it only when it's in the viewport
                if (_this.isInViewport) {
                    // Draw it at the latest position when I am in.
                    if (_this.options.animation && _this.options.animationDuration > 0) {
                        _this.animate(_this._lastPercent, _this.options.percent);
                    }
                    else {
                        _this.draw(_this.options.percent);
                    }
                    _this._lastPercent = _this.options.percent;
                }
            }
            else {
                if (_this.options.animation && _this.options.animationDuration > 0) {
                    _this.animate(_this._lastPercent, _this.options.percent);
                }
                else {
                    _this.draw(_this.options.percent);
                }
                _this._lastPercent = _this.options.percent;
            }
        };
        this.polarToCartesian = function (centerX, centerY, radius, angleInDegrees) {
            var angleInRadius = angleInDegrees * Math.PI / 180;
            var x = centerX + Math.sin(angleInRadius) * radius;
            var y = centerY - Math.cos(angleInRadius) * radius;
            return { x: x, y: y };
        };
        this.draw = function (percent) {
            var _a, _b, e_1, _c, e_2, _d;
            // make percent reasonable
            percent = (percent === undefined) ? _this.options.percent : Math.abs(percent);
            // circle percent shouldn't be greater than 100%.
            var circlePercent = (percent > 100) ? 100 : percent;
            // determine box size
            var boxSize = _this.options.radius * 2 + _this.options.outerStrokeWidth * 2;
            if (_this.options.showBackground) {
                boxSize += (_this.options.backgroundStrokeWidth * 2 + _this.max(0, _this.options.backgroundPadding * 2));
            }
            // the centre of the circle
            var centre = { x: boxSize / 2, y: boxSize / 2 };
            // the start point of the arc
            var startPoint = { x: centre.x, y: centre.y - _this.options.radius };
            // get the end point of the arc
            var endPoint = _this.polarToCartesian(centre.x, centre.y, _this.options.radius, 360 * (_this.options.clockwise ?
                circlePercent :
                (100 - circlePercent)) / 100); // ####################
            // We'll get an end point with the same [x, y] as the start point when percent is 100%, so move x a little bit.
            if (circlePercent === 100) {
                endPoint.x = endPoint.x + (_this.options.clockwise ? -0.01 : +0.01);
            }
            // largeArcFlag and sweepFlag
            var largeArcFlag, sweepFlag;
            if (circlePercent > 50) {
                _a = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__read"])(_this.options.clockwise ? [1, 1] : [1, 0], 2), largeArcFlag = _a[0], sweepFlag = _a[1];
            }
            else {
                _b = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__read"])(_this.options.clockwise ? [0, 1] : [0, 0], 2), largeArcFlag = _b[0], sweepFlag = _b[1];
            }
            // percent may not equal the actual percent
            var titlePercent = _this.options.animateTitle ? percent : _this.options.percent;
            var titleTextPercent = titlePercent > _this.options.maxPercent ?
                _this.options.maxPercent.toFixed(_this.options.toFixed) + "+" : titlePercent.toFixed(_this.options.toFixed);
            var subtitlePercent = _this.options.animateSubtitle ? percent : _this.options.percent;
            // get title object
            var title = {
                x: centre.x,
                y: centre.y,
                textAnchor: 'middle',
                color: _this.options.titleColor,
                fontSize: _this.options.titleFontSize,
                fontWeight: _this.options.titleFontWeight,
                texts: [],
                tspans: []
            };
            // from v0.9.9, both title and titleFormat(...) may be an array of string.
            if (_this.options.titleFormat !== undefined && _this.options.titleFormat.constructor.name === 'Function') {
                var formatted = _this.options.titleFormat(titlePercent);
                if (formatted instanceof Array) {
                    title.texts = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spread"])(formatted);
                }
                else {
                    title.texts.push(formatted.toString());
                }
            }
            else {
                if (_this.options.title === 'auto') {
                    title.texts.push(titleTextPercent);
                }
                else {
                    if (_this.options.title instanceof Array) {
                        title.texts = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spread"])(_this.options.title);
                    }
                    else {
                        title.texts.push(_this.options.title.toString());
                    }
                }
            }
            // get subtitle object
            var subtitle = {
                x: centre.x,
                y: centre.y,
                textAnchor: 'middle',
                color: _this.options.subtitleColor,
                fontSize: _this.options.subtitleFontSize,
                fontWeight: _this.options.subtitleFontWeight,
                texts: [],
                tspans: []
            };
            // from v0.9.9, both subtitle and subtitleFormat(...) may be an array of string.
            if (_this.options.subtitleFormat !== undefined && _this.options.subtitleFormat.constructor.name === 'Function') {
                var formatted = _this.options.subtitleFormat(subtitlePercent);
                if (formatted instanceof Array) {
                    subtitle.texts = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spread"])(formatted);
                }
                else {
                    subtitle.texts.push(formatted.toString());
                }
            }
            else {
                if (_this.options.subtitle instanceof Array) {
                    subtitle.texts = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spread"])(_this.options.subtitle);
                }
                else {
                    subtitle.texts.push(_this.options.subtitle.toString());
                }
            }
            // get units object
            var units = {
                text: "" + _this.options.units,
                fontSize: _this.options.unitsFontSize,
                fontWeight: _this.options.unitsFontWeight,
                color: _this.options.unitsColor
            };
            // get total count of text lines to be shown
            var rowCount = 0, rowNum = 1;
            _this.options.showTitle && (rowCount += title.texts.length);
            _this.options.showSubtitle && (rowCount += subtitle.texts.length);
            // calc dy for each tspan for title
            if (_this.options.showTitle) {
                try {
                    for (var _e = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__values"])(title.texts), _f = _e.next(); !_f.done; _f = _e.next()) {
                        var span = _f.value;
                        title.tspans.push({ span: span, dy: _this.getRelativeY(rowNum, rowCount) });
                        rowNum++;
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_f && !_f.done && (_c = _e.return)) _c.call(_e);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            // calc dy for each tspan for subtitle
            if (_this.options.showSubtitle) {
                try {
                    for (var _g = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__values"])(subtitle.texts), _h = _g.next(); !_h.done; _h = _g.next()) {
                        var span = _h.value;
                        subtitle.tspans.push({ span: span, dy: _this.getRelativeY(rowNum, rowCount) });
                        rowNum++;
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (_h && !_h.done && (_d = _g.return)) _d.call(_g);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
            }
            // create ID for gradient element
            if (null === _this._gradientUUID) {
                _this._gradientUUID = _this.uuid();
            }
            // Bring it all together
            _this.svg = {
                viewBox: "0 0 " + boxSize + " " + boxSize,
                // Set both width and height to '100%' if it's responsive
                width: _this.options.responsive ? '100%' : boxSize,
                height: _this.options.responsive ? '100%' : boxSize,
                backgroundCircle: {
                    cx: centre.x,
                    cy: centre.y,
                    r: _this.options.radius + _this.options.outerStrokeWidth / 2 + _this.options.backgroundPadding,
                    fill: _this.options.backgroundColor,
                    fillOpacity: _this.options.backgroundOpacity,
                    stroke: _this.options.backgroundStroke,
                    strokeWidth: _this.options.backgroundStrokeWidth,
                },
                path: {
                    // A rx ry x-axis-rotation large-arc-flag sweep-flag x y (https://developer.mozilla.org/en/docs/Web/SVG/Tutorial/Paths#Arcs)
                    d: "M " + startPoint.x + " " + startPoint.y + "\n        A " + _this.options.radius + " " + _this.options.radius + " 0 " + largeArcFlag + " " + sweepFlag + " " + endPoint.x + " " + endPoint.y,
                    stroke: _this.options.outerStrokeColor,
                    strokeWidth: _this.options.outerStrokeWidth,
                    strokeLinecap: _this.options.outerStrokeLinecap,
                    fill: 'none'
                },
                circle: {
                    cx: centre.x,
                    cy: centre.y,
                    r: _this.options.radius - _this.options.space - _this.options.outerStrokeWidth / 2 - _this.options.innerStrokeWidth / 2,
                    fill: 'none',
                    stroke: _this.options.innerStrokeColor,
                    strokeWidth: _this.options.innerStrokeWidth,
                },
                title: title,
                units: units,
                subtitle: subtitle,
                image: {
                    x: centre.x - _this.options.imageWidth / 2,
                    y: centre.y - _this.options.imageHeight / 2,
                    src: _this.options.imageSrc,
                    width: _this.options.imageWidth,
                    height: _this.options.imageHeight,
                },
                outerLinearGradient: {
                    id: 'outer-linear-' + _this._gradientUUID,
                    colorStop1: _this.options.outerStrokeColor,
                    colorStop2: _this.options.outerStrokeGradientStopColor === 'transparent' ? '#FFF' : _this.options.outerStrokeGradientStopColor,
                },
                radialGradient: {
                    id: 'radial-' + _this._gradientUUID,
                    colorStop1: _this.options.backgroundColor,
                    colorStop2: _this.options.backgroundGradientStopColor === 'transparent' ? '#FFF' : _this.options.backgroundGradientStopColor,
                }
            };
        };
        this.getAnimationParameters = function (previousPercent, currentPercent) {
            var MIN_INTERVAL = 10;
            var times, step, interval;
            var fromPercent = _this.options.startFromZero ? 0 : (previousPercent < 0 ? 0 : previousPercent);
            var toPercent = currentPercent < 0 ? 0 : _this.min(currentPercent, _this.options.maxPercent);
            var delta = Math.abs(Math.round(toPercent - fromPercent));
            if (delta >= 100) {
                // we will finish animation in 100 times
                times = 100;
                if (!_this.options.animateTitle && !_this.options.animateSubtitle) {
                    step = 1;
                }
                else {
                    // show title or subtitle animation even if the arc is full, we also need to finish it in 100 times.
                    step = Math.round(delta / times);
                }
            }
            else {
                // we will finish in as many times as the number of percent.
                times = delta;
                step = 1;
            }
            // Get the interval of timer
            interval = Math.round(_this.options.animationDuration / times);
            // Readjust all values if the interval of timer is extremely small.
            if (interval < MIN_INTERVAL) {
                interval = MIN_INTERVAL;
                times = _this.options.animationDuration / interval;
                if (!_this.options.animateTitle && !_this.options.animateSubtitle && delta > 100) {
                    step = Math.round(100 / times);
                }
                else {
                    step = Math.round(delta / times);
                }
            }
            // step must be greater than 0.
            if (step < 1) {
                step = 1;
            }
            return { times: times, step: step, interval: interval };
        };
        this.animate = function (previousPercent, currentPercent) {
            if (_this._timerSubscription && !_this._timerSubscription.closed) {
                _this._timerSubscription.unsubscribe();
            }
            var fromPercent = _this.options.startFromZero ? 0 : previousPercent;
            var toPercent = currentPercent;
            var _a = _this.getAnimationParameters(fromPercent, toPercent), step = _a.step, interval = _a.interval;
            var count = fromPercent;
            if (fromPercent < toPercent) {
                _this._timerSubscription = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["timer"])(0, interval).subscribe(function () {
                    count += step;
                    if (count <= toPercent) {
                        if (!_this.options.animateTitle && !_this.options.animateSubtitle && count >= 100) {
                            _this.draw(toPercent);
                            _this._timerSubscription.unsubscribe();
                        }
                        else {
                            _this.draw(count);
                        }
                    }
                    else {
                        _this.draw(toPercent);
                        _this._timerSubscription.unsubscribe();
                    }
                });
            }
            else {
                _this._timerSubscription = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["timer"])(0, interval).subscribe(function () {
                    count -= step;
                    if (count >= toPercent) {
                        if (!_this.options.animateTitle && !_this.options.animateSubtitle && toPercent >= 100) {
                            _this.draw(toPercent);
                            _this._timerSubscription.unsubscribe();
                        }
                        else {
                            _this.draw(count);
                        }
                    }
                    else {
                        _this.draw(toPercent);
                        _this._timerSubscription.unsubscribe();
                    }
                });
            }
        };
        this.emitClickEvent = function (event) {
            if (_this.options.renderOnClick) {
                _this.animate(0, _this.options.percent);
            }
            _this.onClick.emit(event);
        };
        this.applyOptions = function () {
            var e_3, _a;
            try {
                // the options of <circle-progress> may change already
                for (var _b = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__values"])(Object.keys(_this.options)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var name_1 = _c.value;
                    if (_this.hasOwnProperty(name_1) && _this[name_1] !== undefined) {
                        _this.options[name_1] = _this[name_1];
                    }
                    else if (_this.templateOptions && _this.templateOptions[name_1] !== undefined) {
                        _this.options[name_1] = _this.templateOptions[name_1];
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_3) throw e_3.error; }
            }
            // make sure key options valid
            _this.options.radius = Math.abs(+_this.options.radius);
            _this.options.space = +_this.options.space;
            _this.options.percent = +_this.options.percent > 0 ? +_this.options.percent : 0;
            _this.options.maxPercent = Math.abs(+_this.options.maxPercent);
            _this.options.animationDuration = Math.abs(_this.options.animationDuration);
            _this.options.outerStrokeWidth = Math.abs(+_this.options.outerStrokeWidth);
            _this.options.innerStrokeWidth = Math.abs(+_this.options.innerStrokeWidth);
            _this.options.backgroundPadding = +_this.options.backgroundPadding;
        };
        this.getRelativeY = function (rowNum, rowCount) {
            // why '-0.18em'? It's a magic number when property 'alignment-baseline' equals 'baseline'. :)
            var initialOffset = -0.18, offset = 1;
            return (initialOffset + offset * (rowNum - rowCount / 2)).toFixed(2) + 'em';
        };
        this.min = function (a, b) {
            return a < b ? a : b;
        };
        this.max = function (a, b) {
            return a > b ? a : b;
        };
        this.uuid = function () {
            // https://www.w3resource.com/javascript-exercises/javascript-math-exercise-23.php
            var dt = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (dt + Math.random() * 16) % 16 | 0;
                dt = Math.floor(dt / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
            return uuid;
        };
        this.findSvgElement = function () {
            if (this.svgElement === null) {
                var tags = this.elRef.nativeElement.getElementsByTagName('svg');
                if (tags.length > 0) {
                    this.svgElement = tags[0];
                }
            }
        };
        this.checkViewport = function () {
            _this.findSvgElement();
            var previousValue = _this.isInViewport;
            _this.isInViewport = _this.isElementInViewport(_this.svgElement);
            if (previousValue !== _this.isInViewport) {
                _this.onViewportChanged.emit({ oldValue: previousValue, newValue: _this.isInViewport });
            }
        };
        this.onScroll = function (event) {
            _this.checkViewport();
        };
        this.loadEventsForLazyMode = function () {
            if (_this.options.lazy) {
                _this.document.addEventListener('scroll', _this.onScroll, true);
                _this.window.addEventListener('resize', _this.onScroll, true);
                if (_this._viewportChangedSubscriber === null) {
                    _this._viewportChangedSubscriber = _this.onViewportChanged.subscribe(function (_a) {
                        var oldValue = _a.oldValue, newValue = _a.newValue;
                        newValue ? _this.render() : null;
                    });
                }
                // svgElement must be created in DOM before being checked.
                // Is there a better way to check the existence of svgElemnt?
                var _timer_1 = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["timer"])(0, 50).subscribe(function () {
                    _this.svgElement === null ? _this.checkViewport() : _timer_1.unsubscribe();
                });
            }
        };
        this.unloadEventsForLazyMode = function () {
            // Remove event listeners
            _this.document.removeEventListener('scroll', _this.onScroll, true);
            _this.window.removeEventListener('resize', _this.onScroll, true);
            // Unsubscribe onViewportChanged
            if (_this._viewportChangedSubscriber !== null) {
                _this._viewportChangedSubscriber.unsubscribe();
                _this._viewportChangedSubscriber = null;
            }
        };
        this.document = document;
        this.window = this.document.defaultView;
        Object.assign(this.options, defaultOptions);
        Object.assign(this.defaultOptions, defaultOptions);
    }
    CircleProgressComponent.prototype.isDrawing = function () {
        return (this._timerSubscription && !this._timerSubscription.closed);
    };
    CircleProgressComponent.prototype.isElementInViewport = function (el) {
        // Return false if el has not been created in page.
        if (el === null || el === undefined)
            return false;
        // Check if the element is out of view due to a container scrolling
        var rect = el.getBoundingClientRect(), parent = el.parentNode, parentRect;
        do {
            parentRect = parent.getBoundingClientRect();
            if (rect.top >= parentRect.bottom)
                return false;
            if (rect.bottom <= parentRect.top)
                return false;
            if (rect.left >= parentRect.right)
                return false;
            if (rect.right <= parentRect.left)
                return false;
            parent = parent.parentNode;
        } while (parent != this.document.body);
        // Check its within the document viewport
        if (rect.top >= (this.window.innerHeight || this.document.documentElement.clientHeight))
            return false;
        if (rect.bottom <= 0)
            return false;
        if (rect.left >= (this.window.innerWidth || this.document.documentElement.clientWidth))
            return false;
        if (rect.right <= 0)
            return false;
        return true;
    };
    CircleProgressComponent.prototype.ngOnInit = function () {
        this.loadEventsForLazyMode();
    };
    CircleProgressComponent.prototype.ngOnDestroy = function () {
        this.unloadEventsForLazyMode();
    };
    CircleProgressComponent.prototype.ngOnChanges = function (changes) {
        this.render();
        if ('lazy' in changes) {
            changes.lazy.currentValue ? this.loadEventsForLazyMode() : this.unloadEventsForLazyMode();
        }
    };
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], CircleProgressComponent.prototype, "onClick", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "name", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "class", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "backgroundGradient", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "backgroundColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "backgroundGradientStopColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "backgroundOpacity", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "backgroundStroke", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "backgroundStrokeWidth", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "backgroundPadding", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "radius", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "space", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "percent", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "toFixed", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "maxPercent", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "renderOnClick", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "units", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "unitsFontSize", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "unitsFontWeight", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "unitsColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "outerStrokeGradient", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "outerStrokeWidth", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "outerStrokeColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "outerStrokeGradientStopColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "outerStrokeLinecap", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "innerStrokeColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Object)
    ], CircleProgressComponent.prototype, "innerStrokeWidth", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function)
    ], CircleProgressComponent.prototype, "titleFormat", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Object)
    ], CircleProgressComponent.prototype, "title", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "titleColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "titleFontSize", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "titleFontWeight", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function)
    ], CircleProgressComponent.prototype, "subtitleFormat", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Object)
    ], CircleProgressComponent.prototype, "subtitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "subtitleColor", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "subtitleFontSize", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "subtitleFontWeight", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", String)
    ], CircleProgressComponent.prototype, "imageSrc", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "imageHeight", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "imageWidth", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "animation", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "animateTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "animateSubtitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Number)
    ], CircleProgressComponent.prototype, "animationDuration", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showTitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showSubtitle", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showUnits", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showImage", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showBackground", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showInnerStroke", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "clockwise", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "responsive", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "startFromZero", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "showZeroOuterStroke", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Boolean)
    ], CircleProgressComponent.prototype, "lazy", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('options'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", CircleProgressOptions)
    ], CircleProgressComponent.prototype, "templateOptions", void 0);
    CircleProgressComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'circle-progress',
            template: "\n        <svg xmlns=\"http://www.w3.org/2000/svg\" *ngIf=\"svg\"\n             [attr.viewBox]=\"svg.viewBox\" preserveAspectRatio=\"xMidYMid meet\"\n             [attr.height]=\"svg.height\" [attr.width]=\"svg.width\" (click)=\"emitClickEvent($event)\" [attr.class]=\"options.class\">\n            <defs>\n                <linearGradient *ngIf=\"options.outerStrokeGradient\" [attr.id]=\"svg.outerLinearGradient.id\">\n                    <stop offset=\"5%\" [attr.stop-color]=\"svg.outerLinearGradient.colorStop1\"  [attr.stop-opacity]=\"1\"/>\n                    <stop offset=\"95%\" [attr.stop-color]=\"svg.outerLinearGradient.colorStop2\" [attr.stop-opacity]=\"1\"/>\n                </linearGradient>\n                <radialGradient *ngIf=\"options.backgroundGradient\" [attr.id]=\"svg.radialGradient.id\">\n                    <stop offset=\"5%\" [attr.stop-color]=\"svg.radialGradient.colorStop1\" [attr.stop-opacity]=\"1\"/>\n                    <stop offset=\"95%\" [attr.stop-color]=\"svg.radialGradient.colorStop2\" [attr.stop-opacity]=\"1\"/>\n                </radialGradient>\n            </defs>\n            <ng-container *ngIf=\"options.showBackground\">\n                <circle *ngIf=\"!options.backgroundGradient\"\n                        [attr.cx]=\"svg.backgroundCircle.cx\"\n                        [attr.cy]=\"svg.backgroundCircle.cy\"\n                        [attr.r]=\"svg.backgroundCircle.r\"\n                        [attr.fill]=\"svg.backgroundCircle.fill\"\n                        [attr.fill-opacity]=\"svg.backgroundCircle.fillOpacity\"\n                        [attr.stroke]=\"svg.backgroundCircle.stroke\"\n                        [attr.stroke-width]=\"svg.backgroundCircle.strokeWidth\"/>\n                <circle *ngIf=\"options.backgroundGradient\"\n                        [attr.cx]=\"svg.backgroundCircle.cx\"\n                        [attr.cy]=\"svg.backgroundCircle.cy\"\n                        [attr.r]=\"svg.backgroundCircle.r\"\n                        attr.fill=\"url(#{{svg.radialGradient.id}})\"\n                        [attr.fill-opacity]=\"svg.backgroundCircle.fillOpacity\"\n                        [attr.stroke]=\"svg.backgroundCircle.stroke\"\n                        [attr.stroke-width]=\"svg.backgroundCircle.strokeWidth\"/>\n            </ng-container>            \n            <circle *ngIf=\"options.showInnerStroke\"\n                    [attr.cx]=\"svg.circle.cx\"\n                    [attr.cy]=\"svg.circle.cy\"\n                    [attr.r]=\"svg.circle.r\"\n                    [attr.fill]=\"svg.circle.fill\"\n                    [attr.stroke]=\"svg.circle.stroke\"\n                    [attr.stroke-width]=\"svg.circle.strokeWidth\"/>\n            <ng-container *ngIf=\"+options.percent!==0 || options.showZeroOuterStroke\">\n                <path *ngIf=\"!options.outerStrokeGradient\"\n                        [attr.d]=\"svg.path.d\"\n                        [attr.stroke]=\"svg.path.stroke\"\n                        [attr.stroke-width]=\"svg.path.strokeWidth\"\n                        [attr.stroke-linecap]=\"svg.path.strokeLinecap\"\n                        [attr.fill]=\"svg.path.fill\"/>\n                <path *ngIf=\"options.outerStrokeGradient\"\n                        [attr.d]=\"svg.path.d\"\n                        attr.stroke=\"url(#{{svg.outerLinearGradient.id}})\"\n                        [attr.stroke-width]=\"svg.path.strokeWidth\"\n                        [attr.stroke-linecap]=\"svg.path.strokeLinecap\"\n                        [attr.fill]=\"svg.path.fill\"/>\n            </ng-container>\n            <text *ngIf=\"!options.showImage && (options.showTitle || options.showUnits || options.showSubtitle)\"\n                  alignment-baseline=\"baseline\"\n                  [attr.x]=\"svg.circle.cx\"\n                  [attr.y]=\"svg.circle.cy\"\n                  [attr.text-anchor]=\"svg.title.textAnchor\">\n                <ng-container *ngIf=\"options.showTitle\">\n                    <tspan *ngFor=\"let tspan of svg.title.tspans\"\n                           [attr.x]=\"svg.title.x\"\n                           [attr.y]=\"svg.title.y\"\n                           [attr.dy]=\"tspan.dy\"\n                           [attr.font-size]=\"svg.title.fontSize\"\n                           [attr.font-weight]=\"svg.title.fontWeight\"\n                           [attr.fill]=\"svg.title.color\">{{tspan.span}}</tspan>\n                </ng-container>\n                <tspan *ngIf=\"options.showUnits\"\n                       [attr.font-size]=\"svg.units.fontSize\"\n                       [attr.font-weight]=\"svg.units.fontWeight\"\n                       [attr.fill]=\"svg.units.color\">{{svg.units.text}}</tspan>\n                <ng-container *ngIf=\"options.showSubtitle\">\n                    <tspan *ngFor=\"let tspan of svg.subtitle.tspans\"\n                           [attr.x]=\"svg.subtitle.x\"\n                           [attr.y]=\"svg.subtitle.y\"\n                           [attr.dy]=\"tspan.dy\"\n                           [attr.font-size]=\"svg.subtitle.fontSize\"\n                           [attr.font-weight]=\"svg.subtitle.fontWeight\"\n                           [attr.fill]=\"svg.subtitle.color\">{{tspan.span}}</tspan>\n                </ng-container>\n            </text>\n            <image *ngIf=\"options.showImage\" preserveAspectRatio=\"none\" \n                [attr.height]=\"svg.image.height\"\n                [attr.width]=\"svg.image.width\"\n                [attr.xlink:href]=\"svg.image.src\"\n                [attr.x]=\"svg.image.x\"\n                [attr.y]=\"svg.image.y\"\n            />\n        </svg>\n    "
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(2, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"])),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [CircleProgressOptions, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], Object])
    ], CircleProgressComponent);
    return CircleProgressComponent;
}());

var NgCircleProgressModule = /** @class */ (function () {
    function NgCircleProgressModule() {
    }
    NgCircleProgressModule_1 = NgCircleProgressModule;
    NgCircleProgressModule.forRoot = function (options) {
        if (options === void 0) { options = {}; }
        return {
            ngModule: NgCircleProgressModule_1,
            providers: [
                { provide: CircleProgressOptions, useValue: options }
            ]
        };
    };
    var NgCircleProgressModule_1;
    NgCircleProgressModule = NgCircleProgressModule_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
            ],
            declarations: [
                CircleProgressComponent,
            ],
            exports: [
                CircleProgressComponent,
            ]
        })
    ], NgCircleProgressModule);
    return NgCircleProgressModule;
}());

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=ng-circle-progress.js.map


/***/ }),

/***/ "./src/app/pages/administrator/administrator.component.html":
/*!******************************************************************!*\
  !*** ./src/app/pages/administrator/administrator.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container mat-elevation-z8 bgColor\">\n  <div clas=\"row\">\n    <div class=\"col-md-10\">\n      <button mat-icon-button type=\"button\">\n        <mat-icon color=\"primary\">search</mat-icon>\n      </button>\n      <mat-form-field class=\"mat-form-w150\">\n        <mat-label>Filter</mat-label>\n        <input matInput (keyup)=\"applyFilter($event)\" placeholder=\"Filter\">\n      </mat-form-field>\n    </div>\n    <div class=\"col-md-2\">\n      <button mat-icon-button color=\"primary\" matTooltip=\"Add Customer\" (click)=\"openCustomerDialog(true)\">\n        <mat-icon>add</mat-icon>\n      </button>\n    </div>\n  </div>\n  <div clas=\"row\">\n    <div class=\"col-md-12\">\n      <div class=\"table table-hover\" style=\"background-color: #FFF\">\n        <table mat-table [dataSource]=\"customer\" #MatSort1=\"matSort\" matSort width=\"100%\"  matSortActive=\"CustomerName\"\n           matSortDirection=\"asc\">\n          <ng-container matColumnDef=\"CustomerName\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Customer Name </th>\n            <td mat-cell *matCellDef=\"let row\">\n              <span *ngIf=\"row.hasOwnProperty('customerName')\">\n                <a [routerLink]=\"['/pages/customer']\" [queryParams]=\"{ customerId: row._id }\"\n                  queryParamsHandling=\"merge\"> {{row.customerName}} </a></span>\n            </td>\n          </ng-container>\n          <ng-container matColumnDef=\"ContactDetails\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Contact Details </th>\n            <td mat-cell *matCellDef=\"let row\"> {{row.contactDetails}} </td>\n          </ng-container>\n          <ng-container matColumnDef=\"actions\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Actions </th>\n            <td mat-cell *matCellDef=\"let row\">\n              <span>\n                <button mat-icon-button color=\"primary\" (click)=\"openCustomerDialog(false,row._id,row)\"\n                  matTooltip=\"Click to update the script\">\n                  <mat-icon aria-label=\"Edit\">edit</mat-icon>\n                </button>\n              </span>\n              <span>\n                <button mat-icon-button color=\"warn\" matTooltip=\"click here to delete application\"\n                  matTooltipPosition=\"below\" (click)=\"ConfirmDeleteCustomer(row._id)\">\n                  <mat-icon aria-label=\"Delete\">delete</mat-icon>\n                </button>\n              </span>\n            </td>\n          </ng-container>\n\n          <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n          <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\">\n          </tr>\n        </table>\n        <mat-paginator #MatPaginator1 [pageSizeOptions]=\"[5, 10, 25, 100]\" showFirstLastButtons></mat-paginator>\n      </div>\n    </div>\n  </div>\n</div>\n<!-- <div *ngFor=\"let customer of customer\">-->\n<!-- <div class=\"col-md-12\">\n  <div class=\"textright\">\n    <button mat-button color=\"primary\" (click)=\"openCustomerDialog(true)\"> Add Customer</button>\n\n  </div>\n  <div class=\"example-container mat-elevation-z8\">\n    <table mat-table [dataSource]=\"customer\" matSort width=\"100%\">\n      <ng-container matColumnDef=\"CustomerName\">\n        <th mat-header-cell *matHeaderCellDef mat-sort-header> Customer Name</th>\n        <td mat-cell *matCellDef=\"let row\">\n          <span><a [routerLink]=\"['/pages/customer']\" [queryParams]=\"{ customerId: row._id }\"\n              queryParamsHandling=\"merge\"> {{row.customerName}} </a></span>\n        </td>\n      </ng-container>\n\n      <ng-container matColumnDef=\"ContactDetails\">\n        <th mat-header-cell *matHeaderCellDef mat-sort-header> Contact Details</th>\n        <td mat-cell *matCellDef=\"let row\"> {{row.contactDetails}} </td>\n      </ng-container>\n      <ng-container matColumnDef=\"actions\">\n        <th mat-header-cell *matHeaderCellDef mat-sort-header>actions</th>\n        <td mat-cell *matCellDef=\"let row\">\n          <span>\n            <button mat-icon-button color=\"primary\" (click)=\"openCustomerDialog(false,row._id,row)\"\n              matTooltip=\"Click to update the script\">\n              <mat-icon aria-label=\"Edit\">edit</mat-icon>\n            </button>\n          </span>\n          <span>\n            <button mat-icon-button color=\"warn\" matTooltip=\"click here to delete application\"\n              matTooltipPosition=\"below\" (click)=\"ConfirmDeleteCustomer(row._id)\">\n              <mat-icon aria-label=\"Delete\">close</mat-icon>\n            </button>\n          </span>\n        </td>\n      </ng-container>\n      <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\n      <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"> </tr>\n    </table>\n\n    <mat-paginator [pageSizeOptions]=\"[5, 10, 25, 100]\"></mat-paginator>\n  </div>\n\n</div> -->\n<!--</div>-->\n\n\n\n\n\n\n\n\n<!--\n<div class=\"col-md-12\">\n  <div class=\"textright\">\n    <button mat-button color=\"primary\" (click)=\"openCustomerDialog(true)\"> Add Customer</button>\n\n  </div>\n\n  <div *ngFor=\"let customer of customer\">\n    <mat-accordion>\n      <mat-expansion-panel>\n        <mat-expansion-panel-header class=\"right-aligned-header\">\n          <mat-panel-title>\n            {{customer.customerName}}\n          </mat-panel-title>\n\n          <mat-panel-description class=\"center\">\n            <table>\n              <tr>\n                <td>\n                  <button mat-icon-button color=\"primary\" matTooltip=\"click here to delete customer\" matTooltipPosition=\"below\" (click)=\"ConfirmDeleteCustomer(customer._id)\">\n                  <mat-icon aria-label=\"Delete\">delete</mat-icon></button>\n                </td>\n              </tr>\n            </table>\n          </mat-panel-description>\n\n        </mat-expansion-panel-header>\n\n        <nb-tabset>\n          <nb-tab tabTitle=\"Application\">\n           \n            <div class=\"textright\">\n              <button mat-button color=\"primary\" (click)=\"openApplicationDialog(true,customer._id)\"> Add Application</button>\n\n            </div>\n            <table mat-table [dataSource]=\"customer.application\" matSort width=\"90%\">\n              <ng-container matColumnDef=\"applicationName\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> Application Name</th>\n                <td mat-cell *matCellDef=\"let row\"> {{row.applicationName}} </td>\n              </ng-container>\n\n              <ng-container matColumnDef=\"lob\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header> Line of business </th>\n                <td mat-cell *matCellDef=\"let row\"> {{row.lob}} </td>\n              </ng-container>\n              <ng-container matColumnDef=\"actions\">\n                <th mat-header-cell *matHeaderCellDef mat-sort-header></th>\n                <td mat-cell *matCellDef=\"let row\">\n                  <button mat-icon-button color=\"warn\" matTooltip=\"click here to delete application\" matTooltipPosition=\"below\" (click)=\"ConfirmDeleteApplication(customer._id,row.appid)\">\n                  <mat-icon aria-label=\"Delete\">close</mat-icon></button>\n                </td>\n              </ng-container>\n              <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\n              <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"> </tr>\n            </table>\n          </nb-tab>\n          <nb-tab tabTitle=\"users\">\n            <p>No users </p>\n          </nb-tab>\n        </nb-tabset>\n\n      </mat-expansion-panel>\n\n    </mat-accordion>\n  </div>\n</div>\n-->\n\n\n\n<!--\n         MAT Table for  applications           \n<div class=\"example-container mat-elevation-z8\">\n  <table mat-table [dataSource]=\"dataSource\" matSort>\n\n    <ng-container matColumnDef=\"applicationName\" >\n      <th  mat-header-cell *matHeaderCellDef mat-sort-header> Application Name</th>\n      <td mat-cell *matCellDef=\"let row\" > {{row.applicationName}} </td>\n    </ng-container>\n\n    <ng-container matColumnDef=\"lob\" >\n      <th  mat-header-cell *matHeaderCellDef mat-sort-header> Loacation of business </th>\n      <td mat-cell *matCellDef=\"let row\" > {{row.lob}} </td>\n    </ng-container>\n    \n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n\n    <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\" > </tr>\n  </table>\n  \n  \n  <div *ngFor=\"let application of customer.application\">\n<table >\n  <tr>\n    <th> Application Name </th>\n    <th> Loacation of business </th>\n  </tr>\n\n  <tr>\n    <td> {{application.applicationName}}</td>\n    <td> {{application.lob}} </td>\n  </tr>\n</table>\n\n</div>\n  \n  -->"

/***/ }),

/***/ "./src/app/pages/administrator/administrator.component.scss":
/*!******************************************************************!*\
  !*** ./src/app/pages/administrator/administrator.component.scss ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".right {\n  -webkit-box-flex: 1;\n      -ms-flex: 1 1 auto;\n          flex: 1 1 auto;\n  text-align: right; }\n\n.textright {\n  text-align: right;\n  /*float:right;*/ }\n\n.right {\n  -webkit-box-flex: 1;\n      -ms-flex: 1 1 auto;\n          flex: 1 1 auto;\n  text-align: right; }\n\n.textright {\n  text-align: right;\n  /*float:right;*/ }\n\n.bgColor {\n  background-color: #ffffff; }\n\n.customHeader {\n  font-size: 14px;\n  font-weight: bold;\n  color: black; }\n\n.mat-form-w150 {\n  /*display: block;*/\n  position: relative;\n  -webkit-box-flex: 1;\n      -ms-flex: auto;\n          flex: auto;\n  min-width: 0;\n  width: 150px; }\n\n.tableContent {\n  vertical-align: middle; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar {\n  width: 10px !important;\n  height: 5px; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar-thumb {\n  background: #a8a6a6 !important;\n  cursor: pointer;\n  border-radius: 5px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxhZG1pbmlzdHJhdG9yXFxhZG1pbmlzdHJhdG9yLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0csbUJBQWM7TUFBZCxrQkFBYztVQUFkLGNBQWM7RUFDZixpQkFBaUIsRUFBQTs7QUFFbkI7RUFFQSxpQkFBaUI7RUFDakIsZUFBQSxFQUFnQjs7QUFHaEI7RUFDRSxtQkFBYztNQUFkLGtCQUFjO1VBQWQsY0FBYztFQUNmLGlCQUFpQixFQUFBOztBQUVsQjtFQUVBLGlCQUFpQjtFQUNqQixlQUFBLEVBQWdCOztBQUVoQjtFQUNDLHlCQUF5QixFQUFBOztBQUkxQjtFQUNDLGVBQWM7RUFDZCxpQkFBaUI7RUFDakIsWUFBWSxFQUFBOztBQUliO0VBQ0Msa0JBQUE7RUFDQSxrQkFBa0I7RUFDbEIsbUJBQVU7TUFBVixjQUFVO1VBQVYsVUFBVTtFQUNWLFlBQVk7RUFDWixZQUFZLEVBQUE7O0FBR2I7RUFFRSxzQkFBc0IsRUFBQTs7QUFHeEI7RUFDRSxzQkFBc0I7RUFDdEIsV0FBVyxFQUFBOztBQUdiO0VBQ0UsOEJBQThCO0VBQzlCLGVBQWU7RUFDZiw2QkFBNkIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluaXN0cmF0b3IvYWRtaW5pc3RyYXRvci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yaWdodCB7XHJcbiAgIGZsZXg6IDEgMSBhdXRvO1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcbi50ZXh0cmlnaHRcclxue1xyXG50ZXh0LWFsaWduOiByaWdodDtcclxuLypmbG9hdDpyaWdodDsqL1xyXG59XHJcblxyXG4ucmlnaHQge1xyXG4gIGZsZXg6IDEgMSBhdXRvO1xyXG4gdGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuLnRleHRyaWdodFxyXG57XHJcbnRleHQtYWxpZ246IHJpZ2h0O1xyXG4vKmZsb2F0OnJpZ2h0OyovXHJcbn1cclxuLmJnQ29sb3J7XHJcbiBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG5cclxuLmN1c3RvbUhlYWRlcntcclxuIGZvbnQtc2l6ZToxNHB4O1xyXG4gZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiBjb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcblxyXG4ubWF0LWZvcm0tdzE1MCB7XHJcbiAvKmRpc3BsYXk6IGJsb2NrOyovXHJcbiBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiBmbGV4OiBhdXRvO1xyXG4gbWluLXdpZHRoOiAwO1xyXG4gd2lkdGg6IDE1MHB4O1xyXG59XHJcblxyXG4udGFibGVDb250ZW50e1xyXG4gIC8vIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG4vZGVlcC8gLm5iLXRoZW1lLWRlZmF1bHQgbmItbGF5b3V0IDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gIHdpZHRoOiAxMHB4ICFpbXBvcnRhbnQ7IC8vNXB4O1xyXG4gIGhlaWdodDogNXB4O1xyXG59XHJcblxyXG4vZGVlcC8gLm5iLXRoZW1lLWRlZmF1bHQgbmItbGF5b3V0IDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gIGJhY2tncm91bmQ6ICNhOGE2YTYgIWltcG9ydGFudDsgLy8jZGFkYWRhO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA1cHggIWltcG9ydGFudDsgLy8yLjVweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/administrator/administrator.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/pages/administrator/administrator.component.ts ***!
  \****************************************************************/
/*! exports provided: AdministratorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministratorComponent", function() { return AdministratorComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _customerform_customerform_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customerform/customerform.component */ "./src/app/pages/administrator/customerform/customerform.component.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _nebular_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @nebular/auth */ "./node_modules/@nebular/auth/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var AdministratorComponent = /** @class */ (function () {
    function AdministratorComponent(data, dialog, formBuilder, changeDetectorRefs, router, accessChecker, authService) {
        var _this = this;
        this.data = data;
        this.dialog = dialog;
        this.formBuilder = formBuilder;
        this.changeDetectorRefs = changeDetectorRefs;
        this.router = router;
        this.accessChecker = accessChecker;
        this.authService = authService;
        this.customerds = [];
        this.customerName = [];
        this.displayedColumns = ['CustomerName', 'ContactDetails', 'actions'];
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (!res) {
                accessChecker.isGranted('view', 'admin').take(1).subscribe(function (res1) {
                    if ((!res) && (!res1)) {
                        _this.router.navigate(['/']);
                    }
                    _this.authService.onTokenChange().subscribe(function (token) {
                        if (token.isValid()) {
                            var payload = token.getPayload();
                            // console.log('getPayload' + JSON.stringify(payload));
                            var customerID = payload.customerID;
                            // console.log('customerID' + customerID);
                            if (customerID) {
                                _this.router.navigate(['/pages/customer'], {
                                    queryParams: { customerId: customerID }
                                });
                            }
                        }
                    });
                });
            }
        });
        this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"]();
        this.dataSource.paginator = this.paginator1;
        this.dataSource.sort = this.sort1;
        this.changeDetectorRefs.markForCheck();
    }
    AdministratorComponent.prototype.ngOnInit = function () {
        this.dataSource.paginator = this.paginator1;
        this.dataSource.sort = this.sort1;
        this.getAllCustomerInfo();
    };
    AdministratorComponent.prototype.getAllCustomerInfo = function () {
        var _this = this;
        this.data.getAllCustomerDetailsAdmin().take(1).subscribe(function (data) {
            // console.log("customer  details  for  administrator  page");
            // console.log(data);
            _this.customer = data;
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.customer);
            _this.dataSource.paginator = _this.paginator1;
            _this.dataSource.sort = _this.sort1;
            _this.changeDetectorRefs.markForCheck();
        });
    };
    AdministratorComponent.prototype.ConfirmDeleteCustomer = function (customerid) {
        this.checkcustomerdelete = confirm("Are you sure you want to delete?");
        // console.log(this.checkcustomerdelete);
        if (this.checkcustomerdelete)
            this.deleteCustomer(customerid);
        else
            return false;
    };
    AdministratorComponent.prototype.deleteCustomer = function (customerid) {
        var _this = this;
        if (this.checkcustomerdelete) {
            this.data.deleteCustomer(customerid).take(1).subscribe(function (data) {
                // console.log("deleted");
                _this.getAllCustomerInfo();
                _this.changeDetectorRefs.markForCheck();
            });
        }
        else
            return false;
    };
    AdministratorComponent.prototype.openCustomerDialog = function (checkcond, customerId, row) {
        var _this = this;
        var dialogRef = this.dialog.open(_customerform_customerform_component__WEBPACK_IMPORTED_MODULE_1__["CustomerFormComponent"], {
            width: '750px',
            height: '550px',
            data: {
                value: checkcond,
                customerId: customerId,
                customer: row
            }
        });
        dialogRef.afterClosed().take(1).subscribe(function (result) {
            // console.log('The dialog was closed after save');
            if (!result) {
                _this.getAllCustomerInfo();
            }
            ;
        });
    };
    AdministratorComponent.prototype.applyFilter = function (event) {
        var filterValue = event.target.value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('MatPaginator1'),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatPaginator"])
    ], AdministratorComponent.prototype, "paginator1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('MatSort1'),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSort"])
    ], AdministratorComponent.prototype, "sort1", void 0);
    AdministratorComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'administrator',
            template: __webpack_require__(/*! ./administrator.component.html */ "./src/app/pages/administrator/administrator.component.html"),
            styles: [__webpack_require__(/*! ./administrator.component.scss */ "./src/app/pages/administrator/administrator.component.scss")]
        }),
        __metadata("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_6__["DataService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_5__["NbAccessChecker"],
            _nebular_auth__WEBPACK_IMPORTED_MODULE_7__["NbAuthService"]])
    ], AdministratorComponent);
    return AdministratorComponent;
}());



/***/ }),

/***/ "./src/app/pages/administrator/applicationform/applicationform.component.html":
/*!************************************************************************************!*\
  !*** ./src/app/pages/administrator/applicationform/applicationform.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div mat-dialog-title>\n  <h2> Application Details\n    <span class=\"fRight\">\n      <button mat-icon-button color=\"black\" (click)=\"onNoClick()\" matTooltip=\"Close\">\n        <mat-icon>close</mat-icon>\n      </button>\n    </span>\n  </h2>\n</div>\n<form [formGroup]=\"formGroup\" class=\"form\" style=\"text-align:center\" encrypt=\"multipart/form-data\">\n\n  <div mat-dialog-content>\n    <table>\n\n      <tr>\n        <td class=\"right\">Application Name : </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"string\" placeholder=\"Enter Application Names\" matInput\n              formControlName=\"applicationname\" required />\n\n          </mat-form-field>\n        </td>\n      </tr>\n      <tr>\n        <td class=\"right\">Line Of Business : </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"string\" placeholder=\"Enter lob details\" matInput formControlName=\"lob\"\n              required />\n          </mat-form-field>\n        </td>\n      </tr>\n      <tr>\n        <td colspan=\"2\" align=\"center\">\n\n          <button mat-button type=\"submit\" [disabled]=\"!formGroup.valid\" (click)=\"onSubmit(formGroup.value)\"\n            cdkFocusInitial>Save</button>\n\n        </td>\n      </tr>\n    </table>\n  </div>\n</form>\n\n<!--  [mat-dialog-close]=\"formGroup.applicationname\" -->"

/***/ }),

/***/ "./src/app/pages/administrator/applicationform/applicationform.component.scss":
/*!************************************************************************************!*\
  !*** ./src/app/pages/administrator/applicationform/applicationform.component.scss ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  width: 90%; }\n\ntd {\n  padding: 15px;\n  width: 50%; }\n\n.left {\n  text-align: left; }\n\n.right {\n  text-align: right; }\n\n.center {\n  text-align: center; }\n\ntable, td {\n  border: 0px solid black; }\n\nspan.right {\n  float: right; }\n\n.fRight {\n  float: right; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci9hcHBsaWNhdGlvbmZvcm0vQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxwYWdlc1xcYWRtaW5pc3RyYXRvclxcYXBwbGljYXRpb25mb3JtXFxhcHBsaWNhdGlvbmZvcm0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFQyxVQUFVLEVBQUE7O0FBRVg7RUFDSSxhQUFhO0VBQ2IsVUFDSixFQUFBOztBQUNBO0VBRUMsZ0JBQWdCLEVBQUE7O0FBR2pCO0VBQ0EsaUJBQWdCLEVBQUE7O0FBRWhCO0VBRUEsa0JBQWlCLEVBQUE7O0FBRWpCO0VBQ0ksdUJBQXVCLEVBQUE7O0FBRTFCO0VBRUQsWUFBVyxFQUFBOztBQUVYO0VBQ0ksWUFBWSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci9hcHBsaWNhdGlvbmZvcm0vYXBwbGljYXRpb25mb3JtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGV7XHJcblxyXG4gd2lkdGg6IDkwJTtcclxufVxyXG50ZHtcclxuICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICB3aWR0aDo1MCVcclxufVxyXG4ubGVmdFxyXG57XHJcbiB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG4ucmlnaHR7XHJcbnRleHQtYWxpZ246cmlnaHQ7XHJcbn1cclxuLmNlbnRlclxyXG57XHJcbnRleHQtYWxpZ246Y2VudGVyO1xyXG59XHJcbnRhYmxlLHRkIHtcclxuICAgIGJvcmRlcjogMHB4IHNvbGlkIGJsYWNrO1xyXG59XHJcbiBzcGFuLnJpZ2h0IHtcclxuXHJcbmZsb2F0OnJpZ2h0O1xyXG59XHJcbi5mUmlnaHQge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/administrator/applicationform/applicationform.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/administrator/applicationform/applicationform.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ApplicationformComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplicationformComponent", function() { return ApplicationformComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};






var ApplicationformComponent = /** @class */ (function () {
    function ApplicationformComponent(formBuilder, dialogRef, data, el, dialogdata, changeDetectorRefs, router, accessChecker) {
        var _this = this;
        this.formBuilder = formBuilder;
        this.dialogRef = dialogRef;
        this.data = data;
        this.el = el;
        this.dialogdata = dialogdata;
        this.changeDetectorRefs = changeDetectorRefs;
        this.router = router;
        this.accessChecker = accessChecker;
        this.submitted = false;
        this.errormessage = '';
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (!res) {
                accessChecker.isGranted('view', 'admin').take(1).subscribe(function (res1) {
                    if ((!res) && (!res1)) {
                        _this.router.navigate(['/']);
                    }
                });
            }
        });
        this.createForm();
        if (!this.dialogdata.value) {
            this.formGroup.get('applicationname').setValue(this.dialogdata.application.applicationName);
            this.formGroup.get('lob').setValue(this.dialogdata.application.lob);
        }
    }
    ApplicationformComponent.prototype.createForm = function () {
        this.formGroup = this.formBuilder.group({
            applicationname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            lob: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    };
    ApplicationformComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    ApplicationformComponent.prototype.onSubmit = function (postData) {
        var _this = this;
        var sampleobj = {
            "applicationName": postData.applicationname,
            "lob": postData.lob
        };
        if (this.dialogdata.value) {
            this.data.addNewApplicationAdmin(sampleobj, this.dialogdata.customerId).take(1).subscribe((function (data) {
                // console.log(data);
                _this.onNoClick();
            }), function (error) {
                _this.errormessage = error.error;
                //this.errorcheck = true;
                // console.log(" errors :  ");
                // console.log(error);
                alert(_this.errormessage);
                _this.changeDetectorRefs.markForCheck();
            });
        }
        else {
            this.data.updateApplicationAdmin(sampleobj, this.dialogdata.customerId, this.dialogdata.applicationId).take(1).subscribe(function (data) {
                // console.log(data);
                _this.onNoClick();
            });
        }
    };
    ApplicationformComponent.prototype.ngOnInit = function () {
    };
    ApplicationformComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'applicationform',
            template: __webpack_require__(/*! ./applicationform.component.html */ "./src/app/pages/administrator/applicationform/applicationform.component.html"),
            styles: [__webpack_require__(/*! ./applicationform.component.scss */ "./src/app/pages/administrator/applicationform/applicationform.component.scss")]
        }),
        __param(4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"],
            _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], Object, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_5__["NbAccessChecker"]])
    ], ApplicationformComponent);
    return ApplicationformComponent;
}());



/***/ }),

/***/ "./src/app/pages/administrator/customer/customer.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/pages/administrator/customer/customer.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container mat-elevation-z8 bgColor\">\n  <div class=\"row\">\n    <div class=\"col-md-12\">\n      <mat-tab-group dynamicHeight (selectedTabChange)=\"onTabChange($event)\">\n        <mat-tab label=\"Applications\">\n          <br />\n          <div clas=\"row\">\n            <div class=\"col-md-10\">\n              <button mat-icon-button type=\"button\">\n                <mat-icon color=\"primary\">search</mat-icon>\n              </button>\n              <mat-form-field class=\"mat-form-w150\">\n                <mat-label>Filter</mat-label>\n                <input matInput (keyup)=\"applicationApplyFilter($event)\" placeholder=\"Filter\">\n              </mat-form-field>\n            </div>\n            <div class=\"col-md-2\">\n              <button mat-icon-button color=\"primary\" matTooltip=\"Add Application\"\n                (click)=\"openApplicationDialog(true)\">\n                <mat-icon>add</mat-icon>\n              </button>\n            </div>\n          </div>\n          <div clas=\"row\">\n            <div class=\"col-md-12\">\n              <div class=\"table table-hover\" style=\"background-color: #FFF\">\n                <table mat-table [dataSource]=\"applicationDataSource\" #MatSort1=\"matSort\" matSort width=\"100%\"\n                   matSortActive=\"applicationName\"  matSortDirection=\"asc\">\n                  <ng-container matColumnDef=\"applicationName\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\">Application\n                      Name\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\">\n                      <span *ngIf=\"row.hasOwnProperty('applicationName')\">{{row.applicationName}}</span>\n                    </td>\n                  </ng-container>\n                  <ng-container matColumnDef=\"lob\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Line of\n                      business </th>\n                    <td mat-cell *matCellDef=\"let row\"> {{row.lob}} </td>\n                  </ng-container>\n                  <ng-container matColumnDef=\"actions\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Actions\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\">\n                      <span>\n                        <button mat-icon-button color=\"primary\" (click)=\"openApplicationDialog(false,row.appid,row)\"\n                          matTooltip=\"Edit\">\n                          <mat-icon aria-label=\"Edit\">edit</mat-icon>\n                        </button>\n                      </span>\n                      <span>\n                        <button mat-icon-button color=\"warn\" matTooltip=\"Delete\" matTooltipPosition=\"below\"\n                          (click)=\"ConfirmDeleteApplication(customer._id,row.appid)\">\n                          <mat-icon aria-label=\"Delete\">delete</mat-icon>\n                        </button>\n                      </span>\n                    </td>\n                  </ng-container>\n\n                  <tr mat-header-row *matHeaderRowDef=\"applicationDisplayedColumns\"></tr>\n                  <tr mat-row *matRowDef=\"let row; columns: applicationDisplayedColumns;\">\n                  </tr>\n                </table>\n                <mat-paginator #MatPaginator1 [pageSizeOptions]=\"[5, 10, 25, 100]\" showFirstLastButtons></mat-paginator>\n              </div>\n            </div>\n          </div>\n          <br />\n        </mat-tab>\n        <mat-tab label=\"Users\">\n          <br />\n          <div clas=\"row\">\n            <div class=\"col-md-10\">\n              <button mat-icon-button type=\"button\">\n                <mat-icon color=\"primary\">search</mat-icon>\n              </button>\n              <mat-form-field class=\"mat-form-w150\">\n                <mat-label>Filter</mat-label>\n                <input matInput (keyup)=\"usersApplyFilter($event)\" placeholder=\"Filter\">\n              </mat-form-field>\n            </div>\n            <div class=\"col-md-2\">\n              <button mat-icon-button color=\"primary\" matTooltip=\"Add User\"\n                (click)=\"openUserDialog(true,customer.customerName)\">\n                <mat-icon>add</mat-icon>\n              </button>\n            </div>\n          </div>\n          <div clas=\"row\">\n            <div class=\"col-md-12\">\n              <div class=\"table table-hover\" style=\"background-color: #FFF\">\n                <table mat-table [dataSource]=\"usersDataSource\" #MatSort2=\"matSort\" matSort width=\"100%\"\n                   matSortActive=\"userName\"  matSortDirection=\"asc\">\n                  <ng-container matColumnDef=\"userName\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\">User Name\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\">\n                      <span *ngIf=\"row.hasOwnProperty('userName')\">{{row.userName}}</span>\n                    </td>\n                  </ng-container>\n                  <ng-container matColumnDef=\"emailId\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Email ID\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\"> {{row.emailId}} </td>\n                  </ng-container>\n                  <ng-container matColumnDef=\"role\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Role\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\">\n                      <span *ngIf=\"row.hasOwnProperty('role')\">\n                        <span *ngIf=\"row.role=='user'\">Standard</span>\n                        <span *ngIf=\"row.role=='admin'\">Administrator</span>\n                      </span>\n                    </td>\n                  </ng-container>\n                  <ng-container matColumnDef=\"state\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> State\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\">\n                      <span *ngIf=\"row.hasOwnProperty('state')\">\n                        <span *ngIf=\"row.state=='active'\">Active</span>\n                        <span *ngIf=\"row.state=='blocked'\">Blocked</span>\n                      </span>\n                    </td>\n                  </ng-container>\n                  <ng-container matColumnDef=\"actions\">\n                    <th mat-header-cell *matHeaderCellDef mat-sort-header class=\"customHeader tableContent\"> Actions\n                    </th>\n                    <td mat-cell *matCellDef=\"let row\">\n                      <span>\n                        <button mat-icon-button color=\"primary\"\n                          (click)=\"openUserDialog(false,customer.customerName,row._id,row)\" matTooltip=\"Edit\">\n                          <mat-icon aria-label=\"Edit\">edit</mat-icon>\n                        </button>\n                      </span>\n                      <span *ngIf=\"row.state==='active'\">\n                        <button mat-icon-button color=\"primary\" (click)=\"blockUser(row._id)\" matTooltip=\"Lock\">\n                          <mat-icon aria-label=\"Reset Password\">lock</mat-icon>\n                        </button>\n                      </span>\n                      <span *ngIf=\"row.state==='blocked'\">\n                        <button mat-icon-button color=\"primary\" (click)=\"unBlockUser(row._id)\" matTooltip=\"Unlock\">\n                          <mat-icon aria-label=\"Reset Password\">lock_open</mat-icon>\n                        </button>\n                      </span>\n                      <span>\n                        <button mat-icon-button color=\"primary\" (click)=\"openUserPasswordDialog(row._id)\"\n                          matTooltip=\"Reset Password\">\n                          <mat-icon aria-label=\"Reset Password\">refresh</mat-icon>\n                        </button>\n                      </span>\n                      <span>\n                        <button mat-icon-button color=\"warn\" matTooltip=\"Delete\" matTooltipPosition=\"below\"\n                          (click)=\"ConfirmDeleteUser(row._id)\">\n                          <mat-icon aria-label=\"Delete\">delete</mat-icon>\n                        </button>\n                      </span>\n                    </td>\n                  </ng-container>\n\n                  <tr mat-header-row *matHeaderRowDef=\"usersDisplayedColumns\"></tr>\n                  <tr mat-row *matRowDef=\"let row; columns: usersDisplayedColumns;\">\n                  </tr>\n                </table>\n                <mat-paginator #MatPaginator2 [pageSizeOptions]=\"[5, 10, 25, 100]\" showFirstLastButtons></mat-paginator>\n              </div>\n            </div>\n          </div>\n          <br />\n        </mat-tab>\n      </mat-tab-group>\n    </div>\n  </div>\n</div>\n<!-- \n<div class=\"row\" *ngFor=\"let customer of customer\">\n  <div class=\"col-md-6\">\n    <nb-card>\n      <nb-card-header>Applications\n        <span style=\"float:right;\">\n          <button mat-button color=\"primary\" (click)=\"openApplicationDialog(true)\"> Add Application</button>\n        </span>\n      </nb-card-header>\n      <nb-card-body>\n\n        <table mat-table [dataSource]=\"customer.application\" matSort width=\"90%\">\n          <ng-container matColumnDef=\"applicationName\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header> Application Name</th>\n            <td mat-cell *matCellDef=\"let row\"> {{row.applicationName}} </td>\n          </ng-container>\n\n          <ng-container matColumnDef=\"lob\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header> Line of business </th>\n            <td mat-cell *matCellDef=\"let row\"> {{row.lob}} </td>\n          </ng-container>\n          <ng-container matColumnDef=\"actions\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header>Actions</th>\n            <td mat-cell *matCellDef=\"let row\">\n              <span>\n                <button mat-icon-button color=\"primary\"\n                  (click)=\"openUserDialog(false,customer.customerName,row._id,row)\"\n                  matTooltip=\"Click to update the script\">\n                  <mat-icon aria-label=\"Edit\">edit</mat-icon>\n                </button>\n              </span>\n              <span>\n                <button mat-icon-button color=\"warn\" matTooltip=\"click here to delete application\"\n                  matTooltipPosition=\"below\" (click)=\"ConfirmDeleteUser(row._id)\">\n                  <mat-icon aria-label=\"Delete\">delete</mat-icon>\n                </button> </span>\n\n              <span> <button mat-button color=\"primary\" (click)=\"openUserPasswordDialog(row._id)\">Reset\n                  Password</button> </span>\n\n              <span> <button mat-button color=\"primary\" (click)=\"blockUser(row._id)\">lock</button> </span>\n              <span> <button mat-button color=\"primary\" (click)=\"unBlockUser(row._id)\">Unlock</button> </span>-->\n<!--\n                  <span *ngIf=\"checkpasswordvalue\"> <button mat-button color=\"primary\" (click)=\"openUserPassword(false)\"> Reset Password</button> </span>\n                   <span *ngIf=\"!checkpasswordvalue\"> \n                     <form class=\"form\"> \n                      <mat-form-field>\n                     <input autocomplete=\"off\" type=\"password\" placeholder=\"Enter Password\"  matInput [formControl]=\"password\"  required />    \n                       <button mat-icon-button type=\"submit\" color=\"accent\" matTooltip=\"click here to save \" matTooltipPosition=\"below\" (click)=\"updateUserPassword(password,row._id)\">\n                  <mat-icon aria-label=\"Delete\">save</mat-icon></button> \n                     \n                  </mat-form-field>\n                  </form> \n                </span>-->\n<!--\n\n            </td>\n          </ng-container>\n          <tr mat-header-row *matHeaderRowDef=\"appdisplayedColumns\"></tr>\n          <tr mat-row *matRowDef=\"let row; columns: appdisplayedColumns;\"> </tr>\n        </table>\n      </nb-card-body>\n\n    </nb-card>\n  </div>\n\n  <div class=\"col-md-6\">\n    <nb-card>\n      <nb-card-header>Users\n        <span style=\"float:right;\">\n          <button mat-button color=\"primary\" (click)=\"openUserDialog(true,customer.customerName)\"> Add Users</button>\n        </span>\n      </nb-card-header>\n      <nb-card-body>\n\n        <table mat-table [dataSource]=\"users\" matSort width=\"90%\">\n          <ng-container matColumnDef=\"userName\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header>User Name</th>\n            <td mat-cell *matCellDef=\"let row\"> {{row.userName}} </td>\n          </ng-container>\n\n          <ng-container matColumnDef=\"emailId\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header>Email Id </th>\n            <td mat-cell *matCellDef=\"let row\"> {{row.emailId}} </td>\n          </ng-container>\n          <ng-container matColumnDef=\"actions\">\n            <th mat-header-cell *matHeaderCellDef mat-sort-header>Actions</th>\n            <td mat-cell *matCellDef=\"let row\">\n              <span>\n                <button mat-icon-button color=\"primary\"\n                  (click)=\"openUserDialog(false,customer.customerName,row._id,row)\"\n                  matTooltip=\"Click to update the script\">\n                  <mat-icon aria-label=\"Edit\">edit</mat-icon>\n                </button>\n              </span>\n              <span>\n                <button mat-icon-button color=\"warn\" matTooltip=\"click here to delete application\"\n                  matTooltipPosition=\"below\" (click)=\"ConfirmDeleteUser(row._id)\">\n                  <mat-icon aria-label=\"Delete\">close</mat-icon>\n                </button> </span>\n\n              <span> <button mat-button color=\"primary\" (click)=\"openUserPasswordDialog(row._id)\">Reset\n                  Password</button> </span>\n\n              <span> <button mat-button color=\"primary\" (click)=\"blockUser(row._id)\">lock</button> </span>\n              <span> <button mat-button color=\"primary\" (click)=\"unBlockUser(row._id)\">Unlock</button> </span>-->\n<!--\n                  <span *ngIf=\"checkpasswordvalue\"> <button mat-button color=\"primary\" (click)=\"openUserPassword(false)\"> Reset Password</button> </span>\n                   <span *ngIf=\"!checkpasswordvalue\"> \n                     <form class=\"form\"> \n                      <mat-form-field>\n                     <input autocomplete=\"off\" type=\"password\" placeholder=\"Enter Password\"  matInput [formControl]=\"password\"  required />    \n                       <button mat-icon-button type=\"submit\" color=\"accent\" matTooltip=\"click here to save \" matTooltipPosition=\"below\" (click)=\"updateUserPassword(password,row._id)\">\n                  <mat-icon aria-label=\"Delete\">save</mat-icon></button> \n                     \n                  </mat-form-field>\n                  </form> \n                </span>-->\n<!--\n            </td>\n          </ng-container>\n          <tr mat-header-row *matHeaderRowDef=\"usersdisplayedColumns\"></tr>\n          <tr mat-row *matRowDef=\"let row; columns: usersdisplayedColumns;\"> </tr>\n        </table>\n\n\n      </nb-card-body>\n\n    </nb-card>\n  </div>\n</div> -->"

/***/ }),

/***/ "./src/app/pages/administrator/customer/customer.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pages/administrator/customer/customer.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".right {\n  -webkit-box-flex: 1;\n      -ms-flex: 1 1 auto;\n          flex: 1 1 auto;\n  text-align: right; }\n\n.textright {\n  text-align: right;\n  /*float:right;*/ }\n\n.bgColor {\n  background-color: #ffffff; }\n\n.customHeader {\n  font-size: 14px;\n  font-weight: bold;\n  color: black; }\n\n.mat-form-w150 {\n  /*display: block;*/\n  position: relative;\n  -webkit-box-flex: 1;\n      -ms-flex: auto;\n          flex: auto;\n  min-width: 0;\n  width: 150px; }\n\n.tableContent {\n  vertical-align: middle; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci9jdXN0b21lci9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxhZG1pbmlzdHJhdG9yXFxjdXN0b21lclxcY3VzdG9tZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRyxtQkFBYztNQUFkLGtCQUFjO1VBQWQsY0FBYztFQUNmLGlCQUFpQixFQUFBOztBQUVuQjtFQUVBLGlCQUFpQjtFQUNqQixlQUFBLEVBQWdCOztBQUVoQjtFQUNFLHlCQUF5QixFQUFBOztBQUkzQjtFQUNFLGVBQWM7RUFDZCxpQkFBaUI7RUFDakIsWUFBWSxFQUFBOztBQUlkO0VBQ0Usa0JBQUE7RUFDQSxrQkFBa0I7RUFDbEIsbUJBQVU7TUFBVixjQUFVO1VBQVYsVUFBVTtFQUNWLFlBQVk7RUFDWixZQUFZLEVBQUE7O0FBSWQ7RUFFRSxzQkFBc0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluaXN0cmF0b3IvY3VzdG9tZXIvY3VzdG9tZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmlnaHQge1xyXG4gICBmbGV4OiAxIDEgYXV0bztcclxuICB0ZXh0LWFsaWduOiByaWdodDtcclxufVxyXG4udGV4dHJpZ2h0XHJcbntcclxudGV4dC1hbGlnbjogcmlnaHQ7XHJcbi8qZmxvYXQ6cmlnaHQ7Ki9cclxufVxyXG4uYmdDb2xvcntcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG5cclxuLmN1c3RvbUhlYWRlcntcclxuICBmb250LXNpemU6MTRweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBjb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcblxyXG4ubWF0LWZvcm0tdzE1MCB7XHJcbiAgLypkaXNwbGF5OiBibG9jazsqL1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBmbGV4OiBhdXRvO1xyXG4gIG1pbi13aWR0aDogMDtcclxuICB3aWR0aDogMTUwcHg7XHJcbn1cclxuXHJcblxyXG4udGFibGVDb250ZW50e1xyXG4gIC8vIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/administrator/customer/customer.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/administrator/customer/customer.component.ts ***!
  \********************************************************************/
/*! exports provided: CustomerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerComponent", function() { return CustomerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _userform_userform_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../userform/userform.component */ "./src/app/pages/administrator/userform/userform.component.ts");
/* harmony import */ var _userpasswordform_userpasswordform_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../userpasswordform/userpasswordform.component */ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.ts");
/* harmony import */ var _applicationform_applicationform_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../applicationform/applicationform.component */ "./src/app/pages/administrator/applicationform/applicationform.component.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs_add_operator_filter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/add/operator/filter */ "./node_modules/rxjs-compat/_esm5/add/operator/filter.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};












var CustomerComponent = /** @class */ (function () {
    function CustomerComponent(data, dialog, formBuilder, changeDetectorRefs, route, router, accessChecker) {
        var _this = this;
        this.data = data;
        this.dialog = dialog;
        this.formBuilder = formBuilder;
        this.changeDetectorRefs = changeDetectorRefs;
        this.route = route;
        this.router = router;
        this.accessChecker = accessChecker;
        this.application = [];
        this.applicationDisplayedColumns = [
            'applicationName',
            'lob',
            'actions'
        ];
        this.usersDisplayedColumns = [
            'userName',
            'emailId',
            'role',
            'state',
            'actions'
        ];
        this.appdisplayedColumns = ['applicationName', 'lob', 'actions'];
        this.usersdisplayedColumns = ['userName', 'emailId', 'actions'];
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (!res) {
                accessChecker.isGranted('view', 'admin').take(1).subscribe(function (res1) {
                    if ((!res) && (!res1)) {
                        _this.router.navigate(['/']);
                    }
                });
            }
        });
        this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](this.application);
        // this.usersdataSource = new MatTableDataSource();
        var paramMap;
        this.route.queryParamMap.take(1).subscribe(function (queryparams) {
            paramMap = queryparams;
            if (paramMap.hasOwnProperty('params')) {
                //console.log(paramMap.params);
                if (paramMap.params.hasOwnProperty('customerId')) {
                    _this.customerId = paramMap.params.customerId;
                    _this.getCustomerInfo(_this.customerId);
                    _this.getUsersInfo(_this.customerId);
                }
            }
        });
    }
    CustomerComponent.prototype.ngOnInit = function () {
        this.dataSource.paginator = this.paginator;
        /*  this.route.queryParams
           .filter(params => params.customerId)
           .take(1).subscribe(params => {
             // console.log(params);
     
             this.customerId = params.customerId;
             // console.log(this.customerId);
     
             //this.appdataSource.sort = this.sort;
           });
           
             this.getCustomerInfo(this.customerId);
             this.getUsersInfo(this.customerId);
           */
        this.applicationDataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](this.application);
        this.applicationDataSource.paginator = this.paginator1;
        this.applicationDataSource.sort = this.sort1;
        this.changeDetectorRefs.markForCheck();
    };
    CustomerComponent.prototype.getCustomerInfo = function (customerId) {
        var _this = this;
        this.data.getCustomerDetailsAdmin(customerId).take(1).subscribe(function (data) {
            // console.log("customer  details  for  administrator  page");
            _this.customer = data;
            //console.log(data);
            _this.application = _this.customer[0].application;
            _this.applicationDataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](_this.application);
            _this.applicationDataSource.paginator = _this.paginator1;
            _this.applicationDataSource.sort = _this.sort1;
            _this.changeDetectorRefs.markForCheck();
        });
    };
    CustomerComponent.prototype.getUsersInfo = function (customerId) {
        var _this = this;
        this.data.getUserDetails(this.customerId).take(1).subscribe(function (data) {
            _this.users = data;
            // console.log(this.users);
            _this.usersDataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](_this.users);
            _this.usersDataSource.paginator = _this.paginator2;
            _this.usersDataSource.sort = _this.sort2;
            _this.changeDetectorRefs.markForCheck();
        });
    };
    CustomerComponent.prototype.ConfirmDeleteUser = function (userId) {
        this.checkuserdelete = confirm("Are you sure you want to delete?");
        // console.log(this.checkuserdelete);
        // console.log(userId);
        if (this.checkuserdelete)
            this.deleteUser(userId);
        else
            return false;
    };
    CustomerComponent.prototype.deleteUser = function (userId) {
        var _this = this;
        if (this.checkuserdelete) {
            this.data.deleteUser(userId).take(1).subscribe(function (data) {
                // console.log("deleted");
                _this.getUsersInfo(_this.customerId);
                _this.changeDetectorRefs.markForCheck();
            });
        }
        else
            return false;
    };
    CustomerComponent.prototype.ConfirmDeleteApplication = function (customerid, applicationid) {
        this.checkapplndelete = confirm("Are you sure you want to delete?");
        // console.log(this.checkapplndelete);
        // console.log(applicationid);
        if (this.checkapplndelete)
            this.deleteApplication(this.customerId, applicationid);
        else
            return false;
    };
    CustomerComponent.prototype.deleteApplication = function (customerid, applicationid) {
        var _this = this;
        if (this.checkapplndelete) {
            this.data.deleteApplicationAdmin(this.customerId, applicationid).take(1).subscribe(function (data) {
                // console.log("deleted");
                _this.getCustomerInfo(_this.customerId);
                _this.changeDetectorRefs.markForCheck();
            });
        }
        else
            return false;
    };
    CustomerComponent.prototype.openApplicationDialog = function (checkcond, applicationId, appform) {
        var _this = this;
        var dialogRef = this.dialog.open(_applicationform_applicationform_component__WEBPACK_IMPORTED_MODULE_3__["ApplicationformComponent"], {
            width: '750px',
            height: '400px',
            data: {
                value: checkcond,
                applicationId: applicationId,
                application: appform,
                customerId: this.customerId
            }
        });
        dialogRef.afterClosed().take(1).subscribe(function (result) {
            // console.log(result);
            // console.log('The dialog was closed after save');
            if (!result) {
                _this.getCustomerInfo(_this.customerId);
            }
            ;
        });
    };
    CustomerComponent.prototype.openUserDialog = function (checkcond, customerName, userId, user) {
        var _this = this;
        var dialogRef = this.dialog.open(_userform_userform_component__WEBPACK_IMPORTED_MODULE_1__["UserFormComponent"], {
            width: '750px',
            height: '550px',
            data: {
                value: checkcond,
                customerId: this.customerId,
                customerName: customerName,
                userId: userId,
                user: user
            }
        });
        dialogRef.afterClosed().take(1).subscribe(function (result) {
            // console.log(result);
            // console.log('The dialog was closed after save');
            if (!result) {
                _this.getUsersInfo(_this.customerId);
            }
            ;
        });
    };
    /*password = new FormControl('', [Validators.required]);
  checkpasswordvalue:boolean=true;
  openUserPassword(checkvar)
  {
  this.checkpasswordvalue=checkvar;
  this.changeDetectorRefs.markForCheck();
  }
  
  updateUserPassword(password,userId)
  {
  this.data.updateUserPassword(password,userId).take(1).subscribe(data => {
        // console.log(data);
     //this.getCustomerInfo(this.customerId);
      this.checkpasswordvalue=true;
        this.changeDetectorRefs.markForCheck();
      });
   
  }*/
    CustomerComponent.prototype.openUserPasswordDialog = function (userId) {
        var dialogRef = this.dialog.open(_userpasswordform_userpasswordform_component__WEBPACK_IMPORTED_MODULE_2__["UserpasswordformComponent"], {
            width: '450px',
            height: '300px',
            data: {
                userId: userId,
            }
        });
        dialogRef.afterClosed().take(1).subscribe(function (result) {
            //// console.log(result);
            // console.log('The dialog was closed after save');
            //if (!result) { this.getUsersInfo(this.customerId); };
        });
    };
    CustomerComponent.prototype.blockUser = function (userId) {
        var _this = this;
        this.data.blockUser(userId).take(1).subscribe(function (data) {
            // console.log("blockUser");
            _this.getUsersInfo(_this.customerId);
            _this.changeDetectorRefs.markForCheck();
        });
    };
    CustomerComponent.prototype.unBlockUser = function (userId) {
        var _this = this;
        this.data.unBlockUser(userId).take(1).subscribe(function (data) {
            // console.log("UnBlocked");
            _this.getUsersInfo(_this.customerId);
            _this.changeDetectorRefs.markForCheck();
        });
    };
    CustomerComponent.prototype.applicationApplyFilter = function (event) {
        var filterValue = event.target.value;
        this.applicationDataSource.filter = filterValue.trim().toLowerCase();
    };
    CustomerComponent.prototype.usersApplyFilter = function (event) {
        var filterValue = event.target.value;
        this.usersDataSource.filter = filterValue.trim().toLowerCase();
    };
    CustomerComponent.prototype.onTabChange = function (selectedTab) {
        if (selectedTab.hasOwnProperty('tab')) {
            if (selectedTab.tab.textLabel == "Applications") {
                this.applicationDataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](this.application);
                this.applicationDataSource.paginator = this.paginator1;
                this.applicationDataSource.sort = this.sort1;
            }
            else if (selectedTab.tab.textLabel == "Users") {
                this.usersDataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatTableDataSource"](this.users);
                this.usersDataSource.paginator = this.paginator2;
                this.usersDataSource.sort = this.sort2;
            }
            this.changeDetectorRefs.markForCheck();
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"])
    ], CustomerComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSort"]),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSort"])
    ], CustomerComponent.prototype, "sort", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('MatPaginator1'),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"])
    ], CustomerComponent.prototype, "paginator1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('MatSort1'),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSort"])
    ], CustomerComponent.prototype, "sort1", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('MatPaginator2'),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatPaginator"])
    ], CustomerComponent.prototype, "paginator2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('MatSort2'),
        __metadata("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSort"])
    ], CustomerComponent.prototype, "sort2", void 0);
    CustomerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'customer',
            template: __webpack_require__(/*! ./customer.component.html */ "./src/app/pages/administrator/customer/customer.component.html"),
            styles: [__webpack_require__(/*! ./customer.component.scss */ "./src/app/pages/administrator/customer/customer.component.scss")]
        }),
        __metadata("design:paramtypes", [_data_service__WEBPACK_IMPORTED_MODULE_8__["DataService"],
            _angular_material__WEBPACK_IMPORTED_MODULE_4__["MatDialog"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_9__["NbAccessChecker"]])
    ], CustomerComponent);
    return CustomerComponent;
}());



/***/ }),

/***/ "./src/app/pages/administrator/customerform/customerform.component.html":
/*!******************************************************************************!*\
  !*** ./src/app/pages/administrator/customerform/customerform.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div mat-dialog-title>\n  <h2> Customer Details </h2>\n</div>\n<form [formGroup]=\"formGroup\" class=\"form\" style=\"text-align:center\" encrypt=\"multipart/form-data\">\n\n  <div mat-dialog-content>\n    <table>\n      <tr>\n        <td class=\"right\">Customer Name : </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"string\" placeholder=\"Enter the Name\" matInput  formControlName=\"customername\" required/>\n          </mat-form-field>\n      </tr>\n      <!--<input  type=\"file\"  (change)=\"onfileChange($event)\" accept=\"file_extension/*\"  formControlName=\"scriptfile\"/>-->\n\n      <tr>\n        <td class=\"right\">Contact Details : </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"number\" placeholder=\"Enter contact details\" matInput  formControlName=\"contactdetails\" required />\n          </mat-form-field>\n        </td>\n      </tr>\n\n\n      <tr>\n        <td colspan=\"2\" align=\"center\">\n\n          <button mat-button type=\"submit\" [disabled]=\"!formGroup.valid\" (click)=\"onSubmit(formGroup.value)\"  cdkFocusInitial>Save</button>\n\n        </td>\n      </tr>\n    </table>\n  </div>\n</form>\n\n\n\n<!-- [mat-dialog-close]=\"formGroup.customername\" -->"

/***/ }),

/***/ "./src/app/pages/administrator/customerform/customerform.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/pages/administrator/customerform/customerform.component.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  width: 90%; }\n\ntd {\n  padding: 15px;\n  width: 50%; }\n\n.left {\n  text-align: left; }\n\n.right {\n  text-align: right; }\n\n.center {\n  text-align: center; }\n\ntable, td {\n  border: 0px solid black; }\n\nspan.right {\n  float: right; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci9jdXN0b21lcmZvcm0vQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxwYWdlc1xcYWRtaW5pc3RyYXRvclxcY3VzdG9tZXJmb3JtXFxjdXN0b21lcmZvcm0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFQyxVQUFVLEVBQUE7O0FBRVg7RUFDSSxhQUFhO0VBQ2IsVUFDSixFQUFBOztBQUNBO0VBRUMsZ0JBQWdCLEVBQUE7O0FBR2pCO0VBQ0EsaUJBQWdCLEVBQUE7O0FBRWhCO0VBRUEsa0JBQWlCLEVBQUE7O0FBRWpCO0VBQ0ksdUJBQXVCLEVBQUE7O0FBRTFCO0VBRUQsWUFBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci9jdXN0b21lcmZvcm0vY3VzdG9tZXJmb3JtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGV7XHJcblxyXG4gd2lkdGg6IDkwJTtcclxufVxyXG50ZHtcclxuICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICB3aWR0aDo1MCVcclxufVxyXG4ubGVmdFxyXG57XHJcbiB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG4ucmlnaHR7XHJcbnRleHQtYWxpZ246cmlnaHQ7XHJcbn1cclxuLmNlbnRlclxyXG57XHJcbnRleHQtYWxpZ246Y2VudGVyO1xyXG59XHJcbnRhYmxlLHRkIHtcclxuICAgIGJvcmRlcjogMHB4IHNvbGlkIGJsYWNrO1xyXG59XHJcbiBzcGFuLnJpZ2h0IHtcclxuXHJcbmZsb2F0OnJpZ2h0O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/administrator/customerform/customerform.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/pages/administrator/customerform/customerform.component.ts ***!
  \****************************************************************************/
/*! exports provided: CustomerFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerFormComponent", function() { return CustomerFormComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};




//import { TableComponent } from './table.component';


var CustomerFormComponent = /** @class */ (function () {
    function CustomerFormComponent(formBuilder, dialogRef, data, el, dialogdata, router, accessChecker) {
        var _this = this;
        this.formBuilder = formBuilder;
        this.dialogRef = dialogRef;
        this.data = data;
        this.el = el;
        this.dialogdata = dialogdata;
        this.router = router;
        this.accessChecker = accessChecker;
        this.checkrows = false;
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (!res) {
                accessChecker.isGranted('view', 'admin').take(1).subscribe(function (res1) {
                    if ((!res) && (!res1)) {
                        _this.router.navigate(['/']);
                    }
                });
            }
        });
        this.createForm();
        if (!this.dialogdata.value) {
            this.formGroup.get('customername').setValue(this.dialogdata.customer.customerName);
            this.formGroup.get('contactdetails').setValue(this.dialogdata.customer.contactDetails);
        }
    }
    CustomerFormComponent.prototype.createForm = function () {
        this.formGroup = this.formBuilder.group({
            customername: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            contactdetails: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    };
    CustomerFormComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    CustomerFormComponent.prototype.onSubmit = function (postData) {
        var _this = this;
        var sampleobj = {
            "customerName": postData.customername,
            "contactDetails": postData.contactdetails
        };
        if (this.dialogdata.value) {
            this.data.addNewCustomerAdmin(sampleobj).take(1).subscribe(function (data) {
                // console.log(    this.formGroup.value.customername);
                // console.log(data);
                _this.onNoClick();
            });
        }
        else {
            // console.log(this.dialogdata.customerId);
            this.data.updateCustomerAdmin(sampleobj, this.dialogdata.customerId).take(1).subscribe(function (data) {
                // console.log(data);
                _this.onNoClick();
            });
        }
    };
    CustomerFormComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'customerform',
            template: __webpack_require__(/*! ./customerform.component.html */ "./src/app/pages/administrator/customerform/customerform.component.html"),
            styles: [__webpack_require__(/*! ./customerform.component.scss */ "./src/app/pages/administrator/customerform/customerform.component.scss")]
        }),
        __param(4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"], Object, _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_5__["NbAccessChecker"]])
    ], CustomerFormComponent);
    return CustomerFormComponent;
}());



/***/ }),

/***/ "./src/app/pages/administrator/userform/userform.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/pages/administrator/userform/userform.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div mat-dialog-title>\n  <h2>\n    <span *ngIf=\"dialogdata.value\">New User</span>\n    <span *ngIf=\"!dialogdata.value\">Edit User</span>\n    <span class=\"fRight\">\n      <button mat-icon-button color=\"black\" (click)=\"onNoClick()\" matTooltip=\"Close\">\n        <mat-icon>close</mat-icon>\n      </button>\n    </span>\n  </h2>\n</div>\n\n<mat-dialog-content>\n  <div>\n    <!--  mat-dialog-content> -->\n    <table class=\"customTable\">\n      <tr>\n        <td class=\"right\">User Name <span class=\"redColor\">*</span>: </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"text\" placeholder=\"Enter User Name\" matInput [(ngModel)]=\"username\"\n              required />\n          </mat-form-field>\n        </td>\n        <td class=\"right\">Email ID <span class=\"redColor\">*</span>: </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"text\" placeholder=\"Enter Email ID\" matInput [(ngModel)]=\"emailid\"\n              required />\n          </mat-form-field>\n        </td>\n      </tr>\n      <tr>\n        <td class=\"right\">Role <span class=\"redColor\">*</span>: </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <mat-label></mat-label>\n            <mat-select [(ngModel)]=\"role\">\n              <mat-option *ngFor=\"let roletype of rolesList\" [value]=\"roletype.value\">\n                {{roletype.name}}\n              </mat-option>\n            </mat-select>\n          </mat-form-field>\n        </td>\n        <td class=\"right\">Applications : </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <mat-label></mat-label>\n            <mat-select [(ngModel)]=\"apps\" [ngModelOptions]=\"{standalone: true}\" (selectionChange)=\"onChangeApps()\"\n              multiple>\n              <mat-option *ngFor=\"let app of applications\" [value]=\"app\">{{app.applicationName}}</mat-option>\n            </mat-select>\n          </mat-form-field>\n        </td>\n      </tr>\n      <tr *ngIf=\"apps.length>0\">\n        <td colspan=\"4\">\n          <table class=\"table table-hover customTable\">\n            <thead>\n              <tr>\n                <th class=\"right\">Application Name</th>\n                <th class=\"left\">Access Level</th>\n              </tr>\n            </thead>\n            <tbody>\n              <tr *ngFor=\"let appACL of appsACL; let index\">\n                <td class=\"right\">\n                  <span>{{appACL.applicationName}}</span>\n                </td>\n                <td class=\"left\">\n                  <span>\n                    <mat-form-field>\n                      <mat-label>Access Level</mat-label>\n                      <mat-select [(ngModel)]=\"appACL.accesslevel\">\n                        <mat-option *ngFor=\"let ACL of ACLs\" [value]=\"ACL.value\">\n                          {{ACL.name}}\n                        </mat-option>\n                      </mat-select>\n                    </mat-form-field>\n                  </span>\n                </td>\n              </tr>\n            </tbody>\n          </table>\n        </td>\n      </tr>\n      <tr>\n        <td colspan=\"4\" align=\"center\">\n          <!-- <button mat-button type=\"submit\" (click)=\"onSubmit()\" matTooltip=\"Save\" cdkFocusInitial>Save</button> -->\n          <button mat-button mat-dialog-close matTooltip=\"Cancel\">Cancel</button>\n          <button mat-button [mat-dialog-close]=\"true\" type=\"submit\" (click)=\"onSubmit()\" matTooltip=\"Save\" [disabled]=\"isNotValid()\"\n            *ngIf=\"dialogdata.value\">\n            <span>Save</span>\n          </button>\n          <button mat-button [mat-dialog-close]=\"true\" type=\"submit\" (click)=\"onSubmit()\" matTooltip=\"Update\" [disabled]=\"isNotValid()\"\n            *ngIf=\"!dialogdata.value\">\n            <span>Update</span>\n          </button>\n        </td>\n      </tr>\n    </table>\n  </div>\n</mat-dialog-content>"

/***/ }),

/***/ "./src/app/pages/administrator/userform/userform.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pages/administrator/userform/userform.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* table {\r\n    width: 100%;\r\n} */\n/* td{\r\n    padding: 15px;\r\n    width:50%\r\n} */\n.left {\n  text-align: left; }\n.right {\n  text-align: right; }\n.center {\n  text-align: center; }\ntable,\ntd {\n  border: 0px solid black; }\n.fRight {\n  float: right; }\n.redColor {\n  color: red; }\n.customTable {\n  height: 100%;\n  width: 100%; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci91c2VyZm9ybS9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxhZG1pbmlzdHJhdG9yXFx1c2VyZm9ybVxcdXNlcmZvcm0uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2FkbWluaXN0cmF0b3IvdXNlcmZvcm0vdXNlcmZvcm0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0dDRUc7QURDSDs7O0dDR0c7QURDSDtFQUNJLGdCQUFnQixFQUFBO0FBR3BCO0VBQ0ksaUJBQWlCLEVBQUE7QUFFckI7RUFDSSxrQkFBa0IsRUFBQTtBQUV0Qjs7RUFFSSx1QkFBdUIsRUFBQTtBQUUzQjtFQUNJLFlBQVksRUFBQTtBQUdoQjtFQUNJLFVBQVUsRUFBQTtBQUdkO0VBQ0ksWUFBWTtFQUNaLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluaXN0cmF0b3IvdXNlcmZvcm0vdXNlcmZvcm0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiB0YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufSAqL1xyXG4vKiB0ZHtcclxuICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICB3aWR0aDo1MCVcclxufSAqL1xyXG4ubGVmdCB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG4ucmlnaHQge1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuLmNlbnRlciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxudGFibGUsXHJcbnRkIHtcclxuICAgIGJvcmRlcjogMHB4IHNvbGlkIGJsYWNrO1xyXG59XHJcbi5mUmlnaHQge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcblxyXG4ucmVkQ29sb3Ige1xyXG4gICAgY29sb3I6IHJlZDtcclxufVxyXG5cclxuLmN1c3RvbVRhYmxlIHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcbiIsIi8qIHRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59ICovXG4vKiB0ZHtcclxuICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICB3aWR0aDo1MCVcclxufSAqL1xuLmxlZnQge1xuICB0ZXh0LWFsaWduOiBsZWZ0OyB9XG5cbi5yaWdodCB7XG4gIHRleHQtYWxpZ246IHJpZ2h0OyB9XG5cbi5jZW50ZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7IH1cblxudGFibGUsXG50ZCB7XG4gIGJvcmRlcjogMHB4IHNvbGlkIGJsYWNrOyB9XG5cbi5mUmlnaHQge1xuICBmbG9hdDogcmlnaHQ7IH1cblxuLnJlZENvbG9yIHtcbiAgY29sb3I6IHJlZDsgfVxuXG4uY3VzdG9tVGFibGUge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlOyB9XG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/administrator/userform/userform.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/administrator/userform/userform.component.ts ***!
  \********************************************************************/
/*! exports provided: UserFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserFormComponent", function() { return UserFormComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};





var UserFormComponent = /** @class */ (function () {
    function UserFormComponent(dialogRef, data, el, cdRef, dialogdata, router, accessChecker) {
        var _this = this;
        this.dialogRef = dialogRef;
        this.data = data;
        this.el = el;
        this.cdRef = cdRef;
        this.dialogdata = dialogdata;
        this.router = router;
        this.accessChecker = accessChecker;
        this.username = "";
        this.emailid = "";
        this.checkrows = false;
        this.checkPassword = true;
        this.applications = [];
        this.ACLs = [
            { name: "Read-Only", value: 0 },
            { name: "Edit", value: 1 },
            { name: "Full Access", value: 2 }
        ];
        this.rolesList = [
            { name: "Standard", value: "user" },
            { name: "Administrator", value: "admin" }
        ];
        this.role = "user";
        this.apps = [];
        this.appsACL = [];
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (!res) {
                accessChecker.isGranted('view', 'admin').take(1).subscribe(function (res1) {
                    if ((!res) && (!res1)) {
                        _this.router.navigate(['/']);
                    }
                });
            }
        });
        //this.createForm();
        // console.log(this.dialogdata.customerId);
        // console.log(this.checkPassword);
        cdRef.markForCheck();
        this.data.getCustomerDetailsAdmin(this.dialogdata.customerId).take(1).subscribe(function (data) {
            var customer = data;
            //console.log(data);
            _this.applications = JSON.parse(JSON.stringify(customer[0].application));
            _this.cdRef.markForCheck();
            // console.log(this.applications);
            //this.getApps(this.dialogdata.customerId);
            if (!_this.dialogdata.value) {
                /* this.formGroup.get('username').setValue(this.dialogdata.user.userName);
                this.formGroup.get('emailid').setValue(this.dialogdata.user.emailId); */
                // console.log(this.dialogdata.user);
                _this.username = _this.dialogdata.user.userName;
                _this.emailid = _this.dialogdata.user.emailId;
                _this.role = _this.dialogdata.user.role;
                if (_this.dialogdata.user.hasOwnProperty('apps')) {
                    _this.dialogdata.user.apps.forEach(function (selectedApp, index) {
                        _this.applications.forEach(function (app, index) {
                            if (selectedApp.appid == app.appid) {
                                _this.apps.push(app);
                            }
                        });
                    });
                }
                //this.apps = JSON.parse(JSON.stringify(this.dialogdata.user.apps)) ;
                if (_this.dialogdata.user.hasOwnProperty('appsACL')) {
                    _this.appsACL = _this.dialogdata.user.appsACL;
                }
                _this.cdRef.markForCheck();
            }
        });
    }
    UserFormComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    UserFormComponent.prototype.onSubmit = function () {
        var _this = this;
        var sampleobj = {
            "userName": this.username,
            "emailId": this.emailid,
            "role": this.role,
            "apps": this.apps,
            "appsACL": this.appsACL,
        };
        // console.log(sampleobj);
        if (this.dialogdata.value) {
            this.data.addNewUser(sampleobj, this.dialogdata.customerId).take(1).subscribe(function (data) {
                // console.log(data);
                _this.onNoClick();
            });
        }
        else {
            this.data.updateUserAdmin(sampleobj, this.dialogdata.customerId, this.dialogdata.userId).take(1).subscribe(function (data) {
                // console.log(data);
                _this.onNoClick();
            });
        }
    };
    UserFormComponent.prototype.getApps = function (customerId) {
        var _this = this;
        this.data.getCustomerDetailsAdmin(customerId).take(1).subscribe(function (data) {
            var customer = data;
            //console.log(data);
            _this.applications = customer[0].application;
            _this.cdRef.markForCheck();
        });
    };
    UserFormComponent.prototype.onChangeApps = function () {
        var _this = this;
        // console.log(this.apps);
        var appsACL_copy = JSON.parse(JSON.stringify(this.appsACL));
        this.appsACL = [];
        this.apps.forEach(function (app, index) {
            var accesslevel = 0;
            appsACL_copy.forEach(function (app_copy) {
                if (app_copy.appid == app.appid) {
                    accesslevel = app_copy.accesslevel;
                }
            });
            _this.appsACL.push({ appid: app.appid, applicationName: app.applicationName, accesslevel: accesslevel });
        });
        this.cdRef.markForCheck();
    };
    UserFormComponent.prototype.isNotValid = function () {
        var flag = false;
        /* let sampleobj = {
          "userName": this.username,
          "emailId": this.emailid,
          "role": this.role,
          "apps": this.apps,
          "appsACL": this.appsACL,
        } */
        if ((this.username.trim() == "") || (this.username == null) || (this.emailid.trim() == "") || (this.emailid == null)) {
            flag = true;
        }
        return flag;
    };
    UserFormComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'userform',
            template: __webpack_require__(/*! ./userform.component.html */ "./src/app/pages/administrator/userform/userform.component.html"),
            styles: [__webpack_require__(/*! ./userform.component.scss */ "./src/app/pages/administrator/userform/userform.component.scss")]
        }),
        __param(4, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"],
            _data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"], Object, _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_4__["NbAccessChecker"]])
    ], UserFormComponent);
    return UserFormComponent;
}());



/***/ }),

/***/ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/administrator/userpasswordform/userpasswordform.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div mat-dialog-title >\n  <h2> User Details </h2>\n</div>\n<form [formGroup]=\"formGroup\" class=\"form\" style=\"text-align:center\" encrypt=\"multipart/form-data\">\n\n  <div mat-dialog-content >\n    <table>\n  <tr>\n        <td class=\"right\">Password : </td>\n        <td class=\"left\">\n          <mat-form-field>\n            <input autocomplete=\"off\" type=\"password\" placeholder=\"Enter Password\" matInput  formControlName=\"password\" required />\n          </mat-form-field>\n        </td>\n      </tr>\n\n      <tr>\n        <td colspan=\"2\" align=\"center\">\n\n          <button mat-button type=\"submit\" [disabled]=\"!formGroup.valid\" (click)=\"onSubmit(formGroup.value)\"  cdkFocusInitial>Save</button>\n\n        </td>\n      </tr>\n    </table>\n  </div>\n</form>\n\n\n<!--<div *ngIf=\"!checkPassword\">\n  </div>-->\n\n\n  <!-- [mat-dialog-close]=\"formGroup.password\" -->"

/***/ }),

/***/ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/administrator/userpasswordform/userpasswordform.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  width: 90%; }\n\ntd {\n  padding: 15px;\n  width: 50%; }\n\n.left {\n  text-align: left; }\n\n.right {\n  text-align: right; }\n\n.center {\n  text-align: center; }\n\ntable, td {\n  border: 0px solid black; }\n\nspan.right {\n  float: right; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci91c2VycGFzc3dvcmRmb3JtL0M6XFxQZXJmQXNzdXJlXFxHaXRMYWJcXFBlcmZBc3N1cmVfQW5ndWxhci9zcmNcXGFwcFxccGFnZXNcXGFkbWluaXN0cmF0b3JcXHVzZXJwYXNzd29yZGZvcm1cXHVzZXJwYXNzd29yZGZvcm0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFQyxVQUFVLEVBQUE7O0FBRVg7RUFDSSxhQUFhO0VBQ2IsVUFDSixFQUFBOztBQUNBO0VBRUMsZ0JBQWdCLEVBQUE7O0FBR2pCO0VBQ0EsaUJBQWdCLEVBQUE7O0FBRWhCO0VBRUEsa0JBQWlCLEVBQUE7O0FBRWpCO0VBQ0ksdUJBQXVCLEVBQUE7O0FBRTFCO0VBRUQsWUFBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWRtaW5pc3RyYXRvci91c2VycGFzc3dvcmRmb3JtL3VzZXJwYXNzd29yZGZvcm0uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ0YWJsZXtcclxuXHJcbiB3aWR0aDogOTAlO1xyXG59XHJcbnRke1xyXG4gICAgcGFkZGluZzogMTVweDtcclxuICAgIHdpZHRoOjUwJVxyXG59XHJcbi5sZWZ0XHJcbntcclxuIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuXHJcbi5yaWdodHtcclxudGV4dC1hbGlnbjpyaWdodDtcclxufVxyXG4uY2VudGVyXHJcbntcclxudGV4dC1hbGlnbjpjZW50ZXI7XHJcbn1cclxudGFibGUsdGQge1xyXG4gICAgYm9yZGVyOiAwcHggc29saWQgYmxhY2s7XHJcbn1cclxuIHNwYW4ucmlnaHQge1xyXG5cclxuZmxvYXQ6cmlnaHQ7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/pages/administrator/userpasswordform/userpasswordform.component.ts ***!
  \************************************************************************************/
/*! exports provided: UserpasswordformComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserpasswordformComponent", function() { return UserpasswordformComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};






var UserpasswordformComponent = /** @class */ (function () {
    function UserpasswordformComponent(formBuilder, dialogRef, data, el, cdRef, dialogdata, router, accessChecker) {
        var _this = this;
        this.formBuilder = formBuilder;
        this.dialogRef = dialogRef;
        this.data = data;
        this.el = el;
        this.cdRef = cdRef;
        this.dialogdata = dialogdata;
        this.router = router;
        this.accessChecker = accessChecker;
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (!res) {
                accessChecker.isGranted('view', 'admin').take(1).subscribe(function (res1) {
                    if ((!res) && (!res1)) {
                        _this.router.navigate(['/']);
                    }
                });
            }
        });
        this.createForm();
    }
    UserpasswordformComponent.prototype.createForm = function () {
        this.formGroup = this.formBuilder.group({
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        });
    };
    UserpasswordformComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    UserpasswordformComponent.prototype.onSubmit = function (postData) {
        var _this = this;
        var sampleobj = {
            password: postData.password
        };
        this.data.updateUserPassword(sampleobj, this.dialogdata.userId).take(1).subscribe(function (data) {
            // console.log(data);
            _this.onNoClick();
        });
    };
    UserpasswordformComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'userpasswordform',
            template: __webpack_require__(/*! ./userpasswordform.component.html */ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.html"),
            styles: [__webpack_require__(/*! ./userpasswordform.component.scss */ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.scss")]
        }),
        __param(5, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_material__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"],
            _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"], Object, _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_5__["NbAccessChecker"]])
    ], UserpasswordformComponent);
    return UserpasswordformComponent;
}());



/***/ }),

/***/ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.html":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row justify-content-center\">\n  <div class=\"col-11\">\n    <h1 class=\"ctscolor\" mat-dialog-title>License Summary</h1>\n  </div>\n  <div class=\"col-1\">\n    <button id=\"closebutton\" mat-icon-button style=\"float:right\" type=\"button\" (click)=\"onNoClick()\">\n      <mat-icon aria-label=\"close\">close</mat-icon>\n    </button>\n  </div>\n</div>\n<div class=\"row\">\n  <div class=\"col-md-1\">\n  </div>\n  <div class=\"col-md-6\">\n    <button mat-icon-button type=\"button\">\n      <mat-icon color=\"primary\">search</mat-icon>\n    </button>\n    <mat-form-field>\n      <mat-label>Search</mat-label>\n      <input matInput (keyup)=\"applyFilter($event)\">\n    </mat-form-field>\n  </div>\n  <div class=\"col-md-5\">\n    <span *ngIf=\"role=='admin'\">\n      <form [formGroup]=\"formGroup\" class=\"form\" style=\"text-align:center\" encrypt=\"multipart/form-data\">\n        <!-- <input id=\"licenseFile\" type=\"file\" formControlName=\"scriptfilename\" required /> -->\n        <input id=\"licenseFile\" formControlName=\"scriptfilename\" autocomplete=\"off\" hidden type=\"file\" #licenseFileInput  (change)=\"onLicenseFileChange($event)\"\n          accept=\".server\" required />\n      </form>\n      <button mat-icon-button color=\"primary\" type=\"button\" matTooltip=\"Upload new license file\"\n        (click)=\"licenseFileInput.click()\">\n        <mat-icon>add</mat-icon>\n      </button>\n      <button mat-icon-button color=\"primary\" (click)=\"changeFileName()\" matTooltip=\"Click to save\">\n        <mat-icon aria-label=\"save\">save</mat-icon>\n      </button>\n      <span>{{licenseFileName}}</span>\n    </span>\n  </div>\n\n</div>\n\n<div class=\"col-md-12\">\n  <table class=\"table table-bordered table-hover\" matSort #matSort=\"matSort\" mat-table [dataSource]=\"dataSource\"\n    width=\"100%;\">\n    <div>\n      <ng-container matColumnDef=\"components\">\n        <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"12.5%;\">\n          <h6>Modules</h6>\n        </th>\n        <td mat-cell *matCellDef=\"let element\">\n          {{element.components}}\n        </td>\n      </ng-container>\n    </div>\n    <!--     <div>\n          <ng-container matColumnDef=\"model\">\n            <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"12.5%;\">\n              <h6>Model</h6>\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n              {{element.model}}\n            </td>\n          </ng-container>\n        </div> -->\n    <div>\n      <ng-container matColumnDef=\"licensepurchased\">\n        <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"12.5%;\">\n          <h6>License Pack </h6>\n        </th>\n        <td mat-cell *matCellDef=\"let element\"> {{element.licensepurchased}} </td>\n      </ng-container>\n    </div>\n    <div>\n      <ng-container matColumnDef=\"licenseavailable\">\n        <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"12.5%;\">\n          <h6>License Available</h6>\n        </th>\n        <td mat-cell *matCellDef=\"let element\"> {{element.licenseavailable}}\n        </td>\n      </ng-container>\n    </div>\n    <div>\n      <ng-container matColumnDef=\"dateofpurchase\">\n        <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"12.5%;\">\n          <h6> License Activation Date </h6>\n\n        </th>\n        <td mat-cell *matCellDef=\"let element\"> {{element.dateofpurchase}}\n        </td>\n      </ng-container>\n    </div>\n    <!--      <div>\n          <ng-container matColumnDef=\"tenure\">\n            <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"10%;\">\n              <h6>Tenure</h6>\n            </th>\n            <td mat-cell *matCellDef=\"let element\"> {{element.tenure}}\n            </td>\n          </ng-container>\n        </div> -->\n    <div>\n      <ng-container matColumnDef=\"expirydate\">\n        <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"12.5%;\">\n          <h6>License Expiry Date</h6>\n        </th>\n        <td mat-cell *matCellDef=\"let element\"> {{element.expirydate}}\n        </td>\n      </ng-container>\n    </div>\n    <div>\n      <ng-container matColumnDef=\"licensestatus\">\n        <th mat-header-cell class=\"headercell\" mat-sort-header *matHeaderCellDef width=\"15%;\">\n          <h6>License Status</h6>\n        </th>\n        <td title=\"Click here to view more\" mat-cell *matCellDef=\"let element\">\n          {{element.licensestatus}}\n        </td>\n      </ng-container>\n    </div>\n    <tr mat-header-row *matHeaderRowDef=\"purchasedlicensingtablearraycolumns\"></tr>\n    <tr mat-row *matRowDef=\"let row; columns: purchasedlicensingtablearraycolumns;\"></tr>\n  </table>\n  <mat-paginator #paginator [pageSizeOptions]=\"[5, 10, 25, 100]\"></mat-paginator>\n</div>"

/***/ }),

/***/ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.scss":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.scss ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h6 {\n  color: darkblue; }\n\n#closebutton {\n  outline: none; }\n\n.ctscolor {\n  text-align: center;\n  color: #0033a1;\n  font-weight: bold; }\n\n#licenseFile {\n  margin: 0 auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLWxpY2Vuc2luZy1wb3B1cC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxob21lXFxob21lLWxpY2Vuc2luZy1wb3B1cFxcaG9tZS1saWNlbnNpbmctcG9wdXAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxlQUNKLEVBQUE7O0FBQ0E7RUFDSSxhQUNKLEVBQUE7O0FBQ0E7RUFDSSxrQkFBaUI7RUFDcEIsY0FBYztFQUNYLGlCQUFpQixFQUFBOztBQUVyQjtFQUNJLGNBQWMsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS1saWNlbnNpbmctcG9wdXAvaG9tZS1saWNlbnNpbmctcG9wdXAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaDZ7XHJcbiAgICBjb2xvcjpkYXJrYmx1ZVxyXG59XHJcbiNjbG9zZWJ1dHRvbntcclxuICAgIG91dGxpbmU6bm9uZVxyXG59XHJcbi5jdHNjb2xvcntcclxuICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG5cdGNvbG9yOiAjMDAzM2ExO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuI2xpY2Vuc2VGaWxlIHtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.ts ***!
  \***********************************************************************************/
/*! exports provided: HomeLicensingPopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeLicensingPopupComponent", function() { return HomeLicensingPopupComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/paginator */ "./node_modules/@angular/material/esm5/paginator.es5.js");
/* harmony import */ var _angular_material_sort__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/sort */ "./node_modules/@angular/material/esm5/sort.es5.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _nebular_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @nebular/auth */ "./node_modules/@nebular/auth/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









var HomeLicensingPopupComponent = /** @class */ (function () {
    function HomeLicensingPopupComponent(dialogRef, el, formBuilder, toastr, globalData, changeDetectorRefs, authService) {
        var _this = this;
        this.dialogRef = dialogRef;
        this.el = el;
        this.formBuilder = formBuilder;
        this.toastr = toastr;
        this.globalData = globalData;
        this.changeDetectorRefs = changeDetectorRefs;
        this.authService = authService;
        this.purchasedlicensingtablearraycolumns = [
            'components',
            'licensepurchased',
            'licenseavailable',
            'dateofpurchase',
            'expirydate',
            'licensestatus'
        ];
        this.newlicensingtablearraycolumns = [
            'components',
            'model',
            'category',
            'tenure',
            'cost'
        ];
        this.role = 'user';
        this.licenseFileName = "";
        this.createForm();
        this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"]([]);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.toastr.toastrConfig.positionClass = 'toast-top-right';
        this.toastr.toastrConfig.timeOut = 3000;
        this.getLicenseData();
        this.authService.onTokenChange().subscribe(function (token) {
            if (token.isValid()) {
                // this.user = token.getPayload(); // here we receive a payload from the token and assigne it to our `user` variable 
                _this.user = token; // here we receive a payload from the token and assigne it to our `user` variable 
                //console.log('Token in header');
                //console.log('Token in header : ' + JSON.stringify(this.user));
                var payload = token.getPayload();
                //console.log('getPayload' + JSON.stringify(payload));
                _this.role = payload.role;
                _this.changeDetectorRefs.markForCheck();
            }
        });
    }
    HomeLicensingPopupComponent.prototype.getLicenseData = function () {
        var _this = this;
        this.globalData.getLicenseDetails().subscribe((function (responseData) {
            if (responseData.length > 0) {
                _this.dataSource = new _angular_material_table__WEBPACK_IMPORTED_MODULE_3__["MatTableDataSource"](responseData);
                _this.dataSource.paginator = _this.paginator;
                _this.dataSource.sort = _this.sort;
                _this.changeDetectorRefs.markForCheck();
            }
        }), function (error) {
            console.log(" errors :  ");
            console.log(error);
            if (error = "License File is not active") {
                alert(error);
            }
            else {
                _this.toastr.error(error);
            }
            _this.changeDetectorRefs.markForCheck();
        });
    };
    HomeLicensingPopupComponent.prototype.createForm = function () {
        this.formGroup = this.formBuilder.group({
            scriptfilename: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]("", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required])
        });
    };
    HomeLicensingPopupComponent.prototype.ngOnInit = function () {
        // this.purchasedlicensingtablearray.sort(this.sorter)
        // console.log(this.purchasedlicensingtablearray)
        // this.newlicensingtablearray.sort(this.sorter)
        // this.dataSource = new MatTableDataSource(this.purchasedlicensingtablearray);
        // this.dataSource.paginator = this.paginator;
        // this.dataSource.sort = this.sort;
        // this.defaultddlvalue = "All";
    };
    HomeLicensingPopupComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    HomeLicensingPopupComponent.prototype.applyFilter = function (event) {
        //console.log(this.defaultddlvalue)
        /*if (this.defaultddlvalue == "All") {
          const filterValue = (event.target as HTMLInputElement).value;
          this.dataSource.filter = filterValue.trim().toLowerCase();
          if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
          }
        }
        */
        //let filterValue1 =this.defaultddlvalue;
        var filterValue = event.target.value;
        // this.dataSource.filter = filterValue1.trim().toLowerCase();
        this.dataSource.filter = filterValue.trim().toLowerCase();
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    };
    // popuptabschanged(indexNumber) {
    //   setTimeout(() => {
    //     switch (indexNumber) {
    //       case 0:
    //         this.dataSource = new MatTableDataSource(this.purchasedlicensingtablearray);
    //         this.dataSource.paginator = this.paginator;
    //         this.dataSource.sort = this.sort;
    //         !this.dataSource.paginator ? this.dataSource.paginator = this.paginator : null;
    //         break;
    //       case 1:
    //         this.dataSource = new MatTableDataSource(this.newlicensingtablearray);
    //         this.dataSource.paginator = this.paginator2;
    //         this.dataSource.sort = this.sort2;
    //         !this.dataSource.paginator ? this.dataSource.paginator = this.paginator2 : null;
    //     }
    //   });
    // }
    HomeLicensingPopupComponent.prototype.onLicenseFileChange = function (event) {
        this.licenseFileName = "";
        if (event.target.files && event.target.files[0]) {
            var fileList = event.target.files;
            var file_1 = fileList[0];
            var fileReader = new FileReader();
            var self_1 = this;
            fileReader.onloadend = function (x) {
                // self.jmxFileContent = fileReader.result;
                var fname = file_1.name;
                self_1.licenseFileName = fname;
            };
            //this.showToast('info', 'Reading', file.name);
            //fileReader.readAsText(file);
            fileReader.readAsText(file_1, 'UTF-8');
        }
    };
    HomeLicensingPopupComponent.prototype.changeFileName = function () {
        var _this = this;
        this.licenseFileName = "";
        var inputEl = this.el.nativeElement.querySelector('#licenseFile');
        var fileCount = inputEl.files.length;
        var formData = new FormData();
        if (fileCount > 0) {
            //append the key name 'photo' with the first file in the element
            formData.append('licenseFile', inputEl.files.item(0));
            console.log(inputEl.files.item(0));
            this.licenseFileName = inputEl.files.item(0).name;
            this.changeDetectorRefs.markForCheck();
            this.globalData.UploadLicenseFile(formData).subscribe((function (responseData) {
                var message = responseData.toString();
                if (message == "Uploaded License File is already used") {
                    alert(message);
                }
                else {
                    _this.toastr.success(message);
                }
                _this.getLicenseData();
                _this.changeDetectorRefs.markForCheck();
                //Update the UI with new status
            }), function (error) {
                console.log(" errors :  ");
                console.log(error);
                alert(error);
                _this.changeDetectorRefs.markForCheck();
            });
        }
    };
    HomeLicensingPopupComponent.prototype.sorter = function (a, b) {
        // Use toUpperCase() to ignore character casing
        var t1 = a.components.toUpperCase();
        var t2 = b.components.toUpperCase();
        var comparison = 0;
        if (t1 > t2) {
            comparison = 1;
        }
        else if (t1 < t2) {
            comparison = -1;
        }
        return comparison;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('paginator'),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_1__["MatPaginator"])
    ], HomeLicensingPopupComponent.prototype, "paginator", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('paginator2'),
        __metadata("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_1__["MatPaginator"])
    ], HomeLicensingPopupComponent.prototype, "paginator2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('matSort'),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_2__["MatSort"])
    ], HomeLicensingPopupComponent.prototype, "sort", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('matSort2'),
        __metadata("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_2__["MatSort"])
    ], HomeLicensingPopupComponent.prototype, "sort2", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('licenseFileInput'),
        __metadata("design:type", Object)
    ], HomeLicensingPopupComponent.prototype, "licenseFileInput", void 0);
    HomeLicensingPopupComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'home-licensing-popup',
            template: __webpack_require__(/*! ./home-licensing-popup.component.html */ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.html"),
            styles: [__webpack_require__(/*! ./home-licensing-popup.component.scss */ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_4__["MatDialogRef"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_7__["ToastrService"],
            _data_service__WEBPACK_IMPORTED_MODULE_6__["DataService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"],
            _nebular_auth__WEBPACK_IMPORTED_MODULE_8__["NbAuthService"]])
    ], HomeLicensingPopupComponent);
    return HomeLicensingPopupComponent;
}());

// purchasedlicensingtablearray = [
//   {
//     components: 'UXPerf-Web',
//     model: 'Transactional',
//     licensepurchased: '100 Reports',
//     licenseavailable: '50 Reports',
//     dateofpurchase: 'Jan 1st 2020',
//     tenure: '12 Months',
//     expirydate: 'Dec 31st 2020',
//     licensestatus: 'Active'
//   },
//   {
//     components: 'UXPerf-Web',
//     model: 'Transactional',
//     licensepurchased: '150 Reports',
//     licenseavailable: '0 Reports',
//     dateofpurchase: 'Jan 1st 2020',
//     tenure: '12 Months',
//     expirydate: 'Dec 31st 2020',
//     licensestatus: 'Inactive-Renew'
//   },
//   {
//     components: 'Load Testing',
//     model: 'Transactional',
//     licensepurchased: '50K VUH',
//     licenseavailable: '30K VUH',
//     dateofpurchase: 'Jan 1st 2020',
//     tenure: '12 Months',
//     expirydate: 'Dec 31st 2020',
//     licensestatus: 'Active-Running low-Renew'
//   },
//   {
//     components: 'Synthetic Monitoring',
//     model: 'Transactional',
//     licensepurchased: '100K Measurements',
//     licenseavailable: '50K Measurements',
//     dateofpurchase: 'Jan 1st 2020',
//     tenure: '12 Months',
//     expirydate: 'Dec 31st 2020',
//     licensestatus: 'Active'
//   }
// ]
// newlicensingtablearray = [
//   {
//     components: 'UXPerf-Web',
//     model: 'Transactional',
//     category: 'Upto 100 Reports',
//     tenure: '12 Months',
//     cost: '5000 USD',
//   },
//   {
//     components: 'UXPerf-Web',
//     model: 'Transactional',
//     category: '100-250',
//     tenure: '12 Months',
//     cost: '2500 USD',
//   },
//   {
//     components: 'UXPerf-Web',
//     model: 'Transactional',
//     category: '250-500',
//     tenure: '12 Months',
//     cost: '2000 USD',
//   }
//   ,
//   {
//     components: 'UXPerf-Web',
//     model: 'Transactional',
//     category: 'Unlimited',
//     tenure: '12 Months',
//     cost: '10000 USD',
//   }
// ]
/*
dropdownchange(ddlvalue) {
  this.defaultddlvalue = ddlvalue
  if (this.defaultddlvalue == "All") {
    this.dataSource=new MatTableDataSource(this.purchasedlicensingtablearray);
  }
  else{
  const filterValue = ddlvalue;
  this.dataSource.filter = filterValue.trim().toLowerCase();
  
  //this.dataSource=new MatTableDataSource(this.purchasedlicensingtablearray);
  if (this.dataSource.paginator) {
    this.dataSource.paginator.firstPage();
  }
}
}
*/


/***/ }),

/***/ "./src/app/pages/home/home.component.html":
/*!************************************************!*\
  !*** ./src/app/pages/home/home.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nb-card>\r\n  <nb-card-body>\r\n    <!--  <div class=\"row justify-content-center\">\r\n        <h2>Dashboard - Key Metrics</h2>\r\n      </div>\r\n      <div class=\"row justify-content-center\">\r\n        <div class=\"col-md-9\">\r\n  \r\n        </div>\r\n        <div class=\"col-md-3\">\r\n          <mat-form-field class=\"example-full-width\">\r\n            <mat-select placeholder=\"Select time range\"  ([ngModel])=\"timerange\" (selectionChange)=\"changetimerange($event)\"\r\n              >\r\n              <mat-option [value]=\" timeRange.label\" *ngFor=\"let timeRange of timeRangeOptions\">\r\n                {{ timeRange.label }}\r\n              </mat-option>\r\n            </mat-select>\r\n          </mat-form-field>\r\n        </div>\r\n      </div>\r\n      <div  class=\"row \">\r\n        <div class=\"col-5\">\r\n          <ngx-charts-advanced-pie-chart [view]=\"piechartview\" [scheme]=\"piechartcolorScheme\"\r\n            label=\"Total number of Tests\" [results]=\"piechartresults\" (select)=\"onSelect($event)\">\r\n          </ngx-charts-advanced-pie-chart>\r\n        </div>\r\n        <div class=\"col-7\">\r\n          <br>\r\n          <br>\r\n          <ngx-charts-number-card [view]=\"cardchartview\" [scheme]=\"cardchartcolorScheme\" [results]=\"cardchart\"\r\n            [cardColor]=\"cardchartColor\" (select)=\"onSelect($event)\">\r\n          </ngx-charts-number-card>\r\n        </div>\r\n      </div>\r\n      <br>\r\n      <br>\r\n      <div class=\"row justify-content-center\">\r\n        <h5>Performance under Load</h5>\r\n      </div>\r\n      <div class=\"row justify-content-center\">\r\n      <ngx-charts-bar-horizontal-2d [view]=\"horizontalchartview\" [scheme]=\"horizontalchartviewcolorScheme\"\r\n          [schemeType]=\"horizontalchartviewschemeType\" [results]=\"horizontalchartresults\" schemeType='linear'\r\n          gradient=\"false\" xAxis=\"true\" yAxis=\"true\" [legendTitle]=\"false\" legend=\"true\">\r\n        </ngx-charts-bar-horizontal-2d>\r\n      </div>\r\n      <br>\r\n      <br>\r\n      <div class=\"row justify-content-center\">\r\n        <h5>Single User Performance</h5>\r\n      </div>\r\n      <div class=\"row justify-content-center\">\r\n        <br>\r\n        <br>\r\n        <ngx-charts-bar-vertical-2d [barPadding]=\"barpadding2\" [legendTitle]=\"false\" [view]=\"verticalchartview\"\r\n          [scheme]=\"verticalchartviewcolorScheme\" legendPosition=\"below\" [results]=\"verticalbarchartresults\"\r\n          gradient=\"false\" xAxis=\"true\" yAxis=\"true\" legend=\"true\">\r\n        </ngx-charts-bar-vertical-2d>\r\n      </div>\r\n      <br>\r\n      <br>\r\n      <div class=\"row justify-content-center\">\r\n        <h5>Mobile App Performance</h5>\r\n      </div>\r\n      <div class=\"row justify-content-center\">\r\n        <ngx-charts-bar-vertical-2d [barPadding]=\"barpadding\" [legendTitle]=\"false\" [view]=\"verticalchartview2\"\r\n          [scheme]=\"verticalchartviewcolorScheme\" legend=\"true\" [results]=\"verticalbarchartresults2\" gradient=\"false\"\r\n          xAxis=\"true\" yAxis=\"true\">\r\n        </ngx-charts-bar-vertical-2d>\r\n      </div> -->\r\n    <!-- <div class=\"row justify-content-center\">\r\n      <img src=\"assets\\images\\overview.jpeg\" />\r\n    </div> -->\r\n\r\n    <div class=\"row\">\r\n      <div class=\"col-md-12\">\r\n        <button (click)=\"openlicensedialog()\" mat-icon-button color=\"primary\" matTooltip=\"Licensing Summary\"\r\n          class=\"fRight\">\r\n          <!--  [disabled]=\"(accesslevel<1)\"> -->\r\n          <mat-icon>vpn_key</mat-icon>\r\n        </button>\r\n      </div>\r\n    </div>\r\n    <div class=\"row alignCenter\">\r\n      <div class=\"col-md-12\">\r\n        <!-- <h1 class=\"ctscolor\">The End To End Non-Functional Testing Platform</h1> -->\r\n        <h1 class=\"ctscolor\">Accelerate Your Non-Fuctional Test Cycles</h1>\r\n      </div>\r\n    </div>\r\n    <div class=\"row alignCenter\">\r\n      <div class=\"col-md-12\">\r\n        <!-- <span class=\"fs20px boldColor\">NFT Assure </span><span class=\"fs16px\">Product Suite caters to the end to end\r\n          needs of performance test design , execution & analysis ​</span> -->\r\n        <span class=\"fs16px\"> with an intelligent and integrated</span><span\r\n          class=\"fs20px boldColor\"> NFT Assure Platform</span><br /><br />\r\n      </div>\r\n    </div>\r\n    <div class=\"row\">\r\n      <div class=\"col-md-4\">\r\n        <div class=\"row alignCenter\">\r\n          <div class=\"col-md-12\">\r\n            <img class=\"logosize\" src=\"assets\\images\\ux_logo.png\" matTooltip=\"Ux Profiler\" matTooltipPosition=\"right\" /><br /><br />\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"col-md-12 fs16px\">\r\n            <p>Gain Key Insights into the performance parameters that impacts the User Experience for both web and\r\n              mobile.\r\n              Intuitive UI to design & execute the tests or reuse existing automation scripts.​</p>\r\n            <!-- ​<span>To Know More <a class=\"ctscolor\" href=\"#/\">Click Here​</a></span><br /><br /> -->\r\n            ​<span>To Design & Execute <a class=\"ctscolor\" routerLink=\"/pages/uxweb/scriptpage\">Click Here​</a></span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-md-4\">\r\n        <div class=\"row alignCenter\">\r\n          <div class=\"col-md-12\">\r\n            <img class=\"logosize\" src=\"assets\\images\\load_testing.png\" matTooltip=\"Load Simulator\" matTooltipPosition=\"right\" /><br /><br />\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"col-md-12 fs16px\">\r\n            <p>Intelligent, on demand, load testing platform that can execute tests in scale using power of cloud.\r\n              Experience the power of AI for result analysis and to provide human readable observations.</p>\r\n            <!-- ​<span>To Know More <a class=\"ctscolor\" href=\"#/\">Click Here​</a></span><br /><br /> -->\r\n            ​<span>To Design & Execute <a class=\"ctscolor\" routerLink=\"/pages/load/testscenarioslist\">Click\r\n                Here​</a></span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-md-4\">\r\n        <div class=\"row alignCenter\">\r\n          <div class=\"col-md-12\">\r\n            <img class=\"logosize\" src=\"assets\\images\\monitoring.png\" matTooltip=\"Active Monitor\" matTooltipPosition=\"right\" /><br /><br />\r\n          </div>\r\n        </div>\r\n        <div class=\"row\">\r\n          <div class=\"col-md-12 fs16px\">\r\n            <p>Automated solution that monitors end user experience 24x7 from across geographical locations and compares\r\n              performance variance.</p>\r\n            <!-- ​<span>To Know More <a class=\"ctscolor\" href=\"#/\">Click Here​</a></span><br /><br /> -->\r\n            ​<span>To Design & Execute <a class=\"ctscolor\" routerLink=\"/pages/amon/scriptpage\">Click Here​</a></span>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </nb-card-body>\r\n</nb-card>"

/***/ }),

/***/ "./src/app/pages/home/home.component.scss":
/*!************************************************!*\
  !*** ./src/app/pages/home/home.component.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* h2{\r\n    color: green;\r\n}\r\nh5{\r\n    color: green;\r\n} */\n.ctscolor {\n  color: #0033a1; }\n.alignCenter {\n  text-align: center; }\n.fs28px {\n  font-size: 28px; }\n.fs24px {\n  font-size: 24px; }\n.fs20px {\n  font-size: 20px; }\n.fs16px {\n  font-size: 16px; }\n.boldColor {\n  font-weight: bold; }\n.logosize {\n  width: 150px !important;\n  height: 150px !important; }\na:active,\na:link,\na:visited,\na:hover {\n  color: #0033a1; }\n.fRight {\n  float: right; }\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar {\n  width: 10px !important;\n  height: 5px; }\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar-thumb {\n  background: #a8a6a6 !important;\n  cursor: pointer;\n  border-radius: 5px !important; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvc3JjXFxhcHBcXHBhZ2VzXFxob21lXFxob21lLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0dDS0c7QURFSDtFQUNJLGNBQWMsRUFBQTtBQUdsQjtFQUNJLGtCQUFrQixFQUFBO0FBR3RCO0VBQ0ksZUFBZSxFQUFBO0FBRW5CO0VBQ0ksZUFBZSxFQUFBO0FBRW5CO0VBQ0ksZUFBZSxFQUFBO0FBRW5CO0VBQ0ksZUFBZSxFQUFBO0FBR25CO0VBQ0ksaUJBQWlCLEVBQUE7QUFHckI7RUFDSSx1QkFBdUI7RUFDdkIsd0JBQXdCLEVBQUE7QUFHNUI7Ozs7RUFJSSxjQUFjLEVBQUE7QUFHbEI7RUFDSSxZQUFZLEVBQUE7QUFJaEI7RUFDSSxzQkFBc0I7RUFDdEIsV0FBVyxFQUFBO0FBR2I7RUFDRSw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmLDZCQUE2QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogaDJ7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn1cclxuaDV7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn0gKi9cclxuXHJcbi5jdHNjb2xvciB7XHJcbiAgICBjb2xvcjogIzAwMzNhMTtcclxufVxyXG5cclxuLmFsaWduQ2VudGVyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmZzMjhweCB7XHJcbiAgICBmb250LXNpemU6IDI4cHg7XHJcbn1cclxuLmZzMjRweCB7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbn1cclxuLmZzMjBweCB7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuLmZzMTZweCB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbi5ib2xkQ29sb3Ige1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5sb2dvc2l6ZSB7XHJcbiAgICB3aWR0aDogMTUwcHggIWltcG9ydGFudDtcclxuICAgIGhlaWdodDogMTUwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuYTphY3RpdmUsXHJcbmE6bGluayxcclxuYTp2aXNpdGVkLFxyXG5hOmhvdmVyIHtcclxuICAgIGNvbG9yOiAjMDAzM2ExO1xyXG59XHJcblxyXG4uZlJpZ2h0IHtcclxuICAgIGZsb2F0OiByaWdodDtcclxufVxyXG5cclxuXHJcbi9kZWVwLyAubmItdGhlbWUtZGVmYXVsdCBuYi1sYXlvdXQgOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICB3aWR0aDogMTBweCAhaW1wb3J0YW50Oy8vNXB4O1xyXG4gICAgaGVpZ2h0OiA1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC9kZWVwLyAubmItdGhlbWUtZGVmYXVsdCBuYi1sYXlvdXQgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjYThhNmE2ICFpbXBvcnRhbnQ7Ly8jZGFkYWRhO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4ICFpbXBvcnRhbnQ7Ly8yLjVweDtcclxuICB9XHJcbiAgIiwiLyogaDJ7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn1cclxuaDV7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn0gKi9cbi5jdHNjb2xvciB7XG4gIGNvbG9yOiAjMDAzM2ExOyB9XG5cbi5hbGlnbkNlbnRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjsgfVxuXG4uZnMyOHB4IHtcbiAgZm9udC1zaXplOiAyOHB4OyB9XG5cbi5mczI0cHgge1xuICBmb250LXNpemU6IDI0cHg7IH1cblxuLmZzMjBweCB7XG4gIGZvbnQtc2l6ZTogMjBweDsgfVxuXG4uZnMxNnB4IHtcbiAgZm9udC1zaXplOiAxNnB4OyB9XG5cbi5ib2xkQ29sb3Ige1xuICBmb250LXdlaWdodDogYm9sZDsgfVxuXG4ubG9nb3NpemUge1xuICB3aWR0aDogMTUwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiAxNTBweCAhaW1wb3J0YW50OyB9XG5cbmE6YWN0aXZlLFxuYTpsaW5rLFxuYTp2aXNpdGVkLFxuYTpob3ZlciB7XG4gIGNvbG9yOiAjMDAzM2ExOyB9XG5cbi5mUmlnaHQge1xuICBmbG9hdDogcmlnaHQ7IH1cblxuL2RlZXAvIC5uYi10aGVtZS1kZWZhdWx0IG5iLWxheW91dCA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgd2lkdGg6IDEwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA1cHg7IH1cblxuL2RlZXAvIC5uYi10aGVtZS1kZWZhdWx0IG5iLWxheW91dCA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcbiAgYmFja2dyb3VuZDogI2E4YTZhNiAhaW1wb3J0YW50O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweCAhaW1wb3J0YW50OyB9XG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/home/home.component.ts":
/*!**********************************************!*\
  !*** ./src/app/pages/home/home.component.ts ***!
  \**********************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
/* harmony import */ var _home_licensing_popup_home_licensing_popup_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home-licensing-popup/home-licensing-popup.component */ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.ts");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var HomeComponent = /** @class */ (function () {
    function HomeComponent(router, accessChecker, data, cdRef, sidebarService, dialog) {
        var _this = this;
        this.router = router;
        this.accessChecker = accessChecker;
        this.data = data;
        this.cdRef = cdRef;
        this.sidebarService = sidebarService;
        this.dialog = dialog;
        this.piechartcolorScheme = {
            domain: ['skyblue', 'purple', 'yellow', 'orange']
        };
        this.barpadding = 25;
        this.barpadding2 = 40;
        this.timerange = "Last 1 week";
        this.timeRangeOptions = [
            { value: 'Last1Hour', label: 'Last 1 week', startTimeString: "now-1h", endTimeString: "now" },
            { value: 'Last4Hours', label: 'Last 1 month', startTimeString: "now-4h", endTimeString: "now" },
            { value: 'CustomRange', label: 'Custom Range', startTimeString: "", endTimeString: "" }
        ];
        this.verticalchartview = [1000, 200];
        this.verticalchartview2 = [1000, 260];
        this.verticalchartviewcolorScheme = {
            domain: ['skyblue', 'darkgreen', 'orange']
        };
        this.verticalbarchartresults = [
            {
                "name": "Chrome",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            },
            {
                "name": "Firefox",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            },
            {
                "name": "Mobile",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            }
        ];
        this.verticalbarchartresults2 = [
            {
                "name": "Ios_Primary",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            },
            {
                "name": "Android_Primary",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            },
            {
                "name": "Ios_Sec",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            }, {
                "name": "Android_Sec",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            }
        ];
        this.piechartview = [450, 200];
        this.piechartresults = [
            {
                "name": "Smoke",
                "value": 10
            },
            {
                "name": "Load",
                "value": 20
            },
            {
                "name": "Scalability",
                "value": 10
            },
            {
                "name": "Reliability",
                "value": 10
            }
        ];
        this.legendPosition = 'below';
        this.showLegend = false;
        this.horizontalchartview = [1000, 180];
        this.horizontalchartviewcolorScheme = {
            domain: ['darkblue', 'yellow', 'orange']
        };
        this.horizontalchartviewschemeType = 'ordinal';
        this.horizontalchartresults = [
            {
                "name": "Load Tests",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 20
                    },
                    {
                        "name": "Sla Met",
                        "value": 15
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 5
                    }
                ]
            },
            {
                "name": "Scalability Tests",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 3
                    }
                ]
            },
            {
                "name": "Reliability Tests",
                "series": [
                    {
                        "name": "No Of Tests",
                        "value": 10
                    },
                    {
                        "name": "Sla Met",
                        "value": 8
                    },
                    {
                        "name": "Sla Deviated",
                        "value": 2
                    }
                ]
            }
        ];
        this.cardchartview = [670, 150];
        this.cardchartcolorScheme = {
            domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
        };
        this.cardchartColor = 'darkblue';
        this.cardchart = [
            {
                "name": "<b>API/URL's</b> Monitored",
                "value": 15
            },
            {
                "name": "<b>Web</b>-Single user tests",
                "value": 95
            },
            {
                "name": "<b>Mobile</b>-Single user tests",
                "value": 10
            },
        ];
        this.accesslevel = 0;
        this.sidebarService.expand('menu-sidebar');
        this.sidebarService.toggle(true, 'menu-sidebar');
        accessChecker.isGranted('view', 'superadmin').take(1).subscribe(function (res) {
            if (res) {
                _this.router.navigate(['/pages/administrator']);
            }
        });
        var appID = localStorage.getItem("appid");
        this.data.getAppAccessLevelByID(appID).take(1).subscribe(function (data) {
            // console.log(data);
            var alevel = data.accesslevel;
            localStorage.setItem("accesslevel", alevel);
            _this.accesslevel = Number(alevel);
            _this.cdRef.markForCheck();
        });
    }
    HomeComponent.prototype.ngOnInit = function () {
    };
    HomeComponent.prototype.openlicensedialog = function () {
        var dialogRef = this.dialog.open(_home_licensing_popup_home_licensing_popup_component__WEBPACK_IMPORTED_MODULE_5__["HomeLicensingPopupComponent"], {
            disableClose: false,
            width: '85%',
            height: '80%'
        });
    };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/pages/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.scss */ "./src/app/pages/home/home.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _nebular_security__WEBPACK_IMPORTED_MODULE_4__["NbAccessChecker"],
            _data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"],
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__["NbSidebarService"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/pages/pages-menu.ts":
/*!*************************************!*\
  !*** ./src/app/pages/pages-menu.ts ***!
  \*************************************/
/*! exports provided: MENU_ITEMS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENU_ITEMS", function() { return MENU_ITEMS; });
var MENU_ITEMS = [
    {
        title: 'Home',
        icon: 'nb-home',
        link: '/pages/home',
        home: true,
    },
    {
        title: 'Ux Profiler',
        icon: 'nb-shuffle',
        link: '/pages/uxweb',
        expanded: false,
        children: [
            {
                title: 'Web',
                link: '/pages/uxweb',
                expanded: true,
                children: [
                    {
                        title: 'Design & Execution',
                        icon: 'nb-grid-a-outline',
                        link: '/pages/uxweb/scriptpage',
                    },
                    {
                        title: 'Analysis',
                        icon: 'nb-list',
                        link: '/pages/uxweb/test-run'
                    }
                ]
            },
            {
                title: 'Mobile',
                link: '/pages/uxmob',
                expanded: true,
                children: [
                    {
                        title: 'Design & Execution',
                        icon: 'nb-grid-a-outline',
                        link: '/pages/uxmob/execution',
                    },
                    {
                        title: 'Analysis',
                        icon: 'nb-list',
                        link: '/pages/uxmob/testruns',
                    }
                ],
            } /* ,
            {
              title: 'Execution',
              icon: 'nb-grid-a-outline',
              link: '/pages/uxweb/scriptpage',
            },
            {
              title: 'Analysis',
              icon: 'nb-list',
              link: '/pages/uxweb/test-run'
            } */
        ]
    },
    {
        title: 'Load Simulator',
        icon: 'nb-grid-b-outline',
        link: '/pages/load',
        expanded: false,
        children: [
            {
                title: 'Design & Execution',
                icon: 'nb-grid-a-outline',
                link: '/pages/load/testscenarioslist',
            },
            {
                title: 'Analysis',
                icon: 'nb-list',
                link: '/pages/load/testruns',
                home: true
            } /* ,
            {
              title: 'Load Agents',
              icon: 'nb-grid-a',
              link: '/pages/load/loadagentslist',
            } */
        ],
    },
    {
        title: 'Active Monitor',
        icon: 'nb-bar-chart',
        link: '/pages/amon',
        expanded: false,
        children: [
            {
                title: 'Scheduler',
                icon: 'nb-grid-a-outline',
                link: '/pages/amon/scriptpage',
            },
            {
                title: 'Analysis',
                icon: 'nb-list',
                link: '/pages/amon/home',
            }
            /*   {
                title: 'Transactionview',
                icon: 'nb-grid-a',
                link: '/pages/amon/transactionview'
              } */
            /*
                  {
                    title: 'Calendar view',
                    icon: 'nb-layout-default',
                    link: '/pages/amon/calendarpage',
                    // calendarpage: true,
                  } */
        ],
    },
    {
        title: 'Accessibility',
        icon: 'nb-layout-sidebar-left',
        link: '/pages/amon',
        expanded: false,
        children: [
            {
                title: 'Design',
                icon: 'nb-grid-a-outline',
                link: '/pages/accessibility/execution',
            },
            {
                title: 'Analysis',
                icon: 'nb-list',
                link: '/pages/accessibility/testruns',
            }
            /*   {
                title: 'Transactionview',
                icon: 'nb-grid-a',
                link: '/pages/amon/transactionview'
              } */
            /*
                  {
                    title: 'Calendar view',
                    icon: 'nb-layout-default',
                    link: '/pages/amon/calendarpage',
                    // calendarpage: true,
                  } */
        ],
    }
    /* ,
    {
      title: 'Mobile Performance',
      icon: 'nb-keypad',
      link: '/pages/uxmob',
      expanded: false,
      children: [
        {
          title: 'Execution',
          icon: 'nb-grid-a-outline',
          link: '/pages/uxmob/execution',
        },
        {
          title: 'Analysis',
          icon: 'nb-list',
          link: '/pages/uxmob/testruns',
        }
      ],
    } */
];


/***/ }),

/***/ "./src/app/pages/pages-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/pages-routing.module.ts ***!
  \***********************************************/
/*! exports provided: PagesRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesRoutingModule", function() { return PagesRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages.component */ "./src/app/pages/pages.component.ts");
/* harmony import */ var _administrator_administrator_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./administrator/administrator.component */ "./src/app/pages/administrator/administrator.component.ts");
/* harmony import */ var _administrator_customer_customer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./administrator/customer/customer.component */ "./src/app/pages/administrator/customer/customer.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home/home.component */ "./src/app/pages/home/home.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [{
        path: '',
        component: _pages_component__WEBPACK_IMPORTED_MODULE_2__["PagesComponent"],
        children: [
            {
                path: 'home',
                component: _home_home_component__WEBPACK_IMPORTED_MODULE_5__["HomeComponent"],
            },
            {
                path: 'load',
                loadChildren: 'app/pages/cipts/cipts.module#CiptsModule',
            },
            {
                path: 'amon',
                loadChildren: 'app/pages/cieem/cieem.module#CieemModule',
            },
            {
                path: '',
                redirectTo: 'home',
                pathMatch: 'full',
            },
            {
                path: 'administrator',
                component: _administrator_administrator_component__WEBPACK_IMPORTED_MODULE_3__["AdministratorComponent"],
            },
            {
                path: 'customer',
                component: _administrator_customer_customer_component__WEBPACK_IMPORTED_MODULE_4__["CustomerComponent"],
            },
            {
                path: 'uxweb',
                loadChildren: './cxperf/cxperf.module#CxperfModule'
            },
            {
                path: 'uxmob',
                loadChildren: './mobileperf/mobileperf.module#MobilePerfModule'
            },
            {
                path: 'accessibility',
                loadChildren: './accessibility/accessibility.module#AccessibilityModule'
            },
        ],
    }];
var PagesRoutingModule = /** @class */ (function () {
    function PagesRoutingModule() {
    }
    PagesRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]],
        })
    ], PagesRoutingModule);
    return PagesRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/pages.component.html":
/*!********************************************!*\
  !*** ./src/app/pages/pages.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ngx-sample-layout>\r\n  <nb-menu [items]=\"menu\" autoCollapse=\"true\" *ngIf=\"!(accessChecker.isGranted('view', 'admin') | async)\"></nb-menu>\r\n  <nb-menu [items]=\"adminMenu\" autoCollapse=\"true\"\r\n    *ngIf=\"(accessChecker.isGranted('view', 'admin') | async)&&(!(accessChecker.isGranted('view', 'superadmin') | async))\">\r\n  </nb-menu>\r\n  <nb-menu [items]=\"superAdminMenu\" autoCollapse=\"true\" *ngIf=\"(accessChecker.isGranted('view', 'superadmin') | async)\">\r\n  </nb-menu>\r\n  <router-outlet></router-outlet>\r\n</ngx-sample-layout>"

/***/ }),

/***/ "./src/app/pages/pages.component.scss":
/*!********************************************!*\
  !*** ./src/app/pages/pages.component.scss ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/deep/ nb-card {\n  background-color: white !important;\n  background-image: url(\"/\") !important; }\n\n/* \r\n/deep/ div > nb-menu > ul > li > *,\r\n/deep/ div > nb-menu > ul > li > a > i,\r\n/deep/ div > nb-menu > ul > li > ul > li > *,\r\n/deep/ div > nb-menu > ul > li > ul > li > a > i {\r\n    background-color: #0033a1 !important;\r\n    color: white !important;\r\n}\r\n\r\n/deep/ div > nb-menu > ul > li > a:hover,\r\n/deep/ div > nb-menu > ul > li > a:link,\r\n/deep/ div > nb-menu > ul > li > a:active,\r\n/deep/ div > nb-menu > ul > li > a:visited,\r\n/deep/ div > nb-menu > ul > li > ul > li > a:hover,\r\n/deep/ div > nb-menu > ul > li > ul > li > a:link,\r\n/deep/ div > nb-menu > ul > li > ul > li > a:active,\r\n/deep/ div > nb-menu > ul > li > ul > li > a:visited {\r\n    background-color: #0033a1 !important;\r\n    color: #ebeff5 !important;\r\n} */\n\n/* \r\n/deep/ ::-webkit-scrollbar {\r\n    width: 10px !important;\r\n    //height: 100px !important;\r\n} */\n\n/* ::-webkit-scrollbar {\r\n    width: <desired-width> !important;\r\n    height: <desired-width> !important;;\r\n  }\r\n  \r\n  ::-webkit-scrollbar-thumb {\r\n    background: <desired-thumb-color> !important;\r\n    border-radius: <desired-width> / 2 !important;;\r\n  }\r\n  \r\n  ::-webkit-scrollbar-track {\r\n    background: <desired-track-color>;\r\n  } */\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar {\n  width: 10px !important;\n  height: 5px; }\n\n/deep/ .nb-theme-default nb-layout ::-webkit-scrollbar-thumb {\n  background: #a8a6a6 !important;\n  cursor: pointer;\n  border-radius: 5px !important; }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxwYWdlc1xccGFnZXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3BhZ2VzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsa0NBQWtDO0VBQ2xDLHFDQUFxQyxFQUFBOztBQUV2Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQ2tCRzs7QURHSDs7OztHQ0VHOztBRElIOzs7Ozs7Ozs7Ozs7S0NTSzs7QURLTDtFQUNFLHNCQUFzQjtFQUN0QixXQUFXLEVBQUE7O0FBR2I7RUFDRSw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmLDZCQUE2QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcGFnZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvZGVlcC8gbmItY2FyZCB7XHJcbiAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIvYXNzZXRzL2ltYWdlcy9Db2duaXphbnRfQkcuanBlZ1wiKSAhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiL1wiKSAhaW1wb3J0YW50O1xyXG59XHJcbi8qIFxyXG4vZGVlcC8gZGl2ID4gbmItbWVudSA+IHVsID4gbGkgPiAqLFxyXG4vZGVlcC8gZGl2ID4gbmItbWVudSA+IHVsID4gbGkgPiBhID4gaSxcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gdWwgPiBsaSA+ICosXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IHVsID4gbGkgPiBhID4gaSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzM2ExICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcclxufVxyXG5cclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gYTpob3ZlcixcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gYTpsaW5rLFxyXG4vZGVlcC8gZGl2ID4gbmItbWVudSA+IHVsID4gbGkgPiBhOmFjdGl2ZSxcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gYTp2aXNpdGVkLFxyXG4vZGVlcC8gZGl2ID4gbmItbWVudSA+IHVsID4gbGkgPiB1bCA+IGxpID4gYTpob3ZlcixcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gdWwgPiBsaSA+IGE6bGluayxcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gdWwgPiBsaSA+IGE6YWN0aXZlLFxyXG4vZGVlcC8gZGl2ID4gbmItbWVudSA+IHVsID4gbGkgPiB1bCA+IGxpID4gYTp2aXNpdGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDMzYTEgIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZWJlZmY1ICFpbXBvcnRhbnQ7XHJcbn0gKi9cclxuXHJcbi8qIFxyXG4vZGVlcC8gOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICB3aWR0aDogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgLy9oZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XHJcbn0gKi9cclxuXHJcbi8qIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgd2lkdGg6IDxkZXNpcmVkLXdpZHRoPiAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiA8ZGVzaXJlZC13aWR0aD4gIWltcG9ydGFudDs7XHJcbiAgfVxyXG4gIFxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgYmFja2dyb3VuZDogPGRlc2lyZWQtdGh1bWItY29sb3I+ICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA8ZGVzaXJlZC13aWR0aD4gLyAyICFpbXBvcnRhbnQ7O1xyXG4gIH1cclxuICBcclxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgIGJhY2tncm91bmQ6IDxkZXNpcmVkLXRyYWNrLWNvbG9yPjtcclxuICB9ICovXHJcblxyXG4vZGVlcC8gLm5iLXRoZW1lLWRlZmF1bHQgbmItbGF5b3V0IDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gIHdpZHRoOiAxMHB4ICFpbXBvcnRhbnQ7Ly81cHg7XHJcbiAgaGVpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi9kZWVwLyAubmItdGhlbWUtZGVmYXVsdCBuYi1sYXlvdXQgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgYmFja2dyb3VuZDogI2E4YTZhNiAhaW1wb3J0YW50Oy8vI2RhZGFkYTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4ICFpbXBvcnRhbnQ7Ly8yLjVweDtcclxufVxyXG4iLCIvZGVlcC8gbmItY2FyZCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi9cIikgIWltcG9ydGFudDsgfVxuXG4vKiBcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gKixcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gYSA+IGksXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IHVsID4gbGkgPiAqLFxyXG4vZGVlcC8gZGl2ID4gbmItbWVudSA+IHVsID4gbGkgPiB1bCA+IGxpID4gYSA+IGkge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMzNhMSAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IGE6aG92ZXIsXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IGE6bGluayxcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gYTphY3RpdmUsXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IGE6dmlzaXRlZCxcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gdWwgPiBsaSA+IGE6aG92ZXIsXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IHVsID4gbGkgPiBhOmxpbmssXHJcbi9kZWVwLyBkaXYgPiBuYi1tZW51ID4gdWwgPiBsaSA+IHVsID4gbGkgPiBhOmFjdGl2ZSxcclxuL2RlZXAvIGRpdiA+IG5iLW1lbnUgPiB1bCA+IGxpID4gdWwgPiBsaSA+IGE6dmlzaXRlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzM2ExICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogI2ViZWZmNSAhaW1wb3J0YW50O1xyXG59ICovXG4vKiBcclxuL2RlZXAvIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgd2lkdGg6IDEwcHggIWltcG9ydGFudDtcclxuICAgIC8vaGVpZ2h0OiAxMDBweCAhaW1wb3J0YW50O1xyXG59ICovXG4vKiA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgIHdpZHRoOiA8ZGVzaXJlZC13aWR0aD4gIWltcG9ydGFudDtcclxuICAgIGhlaWdodDogPGRlc2lyZWQtd2lkdGg+ICFpbXBvcnRhbnQ7O1xyXG4gIH1cclxuICBcclxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuICAgIGJhY2tncm91bmQ6IDxkZXNpcmVkLXRodW1iLWNvbG9yPiAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogPGRlc2lyZWQtd2lkdGg+IC8gMiAhaW1wb3J0YW50OztcclxuICB9XHJcbiAgXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbiAgICBiYWNrZ3JvdW5kOiA8ZGVzaXJlZC10cmFjay1jb2xvcj47XHJcbiAgfSAqL1xuL2RlZXAvIC5uYi10aGVtZS1kZWZhdWx0IG5iLWxheW91dCA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgd2lkdGg6IDEwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA1cHg7IH1cblxuL2RlZXAvIC5uYi10aGVtZS1kZWZhdWx0IG5iLWxheW91dCA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcbiAgYmFja2dyb3VuZDogI2E4YTZhNiAhaW1wb3J0YW50O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweCAhaW1wb3J0YW50OyB9XG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/pages.component.ts":
/*!******************************************!*\
  !*** ./src/app/pages/pages.component.ts ***!
  \******************************************/
/*! exports provided: PagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesComponent", function() { return PagesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _pages_menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages-menu */ "./src/app/pages/pages-menu.ts");
/* harmony import */ var _nebular_security__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @nebular/security */ "./node_modules/@nebular/security/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var PagesComponent = /** @class */ (function () {
    function PagesComponent(accessChecker) {
        this.accessChecker = accessChecker;
        this.menu = _pages_menu__WEBPACK_IMPORTED_MODULE_1__["MENU_ITEMS"];
        this.adminPath = [
            {
                title: 'Administrator',
                icon: 'nb-person',
                link: '/pages/administrator',
            }
        ];
        this.adminMenu = this.menu.concat(this.adminPath);
        this.superAdminMenu = [
            {
                title: 'Administrator',
                icon: 'nb-person',
                link: '/pages/administrator',
                home: true,
            }
        ];
    }
    PagesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-pages',
            template: __webpack_require__(/*! ./pages.component.html */ "./src/app/pages/pages.component.html"),
            styles: [__webpack_require__(/*! ./pages.component.scss */ "./src/app/pages/pages.component.scss")]
        }),
        __metadata("design:paramtypes", [_nebular_security__WEBPACK_IMPORTED_MODULE_2__["NbAccessChecker"]])
    ], PagesComponent);
    return PagesComponent;
}());



/***/ }),

/***/ "./src/app/pages/pages.module.ts":
/*!***************************************!*\
  !*** ./src/app/pages/pages.module.ts ***!
  \***************************************/
/*! exports provided: PagesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesModule", function() { return PagesModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../@theme/theme.module */ "./src/app/@theme/theme.module.ts");
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @nebular/theme */ "./node_modules/@nebular/theme/index.js");
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages.component */ "./src/app/pages/pages.component.ts");
/* harmony import */ var _pages_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages-routing.module */ "./src/app/pages/pages-routing.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @swimlane/ngx-charts */ "./node_modules/@swimlane/ngx-charts/release/index.js");
/* harmony import */ var _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var ngx_echarts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-echarts */ "./node_modules/ngx-echarts/ngx-echarts.es5.js");
/* harmony import */ var _administrator_administrator_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./administrator/administrator.component */ "./src/app/pages/administrator/administrator.component.ts");
/* harmony import */ var _administrator_customerform_customerform_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./administrator/customerform/customerform.component */ "./src/app/pages/administrator/customerform/customerform.component.ts");
/* harmony import */ var _administrator_applicationform_applicationform_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./administrator/applicationform/applicationform.component */ "./src/app/pages/administrator/applicationform/applicationform.component.ts");
/* harmony import */ var _administrator_userform_userform_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./administrator/userform/userform.component */ "./src/app/pages/administrator/userform/userform.component.ts");
/* harmony import */ var _administrator_customer_customer_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./administrator/customer/customer.component */ "./src/app/pages/administrator/customer/customer.component.ts");
/* harmony import */ var _administrator_userpasswordform_userpasswordform_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./administrator/userpasswordform/userpasswordform.component */ "./src/app/pages/administrator/userpasswordform/userpasswordform.component.ts");
/* harmony import */ var _excel_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../excel.service */ "./src/app/excel.service.ts");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./home/home.component */ "./src/app/pages/home/home.component.ts");
/* harmony import */ var _status_card_status_card_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./status-card/status-card.component */ "./src/app/pages/status-card/status-card.component.ts");
/* harmony import */ var ng_circle_progress__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ng-circle-progress */ "./node_modules/ng-circle-progress/fesm5/ng-circle-progress.js");
/* harmony import */ var _cxperf_cxperf_module__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./cxperf/cxperf.module */ "./src/app/pages/cxperf/cxperf.module.ts");
/* harmony import */ var _mobileperf_mobileperf_module__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./mobileperf/mobileperf.module */ "./src/app/pages/mobileperf/mobileperf.module.ts");
/* harmony import */ var _accessibility_accessibility_module__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./accessibility/accessibility.module */ "./src/app/pages/accessibility/accessibility.module.ts");
/* harmony import */ var _home_home_licensing_popup_home_licensing_popup_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./home/home-licensing-popup/home-licensing-popup.component */ "./src/app/pages/home/home-licensing-popup/home-licensing-popup.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









//import { ToasterModule } from 'angular2-toaster';
















var PAGES_COMPONENTS = [
    _pages_component__WEBPACK_IMPORTED_MODULE_3__["PagesComponent"],
];
var MAT_MODULES = [
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatFormFieldModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatAutocompleteModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatBadgeModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatBottomSheetModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatButtonModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatButtonToggleModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatCardModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatCheckboxModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatChipsModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDatepickerModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDialogModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatDividerModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatExpansionModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatGridListModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatIconModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatInputModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatListModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatMenuModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatNativeDateModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatPaginatorModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatProgressBarModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatProgressSpinnerModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatRadioModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatRippleModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSelectModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSidenavModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSliderModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSlideToggleModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSnackBarModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSortModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatStepperModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatTableModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatTabsModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatToolbarModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatTooltipModule"],
    _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatTreeModule"]
];
var PagesModule = /** @class */ (function () {
    function PagesModule() {
    }
    PagesModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _pages_routing_module__WEBPACK_IMPORTED_MODULE_4__["PagesRoutingModule"],
                _theme_theme_module__WEBPACK_IMPORTED_MODULE_1__["ThemeModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__["CdkTableModule"]
            ].concat(MAT_MODULES, [
                _swimlane_ngx_charts__WEBPACK_IMPORTED_MODULE_8__["NgxChartsModule"],
                ngx_echarts__WEBPACK_IMPORTED_MODULE_9__["NgxEchartsModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_2__["NbRouteTabsetModule"],
                /* NbSpinnerModule */
                //ToasterModule.forRoot(),
                ng_circle_progress__WEBPACK_IMPORTED_MODULE_20__["NgCircleProgressModule"].forRoot({
                    // set defaults here
                    radius: 100,
                    outerStrokeWidth: 16,
                    innerStrokeWidth: 8,
                    outerStrokeColor: "#78C000",
                    innerStrokeColor: "#C7E596",
                    animationDuration: 300,
                }),
                _cxperf_cxperf_module__WEBPACK_IMPORTED_MODULE_21__["CxperfModule"],
                _mobileperf_mobileperf_module__WEBPACK_IMPORTED_MODULE_22__["MobilePerfModule"],
                _accessibility_accessibility_module__WEBPACK_IMPORTED_MODULE_23__["AccessibilityModule"]
            ]),
            exports: MAT_MODULES.concat([
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_6__["CdkTableModule"],
                _nebular_theme__WEBPACK_IMPORTED_MODULE_2__["NbRouteTabsetModule"],
            ]),
            entryComponents: [
                _administrator_customerform_customerform_component__WEBPACK_IMPORTED_MODULE_11__["CustomerFormComponent"],
                _administrator_applicationform_applicationform_component__WEBPACK_IMPORTED_MODULE_12__["ApplicationformComponent"],
                _administrator_userform_userform_component__WEBPACK_IMPORTED_MODULE_13__["UserFormComponent"],
                _administrator_userpasswordform_userpasswordform_component__WEBPACK_IMPORTED_MODULE_15__["UserpasswordformComponent"],
                _home_home_licensing_popup_home_licensing_popup_component__WEBPACK_IMPORTED_MODULE_24__["HomeLicensingPopupComponent"]
            ],
            declarations: PAGES_COMPONENTS.concat([
                _administrator_administrator_component__WEBPACK_IMPORTED_MODULE_10__["AdministratorComponent"],
                _administrator_customer_customer_component__WEBPACK_IMPORTED_MODULE_14__["CustomerComponent"],
                _administrator_customerform_customerform_component__WEBPACK_IMPORTED_MODULE_11__["CustomerFormComponent"],
                _administrator_applicationform_applicationform_component__WEBPACK_IMPORTED_MODULE_12__["ApplicationformComponent"],
                _administrator_userform_userform_component__WEBPACK_IMPORTED_MODULE_13__["UserFormComponent"],
                _administrator_userpasswordform_userpasswordform_component__WEBPACK_IMPORTED_MODULE_15__["UserpasswordformComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_18__["HomeComponent"],
                _status_card_status_card_component__WEBPACK_IMPORTED_MODULE_19__["StatusCardComponent"],
                _home_home_licensing_popup_home_licensing_popup_component__WEBPACK_IMPORTED_MODULE_24__["HomeLicensingPopupComponent"]
            ]),
            bootstrap: [
                _home_home_component__WEBPACK_IMPORTED_MODULE_18__["HomeComponent"],
            ],
            providers: [_excel_service__WEBPACK_IMPORTED_MODULE_16__["ExcelService"], _data_service__WEBPACK_IMPORTED_MODULE_17__["DataService"]],
        })
    ], PagesModule);
    return PagesModule;
}());



/***/ }),

/***/ "./src/app/pages/status-card/status-card.component.html":
/*!**************************************************************!*\
  !*** ./src/app/pages/status-card/status-card.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nb-card>\r\n  <div class=\"icon-container\">\r\n    <div class=\"icon {{ type }}\">\r\n      <ng-content></ng-content>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"details\">\r\n    <div class=\"title\">{{ title }}</div>\r\n    <div>\r\n      <label >{{value}}</label>\r\n      <br>\r\n      <label >{{value2}}</label>\r\n    </div>\r\n  </div>\r\n</nb-card>"

/***/ }),

/***/ "./src/app/pages/status-card/status-card.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/pages/status-card/status-card.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This is a starting point where we declare the maps of themes and globally available functions/mixins\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/**\n * This mixin generates keyfames.\n * Because of all keyframes can't be scoped,\n * we need to puts unique name in each btn-pulse call.\n */\n/*\n\nAccording to the specification (https://www.w3.org/TR/css-scoping-1/#host-selector)\n:host and :host-context are pseudo-classes. So we assume they could be combined,\nlike other pseudo-classes, even same ones.\nFor example: ':nth-of-type(2n):nth-of-type(even)'.\n\nIdeal solution would be to prepend any selector with :host-context([dir=rtl]).\nThen nebular components will behave as an html element and respond to [dir] attribute on any level,\nso direction could be overridden on any component level.\n\nImplementation code:\n\n@mixin nb-rtl() {\n  // add # to scss interpolation statement.\n  // it works in comments and we can't use it here\n  @at-root {selector-append(':host-context([dir=rtl])', &)} {\n    @content;\n  }\n}\n\nAnd when we call it somewhere:\n\n:host {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n:host-context(...) {\n  .some-class {\n    @include nb-rtl() {\n      ...\n    }\n  }\n}\n\nResult will look like:\n\n:host-context([dir=rtl]):host .some-class {\n  ...\n}\n:host-context([dir=rtl]):host-context(...) .some-class {\n  ...\n}\n\n*\n  Side note:\n  :host-context():host selector are valid. https://lists.w3.org/Archives/Public/www-style/2015Feb/0305.html\n\n  :host-context([dir=rtl]):host-context(...) should match any permutation,\n  so order is not important.\n*\n\n\nCurrently, there're two problems with this approach:\n\nFirst, is that we can't combine :host, :host-context. Angular bugs #14349, #19199.\nFor the moment of writing, the only possible way is:\n:host {\n  :host-context(...) {\n    ...\n  }\n}\nIt doesn't work for us because mixin could be called somewhere deeper, like:\n:host {\n  p {\n    @include nb-rtl() { ... }\n  }\n}\nWe are not able to go up to :host level to place content passed to mixin.\n\nThe second problem is that we only can be sure that we appending :host-context([dir=rtl]) to another\n:host/:host-context pseudo-class when called in theme files (*.theme.scss).\n  *\n    Side note:\n    Currently, nb-install-component uses another approach where :host prepended with the theme name\n    (https://github.com/angular/angular/blob/5b96078624b0a4760f2dbcf6fdf0bd62791be5bb/packages/compiler/src/shadow_css.ts#L441),\n    but it was made to be able to use current realization of rtl and it can be rewritten back to\n    :host-context($theme) once we will be able to use multiple shadow selectors.\n  *\nBut when it's called in *.component.scss we can't be sure, that selector starts with :host/:host-context,\nbecause angular allows omitting pseudo-classes if we don't need to style :host component itself.\nWe can break such selectors, by just appending :host-context([dir=rtl]) to them.\n  ***\n    Possible solution\n    check if we in theme by some theme variables and if so append, otherwise nest like\n    @at-root :host-context([dir=rtl]) {\n      // add # to scss interpolation statement.\n      // it works in comments and we can't use it here\n      {&} {\n        @content;\n      }\n    }\n    What if :host specified? Can we add space in :host-context(...) :host?\n    Or maybe add :host selector anyway? If multiple :host selectors are allowed\n  ***\n\n\nProblems with the current approach.\n\n1. Direction can be applied only on document level, because mixin prepends theme class,\nwhich placed on the body.\n2. *.component.scss styles should be in :host selector. Otherwise angular will add host\nattribute to [dir=rtl] attribute as well.\n\n\nGeneral problems.\n\nLtr is default document direction, but for proper work of nb-ltr (means ltr only),\n[dir=ltr] should be specified at least somewhere. ':not([dir=rtl]' not applicable here,\nbecause it's satisfy any parent, that don't have [dir=rtl] attribute.\nPrevious approach was to use single rtl mixin and reset ltr properties to initial value.\nBut sometimes it's hard to find, what the previous value should be. And such mixin call looks too verbose.\n*/\n/**\n * @license\n * Copyright Akveo. All Rights Reserved.\n * Licensed under the MIT License. See License.txt in the project root for license information.\n */\n/*\n      :host can be prefixed\n      https://github.com/angular/angular/blob/8d0ee34939f14c07876d222c25b405ed458a34d3/packages/compiler/src/shadow_css.ts#L441\n\n      We have to use :host insted of :host-context($theme), to be able to prefix theme class\n      with something defined inside of @content, by prefixing &.\n      For example this scss code:\n        .nb-theme-default {\n          .some-selector & {\n            ...\n          }\n        }\n      Will result in next css:\n        .some-selector .nb-theme-default {\n          ...\n        }\n\n      It doesn't work with :host-context because angular splitting it in two selectors and removes\n      prefix in one of the selectors.\n    */\n.nb-theme-default :host .wb {\n  word-break: break-all !important; }\n.nb-theme-default :host nb-card {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 6rem;\n  overflow: visible;\n  -webkit-box-shadow: 0 0 0 0 #dbdbdb, none;\n          box-shadow: 0 0 0 0 #dbdbdb, none;\n  border: 1px solid #d5dbe0;\n  border-top-color: #d5dbe0;\n  border-top-style: solid;\n  border-top-width: 1px;\n  border-right-color: #d5dbe0;\n  border-right-style: solid;\n  border-right-width: 1px;\n  border-bottom-color: #d5dbe0;\n  border-bottom-style: solid;\n  border-bottom-width: 1px;\n  border-left-color: #d5dbe0;\n  border-left-style: solid;\n  border-left-width: 1px;\n  border-image-source: initial;\n  border-image-slice: initial;\n  border-image-width: initial;\n  border-image-outset: initial;\n  border-image-repeat: initial; }\n.nb-theme-default :host nb-card .icon-container {\n    height: 100%;\n    padding: 0.625rem; }\n.nb-theme-default :host nb-card .icon {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    width: 5.75rem;\n    height: 4.75rem;\n    font-size: 3.75rem;\n    border-radius: 0.375rem;\n    -webkit-transition: width 0.4s ease;\n    transition: width 0.4s ease;\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n    -webkit-transform-style: preserve-3d;\n    -webkit-backface-visibility: hidden;\n    color: #ffffff; }\n.nb-theme-default :host nb-card .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#b57fff), to(#8a7fff));\n      background-image: linear-gradient(to right, #b57fff, #8a7fff);\n      -webkit-box-shadow: 0 0 0 0 #896ddb, 0 0 0 0 #9f7fff;\n              box-shadow: 0 0 0 0 #896ddb, 0 0 0 0 #9f7fff; }\n.nb-theme-default :host nb-card .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#40dcb2), to(#40dc7e));\n      background-image: linear-gradient(to right, #40dcb2, #40dc7e);\n      -webkit-box-shadow: 0 0 0 0 #37bd83, 0 0 0 0 #40dc98;\n              box-shadow: 0 0 0 0 #37bd83, 0 0 0 0 #40dc98; }\n.nb-theme-default :host nb-card .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#4cc4ff), to(#4ca6ff));\n      background-image: linear-gradient(to right, #4cc4ff, #4ca6ff);\n      -webkit-box-shadow: 0 0 0 0 #419cdb, 0 0 0 0 #4cb5ff;\n              box-shadow: 0 0 0 0 #419cdb, 0 0 0 0 #4cb5ff; }\n.nb-theme-default :host nb-card .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffcc00), to(#ffa100));\n      background-image: linear-gradient(to right, #ffcc00, #ffa100);\n      -webkit-box-shadow: 0 0 0 0 #db9d00, 0 0 0 0 #ffb600;\n              box-shadow: 0 0 0 0 #db9d00, 0 0 0 0 #ffb600; }\n.nb-theme-default :host nb-card .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff4ca6), to(#ff4c6a));\n      background-image: linear-gradient(to right, #ff4ca6, #ff4c6a);\n      -webkit-box-shadow: 0 0 0 0 #db4175, 0 0 0 0 #ff4c88;\n              box-shadow: 0 0 0 0 #db4175, 0 0 0 0 #ff4c88; }\n.nb-theme-default :host nb-card .icon.secondary {\n      background-color: transparent;\n      -webkit-box-shadow: 0 0 0 0 #bbbec6, 0 0 0 0 #dadde6;\n              box-shadow: 0 0 0 0 #bbbec6, 0 0 0 0 #dadde6;\n      color: #a4abb3; }\n.nb-theme-default :host nb-card:hover {\n    background: white; }\n.nb-theme-default :host nb-card:hover .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#bf91ff), to(#9a91ff));\n      background-image: linear-gradient(to right, #bf91ff, #9a91ff); }\n.nb-theme-default :host nb-card:hover .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#5be1bd), to(#5be190));\n      background-image: linear-gradient(to right, #5be1bd, #5be190); }\n.nb-theme-default :host nb-card:hover .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#65ccff), to(#65b2ff));\n      background-image: linear-gradient(to right, #65ccff, #65b2ff); }\n.nb-theme-default :host nb-card:hover .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffd324), to(#ffae24));\n      background-image: linear-gradient(to right, #ffd324, #ffae24); }\n.nb-theme-default :host nb-card:hover .icon.danger {\n      background-image: 'btn-hero-danger-light-gradient()'; }\n.nb-theme-default :host nb-card:hover .icon.secondary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#dfe0ea), to(rgba(255, 255, 255, 0.14)));\n      background-image: linear-gradient(to right, #dfe0ea, rgba(255, 255, 255, 0.14)); }\n.nb-theme-default :host nb-card.off {\n    color: #a4abb3; }\n.nb-theme-default :host nb-card.off .icon {\n      color: #a4abb3; }\n.nb-theme-default :host nb-card.off .icon.primary, .nb-theme-default :host nb-card.off .icon.success, .nb-theme-default :host nb-card.off .icon.info, .nb-theme-default :host nb-card.off .icon.warning, .nb-theme-default :host nb-card.off .icon.danger {\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background-image: -webkit-gradient(linear, left top, right top, from(transparent), to(transparent));\n        background-image: linear-gradient(to right, transparent, transparent); }\n.nb-theme-default :host nb-card.off .icon.secondary {\n        background: transparent; }\n.nb-theme-default :host nb-card.off .title {\n      color: #a4abb3; }\n.nb-theme-default :host nb-card .details {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    height: 100%;\n    border-left: 1px solid transparent; }\n[dir=ltr] .nb-theme-default :host nb-card .details {\n      padding: 0 0.5rem 0 0.75rem; }\n[dir=rtl] .nb-theme-default :host nb-card .details {\n      padding: 0 0.75rem 0 0.5rem; }\n.nb-theme-default :host nb-card .title {\n    font-family: Roboto;\n    font-size: 1.25rem;\n    font-weight: 600;\n    color: #2a2a2a; }\n.nb-theme-default :host nb-card .status {\n    font-size: 1rem;\n    font-weight: 300;\n    text-transform: uppercase;\n    color: #a4abb3; }\n/*\n      :host can be prefixed\n      https://github.com/angular/angular/blob/8d0ee34939f14c07876d222c25b405ed458a34d3/packages/compiler/src/shadow_css.ts#L441\n\n      We have to use :host insted of :host-context($theme), to be able to prefix theme class\n      with something defined inside of @content, by prefixing &.\n      For example this scss code:\n        .nb-theme-default {\n          .some-selector & {\n            ...\n          }\n        }\n      Will result in next css:\n        .some-selector .nb-theme-default {\n          ...\n        }\n\n      It doesn't work with :host-context because angular splitting it in two selectors and removes\n      prefix in one of the selectors.\n    */\n.nb-theme-cosmic :host .wb {\n  word-break: break-all !important; }\n.nb-theme-cosmic :host nb-card {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 6rem;\n  overflow: visible;\n  -webkit-box-shadow: 0 3px 0 0 #342f6e, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n          box-shadow: 0 3px 0 0 #342f6e, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n  border: 1px solid #d5dbe0;\n  border-top-color: #d5dbe0;\n  border-top-style: solid;\n  border-top-width: 1px;\n  border-right-color: #d5dbe0;\n  border-right-style: solid;\n  border-right-width: 1px;\n  border-bottom-color: #d5dbe0;\n  border-bottom-style: solid;\n  border-bottom-width: 1px;\n  border-left-color: #d5dbe0;\n  border-left-style: solid;\n  border-left-width: 1px;\n  border-image-source: initial;\n  border-image-slice: initial;\n  border-image-width: initial;\n  border-image-outset: initial;\n  border-image-repeat: initial; }\n.nb-theme-cosmic :host nb-card .icon-container {\n    height: 100%;\n    padding: 0.625rem; }\n.nb-theme-cosmic :host nb-card .icon {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    width: 5.75rem;\n    height: 4.75rem;\n    font-size: 3.75rem;\n    border-radius: 0.5rem;\n    -webkit-transition: width 0.4s ease;\n    transition: width 0.4s ease;\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n    -webkit-transform-style: preserve-3d;\n    -webkit-backface-visibility: hidden;\n    color: #ffffff; }\n.nb-theme-cosmic :host nb-card .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ad59ff), to(#7659ff));\n      background-image: linear-gradient(to right, #ad59ff, #7659ff);\n      -webkit-box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#00d9bf), to(#00d977));\n      background-image: linear-gradient(to right, #00d9bf, #00d977);\n      -webkit-box-shadow: 0 3px 0 0 #00bb85, 0 2px 8px 0 #00d99b, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #00bb85, 0 2px 8px 0 #00d99b, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#00b3ff), to(#0088ff));\n      background-image: linear-gradient(to right, #00b3ff, #0088ff);\n      -webkit-box-shadow: 0 3px 0 0 #0087db, 0 2px 8px 0 #009dff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #0087db, 0 2px 8px 0 #009dff, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffcc00), to(#ffa100));\n      background-image: linear-gradient(to right, #ffcc00, #ffa100);\n      -webkit-box-shadow: 0 3px 0 0 #db9d00, 0 2px 8px 0 #ffb600, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #db9d00, 0 2px 8px 0 #ffb600, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff38ac), to(#ff386a));\n      background-image: linear-gradient(to right, #ff38ac, #ff386a);\n      -webkit-box-shadow: 0 3px 0 0 #db3078, 0 2px 8px 0 #ff388b, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #db3078, 0 2px 8px 0 #ff388b, 0 4px 10px 0 rgba(33, 7, 77, 0.5); }\n.nb-theme-cosmic :host nb-card .icon.secondary {\n      background-color: transparent;\n      -webkit-box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n              box-shadow: 0 3px 0 0 #7e4ddb, 0 2px 8px 0 #9259ff, 0 4px 10px 0 rgba(33, 7, 77, 0.5);\n      color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card:hover {\n    background: #463f92; }\n.nb-theme-cosmic :host nb-card:hover .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#b970ff), to(#8970ff));\n      background-image: linear-gradient(to right, #b970ff, #8970ff); }\n.nb-theme-cosmic :host nb-card:hover .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#24dec8), to(#24de8a));\n      background-image: linear-gradient(to right, #24dec8, #24de8a); }\n.nb-theme-cosmic :host nb-card:hover .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#24bdff), to(#2499ff));\n      background-image: linear-gradient(to right, #24bdff, #2499ff); }\n.nb-theme-cosmic :host nb-card:hover .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffd324), to(#ffae24));\n      background-image: linear-gradient(to right, #ffd324, #ffae24); }\n.nb-theme-cosmic :host nb-card:hover .icon.danger {\n      background-image: 'btn-hero-danger-light-gradient()'; }\n.nb-theme-cosmic :host nb-card:hover .icon.secondary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#b970ff), to(rgba(255, 255, 255, 0.14)));\n      background-image: linear-gradient(to right, #b970ff, rgba(255, 255, 255, 0.14)); }\n.nb-theme-cosmic :host nb-card.off {\n    color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card.off .icon {\n      color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card.off .icon.primary, .nb-theme-cosmic :host nb-card.off .icon.success, .nb-theme-cosmic :host nb-card.off .icon.info, .nb-theme-cosmic :host nb-card.off .icon.warning, .nb-theme-cosmic :host nb-card.off .icon.danger {\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background-image: -webkit-gradient(linear, left top, right top, from(transparent), to(transparent));\n        background-image: linear-gradient(to right, transparent, transparent); }\n.nb-theme-cosmic :host nb-card.off .icon.secondary {\n        background: transparent; }\n.nb-theme-cosmic :host nb-card.off .title {\n      color: #a1a1e5; }\n.nb-theme-cosmic :host nb-card .details {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    height: 100%;\n    border-left: 1px solid transparent; }\n[dir=ltr] .nb-theme-cosmic :host nb-card .details {\n      padding: 0 0.5rem 0 0.75rem; }\n[dir=rtl] .nb-theme-cosmic :host nb-card .details {\n      padding: 0 0.75rem 0 0.5rem; }\n.nb-theme-cosmic :host nb-card .title {\n    font-family: Exo;\n    font-size: 1.25rem;\n    font-weight: 600;\n    color: #ffffff; }\n.nb-theme-cosmic :host nb-card .status {\n    font-size: 1rem;\n    font-weight: 300;\n    text-transform: uppercase;\n    color: #a1a1e5; }\n/*\n      :host can be prefixed\n      https://github.com/angular/angular/blob/8d0ee34939f14c07876d222c25b405ed458a34d3/packages/compiler/src/shadow_css.ts#L441\n\n      We have to use :host insted of :host-context($theme), to be able to prefix theme class\n      with something defined inside of @content, by prefixing &.\n      For example this scss code:\n        .nb-theme-default {\n          .some-selector & {\n            ...\n          }\n        }\n      Will result in next css:\n        .some-selector .nb-theme-default {\n          ...\n        }\n\n      It doesn't work with :host-context because angular splitting it in two selectors and removes\n      prefix in one of the selectors.\n    */\n.nb-theme-corporate :host .wb {\n  word-break: break-all !important; }\n.nb-theme-corporate :host nb-card {\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 6rem;\n  overflow: visible;\n  -webkit-box-shadow: 0 0 0 0 #dbdbdb, none;\n          box-shadow: 0 0 0 0 #dbdbdb, none;\n  border: 1px solid #d5dbe0;\n  border-top-color: #d5dbe0;\n  border-top-style: solid;\n  border-top-width: 1px;\n  border-right-color: #d5dbe0;\n  border-right-style: solid;\n  border-right-width: 1px;\n  border-bottom-color: #d5dbe0;\n  border-bottom-style: solid;\n  border-bottom-width: 1px;\n  border-left-color: #d5dbe0;\n  border-left-style: solid;\n  border-left-width: 1px;\n  border-image-source: initial;\n  border-image-slice: initial;\n  border-image-width: initial;\n  border-image-outset: initial;\n  border-image-repeat: initial; }\n.nb-theme-corporate :host nb-card .icon-container {\n    height: 100%;\n    padding: 0.625rem; }\n.nb-theme-corporate :host nb-card .icon {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    width: 5.75rem;\n    height: 4.75rem;\n    font-size: 3.75rem;\n    border-radius: 0.17rem;\n    -webkit-transition: width 0.4s ease;\n    transition: width 0.4s ease;\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n    -webkit-transform-style: preserve-3d;\n    -webkit-backface-visibility: hidden;\n    color: #ffffff; }\n.nb-theme-corporate :host nb-card .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#73a1ff), to(#73a1ff));\n      background-image: linear-gradient(to right, #73a1ff, #73a1ff);\n      -webkit-box-shadow: 0 0 0 0 #638adb, 0 0 20px 0 #73a1ff;\n              box-shadow: 0 0 0 0 #638adb, 0 0 20px 0 #73a1ff; }\n.nb-theme-corporate :host nb-card .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#5dcfe3), to(#5dcfe3));\n      background-image: linear-gradient(to right, #5dcfe3, #5dcfe3);\n      -webkit-box-shadow: 0 0 0 0 #50b2c3, 0 0 20px 0 #5dcfe3;\n              box-shadow: 0 0 0 0 #50b2c3, 0 0 20px 0 #5dcfe3; }\n.nb-theme-corporate :host nb-card .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ba7fec), to(#ba7fec));\n      background-image: linear-gradient(to right, #ba7fec, #ba7fec);\n      -webkit-box-shadow: 0 0 0 0 #a06dcb, 0 0 20px 0 #ba7fec;\n              box-shadow: 0 0 0 0 #a06dcb, 0 0 20px 0 #ba7fec; }\n.nb-theme-corporate :host nb-card .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffa36b), to(#ffa36b));\n      background-image: linear-gradient(to right, #ffa36b, #ffa36b);\n      -webkit-box-shadow: 0 0 0 0 #db8c5c, 0 0 20px 0 #ffa36b;\n              box-shadow: 0 0 0 0 #db8c5c, 0 0 20px 0 #ffa36b; }\n.nb-theme-corporate :host nb-card .icon.danger {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ff6b83), to(#ff6b83));\n      background-image: linear-gradient(to right, #ff6b83, #ff6b83);\n      -webkit-box-shadow: 0 0 0 0 #db5c71, 0 0 20px 0 #ff6b83;\n              box-shadow: 0 0 0 0 #db5c71, 0 0 20px 0 #ff6b83; }\n.nb-theme-corporate :host nb-card .icon.secondary {\n      background-color: #edf2f5;\n      -webkit-box-shadow: 0 0 0 0 #ccd0d3, 0 0 0 0 #edf2f5;\n              box-shadow: 0 0 0 0 #ccd0d3, 0 0 0 0 #edf2f5;\n      color: #a4abb3; }\n.nb-theme-corporate :host nb-card .icon.primary, .nb-theme-corporate :host nb-card .icon.success, .nb-theme-corporate :host nb-card .icon.info, .nb-theme-corporate :host nb-card .icon.warning, .nb-theme-corporate :host nb-card .icon.danger, .nb-theme-corporate :host nb-card .icon.secondary {\n      -webkit-box-shadow: none;\n              box-shadow: none; }\n.nb-theme-corporate :host nb-card:hover {\n    background: white; }\n.nb-theme-corporate :host nb-card:hover .icon.primary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#87aeff), to(#87aeff));\n      background-image: linear-gradient(to right, #87aeff, #87aeff); }\n.nb-theme-corporate :host nb-card:hover .icon.success {\n      background-image: -webkit-gradient(linear, left top, right top, from(#74d6e7), to(#74d6e7));\n      background-image: linear-gradient(to right, #74d6e7, #74d6e7); }\n.nb-theme-corporate :host nb-card:hover .icon.info {\n      background-image: -webkit-gradient(linear, left top, right top, from(#c491ef), to(#c491ef));\n      background-image: linear-gradient(to right, #c491ef, #c491ef); }\n.nb-theme-corporate :host nb-card:hover .icon.warning {\n      background-image: -webkit-gradient(linear, left top, right top, from(#ffb080), to(#ffb080));\n      background-image: linear-gradient(to right, #ffb080, #ffb080); }\n.nb-theme-corporate :host nb-card:hover .icon.danger {\n      background-image: 'btn-hero-danger-light-gradient()'; }\n.nb-theme-corporate :host nb-card:hover .icon.secondary {\n      background-image: -webkit-gradient(linear, left top, right top, from(#f0f4f6), to(#f0f4f6));\n      background-image: linear-gradient(to right, #f0f4f6, #f0f4f6); }\n.nb-theme-corporate :host nb-card.off {\n    color: #a4abb3; }\n.nb-theme-corporate :host nb-card.off .icon {\n      color: #a4abb3; }\n.nb-theme-corporate :host nb-card.off .icon.primary, .nb-theme-corporate :host nb-card.off .icon.success, .nb-theme-corporate :host nb-card.off .icon.info, .nb-theme-corporate :host nb-card.off .icon.warning, .nb-theme-corporate :host nb-card.off .icon.danger {\n        -webkit-box-shadow: none;\n                box-shadow: none;\n        background-image: -webkit-gradient(linear, left top, right top, from(transparent), to(transparent));\n        background-image: linear-gradient(to right, transparent, transparent); }\n.nb-theme-corporate :host nb-card.off .icon.secondary {\n        background: transparent; }\n.nb-theme-corporate :host nb-card.off .title {\n      color: #a4abb3; }\n.nb-theme-corporate :host nb-card .details {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: vertical;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: column;\n            flex-direction: column;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    height: 100%;\n    border-left: 1px solid transparent; }\n[dir=ltr] .nb-theme-corporate :host nb-card .details {\n      padding: 0 0.5rem 0 0.75rem; }\n[dir=rtl] .nb-theme-corporate :host nb-card .details {\n      padding: 0 0.75rem 0 0.5rem; }\n.nb-theme-corporate :host nb-card .title {\n    font-family: Roboto;\n    font-size: 1.25rem;\n    font-weight: 600;\n    color: #181818; }\n.nb-theme-corporate :host nb-card .status {\n    font-size: 1rem;\n    font-weight: 300;\n    text-transform: uppercase;\n    color: #a4abb3; }\n.nb-theme-corporate :host nb-card .icon-container {\n  height: auto; }\n/*  @include nb-for-theme(cosmic) {\r\n    nb-card {\r\n      &.off .icon-container {\r\n        @include nb-ltr(border-right, 1px solid nb-theme(separator));\r\n        @include nb-rtl(border-left, 1px solid nb-theme(separator));\r\n      }\r\n\r\n      .icon-container {\r\n        padding: 0;\r\n      }\r\n\r\n      .details {\r\n        @include nb-ltr(padding-left, 1.25rem);\r\n        @include nb-rtl(padding-right, 1.25rem);\r\n      }\r\n\r\n      .icon {\r\n        width: 7rem;\r\n        height: 100%;\r\n        font-size: 4.5rem;\r\n        @include nb-ltr(border-radius, nb-theme(card-border-radius) 0 0 nb-theme(card-border-radius));\r\n        @include nb-rtl(border-radius, 0 nb-theme(card-border-radius) nb-theme(card-border-radius) 0);\r\n      }\r\n\r\n      .title {\r\n        font-weight: nb-theme(font-weight-bolder);\r\n      }\r\n\r\n      .status {\r\n        font-weight: nb-theme(font-weight-light);\r\n      }\r\n    }\r\n  }*/\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc3RhdHVzLWNhcmQvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL25vZGVfbW9kdWxlc1xcQG5lYnVsYXJcXHRoZW1lXFxzdHlsZXNcXF90aGVtaW5nLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3N0YXR1cy1jYXJkL3N0YXR1cy1jYXJkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9wYWdlcy9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcY29yZVxcX21peGlucy5zY3NzIiwic3JjL2FwcC9wYWdlcy9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcY29yZVxcX2Z1bmN0aW9ucy5zY3NzIiwic3JjL2FwcC9wYWdlcy9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcdGhlbWVzXFxfZGVmYXVsdC5zY3NzIiwic3JjL2FwcC9wYWdlcy9zdGF0dXMtY2FyZC9DOlxcUGVyZkFzc3VyZVxcR2l0TGFiXFxQZXJmQXNzdXJlX0FuZ3VsYXIvbm9kZV9tb2R1bGVzXFxAbmVidWxhclxcdGhlbWVcXHN0eWxlc1xcdGhlbWVzXFxfY29zbWljLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3N0YXR1cy1jYXJkL0M6XFxQZXJmQXNzdXJlXFxHaXRMYWJcXFBlcmZBc3N1cmVfQW5ndWxhci9ub2RlX21vZHVsZXNcXEBuZWJ1bGFyXFx0aGVtZVxcc3R5bGVzXFx0aGVtZXNcXF9jb3Jwb3JhdGUuc2NzcyIsInNyYy9hcHAvcGFnZXMvc3RhdHVzLWNhcmQvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL25vZGVfbW9kdWxlc1xcQG5lYnVsYXJcXHRoZW1lXFxzdHlsZXNcXGdsb2JhbFxcYm9vdHN0cmFwXFxfaGVyby1idXR0b25zLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3N0YXR1cy1jYXJkL0M6XFxQZXJmQXNzdXJlXFxHaXRMYWJcXFBlcmZBc3N1cmVfQW5ndWxhci9zcmNcXGFwcFxccGFnZXNcXHN0YXR1cy1jYXJkXFxzdGF0dXMtY2FyZC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvcGFnZXMvc3RhdHVzLWNhcmQvQzpcXFBlcmZBc3N1cmVcXEdpdExhYlxcUGVyZkFzc3VyZV9Bbmd1bGFyL3NyY1xcYXBwXFxAdGhlbWVcXHN0eWxlc1xcdGhlbWVzLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7RUNJRTtBREdGOztFQ0FFO0FDUEY7Ozs7RURZRTtBQzhKRjs7OztFRHpKRTtBQ21MRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDRC9EQztBRXJJRDs7OztFRjBJRTtBRzFJRjs7OztFSCtJRTtBRS9JRjs7OztFRm9KRTtBQ3BKRjs7OztFRHlKRTtBQ2lCRjs7OztFRFpFO0FDc0NGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NEOEVDO0FJbFJEOzs7O0VKdVJFO0FFdlJGOzs7O0VGNFJFO0FDNVJGOzs7O0VEaVNFO0FDdkhGOzs7O0VENEhFO0FDbEdGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NEc05DO0FHMVpEOzs7O0VIK1pFO0FFL1pGOzs7O0VGb2FFO0FDcGFGOzs7O0VEeWFFO0FDL1BGOzs7O0VEb1FFO0FDMU9GOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NEOFZDO0FLbGlCRDs7OztFTHVpQkU7QUV2aUJGOzs7O0VGNGlCRTtBQzVpQkY7Ozs7RURpakJFO0FDdllGOzs7O0VENFlFO0FDbFhGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NEc2VDO0FHMXFCRDs7OztFSCtxQkU7QUUvcUJGOzs7O0VGb3JCRTtBQ3ByQkY7Ozs7RUR5ckJFO0FDL2dCRjs7OztFRG9oQkU7QUMxZkY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0Q4bUJDO0FNbHpCRDs7OztFTnV6QkU7QURyc0JFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tDeXRCQztBT3YwQkg7RUFDRSxnQ0FBZ0MsRUFBQTtBQUdsQztFQUNFLDhCQUFtQjtFQUFuQiw2QkFBbUI7TUFBbkIsdUJBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQix5QkFBbUI7TUFBbkIsc0JBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQixZQUFZO0VBQ1osaUJBQWlCO0VBSWpCLHlDSndVbUI7VUl4VW5CLGlDSndVbUI7RUl0VW5CLHlCQUF5QjtFQUN6Qix5QkFBb0M7RUFDcEMsdUJBQXVCO0VBQ3ZCLHFCQUFxQjtFQUNyQiwyQkFBc0M7RUFDdEMseUJBQXlCO0VBQ3pCLHVCQUF1QjtFQUN2Qiw0QkFBdUM7RUFDdkMsMEJBQTBCO0VBQzFCLHdCQUF3QjtFQUN4QiwwQkFBcUM7RUFDckMsd0JBQXdCO0VBQ3hCLHNCQUFzQjtFQUN0Qiw0QkFBNEI7RUFDNUIsMkJBQTJCO0VBQzNCLDJCQUEyQjtFQUMzQiw0QkFBNEI7RUFDNUIsNEJBQTRCLEVBQUE7QUFFNUI7SUFDRSxZQUFZO0lBQ1osaUJBQWlCLEVBQUE7QUFHbkI7SUFDRSxvQkFBYTtJQUFiLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHlCQUFtQjtRQUFuQixzQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLHdCQUF1QjtRQUF2QixxQkFBdUI7WUFBdkIsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLHVCSnBCWTtJSXFCWixtQ0FBMkI7SUFBM0IsMkJBQTJCO0lBQzNCLHVDQUErQjtZQUEvQiwrQkFBK0I7SUFDL0Isb0NBQW9DO0lBQ3BDLG1DQUFtQztJQUNuQyxjSlRnQixFQUFBO0FJV2hCO01OWEosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsb0RBNVBvRTtjQTRQcEUsNENBNVBvRSxFQUFBO0FDaEdoRTtNTmZKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLG9EQXhQb0U7Y0F3UHBFLDRDQXhQb0UsRUFBQTtBQ2hHaEU7TU5uQkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsb0RBaFA4RDtjQWdQOUQsNENBaFA4RCxFQUFBO0FDcEcxRDtNTnZCSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSxvREFwUG9FO2NBb1BwRSw0Q0FwUG9FLEVBQUE7QUM1RmhFO01OM0JKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLG9EQTVPa0U7Y0E0T2xFLDRDQTVPa0UsRUFBQTtBQ2hHOUQ7TUQ4UUosNkJIakM2QjtNRytGN0Isb0RBeE80RTtjQXdPNUUsNENBeE80RTtNQ2pHdEUsY0ozQ1csRUFBQTtBSTBEZjtJQUNFLGlCQUEwQyxFQUFBO0FBR3hDO01BQ0UsMkZEc0ZvRDtNQ3RGcEQsNkREc0ZvRCxFQUFBO0FDcEZ0RDtNQUNFLDJGRG1Gb0Q7TUNuRnBELDZERG1Gb0QsRUFBQTtBQ2pGdEQ7TUFDRSwyRkRnRm9EO01DaEZwRCw2RERnRm9ELEVBQUE7QUM5RXREO01BQ0UsMkZENkVvRDtNQzdFcEQsNkRENkVvRCxFQUFBO0FDM0V0RDtNQUNFLG9EQUFvRCxFQUFBO0FBRXREO01BQ0UsNkdEdUVvRDtNQ3ZFcEQsK0VEdUVvRCxFQUFBO0FDbEUxRDtJQUNFLGNKcEZhLEVBQUE7QUlzRmI7TUFDRSxjSnZGVyxFQUFBO0FJeUZYO1FBS0Usd0JBQWdCO2dCQUFoQixnQkFBZ0I7UUFDaEIsbUdBQXFFO1FBQXJFLHFFQUFxRSxFQUFBO0FBR3ZFO1FBQ0UsdUJBQXVCLEVBQUE7QUFJM0I7TUFDRSxjSnhHVyxFQUFBO0FJNEdmO0lBQ0Usb0JBQWE7SUFBYixvQkFBYTtJQUFiLGFBQWE7SUFDYiw0QkFBc0I7SUFBdEIsNkJBQXNCO1FBQXRCLDBCQUFzQjtZQUF0QixzQkFBc0I7SUFDdEIsd0JBQXVCO1FBQXZCLHFCQUF1QjtZQUF2Qix1QkFBdUI7SUFDdkIsWUFBWTtJQUdaLGtDQUFrQyxFQUFBO0FQa3hCcEM7TUM3bUJFLDJCTXZLMkMsRUFBQTtBUHN4QjdDO01DL21CRSwyQk10SzJDLEVBQUE7QUFJN0M7SUFDRSxtQkM1SWtCO0lENklsQixrQkFBa0I7SUFDbEIsZ0JKNUlpQjtJSTZJakIsY0p6SHFCLEVBQUE7QUk0SHZCO0lBQ0UsZUFBZTtJQUNmLGdCSnJKa0I7SUlzSmxCLHlCQUF5QjtJQUN6QixjSmpJYSxFQUFBO0FKOEVmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tDeTFCQztBT3Y4Qkg7RUFDRSxnQ0FBZ0MsRUFBQTtBQUdsQztFQUNFLDhCQUFtQjtFQUFuQiw2QkFBbUI7TUFBbkIsdUJBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQix5QkFBbUI7TUFBbkIsc0JBQW1CO1VBQW5CLG1CQUFtQjtFQUNuQixZQUFZO0VBQ1osaUJBQWlCO0VBSWpCLHdFSHlFZ0Q7VUd6RWhELGdFSHlFZ0Q7RUd2RWhELHlCQUF5QjtFQUN6Qix5QkFBb0M7RUFDcEMsdUJBQXVCO0VBQ3ZCLHFCQUFxQjtFQUNyQiwyQkFBc0M7RUFDdEMseUJBQXlCO0VBQ3pCLHVCQUF1QjtFQUN2Qiw0QkFBdUM7RUFDdkMsMEJBQTBCO0VBQzFCLHdCQUF3QjtFQUN4QiwwQkFBcUM7RUFDckMsd0JBQXdCO0VBQ3hCLHNCQUFzQjtFQUN0Qiw0QkFBNEI7RUFDNUIsMkJBQTJCO0VBQzNCLDJCQUEyQjtFQUMzQiw0QkFBNEI7RUFDNUIsNEJBQTRCLEVBQUE7QUFFNUI7SUFDRSxZQUFZO0lBQ1osaUJBQWlCLEVBQUE7QUFHbkI7SUFDRSxvQkFBYTtJQUFiLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHlCQUFtQjtRQUFuQixzQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLHdCQUF1QjtRQUF2QixxQkFBdUI7WUFBdkIsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLHFCSHJDVTtJR3NDVixtQ0FBMkI7SUFBM0IsMkJBQTJCO0lBQzNCLHVDQUErQjtZQUEvQiwrQkFBK0I7SUFDL0Isb0NBQW9DO0lBQ3BDLG1DQUFtQztJQUNuQyxjSC9CZ0IsRUFBQTtBR2lDaEI7TU5YSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSw2RkYvVGtEO2NFK1RsRCxxRkYvVGtELEVBQUE7QUc3QjlDO01OZkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsNkZGL1RrRDtjRStUbEQscUZGL1RrRCxFQUFBO0FHekI5QztNTm5CSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSw2RkYvVGtEO2NFK1RsRCxxRkYvVGtELEVBQUE7QUdyQjlDO01OdkJKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLDZGRi9Ua0Q7Y0UrVGxELHFGRi9Ua0QsRUFBQTtBR2pCOUM7TU4zQkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsNkZGL1RrRDtjRStUbEQscUZGL1RrRCxFQUFBO0FHYjlDO01EOFFKLDZCSGpDNkI7TUcrRjdCLDZGRi9Ua0Q7Y0UrVGxELHFGRi9Ua0Q7TUdWNUMsY0gvRFcsRUFBQTtBRzhFZjtJQUNFLG1CQUEwQyxFQUFBO0FBR3hDO01BQ0UsMkZEc0ZvRDtNQ3RGcEQsNkREc0ZvRCxFQUFBO0FDcEZ0RDtNQUNFLDJGRG1Gb0Q7TUNuRnBELDZERG1Gb0QsRUFBQTtBQ2pGdEQ7TUFDRSwyRkRnRm9EO01DaEZwRCw2RERnRm9ELEVBQUE7QUM5RXREO01BQ0UsMkZENkVvRDtNQzdFcEQsNkRENkVvRCxFQUFBO0FDM0V0RDtNQUNFLG9EQUFvRCxFQUFBO0FBRXREO01BQ0UsNkdEdUVvRDtNQ3ZFcEQsK0VEdUVvRCxFQUFBO0FDbEUxRDtJQUNFLGNIeEdhLEVBQUE7QUcwR2I7TUFDRSxjSDNHVyxFQUFBO0FHNkdYO1FBS0Usd0JBQWdCO2dCQUFoQixnQkFBZ0I7UUFDaEIsbUdBQXFFO1FBQXJFLHFFQUFxRSxFQUFBO0FBR3ZFO1FBQ0UsdUJBQXVCLEVBQUE7QUFJM0I7TUFDRSxjSDVIVyxFQUFBO0FHZ0lmO0lBQ0Usb0JBQWE7SUFBYixvQkFBYTtJQUFiLGFBQWE7SUFDYiw0QkFBc0I7SUFBdEIsNkJBQXNCO1FBQXRCLDBCQUFzQjtZQUF0QixzQkFBc0I7SUFDdEIsd0JBQXVCO1FBQXZCLHFCQUF1QjtZQUF2Qix1QkFBdUI7SUFDdkIsWUFBWTtJQUdaLGtDQUFrQyxFQUFBO0FQazVCcEM7TUM3dUJFLDJCTXZLMkMsRUFBQTtBUHM1QjdDO01DL3VCRSwyQk10SzJDLEVBQUE7QUFJN0M7SUFDRSxnQkM5SGU7SUQrSGYsa0JBQWtCO0lBQ2xCLGdCSjVJaUI7SUk2SWpCLGNIN0lxQixFQUFBO0FHZ0p2QjtJQUNFLGVBQWU7SUFDZixnQkpySmtCO0lJc0psQix5QkFBeUI7SUFDekIsY0hySmEsRUFBQTtBTGtHZjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQ3k5QkM7QU92a0NIO0VBQ0UsZ0NBQWdDLEVBQUE7QUFHbEM7RUFDRSw4QkFBbUI7RUFBbkIsNkJBQW1CO01BQW5CLHVCQUFtQjtVQUFuQixtQkFBbUI7RUFDbkIseUJBQW1CO01BQW5CLHNCQUFtQjtVQUFuQixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGlCQUFpQjtFQUlqQix5Q0p3VW1CO1VJeFVuQixpQ0p3VW1CO0VJdFVuQix5QkFBeUI7RUFDekIseUJBQW9DO0VBQ3BDLHVCQUF1QjtFQUN2QixxQkFBcUI7RUFDckIsMkJBQXNDO0VBQ3RDLHlCQUF5QjtFQUN6Qix1QkFBdUI7RUFDdkIsNEJBQXVDO0VBQ3ZDLDBCQUEwQjtFQUMxQix3QkFBd0I7RUFDeEIsMEJBQXFDO0VBQ3JDLHdCQUF3QjtFQUN4QixzQkFBc0I7RUFDdEIsNEJBQTRCO0VBQzVCLDJCQUEyQjtFQUMzQiwyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLDRCQUE0QixFQUFBO0FBRTVCO0lBQ0UsWUFBWTtJQUNaLGlCQUFpQixFQUFBO0FBR25CO0lBQ0Usb0JBQWE7SUFBYixvQkFBYTtJQUFiLGFBQWE7SUFDYix5QkFBbUI7UUFBbkIsc0JBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQix3QkFBdUI7UUFBdkIscUJBQXVCO1lBQXZCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2QsZUFBZTtJQUNmLGtCQUFrQjtJQUNsQixzQkYxQlc7SUUyQlgsbUNBQTJCO0lBQTNCLDJCQUEyQjtJQUMzQix1Q0FBK0I7WUFBL0IsK0JBQStCO0lBQy9CLG9DQUFvQztJQUNwQyxtQ0FBbUM7SUFDbkMsY0pUZ0IsRUFBQTtBSVdoQjtNTlhKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLHVEQTVQb0U7Y0E0UHBFLCtDQTVQb0UsRUFBQTtBQ2hHaEU7TU5mSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSx1REF4UG9FO2NBd1BwRSwrQ0F4UG9FLEVBQUE7QUNoR2hFO01ObkJKLDJGQUFzRTtNQUF0RSw2REFBc0U7TUsyV3RFLHVEQWhQOEQ7Y0FnUDlELCtDQWhQOEQsRUFBQTtBQ3BHMUQ7TU52QkosMkZBQXNFO01BQXRFLDZEQUFzRTtNSzJXdEUsdURBcFBvRTtjQW9QcEUsK0NBcFBvRSxFQUFBO0FDNUZoRTtNTjNCSiwyRkFBc0U7TUFBdEUsNkRBQXNFO01LMld0RSx1REE1T2tFO2NBNE9sRSwrQ0E1T2tFLEVBQUE7QUNoRzlEO01EOFFKLHlCRHpUeUI7TUN1WHpCLG9EQXhPNEU7Y0F3TzVFLDRDQXhPNEU7TUNqR3RFLGNKM0NXLEVBQUE7QUkrQ1g7TUFNRSx3QkFBZ0I7Y0FBaEIsZ0JBQWdCLEVBQUE7QUFLdEI7SUFDRSxpQkFBMEMsRUFBQTtBQUd4QztNQUNFLDJGRHNGb0Q7TUN0RnBELDZERHNGb0QsRUFBQTtBQ3BGdEQ7TUFDRSwyRkRtRm9EO01DbkZwRCw2RERtRm9ELEVBQUE7QUNqRnREO01BQ0UsMkZEZ0ZvRDtNQ2hGcEQsNkREZ0ZvRCxFQUFBO0FDOUV0RDtNQUNFLDJGRDZFb0Q7TUM3RXBELDZERDZFb0QsRUFBQTtBQzNFdEQ7TUFDRSxvREFBb0QsRUFBQTtBQUV0RDtNQUNFLDJGRHVFb0Q7TUN2RXBELDZERHVFb0QsRUFBQTtBQ2xFMUQ7SUFDRSxjSnBGYSxFQUFBO0FJc0ZiO01BQ0UsY0p2RlcsRUFBQTtBSXlGWDtRQUtFLHdCQUFnQjtnQkFBaEIsZ0JBQWdCO1FBQ2hCLG1HQUFxRTtRQUFyRSxxRUFBcUUsRUFBQTtBQUd2RTtRQUNFLHVCQUF1QixFQUFBO0FBSTNCO01BQ0UsY0p4R1csRUFBQTtBSTRHZjtJQUNFLG9CQUFhO0lBQWIsb0JBQWE7SUFBYixhQUFhO0lBQ2IsNEJBQXNCO0lBQXRCLDZCQUFzQjtRQUF0QiwwQkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLHdCQUF1QjtRQUF2QixxQkFBdUI7WUFBdkIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFHWixrQ0FBa0MsRUFBQTtBUG9oQ3BDO01DLzJCRSwyQk12SzJDLEVBQUE7QVB3aEM3QztNQ2ozQkUsMkJNdEsyQyxFQUFBO0FBSTdDO0lBQ0UsbUJDaEhrQjtJRGlIbEIsa0JBQWtCO0lBQ2xCLGdCSjVJaUI7SUk2SWpCLGNGN0lxQixFQUFBO0FFZ0p2QjtJQUNFLGVBQWU7SUFDZixnQkpySmtCO0lJc0psQix5QkFBeUI7SUFDekIsY0pqSWEsRUFBQTtBSXVJYjtFQUNFLFlBQVksRUFBQTtBQU1wQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SVAyaUNJIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc3RhdHVzLWNhcmQvc3RhdHVzLWNhcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWt2ZW8uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuIFNlZSBMaWNlbnNlLnR4dCBpbiB0aGUgcHJvamVjdCByb290IGZvciBsaWNlbnNlIGluZm9ybWF0aW9uLlxuICovXG5cblxuLyoqXG4gKiBUaGlzIGlzIGEgc3RhcnRpbmcgcG9pbnQgd2hlcmUgd2UgZGVjbGFyZSB0aGUgbWFwcyBvZiB0aGVtZXMgYW5kIGdsb2JhbGx5IGF2YWlsYWJsZSBmdW5jdGlvbnMvbWl4aW5zXG4gKi9cblxuQGltcG9ydCAnY29yZS9taXhpbnMnO1xuQGltcG9ydCAnY29yZS9mdW5jdGlvbnMnO1xuXG4kbmItZW5hYmxlZC10aGVtZXM6ICgpICFnbG9iYWw7XG4kbmItZW5hYmxlLWNzcy12YXJpYWJsZXM6IGZhbHNlICFnbG9iYWw7XG5cbiRuYi10aGVtZXM6ICgpICFnbG9iYWw7XG4kbmItdGhlbWVzLW5vbi1wcm9jZXNzZWQ6ICgpICFnbG9iYWw7XG4kbmItdGhlbWVzLWV4cG9ydDogKCkgIWdsb2JhbDtcblxuQGZ1bmN0aW9uIG5iLXRoZW1lKCRrZXkpIHtcbiAgQHJldHVybiBtYXAtZ2V0KCR0aGVtZSwgJGtleSk7XG59XG5cbkBmdW5jdGlvbiBuYi1nZXQtdmFsdWUoJHRoZW1lLCAka2V5LCAkdmFsdWUpIHtcbiAgQGlmICh0eXBlLW9mKCR2YWx1ZSkgPT0gJ3N0cmluZycpIHtcbiAgICAkdG1wOiBtYXAtZ2V0KCR0aGVtZSwgJHZhbHVlKTtcblxuICAgIEBpZiAoJHRtcCAhPSBudWxsKSB7XG4gICAgICBAcmV0dXJuIG5iLWdldC12YWx1ZSgkdGhlbWUsICR2YWx1ZSwgJHRtcCk7XG4gICAgfVxuICB9XG5cbiAgQHJldHVybiBtYXAtZ2V0KCR0aGVtZSwgJGtleSk7XG59XG5cbkBmdW5jdGlvbiBjb252ZXJ0LXRvLWNzcy12YXJpYWJsZXMoJHZhcmlhYmxlcykge1xuICAkcmVzdWx0OiAoKTtcbiAgQGVhY2ggJHZhciwgJHZhbHVlIGluICR2YXJpYWJsZXMge1xuICAgICRyZXN1bHQ6IG1hcC1zZXQoJHJlc3VsdCwgJHZhciwgJy0tdmFyKCN7JHZhcn0pJyk7XG4gIH1cblxuICBAZGVidWcgJHJlc3VsdDtcbiAgQHJldHVybiAkcmVzdWx0O1xufVxuXG5AZnVuY3Rpb24gc2V0LWdsb2JhbC10aGVtZS12YXJzKCR0aGVtZSwgJHRoZW1lLW5hbWUpIHtcbiAgJHRoZW1lOiAkdGhlbWUgIWdsb2JhbDtcbiAgJHRoZW1lLW5hbWU6ICR0aGVtZS1uYW1lICFnbG9iYWw7XG4gIEBpZiAoJG5iLWVuYWJsZS1jc3MtdmFyaWFibGVzKSB7XG4gICAgJHRoZW1lOiBjb252ZXJ0LXRvLWNzcy12YXJpYWJsZXMoJHRoZW1lKSAhZ2xvYmFsO1xuICB9XG4gIEByZXR1cm4gJHRoZW1lO1xufVxuXG5AZnVuY3Rpb24gbmItcmVnaXN0ZXItdGhlbWUoJHRoZW1lLCAkbmFtZSwgJGRlZmF1bHQ6IG51bGwpIHtcblxuICAkdGhlbWUtZGF0YTogKCk7XG5cblxuICBAaWYgKCRkZWZhdWx0ICE9IG51bGwpIHtcblxuICAgICR0aGVtZTogbWFwLW1lcmdlKG1hcC1nZXQoJG5iLXRoZW1lcy1ub24tcHJvY2Vzc2VkLCAkZGVmYXVsdCksICR0aGVtZSk7XG4gICAgJG5iLXRoZW1lcy1ub24tcHJvY2Vzc2VkOiBtYXAtc2V0KCRuYi10aGVtZXMtbm9uLXByb2Nlc3NlZCwgJG5hbWUsICR0aGVtZSkgIWdsb2JhbDtcblxuICAgICR0aGVtZS1kYXRhOiBtYXAtc2V0KCR0aGVtZS1kYXRhLCBkYXRhLCAkdGhlbWUpO1xuICAgICRuYi10aGVtZXMtZXhwb3J0OiBtYXAtc2V0KCRuYi10aGVtZXMtZXhwb3J0LCAkbmFtZSwgbWFwLXNldCgkdGhlbWUtZGF0YSwgcGFyZW50LCAkZGVmYXVsdCkpICFnbG9iYWw7XG5cbiAgfSBAZWxzZSB7XG4gICAgJG5iLXRoZW1lcy1ub24tcHJvY2Vzc2VkOiBtYXAtc2V0KCRuYi10aGVtZXMtbm9uLXByb2Nlc3NlZCwgJG5hbWUsICR0aGVtZSkgIWdsb2JhbDtcblxuICAgICR0aGVtZS1kYXRhOiBtYXAtc2V0KCR0aGVtZS1kYXRhLCBkYXRhLCAkdGhlbWUpO1xuICAgICRuYi10aGVtZXMtZXhwb3J0OiBtYXAtc2V0KCRuYi10aGVtZXMtZXhwb3J0LCAkbmFtZSwgbWFwLXNldCgkdGhlbWUtZGF0YSwgcGFyZW50LCBudWxsKSkgIWdsb2JhbDtcbiAgfVxuXG4gICR0aGVtZS1wYXJzZWQ6ICgpO1xuICBAZWFjaCAka2V5LCAkdmFsdWUgaW4gJHRoZW1lIHtcbiAgICAkdGhlbWUtcGFyc2VkOiBtYXAtc2V0KCR0aGVtZS1wYXJzZWQsICRrZXksIG5iLWdldC12YWx1ZSgkdGhlbWUsICRrZXksICR2YWx1ZSkpO1xuICB9XG5cbiAgLy8gZW5hYmxlIHJpZ2h0IGF3YXkgd2hlbiBpbnN0YWxsZWRcbiAgJHRoZW1lLXBhcnNlZDogc2V0LWdsb2JhbC10aGVtZS12YXJzKCR0aGVtZS1wYXJzZWQsICRuYW1lKTtcbiAgQHJldHVybiBtYXAtc2V0KCRuYi10aGVtZXMsICRuYW1lLCAkdGhlbWUtcGFyc2VkKTtcbn1cblxuQGZ1bmN0aW9uIGdldC1lbmFibGVkLXRoZW1lcygpIHtcbiAgJHRoZW1lcy10by1pbnN0YWxsOiAoKTtcblxuICBAaWYgKGxlbmd0aCgkbmItZW5hYmxlZC10aGVtZXMpID4gMCkge1xuICAgIEBlYWNoICR0aGVtZS1uYW1lIGluICRuYi1lbmFibGVkLXRoZW1lcyB7XG4gICAgICAkdGhlbWVzLXRvLWluc3RhbGw6IG1hcC1zZXQoJHRoZW1lcy10by1pbnN0YWxsLCAkdGhlbWUtbmFtZSwgbWFwLWdldCgkbmItdGhlbWVzLCAkdGhlbWUtbmFtZSkpO1xuICAgIH1cbiAgfSBAZWxzZSB7XG4gICAgJHRoZW1lcy10by1pbnN0YWxsOiAkbmItdGhlbWVzO1xuICB9XG5cbiAgQHJldHVybiAkdGhlbWVzLXRvLWluc3RhbGw7XG59XG5cbkBtaXhpbiBpbnN0YWxsLWNzcy12YXJpYWJsZXMoJHRoZW1lLW5hbWUsICR2YXJpYWJsZXMpIHtcbiAgLm5iLXRoZW1lLSN7JHRoZW1lLW5hbWV9IHtcbiAgICBAZWFjaCAkdmFyLCAkdmFsdWUgaW4gJHZhcmlhYmxlcyB7XG4gICAgICAtLSN7JHZhcn06ICR2YWx1ZTtcbiAgICB9XG4gIH1cbn1cblxuLy8gVE9ETzogd2UgaGlkZSA6aG9zdCBpbnNpZGUgb2YgaXQgd2hpY2ggaXMgbm90IG9idmlvdXNcbkBtaXhpbiBuYi1pbnN0YWxsLWNvbXBvbmVudCgpIHtcblxuICAkdGhlbWVzLXRvLWluc3RhbGw6IGdldC1lbmFibGVkLXRoZW1lcygpO1xuXG4gIEBlYWNoICR0aGVtZS1uYW1lLCAkdGhlbWUgaW4gJHRoZW1lcy10by1pbnN0YWxsIHtcbiAgICAvKlxuICAgICAgOmhvc3QgY2FuIGJlIHByZWZpeGVkXG4gICAgICBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvOGQwZWUzNDkzOWYxNGMwNzg3NmQyMjJjMjViNDA1ZWQ0NThhMzRkMy9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxXG5cbiAgICAgIFdlIGhhdmUgdG8gdXNlIDpob3N0IGluc3RlZCBvZiA6aG9zdC1jb250ZXh0KCR0aGVtZSksIHRvIGJlIGFibGUgdG8gcHJlZml4IHRoZW1lIGNsYXNzXG4gICAgICB3aXRoIHNvbWV0aGluZyBkZWZpbmVkIGluc2lkZSBvZiBAY29udGVudCwgYnkgcHJlZml4aW5nICYuXG4gICAgICBGb3IgZXhhbXBsZSB0aGlzIHNjc3MgY29kZTpcbiAgICAgICAgLm5iLXRoZW1lLWRlZmF1bHQge1xuICAgICAgICAgIC5zb21lLXNlbGVjdG9yICYge1xuICAgICAgICAgICAgLi4uXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICBXaWxsIHJlc3VsdCBpbiBuZXh0IGNzczpcbiAgICAgICAgLnNvbWUtc2VsZWN0b3IgLm5iLXRoZW1lLWRlZmF1bHQge1xuICAgICAgICAgIC4uLlxuICAgICAgICB9XG5cbiAgICAgIEl0IGRvZXNuJ3Qgd29yayB3aXRoIDpob3N0LWNvbnRleHQgYmVjYXVzZSBhbmd1bGFyIHNwbGl0dGluZyBpdCBpbiB0d28gc2VsZWN0b3JzIGFuZCByZW1vdmVzXG4gICAgICBwcmVmaXggaW4gb25lIG9mIHRoZSBzZWxlY3RvcnMuXG4gICAgKi9cbiAgICAubmItdGhlbWUtI3skdGhlbWUtbmFtZX0gOmhvc3Qge1xuICAgICAgJHRoZW1lOiBzZXQtZ2xvYmFsLXRoZW1lLXZhcnMoJHRoZW1lLCAkdGhlbWUtbmFtZSk7XG4gICAgICBAY29udGVudDtcbiAgICB9XG4gIH1cbn1cblxuQG1peGluIG5iLWZvci10aGVtZSgkbmFtZSkge1xuICBAaWYgKCR0aGVtZS1uYW1lID09ICRuYW1lKSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQG1peGluIG5iLWV4Y2VwdC10aGVtZSgkbmFtZSkge1xuICBAaWYgKCR0aGVtZS1uYW1lICE9ICRuYW1lKSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuLy8gVE9ETzogYW5vdGhlciBtaXhpbmcgZm9yIHRoZSBhbG1vc3Qgc2FtZSB0aGluZ1xuQG1peGluIG5iLWluc3RhbGwtcm9vdC1jb21wb25lbnQoKSB7XG4gIEB3YXJuICdgbmItaW5zdGFsbC1yb290LWNvbXBvbmVudGAgaXMgZGVwcmljYXRlZCwgcmVwbGFjZSB3aXRoIGBuYi1pbnN0YWxsLWNvbXBvbmVudGAsIGFzIGBib2R5YCBpcyByb290IGVsZW1lbnQgbm93JztcblxuICBAaW5jbHVkZSBuYi1pbnN0YWxsLWNvbXBvbmVudCgpIHtcbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5AbWl4aW4gbmItaW5zdGFsbC1nbG9iYWwoKSB7XG4gICR0aGVtZXMtdG8taW5zdGFsbDogZ2V0LWVuYWJsZWQtdGhlbWVzKCk7XG5cbiAgQGVhY2ggJHRoZW1lLW5hbWUsICR0aGVtZSBpbiAkdGhlbWVzLXRvLWluc3RhbGwge1xuICAgIC5uYi10aGVtZS0jeyR0aGVtZS1uYW1lfSB7XG4gICAgICAkdGhlbWU6IHNldC1nbG9iYWwtdGhlbWUtdmFycygkdGhlbWUsICR0aGVtZS1uYW1lKTtcbiAgICAgIEBjb250ZW50O1xuICAgIH1cbiAgfVxufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IEFrdmVvLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLiBTZWUgTGljZW5zZS50eHQgaW4gdGhlIHByb2plY3Qgcm9vdCBmb3IgbGljZW5zZSBpbmZvcm1hdGlvbi5cbiAqL1xuLyoqXG4gKiBUaGlzIGlzIGEgc3RhcnRpbmcgcG9pbnQgd2hlcmUgd2UgZGVjbGFyZSB0aGUgbWFwcyBvZiB0aGVtZXMgYW5kIGdsb2JhbGx5IGF2YWlsYWJsZSBmdW5jdGlvbnMvbWl4aW5zXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogVGhpcyBtaXhpbiBnZW5lcmF0ZXMga2V5ZmFtZXMuXG4gKiBCZWNhdXNlIG9mIGFsbCBrZXlmcmFtZXMgY2FuJ3QgYmUgc2NvcGVkLFxuICogd2UgbmVlZCB0byBwdXRzIHVuaXF1ZSBuYW1lIGluIGVhY2ggYnRuLXB1bHNlIGNhbGwuXG4gKi9cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogVGhpcyBtaXhpbiBnZW5lcmF0ZXMga2V5ZmFtZXMuXG4gKiBCZWNhdXNlIG9mIGFsbCBrZXlmcmFtZXMgY2FuJ3QgYmUgc2NvcGVkLFxuICogd2UgbmVlZCB0byBwdXRzIHVuaXF1ZSBuYW1lIGluIGVhY2ggYnRuLXB1bHNlIGNhbGwuXG4gKi9cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogVGhpcyBtaXhpbiBnZW5lcmF0ZXMga2V5ZmFtZXMuXG4gKiBCZWNhdXNlIG9mIGFsbCBrZXlmcmFtZXMgY2FuJ3QgYmUgc2NvcGVkLFxuICogd2UgbmVlZCB0byBwdXRzIHVuaXF1ZSBuYW1lIGluIGVhY2ggYnRuLXB1bHNlIGNhbGwuXG4gKi9cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogVGhpcyBtaXhpbiBnZW5lcmF0ZXMga2V5ZmFtZXMuXG4gKiBCZWNhdXNlIG9mIGFsbCBrZXlmcmFtZXMgY2FuJ3QgYmUgc2NvcGVkLFxuICogd2UgbmVlZCB0byBwdXRzIHVuaXF1ZSBuYW1lIGluIGVhY2ggYnRuLXB1bHNlIGNhbGwuXG4gKi9cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogVGhpcyBtaXhpbiBnZW5lcmF0ZXMga2V5ZmFtZXMuXG4gKiBCZWNhdXNlIG9mIGFsbCBrZXlmcmFtZXMgY2FuJ3QgYmUgc2NvcGVkLFxuICogd2UgbmVlZCB0byBwdXRzIHVuaXF1ZSBuYW1lIGluIGVhY2ggYnRuLXB1bHNlIGNhbGwuXG4gKi9cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qKlxuICogVGhpcyBtaXhpbiBnZW5lcmF0ZXMga2V5ZmFtZXMuXG4gKiBCZWNhdXNlIG9mIGFsbCBrZXlmcmFtZXMgY2FuJ3QgYmUgc2NvcGVkLFxuICogd2UgbmVlZCB0byBwdXRzIHVuaXF1ZSBuYW1lIGluIGVhY2ggYnRuLXB1bHNlIGNhbGwuXG4gKi9cbi8qXG5cbkFjY29yZGluZyB0byB0aGUgc3BlY2lmaWNhdGlvbiAoaHR0cHM6Ly93d3cudzMub3JnL1RSL2Nzcy1zY29waW5nLTEvI2hvc3Qtc2VsZWN0b3IpXG46aG9zdCBhbmQgOmhvc3QtY29udGV4dCBhcmUgcHNldWRvLWNsYXNzZXMuIFNvIHdlIGFzc3VtZSB0aGV5IGNvdWxkIGJlIGNvbWJpbmVkLFxubGlrZSBvdGhlciBwc2V1ZG8tY2xhc3NlcywgZXZlbiBzYW1lIG9uZXMuXG5Gb3IgZXhhbXBsZTogJzpudGgtb2YtdHlwZSgybik6bnRoLW9mLXR5cGUoZXZlbiknLlxuXG5JZGVhbCBzb2x1dGlvbiB3b3VsZCBiZSB0byBwcmVwZW5kIGFueSBzZWxlY3RvciB3aXRoIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKS5cblRoZW4gbmVidWxhciBjb21wb25lbnRzIHdpbGwgYmVoYXZlIGFzIGFuIGh0bWwgZWxlbWVudCBhbmQgcmVzcG9uZCB0byBbZGlyXSBhdHRyaWJ1dGUgb24gYW55IGxldmVsLFxuc28gZGlyZWN0aW9uIGNvdWxkIGJlIG92ZXJyaWRkZW4gb24gYW55IGNvbXBvbmVudCBsZXZlbC5cblxuSW1wbGVtZW50YXRpb24gY29kZTpcblxuQG1peGluIG5iLXJ0bCgpIHtcbiAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gIEBhdC1yb290IHtzZWxlY3Rvci1hcHBlbmQoJzpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKScsICYpfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuQW5kIHdoZW4gd2UgY2FsbCBpdCBzb21ld2hlcmU6XG5cbjpob3N0IHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuOmhvc3QtY29udGV4dCguLi4pIHtcbiAgLnNvbWUtY2xhc3Mge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHtcbiAgICAgIC4uLlxuICAgIH1cbiAgfVxufVxuXG5SZXN1bHQgd2lsbCBsb29rIGxpa2U6XG5cbjpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0IC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgLnNvbWUtY2xhc3Mge1xuICAuLi5cbn1cblxuKlxuICBTaWRlIG5vdGU6XG4gIDpob3N0LWNvbnRleHQoKTpob3N0IHNlbGVjdG9yIGFyZSB2YWxpZC4gaHR0cHM6Ly9saXN0cy53My5vcmcvQXJjaGl2ZXMvUHVibGljL3d3dy1zdHlsZS8yMDE1RmViLzAzMDUuaHRtbFxuXG4gIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKTpob3N0LWNvbnRleHQoLi4uKSBzaG91bGQgbWF0Y2ggYW55IHBlcm11dGF0aW9uLFxuICBzbyBvcmRlciBpcyBub3QgaW1wb3J0YW50LlxuKlxuXG5cbkN1cnJlbnRseSwgdGhlcmUncmUgdHdvIHByb2JsZW1zIHdpdGggdGhpcyBhcHByb2FjaDpcblxuRmlyc3QsIGlzIHRoYXQgd2UgY2FuJ3QgY29tYmluZSA6aG9zdCwgOmhvc3QtY29udGV4dC4gQW5ndWxhciBidWdzICMxNDM0OSwgIzE5MTk5LlxuRm9yIHRoZSBtb21lbnQgb2Ygd3JpdGluZywgdGhlIG9ubHkgcG9zc2libGUgd2F5IGlzOlxuOmhvc3Qge1xuICA6aG9zdC1jb250ZXh0KC4uLikge1xuICAgIC4uLlxuICB9XG59XG5JdCBkb2Vzbid0IHdvcmsgZm9yIHVzIGJlY2F1c2UgbWl4aW4gY291bGQgYmUgY2FsbGVkIHNvbWV3aGVyZSBkZWVwZXIsIGxpa2U6XG46aG9zdCB7XG4gIHAge1xuICAgIEBpbmNsdWRlIG5iLXJ0bCgpIHsgLi4uIH1cbiAgfVxufVxuV2UgYXJlIG5vdCBhYmxlIHRvIGdvIHVwIHRvIDpob3N0IGxldmVsIHRvIHBsYWNlIGNvbnRlbnQgcGFzc2VkIHRvIG1peGluLlxuXG5UaGUgc2Vjb25kIHByb2JsZW0gaXMgdGhhdCB3ZSBvbmx5IGNhbiBiZSBzdXJlIHRoYXQgd2UgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byBhbm90aGVyXG46aG9zdC86aG9zdC1jb250ZXh0IHBzZXVkby1jbGFzcyB3aGVuIGNhbGxlZCBpbiB0aGVtZSBmaWxlcyAoKi50aGVtZS5zY3NzKS5cbiAgKlxuICAgIFNpZGUgbm90ZTpcbiAgICBDdXJyZW50bHksIG5iLWluc3RhbGwtY29tcG9uZW50IHVzZXMgYW5vdGhlciBhcHByb2FjaCB3aGVyZSA6aG9zdCBwcmVwZW5kZWQgd2l0aCB0aGUgdGhlbWUgbmFtZVxuICAgIChodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvNWI5NjA3ODYyNGIwYTQ3NjBmMmRiY2Y2ZmRmMGJkNjI3OTFiZTViYi9wYWNrYWdlcy9jb21waWxlci9zcmMvc2hhZG93X2Nzcy50cyNMNDQxKSxcbiAgICBidXQgaXQgd2FzIG1hZGUgdG8gYmUgYWJsZSB0byB1c2UgY3VycmVudCByZWFsaXphdGlvbiBvZiBydGwgYW5kIGl0IGNhbiBiZSByZXdyaXR0ZW4gYmFjayB0b1xuICAgIDpob3N0LWNvbnRleHQoJHRoZW1lKSBvbmNlIHdlIHdpbGwgYmUgYWJsZSB0byB1c2UgbXVsdGlwbGUgc2hhZG93IHNlbGVjdG9ycy5cbiAgKlxuQnV0IHdoZW4gaXQncyBjYWxsZWQgaW4gKi5jb21wb25lbnQuc2NzcyB3ZSBjYW4ndCBiZSBzdXJlLCB0aGF0IHNlbGVjdG9yIHN0YXJ0cyB3aXRoIDpob3N0Lzpob3N0LWNvbnRleHQsXG5iZWNhdXNlIGFuZ3VsYXIgYWxsb3dzIG9taXR0aW5nIHBzZXVkby1jbGFzc2VzIGlmIHdlIGRvbid0IG5lZWQgdG8gc3R5bGUgOmhvc3QgY29tcG9uZW50IGl0c2VsZi5cbldlIGNhbiBicmVhayBzdWNoIHNlbGVjdG9ycywgYnkganVzdCBhcHBlbmRpbmcgOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pIHRvIHRoZW0uXG4gICoqKlxuICAgIFBvc3NpYmxlIHNvbHV0aW9uXG4gICAgY2hlY2sgaWYgd2UgaW4gdGhlbWUgYnkgc29tZSB0aGVtZSB2YXJpYWJsZXMgYW5kIGlmIHNvIGFwcGVuZCwgb3RoZXJ3aXNlIG5lc3QgbGlrZVxuICAgIEBhdC1yb290IDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB7XG4gICAgICAvLyBhZGQgIyB0byBzY3NzIGludGVycG9sYXRpb24gc3RhdGVtZW50LlxuICAgICAgLy8gaXQgd29ya3MgaW4gY29tbWVudHMgYW5kIHdlIGNhbid0IHVzZSBpdCBoZXJlXG4gICAgICB7Jn0ge1xuICAgICAgICBAY29udGVudDtcbiAgICAgIH1cbiAgICB9XG4gICAgV2hhdCBpZiA6aG9zdCBzcGVjaWZpZWQ/IENhbiB3ZSBhZGQgc3BhY2UgaW4gOmhvc3QtY29udGV4dCguLi4pIDpob3N0P1xuICAgIE9yIG1heWJlIGFkZCA6aG9zdCBzZWxlY3RvciBhbnl3YXk/IElmIG11bHRpcGxlIDpob3N0IHNlbGVjdG9ycyBhcmUgYWxsb3dlZFxuICAqKipcblxuXG5Qcm9ibGVtcyB3aXRoIHRoZSBjdXJyZW50IGFwcHJvYWNoLlxuXG4xLiBEaXJlY3Rpb24gY2FuIGJlIGFwcGxpZWQgb25seSBvbiBkb2N1bWVudCBsZXZlbCwgYmVjYXVzZSBtaXhpbiBwcmVwZW5kcyB0aGVtZSBjbGFzcyxcbndoaWNoIHBsYWNlZCBvbiB0aGUgYm9keS5cbjIuICouY29tcG9uZW50LnNjc3Mgc3R5bGVzIHNob3VsZCBiZSBpbiA6aG9zdCBzZWxlY3Rvci4gT3RoZXJ3aXNlIGFuZ3VsYXIgd2lsbCBhZGQgaG9zdFxuYXR0cmlidXRlIHRvIFtkaXI9cnRsXSBhdHRyaWJ1dGUgYXMgd2VsbC5cblxuXG5HZW5lcmFsIHByb2JsZW1zLlxuXG5MdHIgaXMgZGVmYXVsdCBkb2N1bWVudCBkaXJlY3Rpb24sIGJ1dCBmb3IgcHJvcGVyIHdvcmsgb2YgbmItbHRyIChtZWFucyBsdHIgb25seSksXG5bZGlyPWx0cl0gc2hvdWxkIGJlIHNwZWNpZmllZCBhdCBsZWFzdCBzb21ld2hlcmUuICc6bm90KFtkaXI9cnRsXScgbm90IGFwcGxpY2FibGUgaGVyZSxcbmJlY2F1c2UgaXQncyBzYXRpc2Z5IGFueSBwYXJlbnQsIHRoYXQgZG9uJ3QgaGF2ZSBbZGlyPXJ0bF0gYXR0cmlidXRlLlxuUHJldmlvdXMgYXBwcm9hY2ggd2FzIHRvIHVzZSBzaW5nbGUgcnRsIG1peGluIGFuZCByZXNldCBsdHIgcHJvcGVydGllcyB0byBpbml0aWFsIHZhbHVlLlxuQnV0IHNvbWV0aW1lcyBpdCdzIGhhcmQgdG8gZmluZCwgd2hhdCB0aGUgcHJldmlvdXMgdmFsdWUgc2hvdWxkIGJlLiBBbmQgc3VjaCBtaXhpbiBjYWxsIGxvb2tzIHRvbyB2ZXJib3NlLlxuKi9cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cbi8qXG4gICAgICA6aG9zdCBjYW4gYmUgcHJlZml4ZWRcbiAgICAgIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi84ZDBlZTM0OTM5ZjE0YzA3ODc2ZDIyMmMyNWI0MDVlZDQ1OGEzNGQzL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDFcblxuICAgICAgV2UgaGF2ZSB0byB1c2UgOmhvc3QgaW5zdGVkIG9mIDpob3N0LWNvbnRleHQoJHRoZW1lKSwgdG8gYmUgYWJsZSB0byBwcmVmaXggdGhlbWUgY2xhc3NcbiAgICAgIHdpdGggc29tZXRoaW5nIGRlZmluZWQgaW5zaWRlIG9mIEBjb250ZW50LCBieSBwcmVmaXhpbmcgJi5cbiAgICAgIEZvciBleGFtcGxlIHRoaXMgc2NzcyBjb2RlOlxuICAgICAgICAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLnNvbWUtc2VsZWN0b3IgJiB7XG4gICAgICAgICAgICAuLi5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIFdpbGwgcmVzdWx0IGluIG5leHQgY3NzOlxuICAgICAgICAuc29tZS1zZWxlY3RvciAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLi4uXG4gICAgICAgIH1cblxuICAgICAgSXQgZG9lc24ndCB3b3JrIHdpdGggOmhvc3QtY29udGV4dCBiZWNhdXNlIGFuZ3VsYXIgc3BsaXR0aW5nIGl0IGluIHR3byBzZWxlY3RvcnMgYW5kIHJlbW92ZXNcbiAgICAgIHByZWZpeCBpbiBvbmUgb2YgdGhlIHNlbGVjdG9ycy5cbiAgICAqL1xuLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgLndiIHtcbiAgd29yZC1icmVhazogYnJlYWstYWxsICFpbXBvcnRhbnQ7IH1cblxuLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCB7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogNnJlbTtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG4gIGJveC1zaGFkb3c6IDAgMCAwIDAgI2RiZGJkYiwgbm9uZTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2Q1ZGJlMDtcbiAgYm9yZGVyLXRvcC1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLXRvcC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci10b3Atd2lkdGg6IDFweDtcbiAgYm9yZGVyLXJpZ2h0LWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItcmlnaHQtc3R5bGU6IHNvbGlkO1xuICBib3JkZXItcmlnaHQtd2lkdGg6IDFweDtcbiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDFweDtcbiAgYm9yZGVyLWxlZnQtY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci1sZWZ0LXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLWxlZnQtd2lkdGg6IDFweDtcbiAgYm9yZGVyLWltYWdlLXNvdXJjZTogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLXNsaWNlOiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2Utd2lkdGg6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1vdXRzZXQ6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1yZXBlYXQ6IGluaXRpYWw7IH1cbiAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbi1jb250YWluZXIge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBwYWRkaW5nOiAwLjYyNXJlbTsgfVxuICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkIC5pY29uIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgd2lkdGg6IDUuNzVyZW07XG4gICAgaGVpZ2h0OiA0Ljc1cmVtO1xuICAgIGZvbnQtc2l6ZTogMy43NXJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAwLjM3NXJlbTtcbiAgICB0cmFuc2l0aW9uOiB3aWR0aCAwLjRzIGVhc2U7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcbiAgICAtd2Via2l0LXRyYW5zZm9ybS1zdHlsZTogcHJlc2VydmUtM2Q7XG4gICAgLXdlYmtpdC1iYWNrZmFjZS12aXNpYmlsaXR5OiBoaWRkZW47XG4gICAgY29sb3I6ICNmZmZmZmY7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjYjU3ZmZmLCAjOGE3ZmZmKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgIzg5NmRkYiwgMCAwIDAgMCAjOWY3ZmZmOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbi5zdWNjZXNzIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzQwZGNiMiwgIzQwZGM3ZSk7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICMzN2JkODMsIDAgMCAwIDAgIzQwZGM5ODsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQgLmljb24uaW5mbyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM0Y2M0ZmYsICM0Y2E2ZmYpO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDAgMCAjNDE5Y2RiLCAwIDAgMCAwICM0Y2I1ZmY7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZjYzAwLCAjZmZhMTAwKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgI2RiOWQwMCwgMCAwIDAgMCAjZmZiNjAwOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbi5kYW5nZXIge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmY0Y2E2LCAjZmY0YzZhKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgI2RiNDE3NSwgMCAwIDAgMCAjZmY0Yzg4OyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICNiYmJlYzYsIDAgMCAwIDAgI2RhZGRlNjtcbiAgICAgIGNvbG9yOiAjYTRhYmIzOyB9XG4gIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQ6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6IHdoaXRlOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5wcmltYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2JmOTFmZiwgIzlhOTFmZik7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLnN1Y2Nlc3Mge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNWJlMWJkLCAjNWJlMTkwKTsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24uaW5mbyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICM2NWNjZmYsICM2NWIyZmYpOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi53YXJuaW5nIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmZDMyNCwgI2ZmYWUyNCk7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLmRhbmdlciB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiAnYnRuLWhlcm8tZGFuZ2VyLWxpZ2h0LWdyYWRpZW50KCknOyB9XG4gICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZGZlMGVhLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTQpKTsgfVxuICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkLm9mZiB7XG4gICAgY29sb3I6ICNhNGFiYjM7IH1cbiAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbiB7XG4gICAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAgICAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ucHJpbWFyeSwgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uc3VjY2VzcywgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uaW5mbywgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ud2FybmluZywgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uZGFuZ2VyIHtcbiAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCB0cmFuc3BhcmVudCwgdHJhbnNwYXJlbnQpOyB9XG4gICAgICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDsgfVxuICAgIC5uYi10aGVtZS1kZWZhdWx0IDpob3N0IG5iLWNhcmQub2ZmIC50aXRsZSB7XG4gICAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAubmItdGhlbWUtZGVmYXVsdCA6aG9zdCBuYi1jYXJkIC5kZXRhaWxzIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGJvcmRlci1sZWZ0OiAxcHggc29saWQgdHJhbnNwYXJlbnQ7IH1cbiAgICBbZGlyPWx0cl0gLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgICBwYWRkaW5nOiAwIDAuNXJlbSAwIDAuNzVyZW07IH1cbiAgICBbZGlyPXJ0bF0gLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgICBwYWRkaW5nOiAwIDAuNzVyZW0gMCAwLjVyZW07IH1cbiAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAudGl0bGUge1xuICAgIGZvbnQtZmFtaWx5OiBSb2JvdG87XG4gICAgZm9udC1zaXplOiAxLjI1cmVtO1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgY29sb3I6ICMyYTJhMmE7IH1cbiAgLm5iLXRoZW1lLWRlZmF1bHQgOmhvc3QgbmItY2FyZCAuc3RhdHVzIHtcbiAgICBmb250LXNpemU6IDFyZW07XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgIGNvbG9yOiAjYTRhYmIzOyB9XG5cbi8qXG4gICAgICA6aG9zdCBjYW4gYmUgcHJlZml4ZWRcbiAgICAgIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi84ZDBlZTM0OTM5ZjE0YzA3ODc2ZDIyMmMyNWI0MDVlZDQ1OGEzNGQzL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDFcblxuICAgICAgV2UgaGF2ZSB0byB1c2UgOmhvc3QgaW5zdGVkIG9mIDpob3N0LWNvbnRleHQoJHRoZW1lKSwgdG8gYmUgYWJsZSB0byBwcmVmaXggdGhlbWUgY2xhc3NcbiAgICAgIHdpdGggc29tZXRoaW5nIGRlZmluZWQgaW5zaWRlIG9mIEBjb250ZW50LCBieSBwcmVmaXhpbmcgJi5cbiAgICAgIEZvciBleGFtcGxlIHRoaXMgc2NzcyBjb2RlOlxuICAgICAgICAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLnNvbWUtc2VsZWN0b3IgJiB7XG4gICAgICAgICAgICAuLi5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIFdpbGwgcmVzdWx0IGluIG5leHQgY3NzOlxuICAgICAgICAuc29tZS1zZWxlY3RvciAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLi4uXG4gICAgICAgIH1cblxuICAgICAgSXQgZG9lc24ndCB3b3JrIHdpdGggOmhvc3QtY29udGV4dCBiZWNhdXNlIGFuZ3VsYXIgc3BsaXR0aW5nIGl0IGluIHR3byBzZWxlY3RvcnMgYW5kIHJlbW92ZXNcbiAgICAgIHByZWZpeCBpbiBvbmUgb2YgdGhlIHNlbGVjdG9ycy5cbiAgICAqL1xuLm5iLXRoZW1lLWNvc21pYyA6aG9zdCAud2Ige1xuICB3b3JkLWJyZWFrOiBicmVhay1hbGwgIWltcG9ydGFudDsgfVxuXG4ubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQge1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBoZWlnaHQ6IDZyZW07XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBib3gtc2hhZG93OiAwIDNweCAwIDAgIzM0MmY2ZSwgMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDVkYmUwO1xuICBib3JkZXItdG9wLWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXRvcC13aWR0aDogMXB4O1xuICBib3JkZXItcmlnaHQtY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci1yaWdodC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1yaWdodC13aWR0aDogMXB4O1xuICBib3JkZXItYm90dG9tLWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMXB4O1xuICBib3JkZXItbGVmdC1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLWxlZnQtc3R5bGU6IHNvbGlkO1xuICBib3JkZXItbGVmdC13aWR0aDogMXB4O1xuICBib3JkZXItaW1hZ2Utc291cmNlOiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2Utc2xpY2U6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS13aWR0aDogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLW91dHNldDogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLXJlcGVhdDogaW5pdGlhbDsgfVxuICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLmljb24tY29udGFpbmVyIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgcGFkZGluZzogMC42MjVyZW07IH1cbiAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgd2lkdGg6IDUuNzVyZW07XG4gICAgaGVpZ2h0OiA0Ljc1cmVtO1xuICAgIGZvbnQtc2l6ZTogMy43NXJlbTtcbiAgICBib3JkZXItcmFkaXVzOiAwLjVyZW07XG4gICAgdHJhbnNpdGlvbjogd2lkdGggMC40cyBlYXNlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xuICAgIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgIGNvbG9yOiAjZmZmZmZmOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjYWQ1OWZmLCAjNzY1OWZmKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgM3B4IDAgMCAjN2U0ZGRiLCAwIDJweCA4cHggMCAjOTI1OWZmLCAwIDRweCAxMHB4IDAgcmdiYSgzMywgNywgNzcsIDAuNSk7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLmljb24uc3VjY2VzcyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMwMGQ5YmYsICMwMGQ5NzcpO1xuICAgICAgYm94LXNoYWRvdzogMCAzcHggMCAwICMwMGJiODUsIDAgMnB4IDhweCAwICMwMGQ5OWIsIDAgNHB4IDEwcHggMCByZ2JhKDMzLCA3LCA3NywgMC41KTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuaWNvbi5pbmZvIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzAwYjNmZiwgIzAwODhmZik7XG4gICAgICBib3gtc2hhZG93OiAwIDNweCAwIDAgIzAwODdkYiwgMCAycHggOHB4IDAgIzAwOWRmZiwgMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZjYzAwLCAjZmZhMTAwKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgM3B4IDAgMCAjZGI5ZDAwLCAwIDJweCA4cHggMCAjZmZiNjAwLCAwIDRweCAxMHB4IDAgcmdiYSgzMywgNywgNzcsIDAuNSk7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLmljb24uZGFuZ2VyIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgI2ZmMzhhYywgI2ZmMzg2YSk7XG4gICAgICBib3gtc2hhZG93OiAwIDNweCAwIDAgI2RiMzA3OCwgMCAycHggOHB4IDAgI2ZmMzg4YiwgMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5pY29uLnNlY29uZGFyeSB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICAgIGJveC1zaGFkb3c6IDAgM3B4IDAgMCAjN2U0ZGRiLCAwIDJweCA4cHggMCAjOTI1OWZmLCAwIDRweCAxMHB4IDAgcmdiYSgzMywgNywgNzcsIDAuNSk7XG4gICAgICBjb2xvcjogI2ExYTFlNTsgfVxuICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQ6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6ICM0NjNmOTI7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24ucHJpbWFyeSB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNiOTcwZmYsICM4OTcwZmYpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLnN1Y2Nlc3Mge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMjRkZWM4LCAjMjRkZThhKTsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5pbmZvIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzI0YmRmZiwgIzI0OTlmZik7IH1cbiAgICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24ud2FybmluZyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZmQzMjQsICNmZmFlMjQpOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLmRhbmdlciB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiAnYnRuLWhlcm8tZGFuZ2VyLWxpZ2h0LWdyYWRpZW50KCknOyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLnNlY29uZGFyeSB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNiOTcwZmYsIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4xNCkpOyB9XG4gIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYge1xuICAgIGNvbG9yOiAjYTFhMWU1OyB9XG4gICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbiB7XG4gICAgICBjb2xvcjogI2ExYTFlNTsgfVxuICAgICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5wcmltYXJ5LCAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLnN1Y2Nlc3MsIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uaW5mbywgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi53YXJuaW5nLCAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLmRhbmdlciB7XG4gICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgdHJhbnNwYXJlbnQsIHRyYW5zcGFyZW50KTsgfVxuICAgICAgLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDsgfVxuICAgIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZC5vZmYgLnRpdGxlIHtcbiAgICAgIGNvbG9yOiAjYTFhMWU1OyB9XG4gIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHRyYW5zcGFyZW50OyB9XG4gICAgW2Rpcj1sdHJdIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgICBwYWRkaW5nOiAwIDAuNXJlbSAwIDAuNzVyZW07IH1cbiAgICBbZGlyPXJ0bF0gLm5iLXRoZW1lLWNvc21pYyA6aG9zdCBuYi1jYXJkIC5kZXRhaWxzIHtcbiAgICAgIHBhZGRpbmc6IDAgMC43NXJlbSAwIDAuNXJlbTsgfVxuICAubmItdGhlbWUtY29zbWljIDpob3N0IG5iLWNhcmQgLnRpdGxlIHtcbiAgICBmb250LWZhbWlseTogRXhvO1xuICAgIGZvbnQtc2l6ZTogMS4yNXJlbTtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjZmZmZmZmOyB9XG4gIC5uYi10aGVtZS1jb3NtaWMgOmhvc3QgbmItY2FyZCAuc3RhdHVzIHtcbiAgICBmb250LXNpemU6IDFyZW07XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgIGNvbG9yOiAjYTFhMWU1OyB9XG5cbi8qXG4gICAgICA6aG9zdCBjYW4gYmUgcHJlZml4ZWRcbiAgICAgIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi84ZDBlZTM0OTM5ZjE0YzA3ODc2ZDIyMmMyNWI0MDVlZDQ1OGEzNGQzL3BhY2thZ2VzL2NvbXBpbGVyL3NyYy9zaGFkb3dfY3NzLnRzI0w0NDFcblxuICAgICAgV2UgaGF2ZSB0byB1c2UgOmhvc3QgaW5zdGVkIG9mIDpob3N0LWNvbnRleHQoJHRoZW1lKSwgdG8gYmUgYWJsZSB0byBwcmVmaXggdGhlbWUgY2xhc3NcbiAgICAgIHdpdGggc29tZXRoaW5nIGRlZmluZWQgaW5zaWRlIG9mIEBjb250ZW50LCBieSBwcmVmaXhpbmcgJi5cbiAgICAgIEZvciBleGFtcGxlIHRoaXMgc2NzcyBjb2RlOlxuICAgICAgICAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLnNvbWUtc2VsZWN0b3IgJiB7XG4gICAgICAgICAgICAuLi5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIFdpbGwgcmVzdWx0IGluIG5leHQgY3NzOlxuICAgICAgICAuc29tZS1zZWxlY3RvciAubmItdGhlbWUtZGVmYXVsdCB7XG4gICAgICAgICAgLi4uXG4gICAgICAgIH1cblxuICAgICAgSXQgZG9lc24ndCB3b3JrIHdpdGggOmhvc3QtY29udGV4dCBiZWNhdXNlIGFuZ3VsYXIgc3BsaXR0aW5nIGl0IGluIHR3byBzZWxlY3RvcnMgYW5kIHJlbW92ZXNcbiAgICAgIHByZWZpeCBpbiBvbmUgb2YgdGhlIHNlbGVjdG9ycy5cbiAgICAqL1xuLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCAud2Ige1xuICB3b3JkLWJyZWFrOiBicmVhay1hbGwgIWltcG9ydGFudDsgfVxuXG4ubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQge1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBoZWlnaHQ6IDZyZW07XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBib3gtc2hhZG93OiAwIDAgMCAwICNkYmRiZGIsIG5vbmU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkNWRiZTA7XG4gIGJvcmRlci10b3AtY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci10b3Atc3R5bGU6IHNvbGlkO1xuICBib3JkZXItdG9wLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1yaWdodC1jb2xvcjogI2Q1ZGJlMDtcbiAgYm9yZGVyLXJpZ2h0LXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXJpZ2h0LXdpZHRoOiAxcHg7XG4gIGJvcmRlci1ib3R0b20tY29sb3I6ICNkNWRiZTA7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiAjZDVkYmUwO1xuICBib3JkZXItbGVmdC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1sZWZ0LXdpZHRoOiAxcHg7XG4gIGJvcmRlci1pbWFnZS1zb3VyY2U6IGluaXRpYWw7XG4gIGJvcmRlci1pbWFnZS1zbGljZTogaW5pdGlhbDtcbiAgYm9yZGVyLWltYWdlLXdpZHRoOiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2Utb3V0c2V0OiBpbml0aWFsO1xuICBib3JkZXItaW1hZ2UtcmVwZWF0OiBpbml0aWFsOyB9XG4gIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi1jb250YWluZXIge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBwYWRkaW5nOiAwLjYyNXJlbTsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogNS43NXJlbTtcbiAgICBoZWlnaHQ6IDQuNzVyZW07XG4gICAgZm9udC1zaXplOiAzLjc1cmVtO1xuICAgIGJvcmRlci1yYWRpdXM6IDAuMTdyZW07XG4gICAgdHJhbnNpdGlvbjogd2lkdGggMC40cyBlYXNlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm0tc3R5bGU6IHByZXNlcnZlLTNkO1xuICAgIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuO1xuICAgIGNvbG9yOiAjZmZmZmZmOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNzNhMWZmLCAjNzNhMWZmKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgIzYzOGFkYiwgMCAwIDIwcHggMCAjNzNhMWZmOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLnN1Y2Nlc3Mge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjNWRjZmUzLCAjNWRjZmUzKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgIzUwYjJjMywgMCAwIDIwcHggMCAjNWRjZmUzOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLmluZm8ge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjYmE3ZmVjLCAjYmE3ZmVjKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgI2EwNmRjYiwgMCAwIDIwcHggMCAjYmE3ZmVjOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZhMzZiLCAjZmZhMzZiKTtcbiAgICAgIGJveC1zaGFkb3c6IDAgMCAwIDAgI2RiOGM1YywgMCAwIDIwcHggMCAjZmZhMzZiOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLmRhbmdlciB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNmZjZiODMsICNmZjZiODMpO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDAgMCAjZGI1YzcxLCAwIDAgMjBweCAwICNmZjZiODM7IH1cbiAgICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlZGYyZjU7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMCAwICNjY2QwZDMsIDAgMCAwIDAgI2VkZjJmNTtcbiAgICAgIGNvbG9yOiAjYTRhYmIzOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLnByaW1hcnksIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi5zdWNjZXNzLCAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24uaW5mbywgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC5pY29uLndhcm5pbmcsIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi5kYW5nZXIsIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYm94LXNoYWRvdzogbm9uZTsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQ6aG92ZXIge1xuICAgIGJhY2tncm91bmQ6IHdoaXRlOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLnByaW1hcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjODdhZWZmLCAjODdhZWZmKTsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zdWNjZXNzIHtcbiAgICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgIzc0ZDZlNywgIzc0ZDZlNyk7IH1cbiAgICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQ6aG92ZXIgLmljb24uaW5mbyB7XG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICNjNDkxZWYsICNjNDkxZWYpOyB9XG4gICAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkOmhvdmVyIC5pY29uLndhcm5pbmcge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZmZiMDgwLCAjZmZiMDgwKTsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5kYW5nZXIge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogJ2J0bi1oZXJvLWRhbmdlci1saWdodC1ncmFkaWVudCgpJzsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZDpob3ZlciAuaWNvbi5zZWNvbmRhcnkge1xuICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjZjBmNGY2LCAjZjBmNGY2KTsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQub2ZmIHtcbiAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ge1xuICAgICAgY29sb3I6ICNhNGFiYjM7IH1cbiAgICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ucHJpbWFyeSwgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5zdWNjZXNzLCAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQub2ZmIC5pY29uLmluZm8sIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24ud2FybmluZywgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkLm9mZiAuaWNvbi5kYW5nZXIge1xuICAgICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIHRyYW5zcGFyZW50LCB0cmFuc3BhcmVudCk7IH1cbiAgICAgIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZC5vZmYgLmljb24uc2Vjb25kYXJ5IHtcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IH1cbiAgICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQub2ZmIC50aXRsZSB7XG4gICAgICBjb2xvcjogI2E0YWJiMzsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCB0cmFuc3BhcmVudDsgfVxuICAgIFtkaXI9bHRyXSAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmRldGFpbHMge1xuICAgICAgcGFkZGluZzogMCAwLjVyZW0gMCAwLjc1cmVtOyB9XG4gICAgW2Rpcj1ydGxdIC5uYi10aGVtZS1jb3Jwb3JhdGUgOmhvc3QgbmItY2FyZCAuZGV0YWlscyB7XG4gICAgICBwYWRkaW5nOiAwIDAuNzVyZW0gMCAwLjVyZW07IH1cbiAgLm5iLXRoZW1lLWNvcnBvcmF0ZSA6aG9zdCBuYi1jYXJkIC50aXRsZSB7XG4gICAgZm9udC1mYW1pbHk6IFJvYm90bztcbiAgICBmb250LXNpemU6IDEuMjVyZW07XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBjb2xvcjogIzE4MTgxODsgfVxuICAubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLnN0YXR1cyB7XG4gICAgZm9udC1zaXplOiAxcmVtO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICBjb2xvcjogI2E0YWJiMzsgfVxuXG4ubmItdGhlbWUtY29ycG9yYXRlIDpob3N0IG5iLWNhcmQgLmljb24tY29udGFpbmVyIHtcbiAgaGVpZ2h0OiBhdXRvOyB9XG5cbi8qICBAaW5jbHVkZSBuYi1mb3ItdGhlbWUoY29zbWljKSB7XHJcbiAgICBuYi1jYXJkIHtcclxuICAgICAgJi5vZmYgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICBAaW5jbHVkZSBuYi1sdHIoYm9yZGVyLXJpZ2h0LCAxcHggc29saWQgbmItdGhlbWUoc2VwYXJhdG9yKSk7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItcnRsKGJvcmRlci1sZWZ0LCAxcHggc29saWQgbmItdGhlbWUoc2VwYXJhdG9yKSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmRldGFpbHMge1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLWx0cihwYWRkaW5nLWxlZnQsIDEuMjVyZW0pO1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLXJ0bChwYWRkaW5nLXJpZ2h0LCAxLjI1cmVtKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmljb24ge1xyXG4gICAgICAgIHdpZHRoOiA3cmVtO1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICBmb250LXNpemU6IDQuNXJlbTtcclxuICAgICAgICBAaW5jbHVkZSBuYi1sdHIoYm9yZGVyLXJhZGl1cywgbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKSAwIDAgbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKSk7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItcnRsKGJvcmRlci1yYWRpdXMsIDAgbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKSBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpIDApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudGl0bGUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBuYi10aGVtZShmb250LXdlaWdodC1ib2xkZXIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuc3RhdHVzIHtcclxuICAgICAgICBmb250LXdlaWdodDogbmItdGhlbWUoZm9udC13ZWlnaHQtbGlnaHQpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSovXG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWt2ZW8uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuIFNlZSBMaWNlbnNlLnR4dCBpbiB0aGUgcHJvamVjdCByb290IGZvciBsaWNlbnNlIGluZm9ybWF0aW9uLlxuICovXG5cbkBtaXhpbiBuYi1zY3JvbGxiYXJzKCRmZywgJGJnLCAkc2l6ZSwgJGJvcmRlci1yYWRpdXM6ICRzaXplIC8gMikge1xuICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgICB3aWR0aDogJHNpemU7XG4gICAgaGVpZ2h0OiAkc2l6ZTtcbiAgfVxuXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xuICAgIGJhY2tncm91bmQ6ICRmZztcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogJGJvcmRlci1yYWRpdXM7XG4gIH1cblxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcbiAgICBiYWNrZ3JvdW5kOiAkYmc7XG4gIH1cblxuICAvLyBUT0RPOiByZW1vdmVcbiAgLy8gRm9yIEludGVybmV0IEV4cGxvcmVyXG4gIHNjcm9sbGJhci1mYWNlLWNvbG9yOiAkZmc7XG4gIHNjcm9sbGJhci10cmFjay1jb2xvcjogJGJnO1xufVxuXG5AbWl4aW4gbmItcmFkaWFsLWdyYWRpZW50KCRjb2xvci0xLCAkY29sb3ItMiwgJGNvbG9yLTMpIHtcbiAgYmFja2dyb3VuZDogJGNvbG9yLTI7IC8qIE9sZCBicm93c2VycyAqL1xuICBiYWNrZ3JvdW5kOiAtbW96LXJhZGlhbC1ncmFkaWVudChib3R0b20sIGVsbGlwc2UgY292ZXIsICRjb2xvci0xIDAlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICRjb2xvci0yIDQ1JSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAkY29sb3ItMyAxMDAlKTsgLyogRkYzLjYtMTUgKi9cbiAgYmFja2dyb3VuZDogLXdlYmtpdC1yYWRpYWwtZ3JhZGllbnQoYm90dG9tLCBlbGxpcHNlIGNvdmVyLCAkY29sb3ItMSAwJSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAkY29sb3ItMiA0NSUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJGNvbG9yLTMgMTAwJSk7IC8qIENocm9tZTEwLTI1LFNhZmFyaTUuMS02ICovXG4gIGJhY2tncm91bmQ6IHJhZGlhbC1ncmFkaWVudChlbGxpcHNlIGF0IGJvdHRvbSwgJGNvbG9yLTEgMCUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJGNvbG9yLTIgNDUlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICRjb2xvci0zIDEwMCUpOyAvKiBXM0MsIElFMTArLCBGRjE2KywgQ2hyb21lMjYrLCBPcGVyYTEyKywgU2FmYXJpNysgKi9cbiAgZmlsdGVyOiBwcm9naWQ6ZHhpbWFnZXRyYW5zZm9ybS5taWNyb3NvZnQuZ3JhZGllbnQoc3RhcnRDb2xvcnN0cj0nJGNvbG9yLTEnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRDb2xvcnN0cj0nJGNvbG9yLTMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcmFkaWVudFR5cGU9MSk7IC8qIElFNi05IGZhbGxiYWNrIG9uIGhvcml6b250YWwgZ3JhZGllbnQgKi9cbn1cblxuQG1peGluIG5iLXJpZ2h0LWdyYWRpZW50KCRsZWZ0LWNvbG9yLCAkcmlnaHQtY29sb3IpIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAkbGVmdC1jb2xvciwgJHJpZ2h0LWNvbG9yKTtcbn1cblxuQG1peGluIG5iLWhlYWRpbmdzKCRmcm9tOiAxLCAkdG86IDYpIHtcbiAgQGZvciAkaSBmcm9tICRmcm9tIHRocm91Z2ggJHRvIHtcbiAgICBoI3skaX0ge1xuICAgICAgbWFyZ2luOiAwO1xuICAgIH1cbiAgfVxufVxuXG5AbWl4aW4gaG92ZXItZm9jdXMtYWN0aXZlIHtcbiAgJjpmb2N1cyxcbiAgJjphY3RpdmUsXG4gICY6aG92ZXIge1xuICAgIEBjb250ZW50O1xuICB9XG59XG5cbkBtaXhpbiBjZW50ZXItaG9yaXpvbnRhbC1hYnNvbHV0ZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgMCk7XG4gIGxlZnQ6IDUwJTtcbn1cblxuQG1peGluIGluc3RhbGwtdGh1bWIoKSB7XG4gICR0aHVtYi1zZWxlY3RvcnM6IChcbiAgICAnOjotd2Via2l0LXNsaWRlci10aHVtYidcbiAgICAnOjotbW96LXJhbmdlLXRodW1iJ1xuICAgICc6Oi1tcy10aHVtYidcbiAgKTtcblxuICBAZWFjaCAkc2VsZWN0b3IgaW4gJHRodW1iLXNlbGVjdG9ycyB7XG4gICAgJiN7JHNlbGVjdG9yfSB7XG4gICAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICAtbW96LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICBAY29udGVudDtcbiAgICB9XG4gIH1cbn1cblxuQG1peGluIGluc3RhbGwtdHJhY2soKSB7XG4gICR0aHVtYi1zZWxlY3RvcnM6IChcbiAgICAnOjotd2Via2l0LXNsaWRlci1ydW5uYWJsZS10cmFjaydcbiAgICAnOjotbW96LXJhbmdlLXRyYWNrJ1xuICAgICc6Oi1tcy10cmFjaydcbiAgKTtcblxuICBAZWFjaCAkc2VsZWN0b3IgaW4gJHRodW1iLXNlbGVjdG9ycyB7XG4gICAgJiN7JHNlbGVjdG9yfSB7XG4gICAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICAtbW96LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgICBAY29udGVudDtcbiAgICB9XG4gIH1cbn1cblxuQG1peGluIGluc3RhbGwtcGxhY2Vob2xkZXIoJGNvbG9yLCAkZm9udC1zaXplKSB7XG4gICRwbGFjZWhvbGRlci1zZWxlY3RvcnM6IChcbiAgICAnOjotd2Via2l0LWlucHV0LXBsYWNlaG9sZGVyJ1xuICAgICc6Oi1tb3otcGxhY2Vob2xkZXInXG4gICAgJzotbW96LXBsYWNlaG9sZGVyJ1xuICAgICc6LW1zLWlucHV0LXBsYWNlaG9sZGVyJ1xuICApO1xuXG4gICY6OnBsYWNlaG9sZGVyIHtcbiAgICBAaW5jbHVkZSBwbGFjZWhvbGRlcigkY29sb3IsICRmb250LXNpemUpO1xuICB9XG5cbiAgQGVhY2ggJHNlbGVjdG9yIGluICRwbGFjZWhvbGRlci1zZWxlY3RvcnMge1xuICAgICYjeyRzZWxlY3Rvcn0ge1xuICAgICAgQGluY2x1ZGUgcGxhY2Vob2xkZXIoJGNvbG9yLCAkZm9udC1zaXplKTtcbiAgICB9XG5cbiAgICAmOmZvY3VzI3skc2VsZWN0b3J9IHtcbiAgICAgIEBpbmNsdWRlIHBsYWNlaG9sZGVyLWZvY3VzKCk7XG4gICAgfVxuICB9XG59XG5cbkBtaXhpbiBwbGFjZWhvbGRlcigkY29sb3IsICRmb250LXNpemUpIHtcbiAgY29sb3I6ICRjb2xvcjtcbiAgZm9udC1zaXplOiAkZm9udC1zaXplO1xuICBvcGFjaXR5OiAxO1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuM3MgZWFzZTtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG5cbkBtaXhpbiBwbGFjZWhvbGRlci1mb2N1cygpIHtcbiAgb3BhY2l0eTogMDtcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjNzIGVhc2U7XG59XG5cbkBtaXhpbiBhbmltYXRpb24oJGFuaW1hdGUuLi4pIHtcbiAgJG1heDogbGVuZ3RoKCRhbmltYXRlKTtcbiAgJGFuaW1hdGlvbnM6ICcnO1xuXG4gIEBmb3IgJGkgZnJvbSAxIHRocm91Z2ggJG1heCB7XG4gICAgJGFuaW1hdGlvbnM6ICN7JGFuaW1hdGlvbnMgKyBudGgoJGFuaW1hdGUsICRpKX07XG5cbiAgICBAaWYgJGkgPCAkbWF4IHtcbiAgICAgICRhbmltYXRpb25zOiAjeyRhbmltYXRpb25zICsgJywgJ307XG4gICAgfVxuICB9XG4gIC13ZWJraXQtYW5pbWF0aW9uOiAkYW5pbWF0aW9ucztcbiAgLW1vei1hbmltYXRpb246ICAgICRhbmltYXRpb25zO1xuICAtby1hbmltYXRpb246ICAgICAgJGFuaW1hdGlvbnM7XG4gIGFuaW1hdGlvbjogICAgICAgICAkYW5pbWF0aW9ucztcbn1cblxuQG1peGluIGtleWZyYW1lcygkYW5pbWF0aW9uTmFtZSkge1xuICBALXdlYmtpdC1rZXlmcmFtZXMgI3skYW5pbWF0aW9uTmFtZX0ge1xuICAgIEBjb250ZW50O1xuICB9XG4gIEAtbW96LWtleWZyYW1lcyAjeyRhbmltYXRpb25OYW1lfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbiAgQC1vLWtleWZyYW1lcyAjeyRhbmltYXRpb25OYW1lfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbiAgQGtleWZyYW1lcyAjeyRhbmltYXRpb25OYW1lfSB7XG4gICAgQGNvbnRlbnQ7XG4gIH1cbn1cblxuLyoqXG4gKiBUaGlzIG1peGluIGdlbmVyYXRlcyBrZXlmYW1lcy5cbiAqIEJlY2F1c2Ugb2YgYWxsIGtleWZyYW1lcyBjYW4ndCBiZSBzY29wZWQsXG4gKiB3ZSBuZWVkIHRvIHB1dHMgdW5pcXVlIG5hbWUgaW4gZWFjaCBidG4tcHVsc2UgY2FsbC5cbiAqL1xuQG1peGluIGJ0bi1wdWxzZSgkbmFtZSwgJGNvbG9yKSB7XG4gICYuYnRuLXB1bHNlIHtcbiAgICBAaW5jbHVkZSBhbmltYXRpb24oYnRuLSN7JG5hbWV9LXB1bHNlIDEuNXMgaW5maW5pdGUpO1xuICB9XG5cbiAgQGluY2x1ZGUga2V5ZnJhbWVzKGJ0bi0jeyRuYW1lfS1wdWxzZSkge1xuICAgIDAlIHtcbiAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgICBvcGFjaXR5OiBuYi10aGVtZShidG4tZGlzYWJsZWQtb3BhY2l0eSk7XG4gICAgfVxuICAgIDUwJSB7XG4gICAgICBib3gtc2hhZG93OiAwIDAgMXJlbSAwICRjb2xvcjtcbiAgICAgIG9wYWNpdHk6IDAuODtcbiAgICB9XG4gICAgMTAwJSB7XG4gICAgICBib3gtc2hhZG93OiBub25lO1xuICAgICAgb3BhY2l0eTogbmItdGhlbWUoYnRuLWRpc2FibGVkLW9wYWNpdHkpO1xuICAgIH1cbiAgfVxufVxuXG4vKlxuXG5BY2NvcmRpbmcgdG8gdGhlIHNwZWNpZmljYXRpb24gKGh0dHBzOi8vd3d3LnczLm9yZy9UUi9jc3Mtc2NvcGluZy0xLyNob3N0LXNlbGVjdG9yKVxuOmhvc3QgYW5kIDpob3N0LWNvbnRleHQgYXJlIHBzZXVkby1jbGFzc2VzLiBTbyB3ZSBhc3N1bWUgdGhleSBjb3VsZCBiZSBjb21iaW5lZCxcbmxpa2Ugb3RoZXIgcHNldWRvLWNsYXNzZXMsIGV2ZW4gc2FtZSBvbmVzLlxuRm9yIGV4YW1wbGU6ICc6bnRoLW9mLXR5cGUoMm4pOm50aC1vZi10eXBlKGV2ZW4pJy5cblxuSWRlYWwgc29sdXRpb24gd291bGQgYmUgdG8gcHJlcGVuZCBhbnkgc2VsZWN0b3Igd2l0aCA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkuXG5UaGVuIG5lYnVsYXIgY29tcG9uZW50cyB3aWxsIGJlaGF2ZSBhcyBhbiBodG1sIGVsZW1lbnQgYW5kIHJlc3BvbmQgdG8gW2Rpcl0gYXR0cmlidXRlIG9uIGFueSBsZXZlbCxcbnNvIGRpcmVjdGlvbiBjb3VsZCBiZSBvdmVycmlkZGVuIG9uIGFueSBjb21wb25lbnQgbGV2ZWwuXG5cbkltcGxlbWVudGF0aW9uIGNvZGU6XG5cbkBtaXhpbiBuYi1ydGwoKSB7XG4gIC8vIGFkZCAjIHRvIHNjc3MgaW50ZXJwb2xhdGlvbiBzdGF0ZW1lbnQuXG4gIC8vIGl0IHdvcmtzIGluIGNvbW1lbnRzIGFuZCB3ZSBjYW4ndCB1c2UgaXQgaGVyZVxuICBAYXQtcm9vdCB7c2VsZWN0b3ItYXBwZW5kKCc6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSknLCAmKX0ge1xuICAgIEBjb250ZW50O1xuICB9XG59XG5cbkFuZCB3aGVuIHdlIGNhbGwgaXQgc29tZXdoZXJlOlxuXG46aG9zdCB7XG4gIC5zb21lLWNsYXNzIHtcbiAgICBAaW5jbHVkZSBuYi1ydGwoKSB7XG4gICAgICAuLi5cbiAgICB9XG4gIH1cbn1cbjpob3N0LWNvbnRleHQoLi4uKSB7XG4gIC5zb21lLWNsYXNzIHtcbiAgICBAaW5jbHVkZSBuYi1ydGwoKSB7XG4gICAgICAuLi5cbiAgICB9XG4gIH1cbn1cblxuUmVzdWx0IHdpbGwgbG9vayBsaWtlOlxuXG46aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdCAuc29tZS1jbGFzcyB7XG4gIC4uLlxufVxuOmhvc3QtY29udGV4dChbZGlyPXJ0bF0pOmhvc3QtY29udGV4dCguLi4pIC5zb21lLWNsYXNzIHtcbiAgLi4uXG59XG5cbipcbiAgU2lkZSBub3RlOlxuICA6aG9zdC1jb250ZXh0KCk6aG9zdCBzZWxlY3RvciBhcmUgdmFsaWQuIGh0dHBzOi8vbGlzdHMudzMub3JnL0FyY2hpdmVzL1B1YmxpYy93d3ctc3R5bGUvMjAxNUZlYi8wMzA1Lmh0bWxcblxuICA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSk6aG9zdC1jb250ZXh0KC4uLikgc2hvdWxkIG1hdGNoIGFueSBwZXJtdXRhdGlvbixcbiAgc28gb3JkZXIgaXMgbm90IGltcG9ydGFudC5cbipcblxuXG5DdXJyZW50bHksIHRoZXJlJ3JlIHR3byBwcm9ibGVtcyB3aXRoIHRoaXMgYXBwcm9hY2g6XG5cbkZpcnN0LCBpcyB0aGF0IHdlIGNhbid0IGNvbWJpbmUgOmhvc3QsIDpob3N0LWNvbnRleHQuIEFuZ3VsYXIgYnVncyAjMTQzNDksICMxOTE5OS5cbkZvciB0aGUgbW9tZW50IG9mIHdyaXRpbmcsIHRoZSBvbmx5IHBvc3NpYmxlIHdheSBpczpcbjpob3N0IHtcbiAgOmhvc3QtY29udGV4dCguLi4pIHtcbiAgICAuLi5cbiAgfVxufVxuSXQgZG9lc24ndCB3b3JrIGZvciB1cyBiZWNhdXNlIG1peGluIGNvdWxkIGJlIGNhbGxlZCBzb21ld2hlcmUgZGVlcGVyLCBsaWtlOlxuOmhvc3Qge1xuICBwIHtcbiAgICBAaW5jbHVkZSBuYi1ydGwoKSB7IC4uLiB9XG4gIH1cbn1cbldlIGFyZSBub3QgYWJsZSB0byBnbyB1cCB0byA6aG9zdCBsZXZlbCB0byBwbGFjZSBjb250ZW50IHBhc3NlZCB0byBtaXhpbi5cblxuVGhlIHNlY29uZCBwcm9ibGVtIGlzIHRoYXQgd2Ugb25seSBjYW4gYmUgc3VyZSB0aGF0IHdlIGFwcGVuZGluZyA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkgdG8gYW5vdGhlclxuOmhvc3QvOmhvc3QtY29udGV4dCBwc2V1ZG8tY2xhc3Mgd2hlbiBjYWxsZWQgaW4gdGhlbWUgZmlsZXMgKCoudGhlbWUuc2NzcykuXG4gICpcbiAgICBTaWRlIG5vdGU6XG4gICAgQ3VycmVudGx5LCBuYi1pbnN0YWxsLWNvbXBvbmVudCB1c2VzIGFub3RoZXIgYXBwcm9hY2ggd2hlcmUgOmhvc3QgcHJlcGVuZGVkIHdpdGggdGhlIHRoZW1lIG5hbWVcbiAgICAoaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9ibG9iLzViOTYwNzg2MjRiMGE0NzYwZjJkYmNmNmZkZjBiZDYyNzkxYmU1YmIvcGFja2FnZXMvY29tcGlsZXIvc3JjL3NoYWRvd19jc3MudHMjTDQ0MSksXG4gICAgYnV0IGl0IHdhcyBtYWRlIHRvIGJlIGFibGUgdG8gdXNlIGN1cnJlbnQgcmVhbGl6YXRpb24gb2YgcnRsIGFuZCBpdCBjYW4gYmUgcmV3cml0dGVuIGJhY2sgdG9cbiAgICA6aG9zdC1jb250ZXh0KCR0aGVtZSkgb25jZSB3ZSB3aWxsIGJlIGFibGUgdG8gdXNlIG11bHRpcGxlIHNoYWRvdyBzZWxlY3RvcnMuXG4gICpcbkJ1dCB3aGVuIGl0J3MgY2FsbGVkIGluICouY29tcG9uZW50LnNjc3Mgd2UgY2FuJ3QgYmUgc3VyZSwgdGhhdCBzZWxlY3RvciBzdGFydHMgd2l0aCA6aG9zdC86aG9zdC1jb250ZXh0LFxuYmVjYXVzZSBhbmd1bGFyIGFsbG93cyBvbWl0dGluZyBwc2V1ZG8tY2xhc3NlcyBpZiB3ZSBkb24ndCBuZWVkIHRvIHN0eWxlIDpob3N0IGNvbXBvbmVudCBpdHNlbGYuXG5XZSBjYW4gYnJlYWsgc3VjaCBzZWxlY3RvcnMsIGJ5IGp1c3QgYXBwZW5kaW5nIDpob3N0LWNvbnRleHQoW2Rpcj1ydGxdKSB0byB0aGVtLlxuICAqKipcbiAgICBQb3NzaWJsZSBzb2x1dGlvblxuICAgIGNoZWNrIGlmIHdlIGluIHRoZW1lIGJ5IHNvbWUgdGhlbWUgdmFyaWFibGVzIGFuZCBpZiBzbyBhcHBlbmQsIG90aGVyd2lzZSBuZXN0IGxpa2VcbiAgICBAYXQtcm9vdCA6aG9zdC1jb250ZXh0KFtkaXI9cnRsXSkge1xuICAgICAgLy8gYWRkICMgdG8gc2NzcyBpbnRlcnBvbGF0aW9uIHN0YXRlbWVudC5cbiAgICAgIC8vIGl0IHdvcmtzIGluIGNvbW1lbnRzIGFuZCB3ZSBjYW4ndCB1c2UgaXQgaGVyZVxuICAgICAgeyZ9IHtcbiAgICAgICAgQGNvbnRlbnQ7XG4gICAgICB9XG4gICAgfVxuICAgIFdoYXQgaWYgOmhvc3Qgc3BlY2lmaWVkPyBDYW4gd2UgYWRkIHNwYWNlIGluIDpob3N0LWNvbnRleHQoLi4uKSA6aG9zdD9cbiAgICBPciBtYXliZSBhZGQgOmhvc3Qgc2VsZWN0b3IgYW55d2F5PyBJZiBtdWx0aXBsZSA6aG9zdCBzZWxlY3RvcnMgYXJlIGFsbG93ZWRcbiAgKioqXG5cblxuUHJvYmxlbXMgd2l0aCB0aGUgY3VycmVudCBhcHByb2FjaC5cblxuMS4gRGlyZWN0aW9uIGNhbiBiZSBhcHBsaWVkIG9ubHkgb24gZG9jdW1lbnQgbGV2ZWwsIGJlY2F1c2UgbWl4aW4gcHJlcGVuZHMgdGhlbWUgY2xhc3MsXG53aGljaCBwbGFjZWQgb24gdGhlIGJvZHkuXG4yLiAqLmNvbXBvbmVudC5zY3NzIHN0eWxlcyBzaG91bGQgYmUgaW4gOmhvc3Qgc2VsZWN0b3IuIE90aGVyd2lzZSBhbmd1bGFyIHdpbGwgYWRkIGhvc3RcbmF0dHJpYnV0ZSB0byBbZGlyPXJ0bF0gYXR0cmlidXRlIGFzIHdlbGwuXG5cblxuR2VuZXJhbCBwcm9ibGVtcy5cblxuTHRyIGlzIGRlZmF1bHQgZG9jdW1lbnQgZGlyZWN0aW9uLCBidXQgZm9yIHByb3BlciB3b3JrIG9mIG5iLWx0ciAobWVhbnMgbHRyIG9ubHkpLFxuW2Rpcj1sdHJdIHNob3VsZCBiZSBzcGVjaWZpZWQgYXQgbGVhc3Qgc29tZXdoZXJlLiAnOm5vdChbZGlyPXJ0bF0nIG5vdCBhcHBsaWNhYmxlIGhlcmUsXG5iZWNhdXNlIGl0J3Mgc2F0aXNmeSBhbnkgcGFyZW50LCB0aGF0IGRvbid0IGhhdmUgW2Rpcj1ydGxdIGF0dHJpYnV0ZS5cblByZXZpb3VzIGFwcHJvYWNoIHdhcyB0byB1c2Ugc2luZ2xlIHJ0bCBtaXhpbiBhbmQgcmVzZXQgbHRyIHByb3BlcnRpZXMgdG8gaW5pdGlhbCB2YWx1ZS5cbkJ1dCBzb21ldGltZXMgaXQncyBoYXJkIHRvIGZpbmQsIHdoYXQgdGhlIHByZXZpb3VzIHZhbHVlIHNob3VsZCBiZS4gQW5kIHN1Y2ggbWl4aW4gY2FsbCBsb29rcyB0b28gdmVyYm9zZS5cbiovXG5cbkBtaXhpbiBfcHJlcGVuZC13aXRoLXNlbGVjdG9yKCRzZWxlY3RvciwgJHByb3A6IG51bGwsICR2YWx1ZTogbnVsbCkge1xuICAjeyRzZWxlY3Rvcn0gJiB7XG4gICAgQGlmICRwcm9wICE9IG51bGwge1xuICAgICAgI3skcHJvcH06ICR2YWx1ZTtcbiAgICB9XG5cbiAgICBAY29udGVudDtcbiAgfVxufVxuXG5AbWl4aW4gbmItbHRyKCRwcm9wOiBudWxsLCAkdmFsdWU6IG51bGwpIHtcbiAgQGluY2x1ZGUgX3ByZXBlbmQtd2l0aC1zZWxlY3RvcignW2Rpcj1sdHJdJywgJHByb3AsICR2YWx1ZSkge1xuICAgIEBjb250ZW50O1xuICB9XG59XG5cbkBtaXhpbiBuYi1ydGwoJHByb3A6IG51bGwsICR2YWx1ZTogbnVsbCkge1xuICBAaW5jbHVkZSBfcHJlcGVuZC13aXRoLXNlbGVjdG9yKCdbZGlyPXJ0bF0nLCAkcHJvcCwgJHZhbHVlKSB7XG4gICAgQGNvbnRlbnQ7XG4gIH07XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWt2ZW8uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuIFNlZSBMaWNlbnNlLnR4dCBpbiB0aGUgcHJvamVjdCByb290IGZvciBsaWNlbnNlIGluZm9ybWF0aW9uLlxuICovXG5cbi8vLyBTbGlnaHRseSBsaWdodGVuIGEgY29sb3Jcbi8vLyBAYWNjZXNzIHB1YmxpY1xuLy8vIEBwYXJhbSB7Q29sb3J9ICRjb2xvciAtIGNvbG9yIHRvIHRpbnRcbi8vLyBAcGFyYW0ge051bWJlcn0gJHBlcmNlbnRhZ2UgLSBwZXJjZW50YWdlIG9mIGAkY29sb3JgIGluIHJldHVybmVkIGNvbG9yXG4vLy8gQHJldHVybiB7Q29sb3J9XG5AZnVuY3Rpb24gdGludCgkY29sb3IsICRwZXJjZW50YWdlKSB7XG4gIEByZXR1cm4gbWl4KHdoaXRlLCAkY29sb3IsICRwZXJjZW50YWdlKTtcbn1cblxuLy8vIFNsaWdodGx5IGRhcmtlbiBhIGNvbG9yXG4vLy8gQGFjY2VzcyBwdWJsaWNcbi8vLyBAcGFyYW0ge0NvbG9yfSAkY29sb3IgLSBjb2xvciB0byBzaGFkZVxuLy8vIEBwYXJhbSB7TnVtYmVyfSAkcGVyY2VudGFnZSAtIHBlcmNlbnRhZ2Ugb2YgYCRjb2xvcmAgaW4gcmV0dXJuZWQgY29sb3Jcbi8vLyBAcmV0dXJuIHtDb2xvcn1cbkBmdW5jdGlvbiBzaGFkZSgkY29sb3IsICRwZXJjZW50YWdlKSB7XG4gIEByZXR1cm4gbWl4KGJsYWNrLCAkY29sb3IsICRwZXJjZW50YWdlKTtcbn1cblxuQGZ1bmN0aW9uIG1hcC1zZXQoJG1hcCwgJGtleSwgJHZhbHVlOiBudWxsKSB7XG4gICRuZXc6ICgka2V5OiAkdmFsdWUpO1xuICBAcmV0dXJuIG1hcC1tZXJnZSgkbWFwLCAkbmV3KTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuQGltcG9ydCAnLi4vY29yZS9mdW5jdGlvbnMnO1xuQGltcG9ydCAnLi4vY29yZS9taXhpbnMnO1xuXG4kdGhlbWU6IChcbiAgZm9udC1tYWluOiB1bnF1b3RlKCdcIlNlZ29lIFVJXCIsIFJvYm90bywgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBBcmlhbCwgc2Fucy1zZXJpZicpLFxuICBmb250LXNlY29uZGFyeTogZm9udC1tYWluLFxuXG4gIGZvbnQtd2VpZ2h0LXRoaW46IDIwMCxcbiAgZm9udC13ZWlnaHQtbGlnaHQ6IDMwMCxcbiAgZm9udC13ZWlnaHQtbm9ybWFsOiA0MDAsXG4gIGZvbnQtd2VpZ2h0LWJvbGRlcjogNTAwLFxuICBmb250LXdlaWdodC1ib2xkOiA2MDAsXG4gIGZvbnQtd2VpZ2h0LXVsdHJhLWJvbGQ6IDgwMCxcblxuICAvLyBUT0RPOiB1c2UgaXQgYXMgYSBkZWZhdWx0IGZvbnQtc2l6ZVxuICBiYXNlLWZvbnQtc2l6ZTogMTZweCxcblxuICBmb250LXNpemUteGxnOiAxLjI1cmVtLFxuICBmb250LXNpemUtbGc6IDEuMTI1cmVtLFxuICBmb250LXNpemU6IDFyZW0sXG4gIGZvbnQtc2l6ZS1zbTogMC44NzVyZW0sXG4gIGZvbnQtc2l6ZS14czogMC43NXJlbSxcblxuICByYWRpdXM6IDAuMzc1cmVtLFxuICBwYWRkaW5nOiAxLjI1cmVtLFxuICBtYXJnaW46IDEuNXJlbSxcbiAgbGluZS1oZWlnaHQ6IDEuMjUsXG5cbiAgY29sb3ItYmc6ICNmZmZmZmYsXG4gIGNvbG9yLWJnLWFjdGl2ZTogI2U5ZWRmMixcbiAgY29sb3ItZmc6ICNhNGFiYjMsXG4gIGNvbG9yLWZnLWhlYWRpbmc6ICMyYTJhMmEsXG4gIGNvbG9yLWZnLXRleHQ6ICM0YjRiNGIsXG4gIGNvbG9yLWZnLWhpZ2hsaWdodDogIzQwZGM3ZSxcblxuICBzZXBhcmF0b3I6ICNlYmVlZjIsXG5cbiAgY29sb3ItZ3JheTogcmdiYSg4MSwgMTEzLCAxNjUsIDAuMTUpLFxuICBjb2xvci1uZXV0cmFsOiB0cmFuc3BhcmVudCxcbiAgY29sb3Itd2hpdGU6ICNmZmZmZmYsXG4gIGNvbG9yLWRpc2FibGVkOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNCksXG5cbiAgY29sb3ItcHJpbWFyeTogIzhhN2ZmZixcbiAgY29sb3Itc3VjY2VzczogIzQwZGM3ZSxcbiAgY29sb3ItaW5mbzogIzRjYTZmZixcbiAgY29sb3Itd2FybmluZzogI2ZmYTEwMCxcbiAgY29sb3ItZGFuZ2VyOiAjZmY0YzZhLFxuXG4gIC8vIFRPRE86IG1vdmUgdG8gY29uc3RhbnRzXG4gIHNvY2lhbC1jb2xvci1mYWNlYm9vazogIzNiNTk5OCxcbiAgc29jaWFsLWNvbG9yLXR3aXR0ZXI6ICM1NWFjZWUsXG4gIHNvY2lhbC1jb2xvci1nb29nbGU6ICNkZDRiMzksXG4gIHNvY2lhbC1jb2xvci1saW5rZWRpbjogIzAxNzdiNSxcbiAgc29jaWFsLWNvbG9yLWdpdGh1YjogIzZiNmI2YixcbiAgc29jaWFsLWNvbG9yLXN0YWNrb3ZlcmZsb3c6ICMyZjk2ZTgsXG4gIHNvY2lhbC1jb2xvci1kcmliYmxlOiAjZjI2Nzk4LFxuICBzb2NpYWwtY29sb3ItYmVoYW5jZTogIzAwOTNmYSxcblxuICBib3JkZXItY29sb3I6IGNvbG9yLWdyYXksXG4gIHNoYWRvdzogMCAycHggMTJweCAwICNkZmUzZWIsXG5cbiAgbGluay1jb2xvcjogIzNkY2M2ZCxcbiAgbGluay1jb2xvci1ob3ZlcjogIzJlZTU2YixcbiAgbGluay1jb2xvci12aXNpdGVkOiBsaW5rLWNvbG9yLFxuXG4gIHNjcm9sbGJhci1mZzogI2RhZGFkYSxcbiAgc2Nyb2xsYmFyLWJnOiAjZjJmMmYyLFxuICBzY3JvbGxiYXItd2lkdGg6IDVweCxcbiAgc2Nyb2xsYmFyLXRodW1iLXJhZGl1czogMi41cHgsXG5cbiAgcmFkaWFsLWdyYWRpZW50OiBub25lLFxuICBsaW5lYXItZ3JhZGllbnQ6IG5vbmUsXG5cbiAgY2FyZC1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgY2FyZC1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIGNhcmQtZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LW5vcm1hbCxcbiAgY2FyZC1mZzogY29sb3ItZmcsIC8vIFRPRE86IG5vdCB1c2VkXG4gIGNhcmQtZmctdGV4dDogY29sb3ItZmctdGV4dCxcbiAgY2FyZC1mZy1oZWFkaW5nOiBjb2xvci1mZy1oZWFkaW5nLCAvLyBUT0RPOiBub3QgdXNlZFxuICBjYXJkLWJnOiBjb2xvci1iZyxcbiAgY2FyZC1oZWlnaHQteHhzbWFsbDogOTZweCxcbiAgY2FyZC1oZWlnaHQteHNtYWxsOiAyMTZweCxcbiAgY2FyZC1oZWlnaHQtc21hbGw6IDMzNnB4LFxuICBjYXJkLWhlaWdodC1tZWRpdW06IDQ1NnB4LFxuICBjYXJkLWhlaWdodC1sYXJnZTogNTc2cHgsXG4gIGNhcmQtaGVpZ2h0LXhsYXJnZTogNjk2cHgsXG4gIGNhcmQtaGVpZ2h0LXh4bGFyZ2U6IDgxNnB4LFxuICBjYXJkLXNoYWRvdzogc2hhZG93LFxuICBjYXJkLWJvcmRlci13aWR0aDogMCxcbiAgY2FyZC1ib3JkZXItdHlwZTogc29saWQsXG4gIGNhcmQtYm9yZGVyLWNvbG9yOiBjb2xvci1iZyxcbiAgY2FyZC1ib3JkZXItcmFkaXVzOiByYWRpdXMsXG4gIGNhcmQtcGFkZGluZzogcGFkZGluZyxcbiAgY2FyZC1tYXJnaW46IG1hcmdpbixcbiAgY2FyZC1oZWFkZXItZm9udC1mYW1pbHk6IGZvbnQtc2Vjb25kYXJ5LFxuICBjYXJkLWhlYWRlci1mb250LXNpemU6IGZvbnQtc2l6ZS1sZyxcbiAgY2FyZC1oZWFkZXItZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LWJvbGQsXG4gIGNhcmQtc2VwYXJhdG9yOiBzZXBhcmF0b3IsXG4gIGNhcmQtaGVhZGVyLWZnOiBjb2xvci1mZywgLy8gVE9ETzogbm90IHVzZWRcbiAgY2FyZC1oZWFkZXItZmctaGVhZGluZzogY29sb3ItZmctaGVhZGluZyxcbiAgY2FyZC1oZWFkZXItYWN0aXZlLWJnOiBjb2xvci1mZyxcbiAgY2FyZC1oZWFkZXItYWN0aXZlLWZnOiBjb2xvci1iZyxcbiAgY2FyZC1oZWFkZXItZGlzYWJsZWQtYmc6IGNvbG9yLWRpc2FibGVkLFxuICBjYXJkLWhlYWRlci1wcmltYXJ5LWJnOiBjb2xvci1wcmltYXJ5LFxuICBjYXJkLWhlYWRlci1pbmZvLWJnOiBjb2xvci1pbmZvLFxuICBjYXJkLWhlYWRlci1zdWNjZXNzLWJnOiBjb2xvci1zdWNjZXNzLFxuICBjYXJkLWhlYWRlci13YXJuaW5nLWJnOiBjb2xvci13YXJuaW5nLFxuICBjYXJkLWhlYWRlci1kYW5nZXItYmc6IGNvbG9yLWRhbmdlcixcbiAgY2FyZC1oZWFkZXItYm9yZGVyLXdpZHRoOiAxcHgsXG4gIGNhcmQtaGVhZGVyLWJvcmRlci10eXBlOiBzb2xpZCxcbiAgY2FyZC1oZWFkZXItYm9yZGVyLWNvbG9yOiBjYXJkLXNlcGFyYXRvcixcblxuICBoZWFkZXItZm9udC1mYW1pbHk6IGZvbnQtc2Vjb25kYXJ5LFxuICBoZWFkZXItZm9udC1zaXplOiBmb250LXNpemUsXG4gIGhlYWRlci1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIGhlYWRlci1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgaGVhZGVyLWJnOiBjb2xvci1iZyxcbiAgaGVhZGVyLWhlaWdodDogNC43NXJlbSxcbiAgaGVhZGVyLXBhZGRpbmc6IDEuMjVyZW0sXG4gIGhlYWRlci1zaGFkb3c6IHNoYWRvdyxcblxuICBmb290ZXItaGVpZ2h0OiA0LjcyNXJlbSxcbiAgZm9vdGVyLXBhZGRpbmc6IDEuMjVyZW0sXG4gIGZvb3Rlci1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgZm9vdGVyLWZnLWhpZ2hsaWdodDogY29sb3ItZmctaGVhZGluZyxcbiAgZm9vdGVyLWJnOiBjb2xvci1iZyxcbiAgZm9vdGVyLXNlcGFyYXRvcjogc2VwYXJhdG9yLFxuICBmb290ZXItc2hhZG93OiBzaGFkb3csXG5cbiAgbGF5b3V0LWZvbnQtZmFtaWx5OiBmb250LW1haW4sXG4gIGxheW91dC1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgbGF5b3V0LWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgbGF5b3V0LWZnOiBjb2xvci1mZyxcbiAgbGF5b3V0LWJnOiAjZWJlZmY1LFxuICBsYXlvdXQtbWluLWhlaWdodDogMTAwdmgsXG4gIGxheW91dC1jb250ZW50LXdpZHRoOiA5MDBweCxcbiAgbGF5b3V0LXdpbmRvdy1tb2RlLW1pbi13aWR0aDogMzAwcHgsXG4gIGxheW91dC13aW5kb3ctbW9kZS1tYXgtd2lkdGg6IDE5MjBweCxcbiAgbGF5b3V0LXdpbmRvdy1tb2RlLWJnOiBsYXlvdXQtYmcsXG4gIGxheW91dC13aW5kb3ctbW9kZS1wYWRkaW5nLXRvcDogNC43NXJlbSxcbiAgbGF5b3V0LXdpbmRvdy1zaGFkb3c6IHNoYWRvdyxcbiAgbGF5b3V0LXBhZGRpbmc6IDIuMjVyZW0gMi4yNXJlbSAwLjc1cmVtLFxuICBsYXlvdXQtbWVkaXVtLXBhZGRpbmc6IDEuNXJlbSAxLjVyZW0gMC41cmVtLFxuICBsYXlvdXQtc21hbGwtcGFkZGluZzogMXJlbSAxcmVtIDAsXG5cbiAgc2lkZWJhci1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgc2lkZWJhci1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIHNpZGViYXItZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIHNpZGViYXItYmc6IGNvbG9yLWJnLFxuICBzaWRlYmFyLWhlaWdodDogMTAwdmgsXG4gIHNpZGViYXItd2lkdGg6IDE2cmVtLFxuICBzaWRlYmFyLXdpZHRoLWNvbXBhY3Q6IDMuNXJlbSxcbiAgc2lkZWJhci1wYWRkaW5nOiBwYWRkaW5nLFxuICBzaWRlYmFyLWhlYWRlci1oZWlnaHQ6IDMuNXJlbSxcbiAgc2lkZWJhci1mb290ZXItaGVpZ2h0OiAzLjVyZW0sXG4gIHNpZGViYXItc2hhZG93OiBzaGFkb3csXG5cbiAgbWVudS1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIG1lbnUtZm9udC1zaXplOiBmb250LXNpemUsXG4gIG1lbnUtZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LWJvbGRlcixcbiAgbWVudS1mZzogY29sb3ItZmctdGV4dCxcbiAgbWVudS1iZzogY29sb3ItYmcsXG4gIG1lbnUtYWN0aXZlLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBtZW51LWFjdGl2ZS1iZzogY29sb3ItYmcsXG4gIG1lbnUtYWN0aXZlLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkLFxuXG4gIG1lbnUtc3VibWVudS1iZzogY29sb3ItYmcsXG4gIG1lbnUtc3VibWVudS1mZzogY29sb3ItZmctdGV4dCxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1iZzogY29sb3ItYmcsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtYm9yZGVyLWNvbG9yOiBjb2xvci1mZy1oaWdobGlnaHQsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtc2hhZG93OiBub25lLFxuICBtZW51LXN1Ym1lbnUtaG92ZXItZmc6IG1lbnUtc3VibWVudS1hY3RpdmUtZmcsXG4gIG1lbnUtc3VibWVudS1ob3Zlci1iZzogbWVudS1zdWJtZW51LWJnLFxuICBtZW51LXN1Ym1lbnUtaXRlbS1ib3JkZXItd2lkdGg6IDAuMTI1cmVtLFxuICBtZW51LXN1Ym1lbnUtaXRlbS1ib3JkZXItcmFkaXVzOiByYWRpdXMsXG4gIG1lbnUtc3VibWVudS1pdGVtLXBhZGRpbmc6IDAuNXJlbSAxcmVtLFxuICBtZW51LXN1Ym1lbnUtaXRlbS1jb250YWluZXItcGFkZGluZzogMCAxLjI1cmVtLFxuICBtZW51LXN1Ym1lbnUtcGFkZGluZzogMC41cmVtLFxuXG4gIG1lbnUtZ3JvdXAtZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LWJvbGRlcixcbiAgbWVudS1ncm91cC1mb250LXNpemU6IDAuODc1cmVtLFxuICBtZW51LWdyb3VwLWZnOiBjb2xvci1mZyxcbiAgbWVudS1ncm91cC1wYWRkaW5nOiAxcmVtIDEuMjVyZW0sXG4gIG1lbnUtaXRlbS1wYWRkaW5nOiAwLjY3NXJlbSAwLjc1cmVtLFxuICBtZW51LWl0ZW0tc2VwYXJhdG9yOiBzZXBhcmF0b3IsXG4gIG1lbnUtaWNvbi1mb250LXNpemU6IDIuNXJlbSxcbiAgbWVudS1pY29uLW1hcmdpbjogMCAwLjI1cmVtIDAsXG4gIG1lbnUtaWNvbi1jb2xvcjogY29sb3ItZmcsXG4gIG1lbnUtaWNvbi1hY3RpdmUtY29sb3I6IGNvbG9yLWZnLWhlYWRpbmcsXG5cbiAgdGFicy1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIHRhYnMtZm9udC1zaXplOiBmb250LXNpemUtbGcsXG4gIHRhYnMtY29udGVudC1mb250LWZhbWlseTogZm9udC1tYWluLFxuICB0YWJzLWNvbnRlbnQtZm9udC1zaXplOiBmb250LXNpemUsXG4gIHRhYnMtYWN0aXZlLWJnOiB0cmFuc3BhcmVudCxcbiAgdGFicy1hY3RpdmUtZm9udC13ZWlnaHQ6IGNhcmQtaGVhZGVyLWZvbnQtd2VpZ2h0LFxuICB0YWJzLXBhZGRpbmc6IHBhZGRpbmcsXG4gIHRhYnMtY29udGVudC1wYWRkaW5nOiAwLFxuICB0YWJzLWhlYWRlci1iZzogdHJhbnNwYXJlbnQsXG4gIHRhYnMtc2VwYXJhdG9yOiBzZXBhcmF0b3IsXG4gIHRhYnMtZmc6IGNvbG9yLWZnLFxuICB0YWJzLWZnLXRleHQ6IGNvbG9yLWZnLXRleHQsXG4gIHRhYnMtZmctaGVhZGluZzogY29sb3ItZmctaGVhZGluZyxcbiAgdGFicy1iZzogdHJhbnNwYXJlbnQsXG4gIHRhYnMtc2VsZWN0ZWQ6IGNvbG9yLXN1Y2Nlc3MsXG5cbiAgcm91dGUtdGFicy1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIHJvdXRlLXRhYnMtZm9udC1zaXplOiBmb250LXNpemUtbGcsXG4gIHJvdXRlLXRhYnMtYWN0aXZlLWJnOiB0cmFuc3BhcmVudCxcbiAgcm91dGUtdGFicy1hY3RpdmUtZm9udC13ZWlnaHQ6IGNhcmQtaGVhZGVyLWZvbnQtd2VpZ2h0LFxuICByb3V0ZS10YWJzLXBhZGRpbmc6IHBhZGRpbmcsXG4gIHJvdXRlLXRhYnMtaGVhZGVyLWJnOiB0cmFuc3BhcmVudCxcbiAgcm91dGUtdGFicy1zZXBhcmF0b3I6IHNlcGFyYXRvcixcbiAgcm91dGUtdGFicy1mZzogY29sb3ItZmcsXG4gIHJvdXRlLXRhYnMtZmctaGVhZGluZzogY29sb3ItZmctaGVhZGluZyxcbiAgcm91dGUtdGFicy1iZzogdHJhbnNwYXJlbnQsXG4gIHJvdXRlLXRhYnMtc2VsZWN0ZWQ6IGNvbG9yLXN1Y2Nlc3MsXG5cbiAgdXNlci1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgdXNlci1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIHVzZXItYmc6IGNvbG9yLWJnLFxuICB1c2VyLWZnOiBjb2xvci1mZyxcbiAgdXNlci1mZy1oaWdobGlnaHQ6ICNiY2MzY2MsXG4gIHVzZXItZm9udC1mYW1pbHktc2Vjb25kYXJ5OiBmb250LXNlY29uZGFyeSxcbiAgdXNlci1zaXplLXNtYWxsOiAxLjVyZW0sXG4gIHVzZXItc2l6ZS1tZWRpdW06IDIuNXJlbSxcbiAgdXNlci1zaXplLWxhcmdlOiAzLjI1cmVtLFxuICB1c2VyLXNpemUteGxhcmdlOiA0cmVtLFxuXG4gIHBvcG92ZXItZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIHBvcG92ZXItYmc6IGNvbG9yLWJnLFxuICBwb3BvdmVyLWJvcmRlcjogY29sb3Itc3VjY2VzcyxcbiAgcG9wb3Zlci1zaGFkb3c6IG5vbmUsXG5cbiAgY29udGV4dC1tZW51LWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBjb250ZXh0LW1lbnUtYWN0aXZlLWZnOiBjb2xvci13aGl0ZSxcbiAgY29udGV4dC1tZW51LWFjdGl2ZS1iZzogY29sb3Itc3VjY2VzcyxcblxuICBhY3Rpb25zLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBhY3Rpb25zLWZvbnQtZmFtaWx5OiBmb250LXNlY29uZGFyeSxcbiAgYWN0aW9ucy1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIGFjdGlvbnMtZmc6IGNvbG9yLWZnLFxuICBhY3Rpb25zLWJnOiBjb2xvci1iZyxcbiAgYWN0aW9ucy1zZXBhcmF0b3I6IHNlcGFyYXRvcixcbiAgYWN0aW9ucy1wYWRkaW5nOiBwYWRkaW5nLFxuICBhY3Rpb25zLXNpemUtc21hbGw6IDEuNXJlbSxcbiAgYWN0aW9ucy1zaXplLW1lZGl1bTogMi4yNXJlbSxcbiAgYWN0aW9ucy1zaXplLWxhcmdlOiAzLjVyZW0sXG5cbiAgc2VhcmNoLWJ0bi1vcGVuLWZnOiBjb2xvci1mZyxcbiAgc2VhcmNoLWJ0bi1jbG9zZS1mZzpcdGNvbG9yLWZnLFxuICBzZWFyY2gtYmc6IGxheW91dC1iZyxcbiAgc2VhcmNoLWJnLXNlY29uZGFyeTogY29sb3ItZmcsXG4gIHNlYXJjaC10ZXh0OiBjb2xvci1mZy1oZWFkaW5nLFxuICBzZWFyY2gtaW5mbzogY29sb3ItZmcsXG4gIHNlYXJjaC1kYXNoOiBjb2xvci1mZyxcbiAgc2VhcmNoLXBsYWNlaG9sZGVyOiBjb2xvci1mZyxcblxuICBzbWFydC10YWJsZS1oZWFkZXItZm9udC1mYW1pbHk6IGZvbnQtc2Vjb25kYXJ5LFxuICBzbWFydC10YWJsZS1oZWFkZXItZm9udC1zaXplOiBmb250LXNpemUsXG4gIHNtYXJ0LXRhYmxlLWhlYWRlci1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZCxcbiAgc21hcnQtdGFibGUtaGVhZGVyLWxpbmUtaGVpZ2h0OiBsaW5lLWhlaWdodCxcbiAgc21hcnQtdGFibGUtaGVhZGVyLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBzbWFydC10YWJsZS1oZWFkZXItYmc6IGNvbG9yLWJnLFxuXG4gIHNtYXJ0LXRhYmxlLWZvbnQtZmFtaWx5OiBmb250LW1haW4sXG4gIHNtYXJ0LXRhYmxlLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBzbWFydC10YWJsZS1mb250LXdlaWdodDogZm9udC13ZWlnaHQtbm9ybWFsLFxuICBzbWFydC10YWJsZS1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIHNtYXJ0LXRhYmxlLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBzbWFydC10YWJsZS1iZzogY29sb3ItYmcsXG5cbiAgc21hcnQtdGFibGUtYmctZXZlbjogI2Y1ZjdmYyxcbiAgc21hcnQtdGFibGUtZmctc2Vjb25kYXJ5OiBjb2xvci1mZyxcbiAgc21hcnQtdGFibGUtYmctYWN0aXZlOiAjZTZmM2ZmLFxuICBzbWFydC10YWJsZS1wYWRkaW5nOiAwLjg3NXJlbSAxLjI1cmVtLFxuICBzbWFydC10YWJsZS1maWx0ZXItcGFkZGluZzogMC4zNzVyZW0gMC41cmVtLFxuICBzbWFydC10YWJsZS1zZXBhcmF0b3I6IHNlcGFyYXRvcixcbiAgc21hcnQtdGFibGUtYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1ib3JkZXItY29sb3I6IHNlcGFyYXRvcixcbiAgc21hcnQtdGFibGUtcGFnaW5nLWJvcmRlci13aWR0aDogMXB4LFxuICBzbWFydC10YWJsZS1wYWdpbmctZmctYWN0aXZlOiAjZmZmZmZmLFxuICBzbWFydC10YWJsZS1wYWdpbmctYmctYWN0aXZlOiBjb2xvci1zdWNjZXNzLFxuICBzbWFydC10YWJsZS1wYWdpbmctaG92ZXI6IHJnYmEoMCwgMCwgMCwgMC4wNSksXG5cbiAgdG9hc3Rlci1iZzogY29sb3ItcHJpbWFyeSxcbiAgdG9hc3Rlci1mZy1kZWZhdWx0OiBjb2xvci1pbnZlcnNlLFxuICB0b2FzdGVyLWJ0bi1jbG9zZS1iZzogdHJhbnNwYXJlbnQsXG4gIHRvYXN0ZXItYnRuLWNsb3NlLWZnOiB0b2FzdGVyLWZnLWRlZmF1bHQsXG4gIHRvYXN0ZXItc2hhZG93OiBzaGFkb3csXG5cbiAgdG9hc3Rlci1mZzogY29sb3Itd2hpdGUsXG4gIHRvYXN0ZXItc3VjY2VzczogY29sb3Itc3VjY2VzcyxcbiAgdG9hc3Rlci1pbmZvOiBjb2xvci1pbmZvLFxuICB0b2FzdGVyLXdhcm5pbmc6IGNvbG9yLXdhcm5pbmcsXG4gIHRvYXN0ZXItd2FpdDogY29sb3ItcHJpbWFyeSxcbiAgdG9hc3Rlci1lcnJvcjogY29sb3ItZGFuZ2VyLFxuXG4gIGJ0bi1mZzogY29sb3Itd2hpdGUsXG4gIGJ0bi1mb250LWZhbWlseTogZm9udC1zZWNvbmRhcnksXG4gIGJ0bi1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIGJ0bi1kaXNhYmxlZC1vcGFjaXR5OiAwLjMsXG4gIGJ0bi1jdXJzb3I6IGRlZmF1bHQsXG5cbiAgYnRuLXByaW1hcnktYmc6IGNvbG9yLXByaW1hcnksXG4gIGJ0bi1zZWNvbmRhcnktYmc6IHRyYW5zcGFyZW50LFxuICBidG4taW5mby1iZzogY29sb3ItaW5mbyxcbiAgYnRuLXN1Y2Nlc3MtYmc6IGNvbG9yLXN1Y2Nlc3MsXG4gIGJ0bi13YXJuaW5nLWJnOiBjb2xvci13YXJuaW5nLFxuICBidG4tZGFuZ2VyLWJnOiBjb2xvci1kYW5nZXIsXG5cbiAgYnRuLXNlY29uZGFyeS1ib3JkZXI6ICNkYWRmZTYsXG4gIGJ0bi1zZWNvbmRhcnktYm9yZGVyLXdpZHRoOiAycHgsXG5cbiAgYnRuLXBhZGRpbmcteS1sZzogMC44NzVyZW0sXG4gIGJ0bi1wYWRkaW5nLXgtbGc6IDEuNzVyZW0sXG4gIGJ0bi1mb250LXNpemUtbGc6IGZvbnQtc2l6ZS1sZyxcblxuICAvLyBkZWZhdWx0IHNpemVcbiAgYnRuLXBhZGRpbmcteS1tZDogMC43NXJlbSxcbiAgYnRuLXBhZGRpbmcteC1tZDogMS41cmVtLFxuICBidG4tZm9udC1zaXplLW1kOiAxcmVtLFxuXG4gIGJ0bi1wYWRkaW5nLXktc206IDAuNjI1cmVtLFxuICBidG4tcGFkZGluZy14LXNtOiAxLjVyZW0sXG4gIGJ0bi1mb250LXNpemUtc206IDAuODc1cmVtLFxuXG4gIGJ0bi1wYWRkaW5nLXktdG46IDAuNXJlbSxcbiAgYnRuLXBhZGRpbmcteC10bjogMS4yNXJlbSxcbiAgYnRuLWZvbnQtc2l6ZS10bjogMC43NXJlbSxcblxuICBidG4tYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuICBidG4tcmVjdGFuZ2xlLWJvcmRlci1yYWRpdXM6IDAuMjVyZW0sXG4gIGJ0bi1zZW1pLXJvdW5kLWJvcmRlci1yYWRpdXM6IDAuNzVyZW0sXG4gIGJ0bi1yb3VuZC1ib3JkZXItcmFkaXVzOiAxLjVyZW0sXG5cbiAgYnRuLWhlcm8tc2hhZG93OiBub25lLFxuICBidG4taGVyby10ZXh0LXNoYWRvdzogbm9uZSxcbiAgYnRuLWhlcm8tYmV2ZWwtc2l6ZTogMCAwIDAgMCxcbiAgYnRuLWhlcm8tZ2xvdy1zaXplOiAwIDAgMCAwLFxuICBidG4taGVyby1wcmltYXJ5LWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1zdWNjZXNzLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby13YXJuaW5nLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1pbmZvLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1kYW5nZXItZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXNlY29uZGFyeS1nbG93LXNpemU6IGJ0bi1oZXJvLWdsb3ctc2l6ZSxcbiAgYnRuLWhlcm8tZGVncmVlOiAyMGRlZyxcbiAgYnRuLWhlcm8tcHJpbWFyeS1kZWdyZWU6IGJ0bi1oZXJvLWRlZ3JlZSxcbiAgYnRuLWhlcm8tc3VjY2Vzcy1kZWdyZWU6IGJ0bi1oZXJvLWRlZ3JlZSxcbiAgYnRuLWhlcm8td2FybmluZy1kZWdyZWU6IDEwZGVnLFxuICBidG4taGVyby1pbmZvLWRlZ3JlZTogLTEwZGVnLFxuICBidG4taGVyby1kYW5nZXItZGVncmVlOiAtMjBkZWcsXG4gIGJ0bi1oZXJvLXNlY29uZGFyeS1kZWdyZWU6IGJ0bi1oZXJvLWRlZ3JlZSxcbiAgYnRuLWhlcm8tYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuXG4gIGJ0bi1vdXRsaW5lLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBidG4tb3V0bGluZS1ob3Zlci1mZzogI2ZmZmZmZixcbiAgYnRuLW91dGxpbmUtZm9jdXMtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG5cbiAgYnRuLWdyb3VwLWJnOiBsYXlvdXQtYmcsXG4gIGJ0bi1ncm91cC1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgYnRuLWdyb3VwLXNlcGFyYXRvcjogI2RhZGZlNixcblxuICBmb3JtLWNvbnRyb2wtdGV4dC1wcmltYXJ5LWNvbG9yOiBjb2xvci1mZy1oZWFkaW5nLFxuICBmb3JtLWNvbnRyb2wtdGV4dC1zZWNvbmRhcnktY29sb3I6IGNvbG9yLWZnLFxuICBmb3JtLWNvbnRyb2wtZm9udC1mYW1pbHk6IGZvbnQtc2Vjb25kYXJ5LFxuICBmb3JtLWNvbnRyb2wtYmc6IGNvbG9yLWJnLFxuICBmb3JtLWNvbnRyb2wtZm9jdXMtYmc6IGNvbG9yLWJnLFxuXG4gIGZvcm0tY29udHJvbC1ib3JkZXItd2lkdGg6IDJweCxcbiAgZm9ybS1jb250cm9sLWJvcmRlci10eXBlOiBzb2xpZCxcbiAgZm9ybS1jb250cm9sLWJvcmRlci1yYWRpdXM6IHJhZGl1cyxcbiAgZm9ybS1jb250cm9sLWJvcmRlci1jb2xvcjogI2RhZGZlNixcbiAgZm9ybS1jb250cm9sLXNlbGVjdGVkLWJvcmRlci1jb2xvcjogY29sb3Itc3VjY2VzcyxcblxuICBmb3JtLWNvbnRyb2wtaW5mby1ib3JkZXItY29sb3I6IGNvbG9yLWluZm8sXG4gIGZvcm0tY29udHJvbC1zdWNjZXNzLWJvcmRlci1jb2xvcjogY29sb3Itc3VjY2VzcyxcbiAgZm9ybS1jb250cm9sLWRhbmdlci1ib3JkZXItY29sb3I6IGNvbG9yLWRhbmdlcixcbiAgZm9ybS1jb250cm9sLXdhcm5pbmctYm9yZGVyLWNvbG9yOiBjb2xvci13YXJuaW5nLFxuXG4gIGZvcm0tY29udHJvbC1wbGFjZWhvbGRlci1jb2xvcjogY29sb3ItZmcsXG4gIGZvcm0tY29udHJvbC1wbGFjZWhvbGRlci1mb250LXNpemU6IDFyZW0sXG5cbiAgZm9ybS1jb250cm9sLWZvbnQtc2l6ZTogMXJlbSxcbiAgZm9ybS1jb250cm9sLXNtLWZvbnQtc2l6ZTogZm9udC1zaXplLXNtLFxuICBmb3JtLWNvbnRyb2wtc20tcGFkZGluZzogMC4zNzVyZW0gMS4xMjVyZW0sXG4gIGZvcm0tY29udHJvbC1sZy1mb250LXNpemU6IGZvbnQtc2l6ZS1sZyxcbiAgZm9ybS1jb250cm9sLWxnLXBhZGRpbmc6IDEuMTI1cmVtLFxuXG4gIGZvcm0tY29udHJvbC1sYWJlbC1mb250LXdlaWdodDogNDAwLFxuXG4gIGZvcm0tY29udHJvbC1mZWVkYmFjay1mb250LXNpemU6IDAuODc1cmVtLFxuICBmb3JtLWNvbnRyb2wtZmVlZGJhY2stZm9udC13ZWlnaHQ6IGZvbnQtd2VpZ2h0LW5vcm1hbCxcblxuICBjaGVja2JveC1iZzogdHJhbnNwYXJlbnQsXG4gIGNoZWNrYm94LXNpemU6IDEuMjVyZW0sXG4gIGNoZWNrYm94LWJvcmRlci1zaXplOiAycHgsXG4gIGNoZWNrYm94LWJvcmRlci1jb2xvcjogZm9ybS1jb250cm9sLWJvcmRlci1jb2xvcixcbiAgY2hlY2tib3gtY2hlY2ttYXJrOiB0cmFuc3BhcmVudCxcblxuICBjaGVja2JveC1jaGVja2VkLWJnOiB0cmFuc3BhcmVudCxcbiAgY2hlY2tib3gtY2hlY2tlZC1zaXplOiAxLjI1cmVtLFxuICBjaGVja2JveC1jaGVja2VkLWJvcmRlci1zaXplOiAycHgsXG4gIGNoZWNrYm94LWNoZWNrZWQtYm9yZGVyLWNvbG9yOiBjb2xvci1zdWNjZXNzLFxuICBjaGVja2JveC1jaGVja2VkLWNoZWNrbWFyazogY29sb3ItZmctaGVhZGluZyxcblxuICBjaGVja2JveC1kaXNhYmxlZC1iZzogdHJhbnNwYXJlbnQsXG4gIGNoZWNrYm94LWRpc2FibGVkLXNpemU6IDEuMjVyZW0sXG4gIGNoZWNrYm94LWRpc2FibGVkLWJvcmRlci1zaXplOiAycHgsXG4gIGNoZWNrYm94LWRpc2FibGVkLWJvcmRlci1jb2xvcjogY29sb3ItZmctaGVhZGluZyxcbiAgY2hlY2tib3gtZGlzYWJsZWQtY2hlY2ttYXJrOiBjb2xvci1mZy1oZWFkaW5nLFxuXG4gIHJhZGlvLWZnOiBjb2xvci1zdWNjZXNzLFxuXG4gIG1vZGFsLWZvbnQtc2l6ZTogZm9udC1zaXplLFxuICBtb2RhbC1saW5lLWhlaWdodDogbGluZS1oZWlnaHQsXG4gIG1vZGFsLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ub3JtYWwsXG4gIG1vZGFsLWZnOiBjb2xvci1mZy10ZXh0LFxuICBtb2RhbC1mZy1oZWFkaW5nOiBjb2xvci1mZy1oZWFkaW5nLFxuICBtb2RhbC1iZzogY29sb3ItYmcsXG4gIG1vZGFsLWJvcmRlcjogdHJhbnNwYXJlbnQsXG4gIG1vZGFsLWJvcmRlci1yYWRpdXM6IHJhZGl1cyxcbiAgbW9kYWwtcGFkZGluZzogcGFkZGluZyxcbiAgbW9kYWwtaGVhZGVyLWZvbnQtZmFtaWx5OiBmb250LXNlY29uZGFyeSxcbiAgbW9kYWwtaGVhZGVyLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkZXIsXG4gIG1vZGFsLWhlYWRlci1mb250LXNpemU6IGZvbnQtc2l6ZS1sZyxcbiAgbW9kYWwtYm9keS1mb250LWZhbWlseTogZm9udC1tYWluLFxuICBtb2RhbC1ib2R5LWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ub3JtYWwsXG4gIG1vZGFsLWJvZHktZm9udC1zaXplOiBmb250LXNpemUsXG4gIG1vZGFsLXNlcGFyYXRvcjogc2VwYXJhdG9yLFxuXG4gIGJhZGdlLWZnLXRleHQ6IGNvbG9yLXdoaXRlLFxuICBiYWRnZS1wcmltYXJ5LWJnLWNvbG9yOiBjb2xvci1wcmltYXJ5LFxuICBiYWRnZS1zdWNjZXNzLWJnLWNvbG9yOiBjb2xvci1zdWNjZXNzLFxuICBiYWRnZS1pbmZvLWJnLWNvbG9yOiBjb2xvci1pbmZvLFxuICBiYWRnZS13YXJuaW5nLWJnLWNvbG9yOiBjb2xvci13YXJuaW5nLFxuICBiYWRnZS1kYW5nZXItYmctY29sb3I6IGNvbG9yLWRhbmdlcixcblxuICBwcm9ncmVzcy1iYXItaGVpZ2h0LXhsZzogMS43NXJlbSxcbiAgcHJvZ3Jlc3MtYmFyLWhlaWdodC1sZzogMS41cmVtLFxuICBwcm9ncmVzcy1iYXItaGVpZ2h0OiAxLjM3NXJlbSxcbiAgcHJvZ3Jlc3MtYmFyLWhlaWdodC1zbTogMS4yNXJlbSxcbiAgcHJvZ3Jlc3MtYmFyLWhlaWdodC14czogMXJlbSxcbiAgcHJvZ3Jlc3MtYmFyLWFuaW1hdGlvbi1kdXJhdGlvbjogNDAwbXMsXG4gIHByb2dyZXNzLWJhci1mb250LXNpemUteGxnOiBmb250LXNpemUteGxnLFxuICBwcm9ncmVzcy1iYXItZm9udC1zaXplLWxnOiBmb250LXNpemUtbGcsXG4gIHByb2dyZXNzLWJhci1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgcHJvZ3Jlc3MtYmFyLWZvbnQtc2l6ZS1zbTogZm9udC1zaXplLXNtLFxuICBwcm9ncmVzcy1iYXItZm9udC1zaXplLXhzOiBmb250LXNpemUteHMsXG4gIHByb2dyZXNzLWJhci1yYWRpdXM6IHJhZGl1cyxcbiAgcHJvZ3Jlc3MtYmFyLWJnOiBsYXlvdXQtYmcsXG4gIHByb2dyZXNzLWJhci1mb250LWNvbG9yOiBjb2xvci13aGl0ZSxcbiAgcHJvZ3Jlc3MtYmFyLWZvbnQtd2VpZ2h0OiBmb250LXdlaWdodC1ib2xkLFxuICBwcm9ncmVzcy1iYXItZGVmYXVsdC1iZzogY29sb3ItaW5mbyxcbiAgcHJvZ3Jlc3MtYmFyLXByaW1hcnktYmc6IGNvbG9yLXByaW1hcnksXG4gIHByb2dyZXNzLWJhci1zdWNjZXNzLWJnOiBjb2xvci1zdWNjZXNzLFxuICBwcm9ncmVzcy1iYXItaW5mby1iZzogY29sb3ItaW5mbyxcbiAgcHJvZ3Jlc3MtYmFyLXdhcm5pbmctYmc6IGNvbG9yLXdhcm5pbmcsXG4gIHByb2dyZXNzLWJhci1kYW5nZXItYmc6IGNvbG9yLWRhbmdlcixcblxuICBhbGVydC1mb250LXNpemU6IGZvbnQtc2l6ZSxcbiAgYWxlcnQtbGluZS1oZWlnaHQ6IGxpbmUtaGVpZ2h0LFxuICBhbGVydC1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZCxcbiAgYWxlcnQtZmc6IGNvbG9yLXdoaXRlLFxuICBhbGVydC1iZzogY29sb3ItYmcsXG4gIGFsZXJ0LWFjdGl2ZS1iZzogY29sb3ItZmcsXG4gIGFsZXJ0LWRpc2FibGVkLWJnOiBjb2xvci1kaXNhYmxlZCxcbiAgYWxlcnQtZGlzYWJsZWQtZmc6IGNvbG9yLWZnLFxuICBhbGVydC1wcmltYXJ5LWJnOiBjb2xvci1wcmltYXJ5LFxuICBhbGVydC1pbmZvLWJnOiBjb2xvci1pbmZvLFxuICBhbGVydC1zdWNjZXNzLWJnOiBjb2xvci1zdWNjZXNzLFxuICBhbGVydC13YXJuaW5nLWJnOiBjb2xvci13YXJuaW5nLFxuICBhbGVydC1kYW5nZXItYmc6IGNvbG9yLWRhbmdlcixcbiAgYWxlcnQtaGVpZ2h0LXh4c21hbGw6IDUycHgsXG4gIGFsZXJ0LWhlaWdodC14c21hbGw6IDcycHgsXG4gIGFsZXJ0LWhlaWdodC1zbWFsbDogOTJweCxcbiAgYWxlcnQtaGVpZ2h0LW1lZGl1bTogMTEycHgsXG4gIGFsZXJ0LWhlaWdodC1sYXJnZTogMTMycHgsXG4gIGFsZXJ0LWhlaWdodC14bGFyZ2U6IDE1MnB4LFxuICBhbGVydC1oZWlnaHQteHhsYXJnZTogMTcycHgsXG4gIGFsZXJ0LXNoYWRvdzogbm9uZSxcbiAgYWxlcnQtYm9yZGVyLXJhZGl1czogcmFkaXVzLFxuICBhbGVydC1wYWRkaW5nOiAxcmVtIDEuMTI1cmVtLFxuICBhbGVydC1jbG9zYWJsZS1wYWRkaW5nOiAzcmVtLFxuICBhbGVydC1idXR0b24tcGFkZGluZzogM3JlbSxcbiAgYWxlcnQtbWFyZ2luOiBtYXJnaW4sXG4pO1xuXG4vLyByZWdpc3RlciB0aGUgdGhlbWVcbiRuYi10aGVtZXM6IG5iLXJlZ2lzdGVyLXRoZW1lKCR0aGVtZSwgZGVmYXVsdCk7XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgQWt2ZW8uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuIFNlZSBMaWNlbnNlLnR4dCBpbiB0aGUgcHJvamVjdCByb290IGZvciBsaWNlbnNlIGluZm9ybWF0aW9uLlxuICovXG5cbkBpbXBvcnQgJy4uL2NvcmUvZnVuY3Rpb25zJztcbkBpbXBvcnQgJy4uL2NvcmUvbWl4aW5zJztcbkBpbXBvcnQgJ2RlZmF1bHQnO1xuXG4vLyBkZWZhdWx0IHRoZSBiYXNlIHRoZW1lXG4kdGhlbWU6IChcbiAgcmFkaXVzOiAwLjVyZW0sXG5cbiAgY29sb3ItYmc6ICMzZDM3ODAsXG4gIGNvbG9yLWJnLWFjdGl2ZTogIzQ5NDI5OSxcbiAgY29sb3ItZmc6ICNhMWExZTUsXG4gIGNvbG9yLWZnLWhlYWRpbmc6ICNmZmZmZmYsXG4gIGNvbG9yLWZnLXRleHQ6ICNkMWQxZmYsXG4gIGNvbG9yLWZnLWhpZ2hsaWdodDogIzAwZjlhNixcblxuICBjb2xvci1ncmF5OiByZ2JhKDgxLCAxMTMsIDE2NSwgMC4xNSksXG4gIGNvbG9yLW5ldXRyYWw6IHRyYW5zcGFyZW50LFxuICBjb2xvci13aGl0ZTogI2ZmZmZmZixcbiAgY29sb3ItZGlzYWJsZWQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC40KSxcblxuICBjb2xvci1wcmltYXJ5OiAjNzY1OWZmLFxuICBjb2xvci1zdWNjZXNzOiAjMDBkOTc3LFxuICBjb2xvci1pbmZvOiAjMDA4OGZmLFxuICBjb2xvci13YXJuaW5nOiAjZmZhMTAwLFxuICBjb2xvci1kYW5nZXI6ICNmZjM4NmEsXG5cbiAgbGluay1jb2xvcjogIzAwZjlhNixcbiAgbGluay1jb2xvci1ob3ZlcjogIzE0ZmZiZSxcblxuICBzZXBhcmF0b3I6ICMzNDJlNzMsXG4gIHNoYWRvdzogMCA4cHggMjBweCAwIHJnYmEoNDAsIDM3LCA4OSwgMC42KSxcblxuICBjYXJkLWhlYWRlci1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZGVyLFxuXG4gIGxheW91dC1iZzogIzJmMjk2YixcblxuICBzY3JvbGxiYXItZmc6ICM1NTRkYjMsXG4gIHNjcm9sbGJhci1iZzogIzMzMmU3MyxcblxuICByYWRpYWwtZ3JhZGllbnQ6IHJhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgNTAlIDUwJSwgIzQyM2Y4YywgIzMwMmM2ZSksXG4gIGxpbmVhci1ncmFkaWVudDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCAjMTcxNzQ5LCAjNDEzNzg5KSxcblxuICBzaWRlYmFyLWZnOiBjb2xvci1zZWNvbmRhcnksXG4gIHNpZGViYXItYmc6IGNvbG9yLWJnLFxuXG4gIGhlYWRlci1mZzogY29sb3Itd2hpdGUsXG4gIGhlYWRlci1iZzogY29sb3ItYmcsXG5cbiAgZm9vdGVyLWZnOiBjb2xvci1mZyxcbiAgZm9vdGVyLWJnOiBjb2xvci1iZyxcblxuICBhY3Rpb25zLWZnOiBjb2xvci1mZyxcbiAgYWN0aW9ucy1iZzogY29sb3ItYmcsXG5cbiAgdXNlci1mZzogY29sb3ItYmcsXG4gIHVzZXItYmc6IGNvbG9yLWZnLFxuICB1c2VyLWZnLWhpZ2hsaWdodDogY29sb3ItZmctaGlnaGxpZ2h0LFxuXG4gIHBvcG92ZXItYm9yZGVyOiBjb2xvci1wcmltYXJ5LFxuICBwb3BvdmVyLXNoYWRvdzogc2hhZG93LFxuXG4gIGNvbnRleHQtbWVudS1hY3RpdmUtYmc6IGNvbG9yLXByaW1hcnksXG5cbiAgZm9vdGVyLWhlaWdodDogaGVhZGVyLWhlaWdodCxcblxuICBzaWRlYmFyLXdpZHRoOiAxNi4yNXJlbSxcbiAgc2lkZWJhci13aWR0aC1jb21wYWN0OiAzLjQ1cmVtLFxuXG4gIG1lbnUtZmc6IGNvbG9yLWZnLFxuICBtZW51LWJnOiBjb2xvci1iZyxcbiAgbWVudS1hY3RpdmUtZmc6IGNvbG9yLXdoaXRlLFxuICBtZW51LWdyb3VwLWZnOiBjb2xvci13aGl0ZSxcbiAgbWVudS1mb250LXdlaWdodDogZm9udC13ZWlnaHQtbm9ybWFsLFxuICBtZW51LWFjdGl2ZS1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZGVyLFxuICBtZW51LXN1Ym1lbnUtYmc6IGxheW91dC1iZyxcbiAgbWVudS1zdWJtZW51LWZnOiBjb2xvci1mZyxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgbWVudS1zdWJtZW51LWFjdGl2ZS1iZzogcmdiYSgwLCAyNTUsIDE3MCwgMC4yNSksXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtYm9yZGVyLWNvbG9yOiBjb2xvci1mZy1oaWdobGlnaHQsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtc2hhZG93OiAwIDJweCAxMnB4IDAgcmdiYSgwLCAyNTUsIDE3MCwgMC4yNSksXG4gIG1lbnUtaXRlbS1wYWRkaW5nOiAwLjI1cmVtIDAuNzVyZW0sXG4gIG1lbnUtaXRlbS1zZXBhcmF0b3I6IHRyYW5zcGFyZW50LFxuXG4gIGJ0bi1oZXJvLXNoYWRvdzogMCA0cHggMTBweCAwIHJnYmEoMzMsIDcsIDc3LCAwLjUpLFxuICBidG4taGVyby10ZXh0LXNoYWRvdzogMCAxcHggM3B4IHJnYmEoMCwgMCwgMCwgMC4zKSxcbiAgYnRuLWhlcm8tYmV2ZWwtc2l6ZTogMCAzcHggMCAwLFxuICBidG4taGVyby1nbG93LXNpemU6IDAgMnB4IDhweCAwLFxuICBidG4taGVyby1wcmltYXJ5LWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1zdWNjZXNzLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby13YXJuaW5nLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1pbmZvLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1kYW5nZXItZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXNlY29uZGFyeS1nbG93LXNpemU6IGJ0bi1oZXJvLWdsb3ctc2l6ZSxcbiAgYnRuLXNlY29uZGFyeS1ib3JkZXI6IGNvbG9yLXByaW1hcnksXG4gIGJ0bi1vdXRsaW5lLWZnOiBjb2xvci1mZy1oZWFkaW5nLFxuICBidG4tb3V0bGluZS1ob3Zlci1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgYnRuLW91dGxpbmUtZm9jdXMtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIGJ0bi1ncm91cC1iZzogIzM3MzI3MyxcbiAgYnRuLWdyb3VwLXNlcGFyYXRvcjogIzMxMmM2NixcblxuICBmb3JtLWNvbnRyb2wtYmc6ICMzNzMxN2EsXG4gIGZvcm0tY29udHJvbC1mb2N1cy1iZzogc2VwYXJhdG9yLFxuICBmb3JtLWNvbnRyb2wtYm9yZGVyLWNvbG9yOiBzZXBhcmF0b3IsXG4gIGZvcm0tY29udHJvbC1zZWxlY3RlZC1ib3JkZXItY29sb3I6IGNvbG9yLXByaW1hcnksXG5cbiAgY2hlY2tib3gtYmc6IHRyYW5zcGFyZW50LFxuICBjaGVja2JveC1zaXplOiAxLjI1cmVtLFxuICBjaGVja2JveC1ib3JkZXItc2l6ZTogMnB4LFxuICBjaGVja2JveC1ib3JkZXItY29sb3I6IGNvbG9yLWZnLFxuICBjaGVja2JveC1jaGVja21hcms6IHRyYW5zcGFyZW50LFxuXG4gIGNoZWNrYm94LWNoZWNrZWQtYmc6IHRyYW5zcGFyZW50LFxuICBjaGVja2JveC1jaGVja2VkLXNpemU6IDEuMjVyZW0sXG4gIGNoZWNrYm94LWNoZWNrZWQtYm9yZGVyLXNpemU6IDJweCxcbiAgY2hlY2tib3gtY2hlY2tlZC1ib3JkZXItY29sb3I6IGNvbG9yLXN1Y2Nlc3MsXG4gIGNoZWNrYm94LWNoZWNrZWQtY2hlY2ttYXJrOiBjb2xvci1mZy1oZWFkaW5nLFxuXG4gIGNoZWNrYm94LWRpc2FibGVkLWJnOiB0cmFuc3BhcmVudCxcbiAgY2hlY2tib3gtZGlzYWJsZWQtc2l6ZTogMS4yNXJlbSxcbiAgY2hlY2tib3gtZGlzYWJsZWQtYm9yZGVyLXNpemU6IDJweCxcbiAgY2hlY2tib3gtZGlzYWJsZWQtYm9yZGVyLWNvbG9yOiBjb2xvci1mZy1oZWFkaW5nLFxuICBjaGVja2JveC1kaXNhYmxlZC1jaGVja21hcms6IGNvbG9yLWZnLWhlYWRpbmcsXG5cbiAgc2VhcmNoLWJnOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMxNzE3NDksICM0MTM3ODkpLFxuXG4gIHNtYXJ0LXRhYmxlLWhlYWRlci1mb250LXdlaWdodDogZm9udC13ZWlnaHQtbm9ybWFsLFxuICBzbWFydC10YWJsZS1oZWFkZXItYmc6IGNvbG9yLWJnLWFjdGl2ZSxcbiAgc21hcnQtdGFibGUtYmctZXZlbjogIzNhMzQ3YSxcbiAgc21hcnQtdGFibGUtYmctYWN0aXZlOiBjb2xvci1iZy1hY3RpdmUsXG5cbiAgc21hcnQtdGFibGUtcGFnaW5nLWJvcmRlci1jb2xvcjogY29sb3ItcHJpbWFyeSxcbiAgc21hcnQtdGFibGUtcGFnaW5nLWJvcmRlci13aWR0aDogMnB4LFxuICBzbWFydC10YWJsZS1wYWdpbmctZmctYWN0aXZlOiBjb2xvci1mZy1oZWFkaW5nLFxuICBzbWFydC10YWJsZS1wYWdpbmctYmctYWN0aXZlOiBjb2xvci1wcmltYXJ5LFxuICBzbWFydC10YWJsZS1wYWdpbmctaG92ZXI6IHJnYmEoMCwgMCwgMCwgMC4yKSxcblxuICBiYWRnZS1mZy10ZXh0OiBjb2xvci13aGl0ZSxcbiAgYmFkZ2UtcHJpbWFyeS1iZy1jb2xvcjogY29sb3ItcHJpbWFyeSxcbiAgYmFkZ2Utc3VjY2Vzcy1iZy1jb2xvcjogY29sb3Itc3VjY2VzcyxcbiAgYmFkZ2UtaW5mby1iZy1jb2xvcjogY29sb3ItaW5mbyxcbiAgYmFkZ2Utd2FybmluZy1iZy1jb2xvcjogY29sb3Itd2FybmluZyxcbiAgYmFkZ2UtZGFuZ2VyLWJnLWNvbG9yOiBjb2xvci1kYW5nZXIsXG4pO1xuXG4vLyByZWdpc3RlciB0aGUgdGhlbWVcbiRuYi10aGVtZXM6IG5iLXJlZ2lzdGVyLXRoZW1lKCR0aGVtZSwgY29zbWljLCBkZWZhdWx0KTtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuQGltcG9ydCAnLi4vY29yZS9mdW5jdGlvbnMnO1xuQGltcG9ydCAnLi4vY29yZS9taXhpbnMnO1xuQGltcG9ydCAnZGVmYXVsdCc7XG5cbi8vIGRlZmF1bHQgdGhlIGJhc2UgdGhlbWVcbiR0aGVtZTogKFxuICBoZWFkZXItZmc6ICNmN2ZhZmIsXG4gIGhlYWRlci1iZzogIzExMTIxOCxcblxuICBsYXlvdXQtYmc6ICNmMWY1ZjgsXG5cbiAgY29sb3ItZmctaGVhZGluZzogIzE4MTgxOCxcbiAgY29sb3ItZmctdGV4dDogIzRiNGI0YixcbiAgY29sb3ItZmctaGlnaGxpZ2h0OiBjb2xvci1mZyxcblxuICBzZXBhcmF0b3I6ICNjZGQ1ZGMsXG5cbiAgcmFkaXVzOiAwLjE3cmVtLFxuXG4gIHNjcm9sbGJhci1iZzogI2UzZTllZSxcblxuICBjb2xvci1wcmltYXJ5OiAjNzNhMWZmLFxuICBjb2xvci1zdWNjZXNzOiAjNWRjZmUzLFxuICBjb2xvci1pbmZvOiAjYmE3ZmVjLFxuICBjb2xvci13YXJuaW5nOiAjZmZhMzZiLFxuICBjb2xvci1kYW5nZXI6ICNmZjZiODMsXG5cbiAgYnRuLXNlY29uZGFyeS1iZzogI2VkZjJmNSxcbiAgYnRuLXNlY29uZGFyeS1ib3JkZXI6ICNlZGYyZjUsXG5cbiAgYWN0aW9ucy1mZzogI2QzZGJlNSxcbiAgYWN0aW9ucy1iZzogY29sb3ItYmcsXG5cbiAgc2lkZWJhci1iZzogI2UzZTllZSxcblxuICBib3JkZXItY29sb3I6ICNlN2VjZWYsXG5cbiAgbWVudS1mb250LXdlaWdodDogZm9udC13ZWlnaHQtYm9sZGVyLFxuICBtZW51LWZnOiBjb2xvci1mZy10ZXh0LFxuICBtZW51LWJnOiAjZTNlOWVlLFxuICBtZW51LWFjdGl2ZS1mZzogY29sb3ItZmctaGVhZGluZyxcbiAgbWVudS1hY3RpdmUtYmc6IG1lbnUtYmcsXG5cbiAgbWVudS1zdWJtZW51LWJnOiBtZW51LWJnLFxuICBtZW51LXN1Ym1lbnUtZmc6IGNvbG9yLWZnLXRleHQsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtZmc6IGNvbG9yLWZnLWhlYWRpbmcsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtYmc6ICNjZGQ1ZGMsXG4gIG1lbnUtc3VibWVudS1hY3RpdmUtYm9yZGVyLWNvbG9yOiBtZW51LXN1Ym1lbnUtYWN0aXZlLWJnLFxuICBtZW51LXN1Ym1lbnUtYWN0aXZlLXNoYWRvdzogbm9uZSxcbiAgbWVudS1zdWJtZW51LWhvdmVyLWZnOiBtZW51LXN1Ym1lbnUtYWN0aXZlLWZnLFxuICBtZW51LXN1Ym1lbnUtaG92ZXItYmc6IG1lbnUtYmcsXG4gIG1lbnUtc3VibWVudS1pdGVtLWJvcmRlci13aWR0aDogMC4xMjVyZW0sXG4gIG1lbnUtc3VibWVudS1pdGVtLWJvcmRlci1yYWRpdXM6IHJhZGl1cyxcbiAgbWVudS1zdWJtZW51LWl0ZW0tcGFkZGluZzogMC41cmVtIDFyZW0sXG4gIG1lbnUtc3VibWVudS1pdGVtLWNvbnRhaW5lci1wYWRkaW5nOiAwIDEuMjVyZW0sXG4gIG1lbnUtc3VibWVudS1wYWRkaW5nOiAwLjVyZW0sXG5cbiAgYnRuLWJvcmRlci1yYWRpdXM6IGJ0bi1zZW1pLXJvdW5kLWJvcmRlci1yYWRpdXMsXG5cbiAgYnRuLWhlcm8tZGVncmVlOiAwZGVnLFxuICBidG4taGVyby1wcmltYXJ5LWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby1zdWNjZXNzLWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby13YXJuaW5nLWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby1pbmZvLWRlZ3JlZTogYnRuLWhlcm8tZGVncmVlLFxuICBidG4taGVyby1kYW5nZXItZGVncmVlOiBidG4taGVyby1kZWdyZWUsXG4gIGJ0bi1oZXJvLXNlY29uZGFyeS1kZWdyZWU6IGJ0bi1oZXJvLWRlZ3JlZSxcbiAgYnRuLWhlcm8tZ2xvdy1zaXplOiAwIDAgMjBweCAwLFxuICBidG4taGVyby1wcmltYXJ5LWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1zdWNjZXNzLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby13YXJuaW5nLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1pbmZvLWdsb3ctc2l6ZTogYnRuLWhlcm8tZ2xvdy1zaXplLFxuICBidG4taGVyby1kYW5nZXItZ2xvdy1zaXplOiBidG4taGVyby1nbG93LXNpemUsXG4gIGJ0bi1oZXJvLXNlY29uZGFyeS1nbG93LXNpemU6IDAgMCAwIDAsXG4gIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXM6IGJ0bi1ib3JkZXItcmFkaXVzLFxuXG4gIGNhcmQtc2hhZG93OiBub25lLFxuICBjYXJkLWJvcmRlci13aWR0aDogMXB4LFxuICBjYXJkLWJvcmRlci1jb2xvcjogYm9yZGVyLWNvbG9yLFxuICBjYXJkLWhlYWRlci1ib3JkZXItd2lkdGg6IDAsXG5cbiAgbGluay1jb2xvcjogIzVkY2ZlMyxcbiAgbGluay1jb2xvci1ob3ZlcjogIzdkY2ZlMyxcbiAgbGluay1jb2xvci12aXNpdGVkOiBsaW5rLWNvbG9yLFxuXG4gIGFjdGlvbnMtc2VwYXJhdG9yOiAjZjFmNGY1LFxuXG4gIG1vZGFsLXNlcGFyYXRvcjogYm9yZGVyLWNvbG9yLFxuXG4gIHRhYnMtc2VsZWN0ZWQ6IGNvbG9yLXByaW1hcnksXG4gIHRhYnMtc2VwYXJhdG9yOiAjZWJlY2VlLFxuXG4gIHNtYXJ0LXRhYmxlLXBhZ2luZy1iZy1hY3RpdmU6IGNvbG9yLXByaW1hcnksXG5cbiAgcm91dGUtdGFicy1zZWxlY3RlZDogY29sb3ItcHJpbWFyeSxcblxuICBwb3BvdmVyLWJvcmRlcjogY29sb3ItcHJpbWFyeSxcblxuICBmb290ZXItc2hhZG93OiBub25lLFxuICBmb290ZXItc2VwYXJhdG9yOiBib3JkZXItY29sb3IsXG4gIGZvb3Rlci1mZy1oaWdobGlnaHQ6ICMyYTJhMmEsXG4pO1xuXG4vLyByZWdpc3RlciB0aGUgdGhlbWVcbiRuYi10aGVtZXM6IG5iLXJlZ2lzdGVyLXRoZW1lKCR0aGVtZSwgY29ycG9yYXRlLCBkZWZhdWx0KTtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCBBa3Zlby4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi9cblxuQG1peGluIGJ0bi1oZXJvKCkge1xuICAuYnRuLmJ0bi1oZXJvLXByaW1hcnkge1xuICAgIEBpbmNsdWRlIGJ0bi1oZXJvLXByaW1hcnkoKTtcbiAgfVxuXG4gIC5idG4uYnRuLWhlcm8tc3VjY2VzcyB7XG4gICAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2VzcygpO1xuICB9XG5cbiAgLmJ0bi5idG4taGVyby13YXJuaW5nIHtcbiAgICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nKCk7XG4gIH1cblxuICAuYnRuLmJ0bi1oZXJvLWluZm8ge1xuICAgIEBpbmNsdWRlIGJ0bi1oZXJvLWluZm8oKTtcbiAgfVxuXG4gIC5idG4uYnRuLWhlcm8tZGFuZ2VyIHtcbiAgICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXIoKTtcbiAgfVxuXG4gIC5idG4uYnRuLWhlcm8tc2Vjb25kYXJ5IHtcbiAgICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnkoKTtcbiAgfVxufVxuXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeSgpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeS1ncmFkaWVudCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWJldmVsLWdsb3ctc2hhZG93KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tdGV4dCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWZvY3VzKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXByaW1hcnktaG92ZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeS1hY3RpdmUoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeS1ib3JkZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGlzYWJsZWQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tbGluZS1oZWlnaHQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeS1wdWxzZSgpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc3VjY2VzcygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1ncmFkaWVudCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLWJldmVsLWdsb3ctc2hhZG93KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tdGV4dCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1zdWNjZXNzLWZvY3VzKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXN1Y2Nlc3MtaG92ZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1hY3RpdmUoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1ib3JkZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGlzYWJsZWQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tbGluZS1oZWlnaHQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1wdWxzZSgpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8td2FybmluZygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8td2FybmluZy1ncmFkaWVudCgpO1xuICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWJldmVsLWdsb3ctc2hhZG93KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tdGV4dCgpO1xuICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWZvY3VzKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXdhcm5pbmctaG92ZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8td2FybmluZy1hY3RpdmUoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8td2FybmluZy1ib3JkZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGlzYWJsZWQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tbGluZS1oZWlnaHQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8td2FybmluZy1wdWxzZSgpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mbygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taW5mby1ncmFkaWVudCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1pbmZvLWJldmVsLWdsb3ctc2hhZG93KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tdGV4dCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1pbmZvLWZvY3VzKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWluZm8taG92ZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taW5mby1hY3RpdmUoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taW5mby1ib3JkZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGlzYWJsZWQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tbGluZS1oZWlnaHQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taW5mby1wdWxzZSgpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tZGFuZ2VyKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItZ3JhZGllbnQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGFuZ2VyLWJldmVsLWdsb3ctc2hhZG93KCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJvcmRlci1yYWRpdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tdGV4dCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItZm9jdXMoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGFuZ2VyLWhvdmVyKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWRhbmdlci1hY3RpdmUoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGFuZ2VyLWJvcmRlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1kaXNhYmxlZCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1saW5lLWhlaWdodCgpO1xuICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItcHVsc2UoKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXNlY29uZGFyeSgpIHtcbiAgY29sb3I6IG5iLXRoZW1lKGJ0bi1vdXRsaW5lLWZnKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWJnKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXNlY29uZGFyeS1iZXZlbC1nbG93LXNoYWRvdygpO1xuICBAaW5jbHVkZSBidG4taGVyby1ib3JkZXItcmFkaXVzKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXRleHQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWZvY3VzKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXNlY29uZGFyeS1ob3ZlcigpO1xuICBAaW5jbHVkZSBidG4taGVyby1zZWNvbmRhcnktYWN0aXZlKCk7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLXNlY29uZGFyeS1ib3JkZXIoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZGlzYWJsZWQoKTtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LXB1bHNlKCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1ncmFkaWVudC1sZWZ0KCRjb2xvciwgJGRlZ3JlZXM6IDIwZGVnKSB7XG4gIEByZXR1cm4gYWRqdXN0LWh1ZSgkY29sb3IsICRkZWdyZWVzKTtcbn1cblxuLy8gRnVuY3Rpb25zIGZvciBib3gtc2hhZG93XG5AZnVuY3Rpb24gYnRuLWhlcm8tYmV2ZWwoJGNvbG9yKSB7XG4gIEByZXR1cm4gbmItdGhlbWUoYnRuLWhlcm8tYmV2ZWwtc2l6ZSkgc2hhZGUoJGNvbG9yLCAxNCUpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tZ2xvdygkaGVyby1nbG93LXNpemUsICRjb2xvcikge1xuICBAcmV0dXJuIG5iLXRoZW1lKCRoZXJvLWdsb3ctc2l6ZSkgJGNvbG9yO1xufVxuXG4vLyBMZWZ0IGNvbG9yc1xuQGZ1bmN0aW9uIGJ0bi1oZXJvLXByaW1hcnktbGVmdC1jb2xvcigpIHtcbiAgQHJldHVybiBidG4taGVyby1ncmFkaWVudC1sZWZ0KG5iLXRoZW1lKGJ0bi1wcmltYXJ5LWJnKSwgbmItdGhlbWUoYnRuLWhlcm8tcHJpbWFyeS1kZWdyZWUpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXN1Y2Nlc3MtbGVmdC1jb2xvcigpIHtcbiAgQHJldHVybiBidG4taGVyby1ncmFkaWVudC1sZWZ0KG5iLXRoZW1lKGJ0bi1zdWNjZXNzLWJnKSwgbmItdGhlbWUoYnRuLWhlcm8tc3VjY2Vzcy1kZWdyZWUpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXdhcm5pbmctbGVmdC1jb2xvcigpIHtcbiAgQHJldHVybiBidG4taGVyby1ncmFkaWVudC1sZWZ0KG5iLXRoZW1lKGJ0bi13YXJuaW5nLWJnKSwgbmItdGhlbWUoYnRuLWhlcm8td2FybmluZy1kZWdyZWUpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWluZm8tbGVmdC1jb2xvcigpIHtcbiAgQHJldHVybiBidG4taGVyby1ncmFkaWVudC1sZWZ0KG5iLXRoZW1lKGJ0bi1pbmZvLWJnKSwgbmItdGhlbWUoYnRuLWhlcm8taW5mby1kZWdyZWUpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWRhbmdlci1sZWZ0LWNvbG9yKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQobmItdGhlbWUoYnRuLWRhbmdlci1iZyksIG5iLXRoZW1lKGJ0bi1oZXJvLWRhbmdlci1kZWdyZWUpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXNlY29uZGFyeS1sZWZ0LWNvbG9yKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWdyYWRpZW50LWxlZnQobmItdGhlbWUoYnRuLXNlY29uZGFyeS1ib3JkZXIpLCBuYi10aGVtZShidG4taGVyby1zZWNvbmRhcnktZGVncmVlKSk7XG59XG5cbi8vIE1pZGRsZSBjb2xvcnNcbkBmdW5jdGlvbiBidG4taGVyby1wcmltYXJ5LW1pZGRsZS1jb2xvcigpIHtcbiAgQHJldHVybiBtaXgoYnRuLWhlcm8tcHJpbWFyeS1sZWZ0LWNvbG9yKCksIG5iLXRoZW1lKGJ0bi1wcmltYXJ5LWJnKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zdWNjZXNzLW1pZGRsZS1jb2xvcigpIHtcbiAgQHJldHVybiBtaXgoYnRuLWhlcm8tc3VjY2Vzcy1sZWZ0LWNvbG9yKCksIG5iLXRoZW1lKGJ0bi1zdWNjZXNzLWJnKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby13YXJuaW5nLW1pZGRsZS1jb2xvcigpIHtcbiAgQHJldHVybiBtaXgoYnRuLWhlcm8td2FybmluZy1sZWZ0LWNvbG9yKCksIG5iLXRoZW1lKGJ0bi13YXJuaW5nLWJnKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1pbmZvLW1pZGRsZS1jb2xvcigpIHtcbiAgQHJldHVybiBtaXgoYnRuLWhlcm8taW5mby1sZWZ0LWNvbG9yKCksIG5iLXRoZW1lKGJ0bi1pbmZvLWJnKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1kYW5nZXItbWlkZGxlLWNvbG9yKCkge1xuICBAcmV0dXJuIG1peChidG4taGVyby1kYW5nZXItbGVmdC1jb2xvcigpLCBuYi10aGVtZShidG4tZGFuZ2VyLWJnKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zZWNvbmRhcnktbWlkZGxlLWNvbG9yKCkge1xuICBAcmV0dXJuIG1peChidG4taGVyby1zZWNvbmRhcnktbGVmdC1jb2xvcigpLCBuYi10aGVtZShidG4tc2Vjb25kYXJ5LWJvcmRlcikpO1xufVxuXG4vLyBsaWdodCBncmFkaWVudHNcblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpIHtcbiAgJGNvbG9yLWxlZnQ6IHRpbnQoJGNvbG9yLWxlZnQsIDE0JSk7XG4gICRjb2xvci1yaWdodDogdGludCgkY29sb3ItcmlnaHQsIDE0JSk7XG5cbiAgQHJldHVybiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tcHJpbWFyeS1saWdodC1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4tcHJpbWFyeS1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1wcmltYXJ5LWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tc3VjY2Vzcy1saWdodC1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4tc3VjY2Vzcy1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1zdWNjZXNzLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8td2FybmluZy1saWdodC1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4td2FybmluZy1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby13YXJuaW5nLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8taW5mby1saWdodC1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4taW5mby1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1pbmZvLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tZGFuZ2VyLWxpZ2h0LWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1kYW5nZXItYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8tZGFuZ2VyLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tc2Vjb25kYXJ5LWxpZ2h0LWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8tc2Vjb25kYXJ5LWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWxpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG4vLyBkYXJrIGdyYWRpZW50c1xuXG5AZnVuY3Rpb24gYnRuLWhlcm8tZGFyay1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KSB7XG4gICRjb2xvci1sZWZ0OiBzaGFkZSgkY29sb3ItbGVmdCwgMTQlKTtcbiAgJGNvbG9yLXJpZ2h0OiBzaGFkZSgkY29sb3ItcmlnaHQsIDE0JSk7XG5cbiAgQHJldHVybiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8tcHJpbWFyeS1kYXJrLWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1wcmltYXJ5LWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXByaW1hcnktbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tZGFyay1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXN1Y2Nlc3MtZGFyay1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4tc3VjY2Vzcy1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1zdWNjZXNzLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWRhcmstZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby13YXJuaW5nLWRhcmstZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLXdhcm5pbmctYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8td2FybmluZy1sZWZ0LWNvbG9yKCk7XG5cbiAgQHJldHVybiBidG4taGVyby1kYXJrLWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8taW5mby1kYXJrLWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1pbmZvLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLWluZm8tbGVmdC1jb2xvcigpO1xuXG4gIEByZXR1cm4gYnRuLWhlcm8tZGFyay1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWRhbmdlci1kYXJrLWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1kYW5nZXItYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8tZGFuZ2VyLWxlZnQtY29sb3IoKTtcblxuICBAcmV0dXJuIGJ0bi1oZXJvLWRhcmstZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG4vLyBFbmQgZnVuY3Rpb25zXG5cbi8vIEhlbHAgbWl4aW5zXG5AbWl4aW4gYnRuLWhlcm8tdGV4dCgpIHtcbiAgdGV4dC1zaGFkb3c6IG5iLXRoZW1lKGJ0bi1oZXJvLXRleHQtc2hhZG93KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWhvdmVyKCRsaWdodC1ncmFkaWVudCkge1xuICAmOmhvdmVyLFxuICAuaG92ZXIge1xuICAgIGJhY2tncm91bmQtaW1hZ2U6ICRsaWdodC1ncmFkaWVudDtcbiAgfVxufVxuXG5AbWl4aW4gYnRuLWhlcm8tZm9jdXMoJGxpZ2h0LWdyYWRpZW50KSB7XG4gICY6Zm9jdXMsXG4gIC5mb2N1cyB7XG4gICAgYmFja2dyb3VuZC1pbWFnZTogJGxpZ2h0LWdyYWRpZW50O1xuICB9XG59XG5cbkBtaXhpbiBidG4taGVyby1hY3RpdmUoJGRhcmstZ3JhZGllbnQpIHtcbiAgJjphY3RpdmUsXG4gIC5hY3RpdmUge1xuICAgIGJhY2tncm91bmQtaW1hZ2U6ICRkYXJrLWdyYWRpZW50O1xuICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxufVxuXG5AbWl4aW4gYnRuLWhlcm8tYm9yZGVyLXJhZGl1cygpIHtcbiAgYm9yZGVyLXJhZGl1czogbmItdGhlbWUoYnRuLWhlcm8tYm9yZGVyLXJhZGl1cyk7XG59XG4vLyBFbmQgaGVscCBtaXhpbnNcblxuXG4vLyBHcmFkaWVudFxuQG1peGluIGJ0bi1oZXJvLXByaW1hcnktZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLXByaW1hcnktYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8tcHJpbWFyeS1sZWZ0LWNvbG9yKCk7XG5cbiAgQGluY2x1ZGUgbmItcmlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zdWNjZXNzLWdyYWRpZW50KCkge1xuICAkY29sb3ItcmlnaHQ6IG5iLXRoZW1lKGJ0bi1zdWNjZXNzLWJnKTtcbiAgJGNvbG9yLWxlZnQ6IGJ0bi1oZXJvLXN1Y2Nlc3MtbGVmdC1jb2xvcigpO1xuXG4gIEBpbmNsdWRlIG5iLXJpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8td2FybmluZy1ncmFkaWVudCgpIHtcbiAgJGNvbG9yLXJpZ2h0OiBuYi10aGVtZShidG4td2FybmluZy1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby13YXJuaW5nLWxlZnQtY29sb3IoKTtcblxuICBAaW5jbHVkZSBuYi1yaWdodC1ncmFkaWVudCgkY29sb3ItbGVmdCwgJGNvbG9yLXJpZ2h0KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWluZm8tZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLWluZm8tYmcpO1xuICAkY29sb3ItbGVmdDogYnRuLWhlcm8taW5mby1sZWZ0LWNvbG9yKCk7XG5cbiAgQGluY2x1ZGUgbmItcmlnaHQtZ3JhZGllbnQoJGNvbG9yLWxlZnQsICRjb2xvci1yaWdodCk7XG59XG5cbkBtaXhpbiBidG4taGVyby1kYW5nZXItZ3JhZGllbnQoKSB7XG4gICRjb2xvci1yaWdodDogbmItdGhlbWUoYnRuLWRhbmdlci1iZyk7XG4gICRjb2xvci1sZWZ0OiBidG4taGVyby1kYW5nZXItbGVmdC1jb2xvcigpO1xuXG4gIEBpbmNsdWRlIG5iLXJpZ2h0LWdyYWRpZW50KCRjb2xvci1sZWZ0LCAkY29sb3ItcmlnaHQpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc2Vjb25kYXJ5LWJnKCkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBuYi10aGVtZShidG4tc2Vjb25kYXJ5LWJnKTtcbn1cblxuXG4vLyBCZXZlbFxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXByaW1hcnktYmV2ZWwoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tYmV2ZWwoYnRuLWhlcm8tcHJpbWFyeS1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zdWNjZXNzLWJldmVsKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWJldmVsKGJ0bi1oZXJvLXN1Y2Nlc3MtbWlkZGxlLWNvbG9yKCkpO1xufVxuXG5AZnVuY3Rpb24gYnRuLWhlcm8td2FybmluZy1iZXZlbCgpIHtcbiAgQHJldHVybiBidG4taGVyby1iZXZlbChidG4taGVyby13YXJuaW5nLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWluZm8tYmV2ZWwoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tYmV2ZWwoYnRuLWhlcm8taW5mby1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1kYW5nZXItYmV2ZWwoKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tYmV2ZWwoYnRuLWhlcm8tZGFuZ2VyLW1pZGRsZS1jb2xvcigpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLXNlY29uZGFyeS1iZXZlbCgpIHtcbiAgQHJldHVybiBidG4taGVyby1iZXZlbChidG4taGVyby1zZWNvbmRhcnktbWlkZGxlLWNvbG9yKCkpO1xufVxuXG5cbi8vIEdsb3dcbkBmdW5jdGlvbiBidG4taGVyby1wcmltYXJ5LWdsb3coKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tZ2xvdyhidG4taGVyby1wcmltYXJ5LWdsb3ctc2l6ZSwgYnRuLWhlcm8tcHJpbWFyeS1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zdWNjZXNzLWdsb3coKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tZ2xvdyhidG4taGVyby1zdWNjZXNzLWdsb3ctc2l6ZSwgYnRuLWhlcm8tc3VjY2Vzcy1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby13YXJuaW5nLWdsb3coKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tZ2xvdyhidG4taGVyby13YXJuaW5nLWdsb3ctc2l6ZSwgYnRuLWhlcm8td2FybmluZy1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1pbmZvLWdsb3coKSB7XG4gIEByZXR1cm4gYnRuLWhlcm8tZ2xvdyhidG4taGVyby1pbmZvLWdsb3ctc2l6ZSwgYnRuLWhlcm8taW5mby1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1kYW5nZXItZ2xvdygpIHtcbiAgQHJldHVybiBidG4taGVyby1nbG93KGJ0bi1oZXJvLWRhbmdlci1nbG93LXNpemUsIGJ0bi1oZXJvLWRhbmdlci1taWRkbGUtY29sb3IoKSk7XG59XG5cbkBmdW5jdGlvbiBidG4taGVyby1zZWNvbmRhcnktZ2xvdygpIHtcbiAgQHJldHVybiBidG4taGVyby1nbG93KGJ0bi1oZXJvLXNlY29uZGFyeS1nbG93LXNpemUsIGJ0bi1oZXJvLXNlY29uZGFyeS1taWRkbGUtY29sb3IoKSk7XG59XG5cblxuLy8gQmV2ZWwtZ2xvdy1zaGFkb3dcbkBtaXhpbiBidG4taGVyby1iZXZlbC1nbG93LXNoYWRvdygkYmV2ZWwsICRnbG93LCAkc2hhZG93KSB7XG4gICRib3gtc2hhZG93OiAkYmV2ZWwsICRnbG93O1xuICBAaWYgKCRzaGFkb3cgIT0gJ25vbmUnKSB7XG4gICAgJGJveC1zaGFkb3c6ICRib3gtc2hhZG93LCAkc2hhZG93O1xuICB9XG4gIGJveC1zaGFkb3c6ICRib3gtc2hhZG93O1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1iZXZlbC1nbG93LXNoYWRvdygpIHtcbiAgJGJldmVsOiBidG4taGVyby1wcmltYXJ5LWJldmVsKCk7XG4gICRnbG93OiBidG4taGVyby1wcmltYXJ5LWdsb3coKTtcbiAgJHNoYWRvdzogbmItdGhlbWUoYnRuLWhlcm8tc2hhZG93KTtcblxuICBAaW5jbHVkZSBidG4taGVyby1iZXZlbC1nbG93LXNoYWRvdygkYmV2ZWwsICRnbG93LCAkc2hhZG93KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtYmV2ZWwtZ2xvdy1zaGFkb3coKSB7XG4gICRiZXZlbDogYnRuLWhlcm8tc3VjY2Vzcy1iZXZlbCgpO1xuICAkZ2xvdzogYnRuLWhlcm8tc3VjY2Vzcy1nbG93KCk7XG4gICRzaGFkb3c6IG5iLXRoZW1lKGJ0bi1oZXJvLXNoYWRvdyk7XG5cbiAgQGluY2x1ZGUgYnRuLWhlcm8tYmV2ZWwtZ2xvdy1zaGFkb3coJGJldmVsLCAkZ2xvdywgJHNoYWRvdyk7XG59XG5cbkBtaXhpbiBidG4taGVyby13YXJuaW5nLWJldmVsLWdsb3ctc2hhZG93KCkge1xuICAkYmV2ZWw6IGJ0bi1oZXJvLXdhcm5pbmctYmV2ZWwoKTtcbiAgJGdsb3c6IGJ0bi1oZXJvLXdhcm5pbmctZ2xvdygpO1xuICAkc2hhZG93OiBuYi10aGVtZShidG4taGVyby1zaGFkb3cpO1xuXG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJldmVsLWdsb3ctc2hhZG93KCRiZXZlbCwgJGdsb3csICRzaGFkb3cpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mby1iZXZlbC1nbG93LXNoYWRvdygpIHtcbiAgJGJldmVsOiBidG4taGVyby1pbmZvLWJldmVsKCk7XG4gICRnbG93OiBidG4taGVyby1pbmZvLWdsb3coKTtcbiAgJHNoYWRvdzogbmItdGhlbWUoYnRuLWhlcm8tc2hhZG93KTtcblxuICBAaW5jbHVkZSBidG4taGVyby1iZXZlbC1nbG93LXNoYWRvdygkYmV2ZWwsICRnbG93LCAkc2hhZG93KTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWRhbmdlci1iZXZlbC1nbG93LXNoYWRvdygpIHtcbiAgJGJldmVsOiBidG4taGVyby1kYW5nZXItYmV2ZWwoKTtcbiAgJGdsb3c6IGJ0bi1oZXJvLWRhbmdlci1nbG93KCk7XG4gICRzaGFkb3c6IG5iLXRoZW1lKGJ0bi1oZXJvLXNoYWRvdyk7XG5cbiAgQGluY2x1ZGUgYnRuLWhlcm8tYmV2ZWwtZ2xvdy1zaGFkb3coJGJldmVsLCAkZ2xvdywgJHNoYWRvdyk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktYmV2ZWwtZ2xvdy1zaGFkb3coKSB7XG4gICRiZXZlbDogYnRuLWhlcm8tc2Vjb25kYXJ5LWJldmVsKCk7XG4gICRnbG93OiBidG4taGVyby1zZWNvbmRhcnktZ2xvdygpO1xuICAkc2hhZG93OiBuYi10aGVtZShidG4taGVyby1zaGFkb3cpO1xuXG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWJldmVsLWdsb3ctc2hhZG93KCRiZXZlbCwgJGdsb3csICRzaGFkb3cpO1xufVxuXG5cbi8vIEJvcmRlclxuQG1peGluIGJ0bi1oZXJvLXByaW1hcnktYm9yZGVyKCkge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbkBtaXhpbiBidG4taGVyby1zdWNjZXNzLWJvcmRlcigpIHtcbiAgYm9yZGVyOiBub25lO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8td2FybmluZy1ib3JkZXIoKSB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWluZm8tYm9yZGVyKCkge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbkBtaXhpbiBidG4taGVyby1kYW5nZXItYm9yZGVyKCkge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktYm9yZGVyKCkge1xuICBib3JkZXI6IDJweCBzb2xpZCBuYi10aGVtZShidG4tc2Vjb25kYXJ5LWJvcmRlcik7XG5cbiAgQGluY2x1ZGUgbmItZm9yLXRoZW1lKGNvcnBvcmF0ZSkge1xuICAgIGJvcmRlcjogbm9uZTtcbiAgfVxufVxuXG5cbi8vIEhvdmVyXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1ob3ZlcigpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taG92ZXIoYnRuLWhlcm8tcHJpbWFyeS1saWdodC1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtaG92ZXIoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWhvdmVyKGJ0bi1oZXJvLXN1Y2Nlc3MtbGlnaHQtZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby13YXJuaW5nLWhvdmVyKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1ob3ZlcihidG4taGVyby13YXJuaW5nLWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mby1ob3ZlcigpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taG92ZXIoYnRuLWhlcm8taW5mby1saWdodC1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWRhbmdlci1ob3ZlcigpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8taG92ZXIoYnRuLWhlcm8tZGFuZ2VyLWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc2Vjb25kYXJ5LWhvdmVyKCkge1xuICAmOmhvdmVyLFxuICAuaG92ZXIge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEobmItdGhlbWUoYnRuLXNlY29uZGFyeS1ib3JkZXIpLCAwLjIpO1xuICB9XG59XG5cbi8vIEZvY3VzXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1mb2N1cygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZm9jdXMoYnRuLWhlcm8tcHJpbWFyeS1saWdodC1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXN1Y2Nlc3MtZm9jdXMoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWZvY3VzKGJ0bi1oZXJvLXN1Y2Nlc3MtbGlnaHQtZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby13YXJuaW5nLWZvY3VzKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1mb2N1cyhidG4taGVyby13YXJuaW5nLWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mby1mb2N1cygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZm9jdXMoYnRuLWhlcm8taW5mby1saWdodC1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLWRhbmdlci1mb2N1cygpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tZm9jdXMoYnRuLWhlcm8tZGFuZ2VyLWxpZ2h0LWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8tc2Vjb25kYXJ5LWZvY3VzKCkge1xuICAkY29sb3I6IG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYm9yZGVyKTtcblxuICAmOmZvY3VzLFxuICAuZm9jdXMge1xuICAgIGJvcmRlci1jb2xvcjogdGludCgkY29sb3IsIDE0JSk7XG4gIH1cbn1cblxuLy8gQWN0aXZlXG5AbWl4aW4gYnRuLWhlcm8tcHJpbWFyeS1hY3RpdmUoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWFjdGl2ZShidG4taGVyby1wcmltYXJ5LWRhcmstZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zdWNjZXNzLWFjdGl2ZSgpIHtcbiAgQGluY2x1ZGUgYnRuLWhlcm8tYWN0aXZlKGJ0bi1oZXJvLXN1Y2Nlc3MtZGFyay1ncmFkaWVudCgpKTtcbn1cblxuQG1peGluIGJ0bi1oZXJvLXdhcm5pbmctYWN0aXZlKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1hY3RpdmUoYnRuLWhlcm8td2FybmluZy1kYXJrLWdyYWRpZW50KCkpO1xufVxuXG5AbWl4aW4gYnRuLWhlcm8taW5mby1hY3RpdmUoKSB7XG4gIEBpbmNsdWRlIGJ0bi1oZXJvLWFjdGl2ZShidG4taGVyby1pbmZvLWRhcmstZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1kYW5nZXItYWN0aXZlKCkge1xuICBAaW5jbHVkZSBidG4taGVyby1hY3RpdmUoYnRuLWhlcm8tZGFuZ2VyLWRhcmstZ3JhZGllbnQoKSk7XG59XG5cbkBtaXhpbiBidG4taGVyby1zZWNvbmRhcnktYWN0aXZlKCkge1xuICAkY29sb3I6IG5iLXRoZW1lKGJ0bi1zZWNvbmRhcnktYm9yZGVyKTtcblxuICAmOmFjdGl2ZSxcbiAgLmFjdGl2ZSB7XG4gICAgYm9yZGVyLWNvbG9yOiBzaGFkZSgkY29sb3IsIDE0JSk7XG4gICAgYm94LXNoYWRvdzogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xuICB9XG59XG5cblxuLy8gRGlzYWJsZWRcbkBtaXhpbiBidG4taGVyby1kaXNhYmxlZCgpIHtcbiAgJjpkaXNhYmxlZCB7XG4gICAgb3BhY2l0eTogbmItdGhlbWUoYnRuLWRpc2FibGVkLW9wYWNpdHkpO1xuICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gIH1cbn1cblxuLy8gTGluZSBoZWlnaHRcbkBmdW5jdGlvbiBidG4taGVyby1saW5lLWhlaWdodCgkZm9udC1zaXplKSB7XG4gIEByZXR1cm4gY2FsYygoI3skZm9udC1zaXplfSAqIDEuMjUpICsgNHB4KTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LWxnKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0KG5iLXRoZW1lKGJ0bi1mb250LXNpemUtbGcpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LW1kKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0KG5iLXRoZW1lKGJ0bi1mb250LXNpemUtbWQpKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LXNtKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0KG5iLXRoZW1lKGJ0bi1mb250LXNpemUtc20pKTtcbn1cblxuQGZ1bmN0aW9uIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LXRuKCkge1xuICBAcmV0dXJuIGJ0bi1oZXJvLWxpbmUtaGVpZ2h0KG5iLXRoZW1lKGJ0bi1mb250LXNpemUtdG4pKTtcbn1cblxuXG5AbWl4aW4gYnRuLWhlcm8tbGluZS1oZWlnaHQoKSB7XG5cbiAgbGluZS1oZWlnaHQ6IGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LW1kKCk7XG5cbiAgJi5idG4uYnRuLWxnIHtcbiAgICBsaW5lLWhlaWdodDogYnRuLWhlcm8tbGluZS1oZWlnaHQtbGcoKTtcbiAgfVxuXG4gICYuYnRuLmJ0bi1tZCB7XG4gICAgbGluZS1oZWlnaHQ6IGJ0bi1oZXJvLWxpbmUtaGVpZ2h0LW1kKCk7XG4gIH1cblxuICAmLmJ0bi5idG4tc20ge1xuICAgIGxpbmUtaGVpZ2h0OiBidG4taGVyby1saW5lLWhlaWdodC1zbSgpO1xuICB9XG5cbiAgJi5idG4uYnRuLXRuIHtcbiAgICBsaW5lLWhlaWdodDogYnRuLWhlcm8tbGluZS1oZWlnaHQtdG4oKTtcbiAgfVxufVxuXG4vLyBQdWxzZVxuQG1peGluIGJ0bi1oZXJvLXByaW1hcnktcHVsc2UoKSB7XG4gIEBpbmNsdWRlIGJ0bi1wdWxzZShoZXJvLXByaW1hcnksIG5iLXRoZW1lKGNvbG9yLXByaW1hcnkpKTtcbn1cbkBtaXhpbiBidG4taGVyby1zdWNjZXNzLXB1bHNlKCkge1xuICBAaW5jbHVkZSBidG4tcHVsc2UoaGVyby1zdWNjZXNzLCBuYi10aGVtZShjb2xvci1zdWNjZXNzKSk7XG59XG5AbWl4aW4gYnRuLWhlcm8tZGFuZ2VyLXB1bHNlKCkge1xuICBAaW5jbHVkZSBidG4tcHVsc2UoaGVyby1kYW5nZXIsIG5iLXRoZW1lKGNvbG9yLWRhbmdlcikpO1xufVxuQG1peGluIGJ0bi1oZXJvLWluZm8tcHVsc2UoKSB7XG4gIEBpbmNsdWRlIGJ0bi1wdWxzZShoZXJvLWluZm8sIG5iLXRoZW1lKGNvbG9yLWluZm8pKTtcbn1cbkBtaXhpbiBidG4taGVyby13YXJuaW5nLXB1bHNlKCkge1xuICBAaW5jbHVkZSBidG4tcHVsc2UoaGVyby13YXJuaW5nLCBuYi10aGVtZShjb2xvci13YXJuaW5nKSk7XG59XG5AbWl4aW4gYnRuLWhlcm8tc2Vjb25kYXJ5LXB1bHNlKCkge1xuICBAaW5jbHVkZSAgYnRuLXB1bHNlKGhlcm8tc2Vjb25kYXJ5LCBuYi10aGVtZShidG4tc2Vjb25kYXJ5LWJvcmRlcikpO1xufVxuIiwiQGltcG9ydCBcIi4uLy4uL0B0aGVtZS9zdHlsZXMvdGhlbWVzXCI7XHJcbkBpbXBvcnQgXCJ+QG5lYnVsYXIvdGhlbWUvc3R5bGVzL2dsb2JhbC9ib290c3RyYXAvaGVyby1idXR0b25zXCI7XHJcblxyXG5AaW5jbHVkZSBuYi1pbnN0YWxsLWNvbXBvbmVudCgpIHtcclxuICAud2Ige1xyXG4gICAgd29yZC1icmVhazogYnJlYWstYWxsICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICBuYi1jYXJkIHtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgaGVpZ2h0OiA2cmVtO1xyXG4gICAgb3ZlcmZsb3c6IHZpc2libGU7XHJcblxyXG4gICAgJGJldmVsOiBidG4taGVyby1iZXZlbChuYi10aGVtZShjYXJkLWJnKSk7XHJcbiAgICAkc2hhZG93OiBuYi10aGVtZShidG4taGVyby1zaGFkb3cpO1xyXG4gICAgYm94LXNoYWRvdzogJGJldmVsLCAkc2hhZG93O1xyXG5cclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkNWRiZTA7XHJcbiAgICBib3JkZXItdG9wLWNvbG9yOiByZ2IoMjEzLCAyMTksIDIyNCk7XHJcbiAgICBib3JkZXItdG9wLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci10b3Atd2lkdGg6IDFweDtcclxuICAgIGJvcmRlci1yaWdodC1jb2xvcjogcmdiKDIxMywgMjE5LCAyMjQpO1xyXG4gICAgYm9yZGVyLXJpZ2h0LXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci1yaWdodC13aWR0aDogMXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1jb2xvcjogcmdiKDIxMywgMjE5LCAyMjQpO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItYm90dG9tLXdpZHRoOiAxcHg7XHJcbiAgICBib3JkZXItbGVmdC1jb2xvcjogcmdiKDIxMywgMjE5LCAyMjQpO1xyXG4gICAgYm9yZGVyLWxlZnQtc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWxlZnQtd2lkdGg6IDFweDtcclxuICAgIGJvcmRlci1pbWFnZS1zb3VyY2U6IGluaXRpYWw7XHJcbiAgICBib3JkZXItaW1hZ2Utc2xpY2U6IGluaXRpYWw7XHJcbiAgICBib3JkZXItaW1hZ2Utd2lkdGg6IGluaXRpYWw7XHJcbiAgICBib3JkZXItaW1hZ2Utb3V0c2V0OiBpbml0aWFsO1xyXG4gICAgYm9yZGVyLWltYWdlLXJlcGVhdDogaW5pdGlhbDtcclxuXHJcbiAgICAuaWNvbi1jb250YWluZXIge1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgIHBhZGRpbmc6IDAuNjI1cmVtO1xyXG4gICAgfVxyXG5cclxuICAgIC5pY29uIHtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIHdpZHRoOiA1Ljc1cmVtO1xyXG4gICAgICBoZWlnaHQ6IDQuNzVyZW07XHJcbiAgICAgIGZvbnQtc2l6ZTogMy43NXJlbTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKTtcclxuICAgICAgdHJhbnNpdGlvbjogd2lkdGggMC40cyBlYXNlO1xyXG4gICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xyXG4gICAgICAtd2Via2l0LXRyYW5zZm9ybS1zdHlsZTogcHJlc2VydmUtM2Q7XHJcbiAgICAgIC13ZWJraXQtYmFja2ZhY2UtdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gICAgICBjb2xvcjogbmItdGhlbWUoY29sb3Itd2hpdGUpO1xyXG5cclxuICAgICAgJi5wcmltYXJ5IHtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1wcmltYXJ5LWdyYWRpZW50KCk7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8tcHJpbWFyeS1iZXZlbC1nbG93LXNoYWRvdygpO1xyXG4gICAgICB9XHJcbiAgICAgICYuc3VjY2VzcyB7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8tc3VjY2Vzcy1ncmFkaWVudCgpO1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLXN1Y2Nlc3MtYmV2ZWwtZ2xvdy1zaGFkb3coKTtcclxuICAgICAgfVxyXG4gICAgICAmLmluZm8ge1xyXG4gICAgICAgIEBpbmNsdWRlIGJ0bi1oZXJvLWluZm8tZ3JhZGllbnQoKTtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1pbmZvLWJldmVsLWdsb3ctc2hhZG93KCk7XHJcbiAgICAgIH1cclxuICAgICAgJi53YXJuaW5nIHtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby13YXJuaW5nLWdyYWRpZW50KCk7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8td2FybmluZy1iZXZlbC1nbG93LXNoYWRvdygpO1xyXG4gICAgICB9XHJcbiAgICAgICYuZGFuZ2VyIHtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItZ3JhZGllbnQoKTtcclxuICAgICAgICBAaW5jbHVkZSBidG4taGVyby1kYW5nZXItYmV2ZWwtZ2xvdy1zaGFkb3coKTtcclxuICAgICAgfVxyXG4gICAgICAmLnNlY29uZGFyeSB7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWJnKCk7XHJcbiAgICAgICAgQGluY2x1ZGUgYnRuLWhlcm8tc2Vjb25kYXJ5LWJldmVsLWdsb3ctc2hhZG93KCk7XHJcbiAgICAgICAgY29sb3I6IG5iLXRoZW1lKGNhcmQtZmcpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBAaW5jbHVkZSBuYi1mb3ItdGhlbWUoY29ycG9yYXRlKSB7XHJcbiAgICAgICAgJi5wcmltYXJ5LFxyXG4gICAgICAgICYuc3VjY2VzcyxcclxuICAgICAgICAmLmluZm8sXHJcbiAgICAgICAgJi53YXJuaW5nLFxyXG4gICAgICAgICYuZGFuZ2VyLFxyXG4gICAgICAgICYuc2Vjb25kYXJ5IHtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgIGJhY2tncm91bmQ6IGxpZ2h0ZW4obmItdGhlbWUoY2FyZC1iZyksIDUlKTtcclxuXHJcbiAgICAgIC5pY29uIHtcclxuICAgICAgICAmLnByaW1hcnkge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogYnRuLWhlcm8tcHJpbWFyeS1saWdodC1ncmFkaWVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLnN1Y2Nlc3Mge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogYnRuLWhlcm8tc3VjY2Vzcy1saWdodC1ncmFkaWVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLmluZm8ge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogYnRuLWhlcm8taW5mby1saWdodC1ncmFkaWVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLndhcm5pbmcge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogYnRuLWhlcm8td2FybmluZy1saWdodC1ncmFkaWVudCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLmRhbmdlciB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiAnYnRuLWhlcm8tZGFuZ2VyLWxpZ2h0LWdyYWRpZW50KCknO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLnNlY29uZGFyeSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiBidG4taGVyby1zZWNvbmRhcnktbGlnaHQtZ3JhZGllbnQoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAmLm9mZiB7XHJcbiAgICAgIGNvbG9yOiBuYi10aGVtZShjYXJkLWZnKTtcclxuXHJcbiAgICAgIC5pY29uIHtcclxuICAgICAgICBjb2xvcjogbmItdGhlbWUoY2FyZC1mZyk7XHJcblxyXG4gICAgICAgICYucHJpbWFyeSxcclxuICAgICAgICAmLnN1Y2Nlc3MsXHJcbiAgICAgICAgJi5pbmZvLFxyXG4gICAgICAgICYud2FybmluZyxcclxuICAgICAgICAmLmRhbmdlciB7XHJcbiAgICAgICAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0LCB0cmFuc3BhcmVudCwgdHJhbnNwYXJlbnQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgJi5zZWNvbmRhcnkge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICAudGl0bGUge1xyXG4gICAgICAgIGNvbG9yOiBuYi10aGVtZShjYXJkLWZnKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5kZXRhaWxzIHtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgQGluY2x1ZGUgbmItbHRyKHBhZGRpbmcsIDAgMC41cmVtIDAgMC43NXJlbSk7XHJcbiAgICAgIEBpbmNsdWRlIG5iLXJ0bChwYWRkaW5nLCAwIDAuNzVyZW0gMCAwLjVyZW0pO1xyXG4gICAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgfVxyXG5cclxuICAgIC50aXRsZSB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBuYi10aGVtZShmb250LXNlY29uZGFyeSk7XHJcbiAgICAgIGZvbnQtc2l6ZTogMS4yNXJlbTtcclxuICAgICAgZm9udC13ZWlnaHQ6IG5iLXRoZW1lKGZvbnQtd2VpZ2h0LWJvbGQpO1xyXG4gICAgICBjb2xvcjogbmItdGhlbWUoY2FyZC1mZy1oZWFkaW5nKTtcclxuICAgIH1cclxuXHJcbiAgICAuc3RhdHVzIHtcclxuICAgICAgZm9udC1zaXplOiAxcmVtO1xyXG4gICAgICBmb250LXdlaWdodDogbmItdGhlbWUoZm9udC13ZWlnaHQtbGlnaHQpO1xyXG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICBjb2xvcjogbmItdGhlbWUoY2FyZC1mZyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBAaW5jbHVkZSBuYi1mb3ItdGhlbWUoY29ycG9yYXRlKSB7XHJcbiAgICBuYi1jYXJkIHtcclxuICAgICAgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qICBAaW5jbHVkZSBuYi1mb3ItdGhlbWUoY29zbWljKSB7XHJcbiAgICBuYi1jYXJkIHtcclxuICAgICAgJi5vZmYgLmljb24tY29udGFpbmVyIHtcclxuICAgICAgICBAaW5jbHVkZSBuYi1sdHIoYm9yZGVyLXJpZ2h0LCAxcHggc29saWQgbmItdGhlbWUoc2VwYXJhdG9yKSk7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItcnRsKGJvcmRlci1sZWZ0LCAxcHggc29saWQgbmItdGhlbWUoc2VwYXJhdG9yKSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5pY29uLWNvbnRhaW5lciB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmRldGFpbHMge1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLWx0cihwYWRkaW5nLWxlZnQsIDEuMjVyZW0pO1xyXG4gICAgICAgIEBpbmNsdWRlIG5iLXJ0bChwYWRkaW5nLXJpZ2h0LCAxLjI1cmVtKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmljb24ge1xyXG4gICAgICAgIHdpZHRoOiA3cmVtO1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICBmb250LXNpemU6IDQuNXJlbTtcclxuICAgICAgICBAaW5jbHVkZSBuYi1sdHIoYm9yZGVyLXJhZGl1cywgbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKSAwIDAgbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKSk7XHJcbiAgICAgICAgQGluY2x1ZGUgbmItcnRsKGJvcmRlci1yYWRpdXMsIDAgbmItdGhlbWUoY2FyZC1ib3JkZXItcmFkaXVzKSBuYi10aGVtZShjYXJkLWJvcmRlci1yYWRpdXMpIDApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudGl0bGUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBuYi10aGVtZShmb250LXdlaWdodC1ib2xkZXIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuc3RhdHVzIHtcclxuICAgICAgICBmb250LXdlaWdodDogbmItdGhlbWUoZm9udC13ZWlnaHQtbGlnaHQpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSovXHJcbiIsIi8vIEBuZWJ1bGFyIHRoZW1pbmcgZnJhbWV3b3JrXHJcbkBpbXBvcnQgJ35AbmVidWxhci90aGVtZS9zdHlsZXMvdGhlbWluZyc7XHJcbi8vIEBuZWJ1bGFyIG91dCBvZiB0aGUgYm94IHRoZW1lc1xyXG5AaW1wb3J0ICd+QG5lYnVsYXIvdGhlbWUvc3R5bGVzL3RoZW1lcyc7XHJcblxyXG4vLyB3aGljaCB0aGVtZXMgeW91IHdoYXQgdG8gZW5hYmxlIChlbXB0eSB0byBlbmFibGUgYWxsKVxyXG4kbmItZW5hYmxlZC10aGVtZXM6ICgpO1xyXG5cclxuJG5iLXRoZW1lczogbmItcmVnaXN0ZXItdGhlbWUoKFxyXG4gLy8gYXBwIHdpc2UgdmFyaWFibGVzIGZvciBlYWNoIHRoZW1lXHJcbiAgc2lkZWJhci1oZWFkZXItZ2FwOiAycmVtLFxyXG4gIHNpZGViYXItaGVhZGVyLWhlaWdodDogaW5pdGlhbCxcclxuICBsYXlvdXQtY29udGVudC13aWR0aDogMTQwMHB4LFxyXG5cclxuICBmb250LW1haW46IFJvYm90byxcclxuICBmb250LXNlY29uZGFyeTogUm9ib3RvLFxyXG5cclxuICBzd2l0Y2hlci1iYWNrZ3JvdW5kOiAjZWJlZmY1LFxyXG4gIHN3aXRjaGVyLWJhY2tncm91bmQtcGVyY2VudGFnZTogNTAlLFxyXG4gIGRyb3BzLWljb24tbGluZS1nYWRpZW50OiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgjMDFkYmI1LCAjMGJiYjc5KSxcclxuKSwgZGVmYXVsdCwgZGVmYXVsdCk7XHJcblxyXG4kbmItdGhlbWVzOiBuYi1yZWdpc3Rlci10aGVtZSgoXHJcbiAgLy8gYXBwIHdpc2UgdmFyaWFibGVzIGZvciBlYWNoIHRoZW1lXHJcbiAgc2lkZWJhci1oZWFkZXItZ2FwOiAycmVtLFxyXG4gIHNpZGViYXItaGVhZGVyLWhlaWdodDogaW5pdGlhbCxcclxuICBsYXlvdXQtY29udGVudC13aWR0aDogMTQwMHB4LFxyXG5cclxuICBmb250LW1haW46IFJvYm90byxcclxuICBmb250LXNlY29uZGFyeTogRXhvLFxyXG5cclxuICBzd2l0Y2hlci1iYWNrZ3JvdW5kOiAjNGU0MWE1LFxyXG4gIHN3aXRjaGVyLWJhY2tncm91bmQtcGVyY2VudGFnZTogMTQlLFxyXG4gIGRyb3BzLWljb24tbGluZS1nYWRpZW50OiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgjYTI1OGZlLCAjNzk1OGZhKSxcclxuKSwgY29zbWljLCBjb3NtaWMpO1xyXG5cclxuJG5iLXRoZW1lczogbmItcmVnaXN0ZXItdGhlbWUoKFxyXG4gIC8vIGFwcCB3aXNlIHZhcmlhYmxlcyBmb3IgZWFjaCB0aGVtZVxyXG4gIHNpZGViYXItaGVhZGVyLWdhcDogMnJlbSxcclxuICBzaWRlYmFyLWhlYWRlci1oZWlnaHQ6IGluaXRpYWwsXHJcbiAgbGF5b3V0LWNvbnRlbnQtd2lkdGg6IDE0MDBweCxcclxuXHJcbiAgZm9udC1tYWluOiBSb2JvdG8sXHJcbiAgZm9udC1zZWNvbmRhcnk6IFJvYm90byxcclxuXHJcbiAgc3dpdGNoZXItYmFja2dyb3VuZDogIzJiMmQzNCxcclxuICBzd2l0Y2hlci1iYWNrZ3JvdW5kLXBlcmNlbnRhZ2U6IDE0JSxcclxuICBkcm9wcy1pY29uLWxpbmUtZ2FkaWVudDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoI2U5ZThlYiwgI2E3YTJiZSksXHJcbiksIGNvcnBvcmF0ZSwgY29ycG9yYXRlKTtcclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/status-card/status-card.component.ts":
/*!************************************************************!*\
  !*** ./src/app/pages/status-card/status-card.component.ts ***!
  \************************************************************/
/*! exports provided: StatusCardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StatusCardComponent", function() { return StatusCardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var StatusCardComponent = /** @class */ (function () {
    function StatusCardComponent() {
        this.on = true;
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "iconClass", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], StatusCardComponent.prototype, "title", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], StatusCardComponent.prototype, "type", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "on", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "value", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], StatusCardComponent.prototype, "value2", void 0);
    StatusCardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ngx-status-card',
            template: __webpack_require__(/*! ./status-card.component.html */ "./src/app/pages/status-card/status-card.component.html"),
            styles: [__webpack_require__(/*! ./status-card.component.scss */ "./src/app/pages/status-card/status-card.component.scss")]
        })
    ], StatusCardComponent);
    return StatusCardComponent;
}());



/***/ })

}]);
//# sourceMappingURL=app-pages-pages-module.js.map