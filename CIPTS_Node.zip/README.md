CIPTS Node server

Fastest Version
