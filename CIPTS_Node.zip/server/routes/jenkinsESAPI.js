
var express = require('express');
var router = express.Router();
var config = require('../configuration.json');
let validationRoute = require('./validation.js');

var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    host: 'http://' + config.elasticsearchDBHost + ':9200',
    log: 'trace'
});
elasticClient.ping({
    requestTimeout: 30000,
}, function (error) {
    if (error) {
        console.log('jenkinsESAPI.js : ERROR: Elasticsearch DB Connection failed !');
    } else {
        console.log('jenkinsESAPI.js : Connection to ElasticSearch DB established !');
    }
});


//Insert json into the ElasticSearch
router.post('/insertNewSample', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----insertNewSample------");
    var json = req.body;
    if (json === null || json === undefined || json === "") {
        return res.status(404).json("Data is not specified");
    }
    console.log(JSON.stringify(json));
    var indexName = json.indexName;
    var indexType = json.indexType;
    var doc = json.doc;
    elasticClient.index({
        index: indexName,
        type: indexType,
        body: doc
    }, function (err, response, status) {
        if (err) {
            console.log("error in insertnewsample : " + err)
            return res.status(500).json(err);

        } else {
            return res.status(200).json(response);
        }
    });
});

//Create Index in ElasticSearch
router.post('/createIndex', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----createIndex------");
    var indexName = req.body.indexName;
    elasticClient.indices.create({
        index: indexName
    }, function (err, resp, status) {
        if (err) {
            console.log("error in createIndex : " +err);
            return res.status(500).json(err);
        } else {
            console.log("index created: "+ resp);
            return res.status(200).json(response);
        }
    });
});

module.exports = router;