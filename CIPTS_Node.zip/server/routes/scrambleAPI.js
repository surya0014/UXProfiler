var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

let validationRoute = require('./validation.js');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('scrambleAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('scrambleAPI.js : DB connection established using mongodb!');
    }
});
const fs = require('fs');

//Get Test Run Stacked By ID For ScrambleURL
router.get('/getTestResultStackedByIDForScrambleURL', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestResultStackedByIDForScrambleURL------");
    var testrunnid = req.query._id;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    var metricname = req.query.metricname;
    if (metricname === null || metricname === undefined || metricname === "" || validationRoute(metricname)) {
        return res.status(404).json("Metric Name is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let responseMessage = {
                scenarioName: records.scenarioName,
                status: records.status,
                startTime: records.startTime,
                endTime: records.endTime,
                duration: records.duration,
            };

            if (records.hasOwnProperty('RAWenabled')) {
                responseMessage.RAWenabled = records.RAWenabled;
            } else {
                responseMessage.RAWenabled = false;
            }

            let fsEnabled = false;
            switch (metricname) {
                case "PanelSummary": {
                    if (records.hasOwnProperty('sla')) {
                        responseMessage.sla = {
                            enabled: records.sla.enabled
                        };
                    } else {
                        responseMessage.sla = {
                            enabled: false
                        };
                    }
                    responseMessage.panelsummary = records.testResult.panelsummary;
                    break;
                }
                case "Summary": {
                    responseMessage.summary = records.testResult.summary;
                    responseMessage.stackedbarchartdata = records.testResult.stackedbarchartdata;
                    break;
                }
                case "Observations": {

                    break;
                }
                case "TotalActiveVUsers": {
                    responseMessage.vUsers = {
                        data: records.testResult.vUsers.data,
                        observations: records.testResult.vUsers.observations
                    };
                    fsEnabled = true;
                    break;
                }
                case "VusersByThreadGroups": {
                    if (records.testResult.hasOwnProperty('vUsersByThreadGroups')) {
                        responseMessage.vUsersByThreadGroups = {
                            data: records.testResult.vUsersByThreadGroups.data,
                            observations: records.testResult.vUsersByThreadGroups.observations
                        };
                    } else {
                        responseMessage.vUsersByThreadGroups = {
                            data: [],
                            observations: []
                        }
                    }
                    fsEnabled = true;
                    break;
                }
                case "ResponseTime": {
                    responseMessage.responseTime = {
                        data: records.testResult.responseTime.data,
                        observations: records.testResult.responseTime.observations
                    };
                    fsEnabled = true;
                    break;
                }
                case "Latency": {
                    if (records.testResult.hasOwnProperty('latency')) {
                        responseMessage.latency = {
                            data: records.testResult.latency.data,
                            observations: records.testResult.latency.observations
                        };
                    } else {
                        responseMessage.latency = {
                            data: [],
                            observations: []
                        }
                    }
                    fsEnabled = true;
                    break;
                }
                case "Throughput": {
                    responseMessage.throughput = {
                        data: records.testResult.throughput.data,
                        observations: records.testResult.throughput.observations
                    };
                    fsEnabled = true;
                    break;
                }
                case "Hits": {
                    responseMessage.hits = {
                        data: records.testResult.hits.data,
                        observations: records.testResult.hits.observations
                    };
                    fsEnabled = true;
                    break;
                }
                case "StatusCodes": {
                    if (records.testResult.hasOwnProperty('statuscodes')) {
                        responseMessage.statuscodes = {
                            data: records.testResult.statuscodes.data,
                            observations: records.testResult.statuscodes.observations
                        };
                    } else {
                        responseMessage.statuscodes = {
                            data: [],
                            observations: []
                        }
                    }
                    fsEnabled = true;
                    break;
                }
                case "Errors": {
                    responseMessage.error = {
                        data: records.testResult.error.data,
                        observations: records.testResult.error.observations
                    };
                    responseMessage.errorsPerTranscationData = records.testResult.errorsPerTranscationData;
                    fsEnabled = true;
                    break;
                }
                case "AssertionErrorResults": {
                    if (records.testResult.hasOwnProperty('assertionerrors')) {
                        responseMessage.assertionerrors = {
                            data: records.testResult.assertionerrors.data,
                        };
                    } else {
                        responseMessage.assertionerrors = {
                            data: [],
                        };
                    }
                    fsEnabled = true;
                    break;
                }
                case "SystemMonitoring": {
                    if (records.hasOwnProperty('systemMonitor')) {
                        responseMessage.systemMonitor = records.systemMonitor;
                    } else {
                        responseMessage.systemMonitor = {
                            enabled: false,
                            machines: []
                        };
                    }

                    if (records.testResult.hasOwnProperty('serverMetrics')) {
                        responseMessage.serverMetrics = records.testResult.serverMetrics;
                    } else {
                        responseMessage.serverMetrics = {
                            data: {
                                cpu_data: [],
                                processor_data: [],
                                memory_data: []
                            },
                            observations: []
                        };
                    }
                    fsEnabled = true;
                    break;
                }
                case "TransactionsRequestsBreakdown": {
                    if (records.testResult.hasOwnProperty('TransactionsRequestsBreakdown')) {
                        responseMessage.TransactionsRequestsBreakdown = {
                            data: records.testResult.TransactionsRequestsBreakdown.data,
                        };
                    } else {
                        responseMessage.TransactionsRequestsBreakdown = {
                            data: [],
                        };
                    }
                    fsEnabled = true;
                    break;
                }
                case "TomcatLogs": {
                    if (records.testResult.hasOwnProperty('TomcatLogs')) {
                        responseMessage.TomcatLogs = records.testResult.TomcatLogs;
                    } else {
                        responseMessage.TomcatLogs = {
                            stdoutLogs: [],
                            stderrLogs: []
                        };
                    }
                    fsEnabled = true;
                    break;
                }
            }
            //console.log(JSON.stringify(responseMessage));
            //return res.status(200).json(responseMessage);
            var jsonFromFs = {};
            //console.log(JSON.stringify(responseMessage));
            try {
                let testRunDocDir = config.mongodocsFSPath + "testruns/" + testrunnid;
                let testRunDocPath = testRunDocDir + "/" + testrunnid + ".json";
                if (fs.existsSync(testRunDocPath) && fsEnabled) {
                    jsonFromFs = getMetricesFromFs(records, metricname);
                    // console.log(JSON.stringify(jsonFromFs));
                    var metrices = Object.keys(jsonFromFs)[0];
                    responseMessage[metrices] = {};
                    // console.log(" responseMessage[metrices] ");
                    // console.log(responseMessage[metrices]);
                    // console.log(jsonFromFs[metrices]);
                    responseMessage[metrices] = jsonFromFs[metrices];
                }
                return res.status(200).json(responseMessage);
            } catch (error) {
                console.log(error);
                return res.status(500).json({ "message": " Error in getting data for" + metricname });
            }
        }
    });
});//end of //getTestResultStackedByIDForScrambleURL



//Getting Scramble
router.get('/getScramble', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getScramble------");


    let serverURI, port, secretKey;
    serverURI = config.scrambled_serverURI;
    port = config.scrambled_port;
    secretKey = config.scrambledSecretKey;

    if (serverURI == "" || port == "") {
        return res.status(500).json({ error: "NOT FOUND" });
    }

    if (port == "80") {
        serverURL = "http://" + serverURI;
    } else if (port == "443") {
        serverURL = "https://" + serverURI;
    } else {
        serverURL = "http://" + serverURI + ":" + port;
    }
    let responseDoc = { URI: serverURL, secretKey: secretKey };
    return res.status(200).json(responseDoc);
});//end of //Getting Scramble 

function getMetricesFromFs(records, metricname) {
    return new Promise(function (resolve, reject) {
        var testResultDocPath = config.mongodocsFSPath + "testruns/";

        var testResultJson = {};
        // console.log(" getMetricesFromFs() ");
        // console.log(metricname);
        switch (metricname) {
            case "PanelSummary": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "panelsummary.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    testResultJson.panelsummary = resultJSON;
                }

                resolve(testResultJson);
            }
            case "Summary": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "summary.json";
                var DocPathBarChart = testResultDocPath + records._id + "/" + records._id + "_" + "stackedbarchartdata.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    const testResultDocBarChart = fs.readFileSync(DocPathBarChart, { encoding: 'utf8', flag: 'r' });
                    var resultJSONBarChart = JSON.parse(testResultDocBarChart);
                    testResultJson.summary = resultJSON;
                    testResultJson.stackedbarchartdata = resultJSONBarChart;
                }

                resolve(testResultJson);
            }
            case "Observations": {

                break;
            }
            case "TotalActiveVUsers": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "vUsers.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    testResultJson.vUsers = {
                        data: resultJSON.data,
                        observations: resultJSON.observations
                    };
                }

                resolve(testResultJson)
            }
            case "VusersByThreadGroups": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "vUsersByThreadGroups.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    if (resultJSON != "" || resultJSON != null) {
                        testResultJson.vUsersByThreadGroups = {
                            data: resultJSON.data,
                            observations: resultJSON.observations
                        };
                    } else {
                        testResultJson.vUsersByThreadGroups = {
                            data: [],
                            observations: []
                        }
                    }
                }
                resolve(testResultJson)
            }
            case "ResponseTime": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "responseTime.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    testResultJson.responseTime = {
                        data: resultJSON.data,
                        observations: resultJSON.observations
                    };
                }
                resolve(testResultJson)
            }
            case "Latency": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "latency.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    if (resultJSON != "" || resultJSON != null) {
                        testResultJson.latency = {
                            data: resultJSON.data,
                            observations: resultJSON.observations
                        };
                    } else {
                        testResultJson.latency = {
                            data: [],
                            observations: []
                        }
                    }
                }
                resolve(testResultJson)
            }
            case "Throughput": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "throughput.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    testResultJson.throughput = {
                        data: resultJSON.data,
                        observations: resultJSON.observations
                    };
                }
                resolve(testResultJson)
            }
            case "Hits": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "hits.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    testResultJson.hits = {
                        data: resultJSON.data,
                        observations: resultJSON.observations
                    };
                }
                resolve(testResultJson)
            }
            case "StatusCodes": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "statuscodes.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    if (resultJSON != "" || resultJSON != null) {
                        testResultJson.statuscodes = {
                            data: resultJSON.data,
                            observations: resultJSON.observations
                        };
                    } else {
                        testResultJson.statuscodes = {
                            data: [],
                            observations: []
                        }
                    }
                }
                resolve(testResultJson)
            }
            case "Errors": {

                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "error.json";
                var DocPathEpt = testResultDocPath + records._id + "/" + records._id + "_" + "errorsPerTranscationData.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDocError = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSONErrorError = JSON.parse(testResultDocError);
                    const testResultDocEpt = fs.readFileSync(DocPathEpt, { encoding: 'utf8', flag: 'r' });
                    var resultJSONEpt = JSON.parse(testResultDocEpt);
                    testResultJson.error = {
                        data: resultJSONErrorError.data,
                        observations: resultJSONErrorError.observations
                    };
                    testResultJson.errorsPerTranscationData = resultJSONEpt;
                }
                resolve(testResultJson)
            }
            case "AssertionErrorResults": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "assertionerrors.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    if (resultJSON != "" || resultJSON != null) {
                        testResultJson.assertionerrors = {
                            data: resultJSON.data,
                        };
                    } else {
                        testResultJson.assertionerrors = {
                            data: [],
                        };
                    }
                }
                resolve(testResultJson)
            }
            case "SystemMonitoring": {
                var DocPathSys = testResultDocPath + records._id + "/" + records._id + "_" + "systemMonitor.json";
                var DocPathServer = testResultDocPath + records._id + "/" + records._id + "_" + "serverMetrics.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDocSys = fs.readFileSync(DocPathSys, { encoding: 'utf8', flag: 'r' });
                    var resultJSONSys = JSON.parse(testResultDocSys);
                    const testResultDocServer = fs.readFileSync(DocPathServer, { encoding: 'utf8', flag: 'r' });
                    var resultJSONServer = JSON.parse(testResultDocServer);
                    if (resultJSONSys != null || resultJSONSys != "") {
                        testResultJson.systemMonitor = resultJSONSys;
                    } else {
                        testResultJson.systemMonitor = {
                            enabled: false,
                            machines: []
                        };
                    }

                    if (resultJSONServer != "" || resultJSONServer != null) {
                        testResultJson.serverMetrics = resultJSONServer;
                    } else {
                        testResultJson.serverMetrics = {
                            data: {
                                cpu_data: [],
                                processor_data: [],
                                memory_data: []
                            },
                            observations: []
                        };
                    }
                }
                resolve(testResultJson)
            }
            case "TransactionsRequestsBreakdown": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "TransactionsRequestsBreakdown.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    if (resultJSON != "" || resultJSON != null) {
                        testResultJson.TransactionsRequestsBreakdown = {
                            data: resultJSON.data,
                        };
                    } else {
                        testResultJson.TransactionsRequestsBreakdown = {
                            data: [],
                        };
                    }
                }
                resolve(testResultJson)
            }
            case "TomcatLogs": {
                var DocPath = testResultDocPath + records._id + "/" + records._id + "_" + "TomcatLogs.json";
                if (fs.existsSync(testResultDocPath + records._id)) {
                    const testResultDoc = fs.readFileSync(DocPath, { encoding: 'utf8', flag: 'r' });
                    var resultJSON = JSON.parse(testResultDoc);
                    if (resultJSON != "" || resultJSON != null) {
                        testResultJson.TomcatLogs = resultJSON;
                    } else {
                        testResultJson.TomcatLogs = {
                            stdoutLogs: [],
                            stderrLogs: []
                        };
                    }
                }
                resolve(testResultJson)
            }

        }
    });
}

module.exports = router;
