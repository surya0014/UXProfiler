

var amqp = require('amqplib/callback_api');
// amqp.connect('amqp://ec2-35-154-123-139.ap-south-1.compute.amazonaws.com', function (err, conn) {
// amqp.connect('amqp://13.234.166.85', function (err, conn) {
// amqp.connect('amqp://guest:guest@172.31.26.66:5672', function (err, conn) {
amqp.connect('amqp://zantmeter:zantmeter2019@ec2-35-154-123-139.ap-south-1.compute.amazonaws.com:5672', function (err, conn) {

    if (err !== null) { return console.warn(err); }
    console.log("Connection established RabbitMQ !");
    conn.createChannel(function (err, ch) {
        var jwt = require('jsonwebtoken');
        const token = jwt.sign({ id: 123, customerID: 123, role: "admin" }, "secretKey", { expiresIn: "7d" });
        let data = new Date().toISOString() + " - "+ token;

        let t1="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTIzLCJjdXN0b21lcklEIjoxMjMsInJvbGUiOiJhZG1pbiIsImlhdCI6MTU2MjkyMzUzOSwiZXhwIjoxNTYzNTI4MzM5fQ.IfAkJSihjEw6LAsbl5G-inwaRO_lRPhX9C77CP7g2mo";

        jwt.verify(t1, "secretKey", function (err, decoded) {
            if (err) { //failed verification.
                console.log(err);
            }
            console.log(decoded);
        });
        console.log("Channel created RabbitMQ !");
        ch.assertQueue("StopFinalThreadGroup_task_queue", { durable: true });
        ch.sendToQueue("StopFinalThreadGroup_task_queue", new Buffer(JSON.stringify(data)), { persistent: true });
        console.log(" [x] Sent '%s'", data);
    });
    setTimeout(function () {
        conn.close();
        /* process.exit(0) */
        console.log("Connection terminated RabbitMQ !");
    }, 2000);
});