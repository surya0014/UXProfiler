var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

var Request = require("request");

let validationRoute = require('./validation.js');
var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('devAPI.js : ERROR: DB connection failed');
        return err;
    } else {
        db = mydb.db();
        console.log('devAPI.js : DB connection established for analyse API!');
    }
});

const Influx = require('influx');
// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://' + config.influxDBUserName + ':' + config.influxDBPassword + '@' + config.influxDBHost + ':8086/zantmeter');

var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    host: 'http://' + config.elasticsearchDBHost + ':9200',
    log: 'trace'
});
elasticClient.ping({
    requestTimeout: 30000,
}, function (error) {
    if (error) {
        console.log('devAPI.js : ERROR: Elasticsearch DB Connection failed !');
    } else {
        console.log('devAPI.js : Connection to ElasticSearch DB established !');
    }
});
//getResponseTimeForIDByAggregationInterval
router.get('/getResponseTimeForIDByAggregationInterval', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getResponseTimeForIDByAggregationInterval------");
    var testrunid = req.query.testrunid;

    if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }


    var aggregationInterval = 12;
    if (req.query.aggregationInterval) {
        aggregationInterval = req.query.aggregationInterval;
    }
    //select mean(ResponseTime) from Transactions where RunID='5cef7edb3753e59844101115' group by TransactionName, time(12m) fill(none);
    var sql = "select mean(ResponseTime) from Transactions where RunID='" + testrunid + "' group by TransactionName, time(" + aggregationInterval + "m) fill(none)";
    influx.query(sql)
        .then(result => {
            var formattedData = [];
            try {
                let Data = JSON.parse(JSON.stringify(result));
                if (Data.length > 0) {
                    var groupByName = {};

                    Data.forEach((obj) => {
                        groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
                        groupByName[obj.TransactionName].push(obj);
                    });
                    //console.log(JSON.stringify(groupByName));
                    let transcationNames = Object.keys(groupByName);
                    let series, seriesVal;
                    for (var iName = 0; iName < transcationNames.length; iName++) {
                        series = [];
                        //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
                        for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                            seriesVal = {
                                name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                                value: groupByName[transcationNames[iName]][vi].mean,
                            };
                            series.push(seriesVal);
                        }
                        //console.log(JSON.stringify(series));
                        formattedData.push({ name: transcationNames[iName], series: series });
                    }
                }
            } catch (e) {
                console.log("Error in getResponseTimeForIDByAggregationInterval " + e);
                callback("");
            }
            //res.status(200).json(result);
            res.status(200).json(formattedData);
        }).catch(error => res.status(500).json({ error }));
});//end of getResponseTimeForIDByAggregationInterval



//get90percentileResponseTimeForIDByAggregationInterval
router.get('/get90percentileResponseTimeForIDByAggregationInterval', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----get90percentileResponseTimeForIDByAggregationInterval------");
    var testrunid = req.query.testrunid;

    if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }


    var aggregationInterval = 12;
    if (req.query.aggregationInterval) {
        aggregationInterval = req.query.aggregationInterval;
    }
    //percentile(\"ResponseTime\", 90) as percentile
    //select mean(ResponseTime) from Transactions where RunID='5cef7edb3753e59844101115' group by TransactionName, time(12m) fill(none);
    var sql = "select percentile(\"ResponseTime\", 90) from Transactions where RunID='" + testrunid + "' group by TransactionName, time(" + aggregationInterval + "m) fill(none)";
    influx.query(sql)
        .then(result => {
            var formattedData = [];
            try {
                let Data = JSON.parse(JSON.stringify(result));
                if (Data.length > 0) {
                    var groupByName = {};

                    Data.forEach((obj) => {
                        groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
                        groupByName[obj.TransactionName].push(obj);
                    });
                    //console.log(JSON.stringify(groupByName));
                    let transcationNames = Object.keys(groupByName);
                    let series, seriesVal;
                    for (var iName = 0; iName < transcationNames.length; iName++) {
                        series = [];
                        //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
                        for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                            seriesVal = {
                                name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                                value: groupByName[transcationNames[iName]][vi].mean,
                            };
                            series.push(seriesVal);
                        }
                        //console.log(JSON.stringify(series));
                        formattedData.push({ name: transcationNames[iName], series: series });
                    }
                }
            } catch (e) {
                console.log("Error in getResponseTimeForIDByAggregationInterval " + e);
                callback("");
            }
            //res.status(200).json(result);
            res.status(200).json(formattedData);
        }).catch(error => res.status(500).json({ error }));
});//end of get90percentileResponseTimeForIDByAggregationInterval

function customFormatDate(dateTBM) {
    //console.log("-----customFormatDate()------");
    var Mdate = '';
    if (dateTBM) {
        //Mdate = formatDate(dateTBM, 'MM-d-y HH:mm:ss', 'en-US');
        //Mdate = formatDate(dateTBM, 'HH:mm:ss', 'en-US');
        //new Date(dateTBM).getTime()
        Mdate = new Date(dateTBM).getTime();
    }
    return Mdate;
}


//Get the TomcatLogs apachelogs-stdout
router.get('/getTomcatLogs', async function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    var indexName = req.query.indexName;
    //var hostName = req.query.hostName;
    var testrunid = req.query.testrunid;

    var docsLimit = req.query.limit;//4000
    //getTomcatLogs?indexName=apachelogs-stdout&testrunid=
    //getTomcatLogs?indexName=apachelogs-stderr&testrunid=

    /* console.log('indexName: '+indexName);
    console.log('hostName: '+hostName); */
    if (indexName === null || indexName === undefined || indexName === "" || validationRoute(indexName)) {
        return res.status(404).json("Index Name is not specified or not valid");
    }
    /* if (hostName === null || hostName === undefined || hostName === "" || validationRoute(hostName)) {
        return res.status(404).json("Host Name is not specified or not valid");
    } */
    if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }

    if (docsLimit === null || docsLimit === undefined || docsLimit === "" || validationRoute(docsLimit)) {
        return res.status(404).json("Size is not specified or not valid");
    }



    let testRunDoc = await getTestRunDoc(testrunid);

    let gteString = testRunDoc.startTime;//"now-1h"

    let lteString = "now";

    if (testRunDoc.endTime !== null || testRunDoc.endTime !== undefined || testRunDoc.endTime !== "") {
        lteString = testRunDoc.endTime;
    }
    let hostName;
    /* if(testRunDoc.testGroups[0].loadAgent.type =="CloudAuto"){
        let CloudAutoLA_ID = testRunDoc.testGroups[0].loadAgent.CloudAutoLA_ID;
        let instanceID =testRunDoc.testGroups[0].loadAgent.instanceID;
        //  console.log(CloudAutoLA_ID);
        // console.log(instanceID); 
        hostName = await getCloudAutoHostName(String(CloudAutoLA_ID), String(instanceID));
    }else{
        let loadAgentName =testRunDoc.testGroups[0].loadAgent.loadAgentName;
        hostName = await getHostName(String(loadAgentName));
        // if(hostName == "localhost"){
        //     hostName = "EC2AMAZ-D04857E";//CPCINCHDV000849//EC2AMAZ-D04857E
        // } 
    } */
    /* 
    if (hostName === null || hostName === undefined || hostName === "") {
        return res.status(500).json("Host Name Missing");
    } */
    let ESData = await getESData(indexName, hostName, gteString, lteString, testrunid, docsLimit);

    if (ESData instanceof Array) {
        let responseLogs = [];
        let content = "<!DOCTYPE html><html><head><title>Logs</title></head><body><p>";
        ESData.forEach((obj) => {
            responseLogs.push(obj.message);
            content += obj.message + "<br/>";
        });
        content += "</p></body></html>";

        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write(content);
        return res.end();
        //return res.status(200).json(ESData);
    } else {
        return res.status(500).json(ESData);
    }

});


async function getESData(indexName, hostName, gteString, lteString, testrunid, docsLimit) {
    try {
        console.log("-----getESData()------");

        /* const ESresponsecount = await elasticClient.count({
            index: indexName,
            body: {
                "query": {
                    "bool": {
                        // "must": [
                        //     {
                        //         "match": {
                        //             "host": hostName
                        //         }
                        //     }
                        // ],
                        "must": [
                            {
                                "match": {
                                    "testrunid": testrunid
                                }
                            }
                        ],
                        "filter": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": gteString,
                                        "lt": lteString
                                    }
                                }
                            }
                        ]
                    }
                }
            }
        });
        console.log("--------------------ESresponsecount------------------------------");
        console.log(ESresponsecount);
        console.log("-----------------------------------------------------------------");
        // {
        //     count: 290,
        //     _shards: { total: 1, successful: 1, skipped: 0, failed: 0 }
        // }
        let DocsCount = ESresponsecount.count; */
        const ESresponse = await elasticClient.search({
            index: indexName,
            body: {

                "size": docsLimit,//4000,
                "query": {
                    "bool": {
                        /* "must": [
                            {
                                "match": {
                                    "host": hostName
                                }
                            }
                        ], */
                        "must": [
                            {
                                "match": {
                                    "testrunid": testrunid
                                }
                            }
                        ],
                        "filter": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": gteString,
                                        "lt": lteString
                                    }
                                }
                            }
                        ]
                    }

                }/* ,
                "_source": {
                    "includes": ["id", "post_date"]
                } */,
                "sort": [
                    {
                        "@timestamp": {
                            "order": "desc"
                        }
                    }
                ]
            }
        });

        /* 
           _index
           _source.message
    
    {
     "_index":"apachelogs-stdout",
     "_type":"doc",
     "_id":"25OME2gBaJachl_2E7m0",
     "_score":null,
     "_source":{
       "@timestamp":"2019-01-03T11:49:33.589Z",
       "host":"EC2AMAZ-OOVMB4A",
       "@version":"1",
       "path":"C:/Program Files/Apache Software Foundation/Tomcat 9.0/logs/tomcat9-stdout.2019-01-03.log",
       "message":"Have set test run ID to NULL\r"
     },
     "sort":[
       1546516173589
     ]
    }
    
    
    {
     "_index":"apachelogs-stderr",
     "_type":"doc",
     "_id":"3pOME2gBaJachl_2I7md",
     "_score":null,
     "_source":{
       "host":"EC2AMAZ-OOVMB4A",
       "time":"11:49:37.511",
       "logtype":"WARNING",
       "log":"[Thread-9] org.apache.catalina.loader.WebappClassLoaderBase.clearReferencesThreads The web application [ZantMeterServices] appears to have started a thread named [NanoOffset] but has failed to stop it. This is very likely to create a memory leak. Stack trace of thread:",
       "@timestamp":"2019-01-03T11:49:37.667Z",
       "date":"03-Jan-2019",
       "@version":"1",
       "path":"C:/Program Files/Apache Software Foundation/Tomcat 9.0/logs/tomcat9-stderr.2019-01-03.log",
       "message":"03-Jan-2019 11:49:37.511 WARNING [Thread-9] org.apache.catalina.loader.WebappClassLoaderBase.clearReferencesThreads The web application [ZantMeterServices] appears to have started a thread named [NanoOffset] but has failed to stop it. This is very likely to create a memory leak. Stack trace of thread:"
     },
     "sort":[
       1546516177667
     ]
    }
           */
        let Logs = [];
        let Hits = ESresponse.hits.hits;
        if ((Hits != null) || (Hits != undefined) || (Hits != [])) {
            if (indexName == "apachelogs-stderr") {
                Hits.forEach((hit) => {
                    let Obj = {
                        indexName: hit._index,
                        hostName: hit._source.host,
                        message: hit._source.message,
                        logtype: hit._source.logtype,
                        datetime: hit._source.date + " " + hit._source.time,
                        log: hit._source.log,
                    };

                    if ((Obj.logtype == "WARNING") || (Obj.logtype == "ERROR") || (Obj.logtype == "FATAL")) {
                        Logs.push(Obj);
                    }
                });
            } else {
                Hits.forEach((hit) => {
                    let Obj = {
                        indexName: hit._index,
                        hostName: hit._source.host,
                        message: hit._source.message,
                    };
                    Logs.push(Obj);
                });
            }
        }
        return Logs;
        //return res.status(200).json(Logs);
    } catch (error) {
        console.log(error.message);
        return error.message;
        //return res.status(500).json(error.message);
    }
}



function getTestRunDoc(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----getTestRunDoc()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, record) {
            if (err) {
                console.log("Error in getTestRunDoc : " + err);
                reject(err);
            } else {
                callback(record);
            }
        });
    });
}


function getHostName(loadAgentName) {
    return new Promise(function (callback, reject) {
        console.log("-----getHostName()------");
        console.log(loadAgentName);
        db.collection('LoadAgents').findOne({ "loadAgentName": loadAgentName }, function (err, record) {
            if (err) {
                console.log("Error in getHostName : " + err);
                reject(err);
            } else {
                console.log(record);
                callback(record.localHostName);
            }
        });
    });
}

function getCloudAutoHostName(CloudAutoLA_ID, instanceID) {
    return new Promise(function (callback, reject) {
        console.log("-----getCloudAutoHostName()------");
        console.log(CloudAutoLA_ID);
        console.log(instanceID);
        db.collection('LoadAgents').findOne({ "CloudAutoLA_ID": parseInt(CloudAutoLA_ID), "instanceID": String(instanceID) }, function (err, record) {
            if (err) {
                console.log("Error in getCloudAutoHostName : " + err);
                reject(err);
            } else {
                console.log(record);
                callback(record.localHostName);
            }
        });
    });
}

async function getHost() {
    console.log("--------started--------");
    let sample = await getHostName("52615", "i-0205949c2a942e60a");
    console.log(sample);
    console.log("--------finished--------");
    //console.log(JSON.stringify(sample));
}

//getHost();

//Get Specific Response Time Samples For ID
router.get('/getSpecificResponseTimeSamplesForID', async function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getSpecificResponseTimeSamplesForID------");
    var testrunnid = req.query.testrunid;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    /* let fromDateTime = req.query.fromDateTime;
    if (fromDateTime === null || fromDateTime === undefined || fromDateTime === "" || validationRoute(fromDateTime)) {
        return res.status(404).json("From Date Time is not specified or not valid");
    } */
    let toDateTime = req.query.toDateTime;
    if (toDateTime === null || toDateTime === undefined || toDateTime === "" || validationRoute(toDateTime)) {
        return res.status(404).json("To Date Time is not specified or not valid");
    }

    let transactionName = req.query.transactionName;
    if (transactionName === null || transactionName === undefined || transactionName === "") {
        return res.status(404).json("Transaction Name is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    // console.log(fromDateTime +" "+1568183344000);
    // console.log(typeof(fromDateTime) +" "+typeof(1568183344000));
    // console.log(toDateTime);

    //let duration = await getTestRunDuration(testrunnid);

    let aggregationInterval = 10;

    /* db.collection('TestRuns').findOne({ "_id": bsonID }, { projection: { 'testResult.influxRawData.Transactions': true } }, function (err, record) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let data = new Array();
            if (record.hasOwnProperty("testResult")) {
                if (record.testResult.hasOwnProperty("influxRawData")) {
                    if (record.testResult.influxRawData.hasOwnProperty("Transactions")) {
                        data = data.concat(record.testResult.influxRawData.Transactions);
                        // let fromDate = new Date(1568183344000),toDate = new Date(1568183348000);
                        let fromDate = new Date(new Number(fromDateTime)), toDate = new Date(new Number(toDateTime));
                        data.forEach((obj) => {
                            obj.time = new Date(obj.time);
                        });
                        data = data.filter((item) => {
                            return ((item.time.getTime() >= fromDate.getTime()) && (item.time.getTime() <= toDate.getTime()));
                        });
                    }
                }
            }
            return res.status(200).json(data);
        }
    }); */
    let datetime = new Date(new Number(toDateTime));
    // console.log("before : " + new Date(datetime.getTime()));

    datetime.setSeconds(datetime.getSeconds() - aggregationInterval);
    // console.log("after -"+aggregationInterval+"s : " + new Date(datetime.getTime()));
    let fromDateTime = datetime.getTime();
    let responseData;
    responseData = await getSpecificResponseTimeSamples(bsonID, fromDateTime, toDateTime, transactionName);
    if (responseData instanceof Array) {
        return res.status(200).json(responseData);
    } else {
        return res.status(500).json(responseData);
    }
});//end of //getSpecificResponseTimeSamplesForID


function getSpecificResponseTimeSamples(bsonID, fromDateTime, toDateTime, transactionName) {
    return new Promise(function (callback, reject) {
        console.log("-----getSpecificResponseTimeSamples------");
        db.collection('TestRuns').findOne({ "_id": bsonID }, { projection: { 'testResult.influxRawData.Transactions': true } }, function (err, record) {
            if (err) {
                reject(err);
            } else {
                let data = new Array();
                if (record.hasOwnProperty("testResult")) {
                    if (record.testResult.hasOwnProperty("influxRawData")) {
                        if (record.testResult.influxRawData.hasOwnProperty("Transactions")) {
                            data = data.concat(record.testResult.influxRawData.Transactions);
                            // let fromDate = new Date(1568183344000),toDate = new Date(1568183348000);
                            let fromDate = new Date(new Number(fromDateTime)), toDate = new Date(new Number(toDateTime));
                            data.forEach((obj) => {
                                obj.time = new Date(obj.time);
                            });
                            data = data.filter((item) => {
                                return ((item.time.getTime() >= fromDate.getTime()) && (item.time.getTime() <= toDate.getTime()) && (item.TransactionName == transactionName));
                            });
                        }
                    }
                }
                callback(data);
            }
        });
    });
}



module.exports = router;