var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var config = require('../configuration.json');
let validationRoute = require('./validation.js');

//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('Loadagents.js : ERROR: DB connection failed');
        return err;
    } else {
        db = mydb.db();
        console.log('Loadagents.js : DB connection established!');
    }
});



//Insert new load agent
router.post('/newLoadAgent', function (req, res, next) {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds
    
    console.log("-----newLoadAgent------");
    
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    var loadAgentData = req.body;
    if (loadAgentData === null || loadAgentData === undefined || loadAgentData === "") {
        return res.status(404).json("Load Agent Data is not specified");
    }
    // console.log(JSON.stringify(loadAgentData));
    loadAgentData.customerId = bsonCustomerID;
    db.collection('LoadAgents').insertOne(loadAgentData, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({
                status: 'Added Load Agent'
            });
        }
    });
});//end of ///newLoadAgent


//Update load agent
router.put('/updateLoadAgent', function (req, res, next) {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds

    console.log("-----updateLoadAgent------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    var loadAgentid = req.query._id;
    var loadAgentData = req.body;
    //console.log(JSON.stringify(loadAgentData));

    if (loadAgentid === null || loadAgentid === undefined || loadAgentid === "" || validationRoute(loadAgentid)) {
        return res.status(404).json("Load Agent ID is not specified or not valid");
    }
    if (loadAgentData === null || loadAgentData === undefined || loadAgentData === "") {
        return res.status(404).json("Load Agent Data is not specified");
    }
    var bsonID = mongodb.ObjectID(loadAgentid);
    var newvalues = { $set: loadAgentData };

    db.collection('LoadAgents').update({ '_id': bsonID, "customerId": bsonCustomerID }, newvalues, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({
                status: 'Updated Load Agent'
            })
        }
    });
});//end of //update Load Agent

//delete load agent
router.delete('/removeLoadAgent', function (req, res, next) {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds

    console.log("-----removeLoadAgent------");
    var loadAgentid = req.query._id;
    if (loadAgentid === null || loadAgentid === undefined || loadAgentid === "" || validationRoute(loadAgentid)) {
        return res.status(404).json("Load Agent ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(loadAgentid);
    
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection('LoadAgents').deleteOne({ "_id": bsonID, "customerId": bsonCustomerID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({
                status: 'Deleted Load Agent'
            })
        }
    });
});//end of //delete load agent


module.exports = router;