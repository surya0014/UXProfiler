
async function timer() {
    
    console.log("-------------Started--------------");
    //const response = await timeoutTimer(10);
    const response = await Promise.all([timeoutTimer(11)]);
    const response1 = await Promise.all([timeoutTimer(12)]);
    console.log("-------------Finished--------------");
    return response1;
    
}

timer().then(data => {
    console.log("data :"+data);
}).catch(err => {
    console.log(err);
});

function timeoutTimer(i){
    console.log("-------------timeoutTimer---Started------"+i+"--------");
    return new Promise(function (callback, reject) {
        try {
            setTimeout(()=>{
                console.log("index:"+i);
                console.log("-------------timeoutTimer---Completed------"+i+"--------");
                callback("success");
            },2000);
            console.log("-------------timeoutTimer---Ended------"+i+"--------");
        } catch (e) {
            console.log("Error" + e);
            reject(e);
        }
    });
}

