var config = require('../configuration.json');

var Request = require("request");

var path = require('path');

var rfs = require("rotating-file-stream");
var stdoutLogStream = rfs(config.heartbeatLogFile, {//'stdout_heartbeat.log', {
    size: config.logFileSize,//"10M",
    interval: config.logFileInterval,//"1d",
    path: config.scriptLogPath,//path: 'C:/ZantMeter/SourceCode/Node-SourceCode/ZantmeterNodeServer_Oct302108/server/logs/',//path.join(__dirname, '/logs/'),
    //compress: "gzip" 
});

var fs = require('fs');
function Logger(content) {
    try {
        console.log(content);
        //fs.appendFile('C:/ZantMeter/SourceCode/Node-SourceCode/ZantmeterNodeServer_Oct302108/server/logs/stdout_heartbeat.log', content + "\r\n", function (err) {
        fs.appendFile(config.scriptLogPath + config.heartbeatLogFile, content + "\r\n", function (err) {
            if (err) throw err;
        });
    } catch (e) {
        console.log("Error in Logger " + e);
    }
}

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
var heartbeatTimer = config.heartbeatTimer;//3 * 60 * 1000;//15 mins //3 mins
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        Logger('heartbeat.js : ERROR: DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        Logger('heartbeat.js : DB connection established using mongodb!');
        let timer = heartbeatTimer * 60 * 1000;//3 * 60 * 1000;//15 mins //3 mins
        setInterval(heartbeat, timer);
        heartbeat();
    }
});

const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));

async function heartbeat() {

    let utcTimestamp = new Date();
    let isoTimestamp = utcTimestamp.toISOString();
    Logger('heartbeat.js : Started : ' + isoTimestamp);

    //while (true) {
    let loadAgents = await getLoadAgents();
    if (loadAgents.status == 'SUCCESS') {
        let laList = loadAgents.message;
        // Logger(laList);
        for (let ila = 0; ila < laList.length; ila++) {
            try {
                let loadAgent = JSON.parse(JSON.stringify(laList[ila]));
                let hostname = loadAgent.loadAgentName;
                let port;
                if (loadAgent.hasOwnProperty('port')) {
                    port = loadAgent.port;
                }
                if ((port == undefined) || (port == null) || (port == "")) {
                    port = 8080;
                }
                let loadAgentCheckStatus = await getLoadAgentStatus(hostname, port);
                if (loadAgentCheckStatus.status == 'SUCCESS') {
                    // Logger("status : old " + loadAgent.status + " - new " + loadAgentCheckStatus.message);
                    if (String(loadAgent.status).toLowerCase() != String(loadAgentCheckStatus.message).toLowerCase()) {
                        // Logger("Updating status " + loadAgentCheckStatus.message + " - " + hostname);
                        updateLoadAgentStatus(loadAgent._id, String(loadAgentCheckStatus.message), hostname);
                    }
                }
            } catch (e) {
                Logger("Error in heartbeat " + e);
            }
            await sleep(1000);
        }
    }
    //await sleep(1000);
    //}

    utcTimestamp = new Date();
    isoTimestamp = utcTimestamp.toISOString();
    Logger('heartbeat.js : Ended : ' + isoTimestamp);
}

function getLoadAgents() {
    Logger("-----getLoadAgents()------");
    return new Promise(function (callback, reject) {
        try {
            db.collection("LoadAgents").find({ "type": "OnPremise" }).toArray((err, result) => {
                if (err) {
                    Logger("Error in getLoadAgents : " + err);
                    reject({
                        'status': 'ERROR',
                        'message': err
                    });
                } else {
                    //Logger("Result  "  +result);
                    callback({
                        'status': 'SUCCESS',
                        'message': result
                    });
                }
            });
        } catch (e) {
            Logger("Error in getLoadAgents " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}


function getLoadAgentStatus(hostName, port) {
    return new Promise(function (callback, reject) {
        Logger("-----getLoadAgentStatus()------");
        let URL = "http://" + hostName + ":" + port + "/ZantMeterServices/rest/checkagentstatus"
        try {
            Logger(URL);
            Request.get(URL, (error, response, body) => {
                if (error) {
                    if (error.hasOwnProperty('code')) {
                        if ((error.code == "ETIMEDOUT") || (error.code == "ECONNREFUSED")) {
                            Logger("Error in getLoadAgentStatus : " + error);
                            callback({
                                'status': 'SUCCESS',
                                'message': "OFFLINE"
                            });
                        }
                    }
                    Logger("Error in getLoadAgentStatus : " + error);
                    reject({
                        'status': 'ERROR',
                        'message': error
                    });
                }
                if ((body != null)) {// && typeof body == 'object')) {
                    //Logger(body);
                    let checkagentstatusObj = JSON.parse(body);

                    callback({
                        'status': 'SUCCESS',
                        'message': checkagentstatusObj.status
                    });
                } else {
                    reject({
                        'status': 'ERROR',
                        'message': body
                    });
                }
            });
        } catch (e) {
            Logger("Error in getLoadAgentStatus " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

function updateLoadAgentStatus(id, status, hostName) {
    return new Promise(function (callback, reject) {
        Logger("-----updateLoadAgentStatus()------");
        try {
            let newval = { $set: { status: status } };

            db.collection("LoadAgents").update({ "_id": mongodb.ObjectId(id) }, newval, function (err, result) {
                if (err) {
                    Logger("Error in updateLoadAgentStatus : " + err);
                    reject({
                        'status': 'ERROR',
                        'message': err
                    });
                }
                Logger("Updating status " + status + " - " + hostName);
                callback(result);
            });
        } catch (e) {
            Logger("Error in updateLoadAgentStatus " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}
