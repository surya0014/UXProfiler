var express = require('express');

var router = express.Router();

var mongoDb = require('mongodb');
var config = require('../configuration.json');

var validationRoute = require('./validation.js');

var mongoClient = mongoDb.MongoClient;
var dbUrl = config.mongoDBURL;
var db;

mongoClient.connect(dbUrl, function (error, myDb) {
    if (error) {
        console.log(" billingAPI.js - Mongodb connection Failed");
    }
    else {
        db = myDb.db();
        console.log(" billingAPI.js - Mongodb connected");
    }
});


router.get('/getBillingRecordsForTimeRange', function (req, res) {

    var stTime = req.query.startTime;
    var edTime = req.query.endTime;
    var startTime = new Date(stTime);
    var endTime = new Date(edTime);
    var CustomerId = req.query.CustomerId;

    console.log("customer id : " + CustomerId);
    console.log(" startTime : " + startTime);
    console.log(" endTime : " + endTime);
    var TotalCost = 0;
    db.collection('AWSBilling').find({ "CustomerId": mongoDb.ObjectID(CustomerId), "startTime": { $gte: startTime.toISOString() }, "endTime": { $lte: endTime.toISOString() } }).toArray(function (error, result) {
        if (error) {
            return res.status(500).json("Failed");
        } else {
            for (let resultObj of result) {
                TotalCost = TotalCost + resultObj.price;
            }
            return res.status(200).json({ "TotalCost": TotalCost })
        }
    })

});
router.get('/addDataToBillingRecordForTestRun', async function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');

    console.log(" inside /addDataToBillingRecord ");
    var testRunId = req.query.testRunId;
    var resultForAddData;
    try {
        resultForAddData = await calculatePriceForTestRun(testRunId);
    } catch (error) {
        console.log("inside catch in /addDataToBillingRecord")
    }

    if (resultForAddData === undefined) {
        return res.status(500).json("Error  in adding Data .....");
    } else {
        return res.status(200).json(resultForAddData);
    }


});


router.get('/addDataToBillingRecordForCustomers', async function (req, res) {

    console.log(" inside /addDataToBillingRecordForCustomers ");
    var customerID = req.query.customerID;
    var stTime = req.query.startTime;
    var edTime = req.query.endTime;
    var startTime = new Date(stTime);
    var endTime = new Date(edTime);
    console.log(startTime);
    console.log(endTime);

    try {
        let resultForAddData = await calculatePriceForCustomer(customerID, startTime, endTime);

        if (resultForAddData === undefined) {
            return res.status(500).json("Error  in adding Data .....");
        } else {
            return res.status(200).json(resultForAddData);
        }
    } catch (error) {
        console.log(" error in /addDataToBillingRecordForCustomers");
        return res.status(500).json("Error  in adding Data .....");
    }


});

function calculatePriceForCustomer(customerID, startTime, endTime) {
    console.log("calculatePriceForCustomer");
    return new Promise(async function (callback, reject) {
        var billingRecordsResult;
        console.log(customerID + startTime + endTime);
        //db.collection('TestRuns').find({ "customerId": mongoDb.ObjectID(customerID) }, { projection: { customerId: 1 } }).toArray(async function (error, result) {
        await db.collection('TestRuns').find({ "customerId": mongoDb.ObjectID(customerID), "startTime": { "$gte": startTime.toISOString() }, "endTime": { "$lte": endTime.toISOString() } }).toArray(async function (error, result) {
            if (error) {
                console.log(error);
                reject("error in getting doc from TestRun")
            } else {
                console.log("TestRuns");
                console.log(result.length);
                if (result.length == 0) {
                    console.log(" No Test Run Document ");
                    callback("No Test Run Document Found ")
                }
                for (let resultObj of result) {
                    try {
                        //console.log(resultObj)
                        billingRecordsResult = await addDataToBillingRecords(resultObj);
                        console.log(billingRecordsResult);

                    } catch (exception) {
                        console.log("Error in Calculating Price for Test Run");
                        // reject("Error in Calculating Price for Test Run")
                    }
                }
                callback(billingRecordsResult);
            }


        });



    });
}

function calculatePriceForTestRun(testRunId) {
    console.log(" calculatePriceForTestRun() ")
    return new Promise(async function (callback, reject) {

        var testRunDocs;
        var testRunDocument
        var billingRecordsResult;
        try {
            testRunDocs = await getTestRunDocument(testRunId);
            for (temp of testRunDocs)
                testRunDocument = temp;
            try {
                billingRecordsResult = await addDataToBillingRecords(testRunDocument);
                callback(billingRecordsResult);
                //return res.status(200).json(billingRecordsResult);
            }
            catch (err) {
                console.log("Error in inserting data DB . ");
                reject("Error in inserting data DB");
                //return res.status(500).json("Error in inserting data DB ");
            }
        }
        catch (err) {
            console.log("Error in getting data from DB . ");
            reject("Error in getting data from DB (TestRun collection");
            //return res.status(500).json("Error in getting data from DB (TestRun collection)");
        }

    })


}



function getTestRunDocument(testRunId) {
    return new Promise(function (callback, reject) {
        db.collection('TestRuns').find({ "_id": mongoDb.ObjectID(testRunId) }).toArray((err, result) => {
            if (!err) {
                //console.log(result);
                console.log(" result from DB (TestRun collection) in getTestRunDocument() ");
                callback(result);
            }
            else {
                console.log(" Error in getting data from DB (TestRun collection) in getTestRunDocument()");
                reject(error);
            }
        });
    })
}

function addDataToBillingRecords(testRunDocument) {
    console.log("addDataToBillingRecords() ");
    return new Promise(async function (callback, reject) {
        console.log(" inside addDataToBillingRecords() ")
        var customerId = testRunDocument.customerId;
        var customerName = testRunDocument.customerName;
        var testRunId = testRunDocument._id;
        var totalCost = 0;
        var startTime = testRunDocument.startTime;
        var endTime = testRunDocument.endTime;
        var duration = testRunDocument.duration;
        var durationInHr = Math.ceil(duration / (1000 * 60 * 60));
        var testGroups = testRunDocument.testGroups;
        console.log(" id : " + testRunDocument._id);
        var Instance = [];
        var machineCloud = [];
        var machineAutoCloud = [];
        var machineOnPremise = [];
        var count = 0;
        var cloudAgent = testRunDocument.CloudAutoLAs;

        for (let testGroup of testGroups) {
            //console.log(testGroup);
            if (testGroup.enabled) {
                switch (testGroup.loadAgent.type) {
                    case "CloudAuto":
                        {
                            console.log("inside autocloud type ");
                            for (let cloudAuto of cloudAgent) {
                                console.log(cloudAuto.id == testGroup.loadAgent.CloudAutoLA_ID);
                                console.log(" machineAutoCloud " + machineAutoCloud.length);
                                if (cloudAuto.id == testGroup.loadAgent.CloudAutoLA_ID) {

                                    if (machineAutoCloud.length < 1) { // check it for mix
                                        console.log(" first instance inside cloudAuto: ");
                                        var instancesTemp = { "config": cloudAuto.config, "count": 1, "region": cloudAuto.region, "LGType": testGroup.loadAgent.type };
                                        console.log(instancesTemp);
                                        Instance.push(instancesTemp);
                                        console.log(Instance.length);
                                        //console.log(" auto cloud Insatnces : ");
                                        // for (let temp of Instance) {
                                        //     console.log(temp)
                                        // }
                                        machineAutoCloud.push(cloudAuto.id);
                                    }
                                    else {
                                        console.log(" machineAutoCloud " + machineAutoCloud.length + "  machine length greater than 1 ");
                                        var flag = false;
                                        for (let machine of machineAutoCloud) {
                                            if (machine == cloudAuto.id) {
                                                flag = true;
                                                break;
                                            }
                                        }
                                        if (!flag) {
                                            var flagVar = false;
                                            machineAutoCloud.push(cloudAuto.id);
                                            for (let instance of Instance) {
                                                if (instance.LGType == "CloudAuto") {
                                                    if (instance.config == cloudAuto.config && instance.region == cloudAuto.region) {
                                                        instance.count = instance.count + 1;
                                                        flagVar = true;
                                                    }
                                                }
                                            }
                                            if (!flagVar) {
                                                var instancesTemp = { config: cloudAuto.config, count: 1, region: cloudAuto.region, LGType: testGroup.loadAgent.type }
                                                Instance.push(instancesTemp);
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        }
                    case "Cloud":   // Cloud
                        {
                            console.log("inside cloud type ");
                            var loadagent = testGroup.loadAgent.loadAgentName;

                            var loadAgentDocument = await getLoadAgent(loadagent);

                            if (machineCloud.length < 1) { // check it for mix
                                console.log(" first instance inside cloud: ");
                                var instancesTemp = { config: loadAgentDocument.config, count: 1, region: loadAgentDocument.region, LGType: testGroup.loadAgent.type };
                                Instance.push(instancesTemp);
                                machineCloud.push(testGroup.loadAgent.loadAgentName);
                            }
                            else {
                                var flag = false;
                                for (let machine of machineCloud) {
                                    if (machine == testGroup.loadAgent.loadAgentName) {
                                        console.log("same machine inside cloud :")
                                        flag = true;
                                        break;
                                    }
                                }
                                if (!flag) {
                                    console.log("different machine  inside cloud :")
                                    var flagVar = false;
                                    machineCloud.push(testGroup.loadAgent.loadAgentName);
                                    for (let instance of Instance) {
                                        if (instance.LGType == "Cloud") {
                                            console.log("comparing with previous document in cloud");
                                            if (instance.config == loadAgentDocument.config && instance.region == loadAgentDocument.region) {
                                                instance.count = instance.count + 1;
                                                console.log(" increase count  in cloud");
                                                flagVar = true;
                                            }
                                        }
                                    }
                                    if (!flagVar) {
                                        var instancesTemp = { config: loadAgentDocument.config, count: 1, region: loadAgentDocument.region, LGType: testGroup.loadAgent.type }
                                        console.log(" add new document in cloud");
                                        Instance.push(instancesTemp);
                                    }
                                }
                            }
                            break;

                        }
                    case "OnPremise":
                        {
                            console.log("inside OnPremise type ");
                            var loadagent = testGroup.loadAgent.loadAgentName;

                            var loadAgentDocument = await getLoadAgent(loadagent);

                            if (machineOnPremise.length < 1) { // check it for mix
                                var instancesTemp = { config: loadAgentDocument.config, count: 1, region: loadAgentDocument.region, LGType: testGroup.loadAgent.type }
                                Instance.push(instancesTemp);
                                machineOnPremise.push(testGroup.loadAgent.loadAgentName);
                            }
                            else {
                                var flag = false;
                                for (let machine of machineOnPremise) {
                                    if (machine == testGroup.loadAgent.loadAgentName) {
                                        console.log("same machine in OnPremise:")
                                        flag = true;
                                        break;
                                    }
                                }
                                if (!flag) {
                                    console.log("different machine in OnPremise:")
                                    var flagVar = false;
                                    machineOnPremise.push(testGroup.loadAgent.loadAgentName);
                                    for (let instance of Instance) {
                                        if (instance.LGType == "OnPremise") {
                                            console.log("comparing with previous document in  OnPremise");
                                            if (instance.config == loadAgentDocument.config && instance.region == loadAgentDocument.region) {
                                                instance.count = instance.count + 1;
                                                console.log(" increase count in OnPremise");
                                                flagVar = true;
                                            }
                                        }
                                    }
                                    if (!flagVar) {
                                        var instancesTemp = { config: loadAgentDocument.config, count: 1, region: loadAgentDocument.region, LGType: testGroup.loadAgent.type }
                                        console.log(" add new document in OnPremise");
                                        Instance.push(instancesTemp);
                                    }
                                }
                            }
                            break;
                        }
                    default: {
                        console.log("inside default");
                    }

                }

            }

        }

        console.log(" durationInHr : " + durationInHr);
        for (let instaceObj of Instance) {
            console.log(" instances before billing ");
            //console.log(instaceObj)
            var machinePricing = await getMachineCost(instaceObj);

            var cost = durationInHr * machinePricing.cost * instaceObj.count;
            console.log(" totalcost for each instance : " + cost)
            totalCost = totalCost + cost;

        }
        console.log(" totalcost : " + totalCost);
        //"customerName": customerName,
        var resultJson = {
            "CustomerId": customerId, "testRunId": testRunId, "price": totalCost, "startTime": startTime, "endTime": endTime,
            "duration": duration, "Instance": Instance
        }
        var billingTableData = await insertDataToBillingTable(resultJson);
        callback(billingTableData);
    });
}

function getLoadAgent(loadagent) {
    return new Promise(function (callback, reject) {
        db.collection('LoadAgents').findOne({ "loadAgentName": loadagent }, function (error, result) {
            if (!error) {
                console.log(" data from DB (LG collection) in getLoadAgent()");
                //console.log(result);
                callback(result);
            }
            else {
                console.log(" Error in getting data from DB (LG collection) in getLoadAgent()");
                reject(error);
            }

        });
    });
}

function getMachineCost(instaceObj) {
    return new Promise(function (callback, reject) {
        console.log(" config : " + instaceObj.config + " region : " + instaceObj.region + " LGType : " + instaceObj.LGType);
        if (instaceObj.LGType != "CloudAuto") {
            db.collection("EC2InstanceCost").findOne({ "config": instaceObj.config, "regioncode": instaceObj.region },function (error, result) {
                if (!error) {
                    console.log(" data from DB (EC2InstanceCost collection) in getMachineCost() ");
                    //console.log(result);
                    callback(result);
                } else {
                    console.log(" Error in getting data from DB (EC2InstanceCost collection) in getMachineCost() ");
                    reject(error);
                }
            });
        } else {
            db.collection("EC2InstanceCost").findOne({ "config": instaceObj.config, "region": instaceObj.region },function (error, result) {
                if (!error) {
                    console.log(" data from DB (EC2InstanceCost collection) in getMachineCost() ");
                   //console.log(result);
                   callback(result);
                } else {
                    console.log(" Error in getting data from DB (EC2InstanceCost collection) in getMachineCost() ");
                    reject(error);
                }
            });
        }
    });

}

function insertDataToBillingTable(resultJson) {
    return new Promise(function (callback, reject) {

        db.collection('AWSBilling').find({ "testRunId": mongoDb.ObjectID(resultJson.testRunId) }).toArray(function (error1, result) {
            if (error1) {
                console.log("Error in getting data from DB in insertDataToBillingTable() ");
                reject(error1);
            } else {
                console.log("inside get data ")
                if (result.length > 0) {
                    db.collection('AWSBilling').updateOne({ "testRunId": mongoDb.ObjectID(resultJson.testRunId) }, { $set: resultJson }, function (error, result) {
                        if (error) {
                            console.log("Error in update data DB in insertDataToBillingTable() ");
                            reject(error);
                        }
                        else {
                            //console.log(result);
                            console.log(" updating in db is done in insertDataToBillingTable() ");
                            res = { "message": " updating in db is done" };
                            callback(res);
                        }
                    });
                } else {
                    db.collection('AWSBilling').insertOne(resultJson, function (error, result) {
                        if (error) {
                            console.log("Error in inserting data DB in insertDataToBillingTable() ");
                            reject(error);
                        }
                        else {
                            //console.log(result);
                            console.log(" inserting in db is done in insertDataToBillingTable() ");
                            var res = { "message": " inserting in db is done" };
                            callback(res);
                        }
                    });
                }
            }
        })


    })

}


module.exports = router;
