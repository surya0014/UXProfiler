
var express = require('express');
var router = express.Router();
var config = require('../configuration.json');
let validationRoute = require('./validation.js');

var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    host: 'http://' + config.elasticsearchDBHost + ':9200',
    log: 'trace'
});
elasticClient.ping({
    requestTimeout: 30000,
}, function (error) {
    if (error) {
        console.log('elasticsearchAPI.js : ERROR: Elasticsearch DB Connection failed !');
    } else {
        console.log('elasticsearchAPI.js : Connection to ElasticSearch DB established !');
    }
});

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('elasticsearchAPI.js : ERROR: DB connection failed');
        return err;
    } else {
        db = mydb.db();
        console.log('elasticsearchAPI.js : DB connection established for elasticsearch API!');
    }
});


//Get the TomcatLogs apachelogs-stdout
router.get('/getTomcatLogs', async function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    var indexName = req.query.indexName;
    //var hostName = req.query.hostName;
    var testrunid = req.query.testrunid;




    /* console.log('indexName: '+indexName);
    console.log('hostName: '+hostName); */
    if (indexName === null || indexName === undefined || indexName === "" || validationRoute(indexName)) {
        return res.status(404).json("Index Name is not specified or not valid");
    }
    /* if (hostName === null || hostName === undefined || hostName === "" || validationRoute(hostName)) {
        return res.status(404).json("Host Name is not specified or not valid");
    } */
    if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }




    let testRunDoc = await getTestRunDoc(testrunid);

    let gteString = testRunDoc.startTime;//"now-1h"

    let lteString = "now";

    if (testRunDoc.endTime !== null || testRunDoc.endTime !== undefined || testRunDoc.endTime !== "") {
        lteString = testRunDoc.endTime;
    }
    let hostName, LGtype;
    LGtype = testRunDoc.testGroups[0].loadAgent.type;
    if(testRunDoc.testGroups[0].loadAgent.type =="CloudAuto"){
        let CloudAutoLA_ID = testRunDoc.testGroups[0].loadAgent.CloudAutoLA_ID;
        let instanceID =testRunDoc.testGroups[0].loadAgent.instanceID;
        /* console.log(CloudAutoLA_ID);
        console.log(instanceID); */
        hostName = await getCloudAutoHostName(String(CloudAutoLA_ID), String(instanceID));
    }else{
        let loadAgentName =testRunDoc.testGroups[0].loadAgent.loadAgentName;
        hostName = await getHostName(String(loadAgentName));
        /* if(hostName == "localhost"){
            hostName = "EC2AMAZ-D04857E";//CPCINCHDV000849//EC2AMAZ-D04857E
        } */
    }
    /* 
    if (hostName === null || hostName === undefined || hostName === "") {
        return res.status(500).json("Host Name Missing");
    } */
    let ESData = await getESData(indexName, hostName, gteString, lteString, testrunid, LGtype);

    if (ESData instanceof Array) {
        return res.status(200).json(ESData);
    } else {
        return res.status(500).json(ESData);
    }

});


async function getESData(indexName, hostName, gteString, lteString, testrunid,LGtype) {
    try {
        console.log("-----getESData()------");
        if (LGtype == "CloudAuto") {
            ESresponse = await elasticClient.search({
                index: indexName,
                body: {

                    "size": 4000,
                    "query": {
                        "bool": {
                            /* "must": [
                                {
                                    "match": {
                                        "host": hostName
                                    }
                                }
                            ], */
                            "must": [
                                {
                                    "match": {
                                        "testrunid": testrunid
                                    }
                                }
                            ],
                            /* "must": [
                                {
                                    "match": {
                                        "testrunid": "default"
                                    }
                                }
                            ], */
                            "filter": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": gteString,
                                            "lt": lteString
                                        }
                                    }
                                }
                            ]
                        }

                    }/* ,
                "_source": {
                    "includes": ["id", "post_date"]
                } */,
                    "sort": [
                        {
                            "@timestamp": {
                                "order": "desc"
                            }
                        }
                    ]
                }
            });
        } else {
            ESresponse = await elasticClient.search({
                index: indexName,
                body: {

                    "size": 4000,
                    "query": {
                        "bool": {
                            /* "must": [
                                {
                                    "match": {
                                        "host": hostName
                                    }
                                }
                            ], */
                            /* "must": [
                                {
                                    "match": {
                                        "testrunid": testrunid
                                    }
                                }
                            ],  */
                            "must": [
                                {
                                    "match": {
                                        "testrunid": "default"
                                       /*  "testrunid": "0a1b2c3d4e5f6g7h8i9j007" */
                                        /* "machinename": "LA00" */
                                        /* "host": "EC2AMAZ-OOVMB4A" */
                                        /* "host": "EC2AMAZ-D04857E" */
                                    }
                                }
                            ],
                            "filter": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": gteString,
                                            "lt": lteString
                                        }
                                    }
                                }
                            ]
                        }

                    }/* ,
                "_source": {
                    "includes": ["id", "post_date"]
                } */,
                    "sort": [
                        {
                            "@timestamp": {
                                "order": "desc"
                            }
                        }
                    ]
                }
            });
        }

        /* 
           _index
           _source.message
    
    {
     "_index":"apachelogs-stdout",
     "_type":"doc",
     "_id":"25OME2gBaJachl_2E7m0",
     "_score":null,
     "_source":{
       "@timestamp":"2019-01-03T11:49:33.589Z",
       "host":"EC2AMAZ-OOVMB4A",
       "@version":"1",
       "path":"C:/Program Files/Apache Software Foundation/Tomcat 9.0/logs/tomcat9-stdout.2019-01-03.log",
       "message":"Have set test run ID to NULL\r"
     },
     "sort":[
       1546516173589
     ]
    }
    
    
    {
     "_index":"apachelogs-stderr",
     "_type":"doc",
     "_id":"3pOME2gBaJachl_2I7md",
     "_score":null,
     "_source":{
       "host":"EC2AMAZ-OOVMB4A",
       "time":"11:49:37.511",
       "logtype":"WARNING",
       "log":"[Thread-9] org.apache.catalina.loader.WebappClassLoaderBase.clearReferencesThreads The web application [ZantMeterServices] appears to have started a thread named [NanoOffset] but has failed to stop it. This is very likely to create a memory leak. Stack trace of thread:",
       "@timestamp":"2019-01-03T11:49:37.667Z",
       "date":"03-Jan-2019",
       "@version":"1",
       "path":"C:/Program Files/Apache Software Foundation/Tomcat 9.0/logs/tomcat9-stderr.2019-01-03.log",
       "message":"03-Jan-2019 11:49:37.511 WARNING [Thread-9] org.apache.catalina.loader.WebappClassLoaderBase.clearReferencesThreads The web application [ZantMeterServices] appears to have started a thread named [NanoOffset] but has failed to stop it. This is very likely to create a memory leak. Stack trace of thread:"
     },
     "sort":[
       1546516177667
     ]
    }
           */
        let Logs = [];
        let Hits = ESresponse.hits.hits;
        if((Hits!=null)||(Hits!=undefined)||(Hits!=[])){
            if (indexName == "apachelogs-stderr") {
                Hits.forEach((hit) => {
                    let Obj = {
                        indexName: hit._index,
                        hostName: hit._source.host,
                        message: hit._source.message,
                        logtype: hit._source.logtype,
                        datetime: hit._source.date + " " + hit._source.time,
                        log: hit._source.log,
                    };
    
                    if ((Obj.logtype == "WARNING") || (Obj.logtype == "ERROR") || (Obj.logtype == "FATAL")) {
                        Logs.push(Obj);
                    }
                });
            } else {
                Hits.forEach((hit) => {
                    let Obj = {
                        indexName: hit._index,
                        hostName: hit._source.host,
                        message: hit._source.message,
                    };
                    Logs.push(Obj);
                });
            }
        }
        return Logs;
        //return res.status(200).json(Logs);
    } catch (error) {
        console.log(error.message);
        return error.message;
        //return res.status(500).json(error.message);
    }
}


function getTestRunDoc(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----getTestRunDoc()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, record) {
            if (err) {
                console.log("Error in getTestRunDoc : " + err);
                reject(err);
            } else {
                callback(record);
            }
        });
    });
}


function getHostName(loadAgentName) {
    return new Promise(function (callback, reject) {
        console.log("-----getHostName()------");
        console.log(loadAgentName);
        db.collection('LoadAgents').findOne({ "loadAgentName": loadAgentName }, function (err, record) {
            if (err) {
                console.log("Error in getHostName : " + err);
                reject(err);
            } else {
                console.log(record);
                callback(record.localHostName);
            }
        });
    });
}

function getCloudAutoHostName(CloudAutoLA_ID, instanceID) {
    return new Promise(function (callback, reject) {
        console.log("-----getCloudAutoHostName()------");
        console.log(CloudAutoLA_ID);
        console.log(instanceID);
        db.collection('LoadAgents').findOne({ "CloudAutoLA_ID": parseInt(CloudAutoLA_ID), "instanceID": String(instanceID) }, function (err, record) {
            if (err) {
                console.log("Error in getCloudAutoHostName : " + err);
                reject(err);
            } else {
                console.log(record);
                callback(record.localHostName);
            }
        });
    });
}

async function getHost() {
    console.log("--------started--------");
    let sample = await getHostName("52615", "i-0205949c2a942e60a");
    console.log(sample);
    console.log("--------finished--------");
    //console.log(JSON.stringify(sample));
}

//getHost();
module.exports = router;