var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

//require multer for the file uploads
var multer = require('multer');

let validationRoute = require('./validation.js');

var Request = require("request");
const fs = require('fs');


let rabbitMQ = require('./publisher.js');

//redis lock
/* const client = require('redis').createClient();
const { promisify } = require('util');
const lock = promisify(require('redis-lock')(client));
 */

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('testAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('testAPI.js : DB connection established using mongodb!');
    }
});

var customerDB_URL = config.mongoDBURL;
let customerDB;
MongoClient.connect(customerDB_URL, function (err, mydb) {
    if (err) {
        console.log('testAPI.js : ERROR : customer DB connection failed using mongodb');
        return err;
    } else {
        customerDB = mydb.db();
        console.log('testAPI.js : customer DB connection established using mongodb!');
    }
});


var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        //cb(null, 'customer/application/uploads/')
        cb(null, 'C:/ZantMeter/ftp/temp')
    },
    filename: function (req, file, cb) {
        var fname = file.originalname;
        var regexAll = /^([^\\]*)\.(\w+)$/;;

        // var total = path.match(regexAll);
        // var total=fname.slice((fname.lastIndexOf(".") - 1 >>> 0) + 2);
        var temp1, temp2;
        temp1 = fname.split(".");
        //console.log(temp1[0] + "  " + temp1[1]);
        // console.log();
        var total = fname.split(fname.lastIndexOf("."));
        var filename = total[0];
        var extension = total[1];

        cb(null, temp1[0] + "_" + Date.now() + "." + temp1[1]);
        /* cb(null, filename+"_"+Date.now()+"."+extension);*/
    }
});



// Multer configuration for file uploads
var upload = multer({ storage: storage });
/*var upload = multer({});*/
var multiUpload = upload.fields([{ name: 'jmxFile', maxCount: 1 }, { name: 'dataFiles', maxCount: 10 }]);


const Influx = require('influx');
// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://' + config.influxDBUserName + ':' + config.influxDBPassword + '@' + config.influxDBHost + ':8086/zantmeter');


const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));

//Get Test Run By ID
router.get('/getTestRunByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestRunByID------");
    var testrunnid = req.query._id;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }

    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            /* let response = {
                scenarioName: records.scenarioName,
                status: records.status,
                testResult: records.testResult,
            }; */
            //return res.status(200).json(records);
            //temporary
            let testRunDocResponse = JSON.parse(JSON.stringify(records));
            /* try {
                //temporary
                var testRunDocPath = "C:/PerfAssure/GitLab/CIPTS_Node/mongodocs/" + records.testScenarioID + ".json";
                //temporary
                if (fs.existsSync(testRunDocPath)) {
                    //temporary
                    const testRunDoc = fs.readFileSync(testRunDocPath, { encoding: 'utf8', flag: 'r' });
                    //temporary
                    var testRunJSON = JSON.parse(testRunDoc);
                    //temporary
                    testRunDocResponse.testGroups = JSON.parse(JSON.stringify(testRunJSON.testGroups));
                }
            } catch (err) {
                console.log(err);
            } */
            return res.status(200).json(testRunDocResponse);
        }
    });
});//end of //getTestRunByID



//Get Test Run Stacked By ID
router.get('/getTestResultStackedByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestResultStackedByID------");
    var testrunnid = req.query._id;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    var metricname = req.query.metricname;
    if (metricname === null || metricname === undefined || metricname === "" || validationRoute(metricname)) {
        return res.status(404).json("Metric Name is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let responseMessage = {
                scenarioName: records.scenarioName,
                status: records.status,
                startTime: records.startTime,
                endTime: records.endTime,
                duration: records.duration,
            };

            if (records.hasOwnProperty('RAWenabled')) {
                responseMessage.RAWenabled = records.RAWenabled;
            } else {
                responseMessage.RAWenabled = false;
            }
            if (records.hasOwnProperty('runID')) {
                responseMessage.runID = records.runID;
            }

            switch (metricname) {
                case "PanelSummary": {
                    if (records.hasOwnProperty('sla')) {
                        responseMessage.sla = {
                            enabled: records.sla.enabled
                        };
                    } else {
                        responseMessage.sla = {
                            enabled: false
                        };
                    }
                    responseMessage.panelsummary = records.testResult.panelsummary;
                    break;
                }
                case "Summary": {
                    responseMessage.summary = records.testResult.summary;
                    responseMessage.stackedbarchartdata = records.testResult.stackedbarchartdata;
                    break;
                }
                case "Observations": {

                    break;
                }
                case "TotalActiveVUsers": {
                    responseMessage.vUsers = {
                        data: records.testResult.vUsers.data,
                        observations: records.testResult.vUsers.observations
                    };
                    break;
                }
                case "VusersByThreadGroups": {
                    if (records.testResult.hasOwnProperty('vUsersByThreadGroups')) {
                        responseMessage.vUsersByThreadGroups = {
                            data: records.testResult.vUsersByThreadGroups.data,
                            observations: records.testResult.vUsersByThreadGroups.observations
                        };
                    } else {
                        responseMessage.vUsersByThreadGroups = {
                            data: [],
                            observations: []
                        }
                    }
                    break;
                }
                case "ResponseTime": {
                    responseMessage.responseTime = {
                        data: records.testResult.responseTime.data,
                        observations: records.testResult.responseTime.observations
                    };
                    break;
                }
                case "Latency": {
                    if (records.testResult.hasOwnProperty('latency')) {
                        responseMessage.latency = {
                            data: records.testResult.latency.data,
                            observations: records.testResult.latency.observations
                        };
                    } else {
                        responseMessage.latency = {
                            data: [],
                            observations: []
                        }
                    }
                    break;
                }
                case "Throughput": {
                    responseMessage.throughput = {
                        data: records.testResult.throughput.data,
                        observations: records.testResult.throughput.observations
                    };
                    break;
                }
                case "Hits": {
                    responseMessage.hits = {
                        data: records.testResult.hits.data,
                        observations: records.testResult.hits.observations
                    };
                    break;
                }
                case "StatusCodes": {
                    if (records.testResult.hasOwnProperty('statuscodes')) {
                        responseMessage.statuscodes = {
                            data: records.testResult.statuscodes.data,
                            observations: records.testResult.statuscodes.observations
                        };
                    } else {
                        responseMessage.statuscodes = {
                            data: [],
                            observations: []
                        }
                    }
                    break;
                }
                case "Errors": {
                    responseMessage.error = {
                        data: records.testResult.error.data,
                        observations: records.testResult.error.observations
                    };
                    responseMessage.errorsPerTranscationData = records.testResult.errorsPerTranscationData;
                    break;
                }
                case "AssertionErrorResults": {
                    if (records.testResult.hasOwnProperty('assertionerrors')) {
                        responseMessage.assertionerrors = {
                            data: records.testResult.assertionerrors.data,
                        };
                    } else {
                        responseMessage.assertionerrors = {
                            data: [],
                        };
                    }
                    break;
                }
                case "SystemMonitoring": {
                    if (records.hasOwnProperty('systemMonitor')) {
                        responseMessage.systemMonitor = records.systemMonitor;
                    } else {
                        responseMessage.systemMonitor = {
                            enabled: false,
                            machines: []
                        };
                    }

                    if (records.testResult.hasOwnProperty('serverMetrics')) {
                        responseMessage.serverMetrics = records.testResult.serverMetrics;
                    } else {
                        responseMessage.serverMetrics = {
                            data: {
                                cpu_data: [],
                                processor_data: [],
                                memory_data: []
                            },
                            observations: []
                        };
                    }
                    break;
                }
                case "TransactionsRequestsBreakdown": {
                    if (records.testResult.hasOwnProperty('TransactionsRequestsBreakdown')) {
                        responseMessage.TransactionsRequestsBreakdown = {
                            data: records.testResult.TransactionsRequestsBreakdown.data,
                        };
                    } else {
                        responseMessage.TransactionsRequestsBreakdown = {
                            data: [],
                        };
                    }
                    break;
                }
                case "TomcatLogs": {
                    if (records.testResult.hasOwnProperty('TomcatLogs')) {
                        responseMessage.TomcatLogs = records.testResult.TomcatLogs;
                    } else {
                        responseMessage.TomcatLogs = {
                            stdoutLogs: [],
                            stderrLogs: []
                        };
                    }
                    break;
                }
            }
            //console.log(JSON.stringify(responseMessage));
            return res.status(200).json(responseMessage);
        }
    });
});//end of //getTestResultStackedByID




//Get Test Run Status By ID
router.get('/getTestRunStatusByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestRunStatusByID------");
    var testrunnid = req.query._id;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({ "status": records.status });
        }
    });
});//end of //getTestRunStatusByID


//Get Transaction Summary of Test Run By ID
router.get('/getTransactionSummaryByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTransactionSummaryByID------");
    var testrunnid = req.query._id;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json(records.testResult.summary.data);
        }
    });
});//end of //getTransactionSummaryByID

//Getting Test Runs 
router.get('/getTestRuns', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestRuns------");
    var status = req.query.status;
    if (status === null || status === undefined || status === "" || validationRoute(status)) {
        return res.status(404).json("Status is not specified or not valid");
    }

    var appID = req.query.appid;
    if (appID === null || appID === undefined || appID === "" || validationRoute(appID)) {
        return res.status(404).json("Application ID is not specified or not valid");
    }
    var bsonAppID = mongodb.ObjectID(appID);
    //"appid": bsonAppID

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 

    console.log("inside getTestRuns");
    db.collection("TestRuns").find({ "status": status, "customerId": bsonCustomerID, "appid": bsonAppID }).project({ runID: 1, status: 1, startTime: 1, duration: 1, scenarioName: 1, 'testResult.panelsummary.responsetimehealth': 1, 'testResult.panelsummary.transactionhealth': 1 }).toArray((err, result) => {
        if (err) {
            console.log("Error in getTestRuns : " + err);
            return res.status(500).json(err);
        } else {
            /*console.log("Result  "  +result);*/
            return res.status(200).json(result);
        }
    });
});//end of //Getting Test Runs 

//TestRuns

//Add a new Test Run
router.post('/addTestRun', multiUpload, function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----addTestRun------");
    let testrundata = req.body;
    if (testrundata === null || testrundata === undefined || testrundata === "") {
        return res.status(404).json("Test Run Data is not specified");
    }
    //console.log(JSON.stringify(testscenariodata));
    if (testrundata) {

        let bsonTestScenarioID = mongodb.ObjectID(testrundata['_id']);
        testrundata.testScenarioID = bsonTestScenarioID;

        if (testrundata['_id'] === null || testrundata['_id'] === undefined || testrundata['_id'] === "" || validationRoute(testrundata['_id'])) {
            return res.status(404).json("Test Run ID is not specified or not valid");
        }

        delete testrundata['_id'];
        //appid
        //customerId
        let bsonCustomerID = mongodb.ObjectID(testrundata['customerId']);
        testrundata.customerId = bsonCustomerID;
        let bsonAppID = mongodb.ObjectID(testrundata['appid']);
        testrundata.appid = bsonAppID;
        //let newRunID = 1;
        db.collection("RunID").findOne({ "customerId": bsonCustomerID, "appid": bsonAppID }, (err, result) => {
            if (err) {
                //console.log("err" + result)
                return res.status(500).json(err);
            } else {
                if (result == null) {
                    var newID = 1;
                    db.collection("RunID").insert({ "customerId": bsonCustomerID, "appid": bsonAppID, "name": testrundata.customerId + '_' + testrundata.appid, "value": newID }, function (err, result) {
                        if (err) {
                            console.log(err);
                            //return res.status(500).json(err);
                            return null;
                        }
                        else {
                            console.log(" document inserted RunID");
                            testrundata.runID = newID;
                            db.collection('TestRuns').insert(testrundata, function (err, result) {
                                if (err) {
                                    console.log(err);
                                    return res.status(200).json({
                                        status: 'ERROR',
                                        'message': err
                                    });
                                } else {
                                    //console.log("result.ops[0]['_id']:" + result.ops[0]['_id']);
                                    /* var id = result.ops[0]['_id'];
                                    
                                    //console.log("id:"+id); */

                                    return res.status(200).json({
                                        status: 'Added Test Run',
                                        testRunID: result.ops[0]['_id']
                                    });
                                }
                            });
                        }
                    });
                } else {
                    var newID = result.value + 1;
                    db.collection("RunID").updateOne({ "customerId": bsonCustomerID, "appid": bsonAppID }, {
                        "$set": {
                            "value": newID,
                        }
                    }, function (err) {
                        if (err) {
                            console.log(err);
                            return null;
                        }
                        else {
                            console.log(" document updated RunID");
                            testrundata.runID = newID;
                            db.collection('TestRuns').insert(testrundata, function (err, result) {
                                if (err) {
                                    console.log(err);
                                    return res.status(200).json({
                                        status: 'ERROR',
                                        'message': err
                                    });
                                } else {
                                    //console.log("result.ops[0]['_id']:" + result.ops[0]['_id']);
                                    /* var id = result.ops[0]['_id'];
                                    
                                    //console.log("id:"+id); */

                                    return res.status(200).json({
                                        status: 'Added Test Run',
                                        testRunID: result.ops[0]['_id']
                                    });
                                }
                            });
                        }
                    });
                }
            }
        });
    }
});//end of //addTestRun

//Update TestRun
router.put('/updateTestRun', multiUpload, function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----updateTestRun------");
    var testRundata = req.body;
    //console.log(JSON.stringify(testRundata));

    if (testRundata === null || testRundata === undefined || testRundata === "") {
        return res.status(404).json("Test Run Data is not specified");
    }
    let testRunID = testRundata._id;
    var bsonID = mongodb.ObjectID(testRundata._id);
    delete testRundata['_id'];

    let bsonCustomerID = mongodb.ObjectID(testRundata['customerId']);
    testRundata.customerId = bsonCustomerID;
    let bsonAppID = mongodb.ObjectID(testRundata['appid']);
    testRundata.appid = bsonAppID;
    var newvalues = { $set: testRundata };

    db.collection('TestRuns').update({ '_id': bsonID }, newvalues, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({
                status: 'Updated Test Run',
                testRunID: testRunID
            })
        }
    });
});//end of //updateTestRun

//Automate Start Test
async function automateStartTest(CloudAutoLA_ID, instanceID, threadGroupName, id, jsonResponseArray, port) {//, token) {

    console.log("-----automateStartTest()------");

    //await 
    if (!CloudAutoLA_ID || !instanceID || !threadGroupName || !id) {
        return ({ 'status': 'error', 'message': 'CloudAutoLA_ID|instanceID|threadGroupName|id missing !' });
    }
    let laport = port;
    if ((laport == undefined) || (laport == null) || (laport == "")) {
        laport = 8080;
    }
    await sleep(3000);
    console.log("CloudAutoLA_ID: " + CloudAutoLA_ID + " instanceID: " + instanceID)
    let LoadAgentResponse = await getLoadAgentDoc(CloudAutoLA_ID, instanceID);
    if (LoadAgentResponse.status == 'SUCCESS') {
        let LoadAgentDoc = LoadAgentResponse.message;
        console.log(JSON.stringify(LoadAgentDoc));
        //console.log('Starting Load agent : ' + LoadAgentDoc.hostName + ", threadGroupName : " + threadGroupName);
        // var startURL = "http://" + LoadAgentDoc.hostName + ":" + laport + "/ZantMeterServices/rest/starttest/" + id + "/" + threadGroupName + "/" + config.influxDBHost + "/" + laport;// + "/" + token;
        var startURL = "http://" + LoadAgentDoc.hostName + ":" + laport + "/ZantMeterServices/rest/starttest/" + id + "/" + threadGroupName + "/" + config.influxDBHost + "/" + laport + "/" + config.influxDBUserName + "/" + config.influxDBPassword;
        //startURL=encodeURI(startURL);
        //console.log(startURL);
        await Request.get(startURL, (error, response, body) => {
            if (error) {
                console.error(error);
                jsonResponseArray.push({
                    'threadgroupname': threadGroupName,
                    'loadagentname': LoadAgentDoc.hostName,
                    'status': 'ERROR',
                    'message': error
                });
            }
            //console.log(body);
            jsonResponseArray.push({
                'threadgroupname': threadGroupName,
                'loadagentname': LoadAgentDoc.hostName,
                'status': 'STARTED',
                'message': body
            });
        });
        return jsonResponseArray;
    } else {
        console.error(LoadAgentResponse);
    }
}


//start Test Runs 
router.get('/startTestRun', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----startTestRun------");

    let testRunID = req.query.testRunID;

    if (testRunID === null || testRunID === undefined || testRunID === "" || validationRoute(testRunID)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    else {
        //console.log("testRunID:" + testRunID);
        if (testRunID) {
            var bsonID = mongodb.ObjectID(testRunID);
            db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
                if (err) {
                    //console.log("Error in fetching Test Run id : " + testRunID + " :" + err);
                    return res.status(500).json(err);
                } else {
                    let newTestRun = records;
                    /*  newTestRun.testScenarioID = records['_id'];*/
                    var recordid = newTestRun['_id'];
                    delete newTestRun['_id'];
                    newTestRun.testRunName = newTestRun['scenarioName'];//+ "_" + msTimestamp;
                    /* newTestRun.application = "default";
                    newTestRun.customerName = "default"; */
                    newTestRun.status = "Running";

                    let utcTimestamp = new Date();
                    let isoTimestamp = utcTimestamp.toISOString();
                    newTestRun.startTime = isoTimestamp;
                    if (!newTestRun.hasOwnProperty('endTime')) {
                        newTestRun.endTime = null;
                    }
                    if (!newTestRun.hasOwnProperty('duration')) {
                        newTestRun.duration = null;
                    }

                    for (var nit = 0; nit < newTestRun.testGroups.length; nit++) {
                        if (newTestRun.testGroups[nit].enabled) {
                            newTestRun.testGroups[nit].status = "Running";
                        }
                    }

                    var newvalues = { $set: newTestRun };

                    db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
                        if (err) {
                            console.log("Error in updateTestRuns : " + err);
                            return res.status(500).json(err);
                        }
                        else {
                            console.log("Data Updated");
                            //console.log(result);
                            var jsonResponseArray = [];
                            newTestRun._id = recordid;
                            /* let authorization = req.headers['authorization'];
                            var token = '';
                            if (typeof authorization !== 'undefined') {
                                const bearer = authorization.split(' ');
                                token = bearer[1];
                                //console.log('Token inside /startTestRun : ' + token);
                            } else {
                                //If header is undefined return Forbidden (403)
                                return res.status(403).send({
                                    error: true,
                                    message: "Forbidden - No token found"
                                });
                            } */

                            if (newTestRun) {//&& token) {
                                // console.log("id:" + newTestRun['_id']);
                                //Now call the tomcat to start JMeter
                                try {
                                    if (newTestRun['_id'] && typeof newTestRun.testGroups != "undefined" && newTestRun.testGroups != null && newTestRun.testGroups != []) {

                                        var testGroups = newTestRun.testGroups;
                                        for (var it = 0; it < testGroups.length; it++) {
                                            (function () {
                                                var itg = it;
                                                //setTimeout(function(){
                                                //console.log(it);
                                                //console.log(itg);
                                                var testGroup = testGroups[itg];
                                                var loadAgent = testGroups[itg].loadAgent;
                                                var threadGroupName = testGroups[itg].testGroupName;
                                                //console.log("testGroupName " + itg + " :" + testGroups[itg].testGroupName);
                                                let port = testGroups[itg].loadAgent.port;
                                                if ((port == undefined) || (port == null) || (port == "")) {
                                                    port = 8080;
                                                }
                                                if (testGroup.enabled) {
                                                    if (loadAgent.type == "CloudAuto") {
                                                        /* 
                                                        console.log("------------CloudAutoLA_ID--------------");
                                                        //console.log(loadAgent.CloudAutoLA_ID.toString()); */

                                                        jsonResponseArray = automateStartTest(String(loadAgent.CloudAutoLA_ID), String(loadAgent.instanceID), threadGroupName, newTestRun['_id'], jsonResponseArray, port);//, token);
                                                    } else {

                                                        // var startURL = "http://" + testGroups[itg].loadAgent.loadAgentName + ":" + port + "/ZantMeterServices/rest/starttest/" + newTestRun['_id'] + "/" + testGroups[itg].testGroupName + "/" + config.influxDBHost + "/" + port;//+ "/" + token;
                                                        var startURL = "http://" + testGroups[itg].loadAgent.loadAgentName + ":" + port + "/ZantMeterServices/rest/starttest/" + newTestRun['_id'] + "/" + testGroups[itg].testGroupName + "/" + config.influxDBHost + "/" + port + "/" + config.influxDBUserName + "/" + config.influxDBPassword;
                                                        //startURL=encodeURI(startURL);
                                                        console.log(startURL);
                                                        Request.get(startURL, (error, response, body) => {
                                                            if (error) {
                                                                console.error(error);
                                                                jsonResponseArray.push({
                                                                    'threadgroupname': testGroups[itg].testGroupName,
                                                                    'loadagentname': testGroups[itg].loadAgent.loadAgentName,
                                                                    'status': 'ERROR',
                                                                    'message': error
                                                                });
                                                            }
                                                            //console.log((new Date()) + ': STARTED LOAD AGENT : ' + testGroups[itg].loadAgent.loadAgentName + ' ThreadGroup: ' + testGroups[itg].testGroupName + ', RESPONSE : ' + body);
                                                            jsonResponseArray.push({
                                                                'threadgroupname': testGroups[itg].testGroupName,
                                                                'loadagentname': testGroups[itg].loadAgent.loadAgentName,
                                                                'status': 'STARTED',
                                                                'message': body
                                                            });
                                                        });
                                                    }
                                                }
                                            })();
                                        }
                                    }
                                } catch (e) {
                                    console.log("Error in startscript " + e);
                                    return res.status(500).json({
                                        status: "ERROR",
                                        message: e
                                    });

                                }
                            }
                            return res.status(200).json({ _id: testRunID });
                        }
                    });
                }
            });
        }



    }
});//end of start Test Runs 


//Get Test Run Document
function getTestRunDoc(testRunID) {
    console.log("-----getTestRunDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if (testRunID) {
                //console.log("testRunID:" + testRunID);
                var bsonID = mongodb.ObjectID(testRunID);
                db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    //console.log("record:"+record);
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in getTestRunDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Get Load Agent Document
function getLoadAgentDoc(CloudAutoLA_ID, instanceID) {
    console.log("-----getLoadAgentDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if ((CloudAutoLA_ID) && (instanceID)) {
                let query = { 'CloudAutoLA_ID': parseInt(CloudAutoLA_ID), 'instanceID': String(instanceID) };
                db.collection("LoadAgents").findOne(query, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    console.log(record);
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in getLoadAgentDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Delete Load Agent Document
function deleteLoadAgentDoc(loadAgentid) {
    console.log("-----deleteLoadAgentDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if (loadAgentid) {
                var bsonID = mongodb.ObjectID(loadAgentid);
                db.collection('LoadAgents').deleteOne({ "_id": bsonID }, function (err, records) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    } else {
                        callback({
                            'status': 'SUCCESS',
                            'message': 'Deleted Load Agent'
                        });
                    }
                });
            }
        } catch (e) {
            console.log("Error in deleteLoadAgentDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Get LARegion ByRegion Document
function getLARegionDocByRegion(region) {
    console.log("-----getLARegionDocByRegion()------");
    return new Promise(function (callback, reject) {
        try {
            if (region) {
                let query = { 'region': region };
                db.collection("LARegions").findOne(query, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in getLARegionDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}


//Stop Load Agent Threadgroup
function stopLoadAgentThreadgroup(hostName, testRunID, threadGroupName, port) {
    console.log("-----stopLoadAgentThreadgroup()------");
    console.log("hostName: " + hostName + " testRunID: " + testRunID + " threadGroupName: " + threadGroupName);
    return new Promise(function (callback, reject) {
        try {
            let laport = port;
            if ((laport == undefined) || (laport == null) || (laport == "")) {
                laport = 8080;
            }
            if ((hostName) && (testRunID)) {
                //console.log('Stopping Load agent : ' + hostName);
                let URL = "http://" + hostName + ":" + laport + "/ZantMeterServices/rest/stoptestgroup/" + testRunID + "/" + threadGroupName;
                console.log(URL);
                /* Request.get(URL, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        callback({
                            'loadagentname': hostName,
                            'status': 'ERROR',
                            'message': error
                        });
                    }
                    //console.log(body);

                    callback({
                        'loadagentname': hostName,
                        'status': 'STOPPED',
                        'message': body
                    });

                }); */
                Request.get(URL, { timeout: 60000 }, async (error, response, body) => {
                    if (error) {
                        console.error(error);
                        if ((error.code == "ETIMEDOUT") || (error.code == "ECONNREFUSED") || (error.code == "ESOCKETTIMEDOUT")) {
                            try {
                                let data = {
                                    testrunid: testRunID,
                                    threadgroupname: threadGroupName
                                };
                                jsonResponseArray = await rabbitMQ(data);
                                /* jsonResponseArray = await stopFinalThreadGroup(testRunID, threadGroupName); */
                            } catch (ex) {
                                console.log("Error while force stop after 60 sec timeout " + ex);
                                jsonResponseArray = {
                                    "error": ex
                                };
                            }
                        }
                        callback({
                            'loadagentname': hostName,
                            'status': 'ERROR',
                            'message': error
                        });
                    }
                    //console.log(body);
                    if (body == '{\'error\':\'No test running in Load agent\'}') {
                        try {
                            let data = {
                                testrunid: testRunID,
                                threadgroupname: threadGroupName
                            };
                            jsonResponseArray = await rabbitMQ(data);
                            /* jsonResponseArray = await stopFinalThreadGroup(testRunID, threadGroupName); */
                        } catch (ex) {
                            console.log("Error while force stop after 60 sec timeout " + ex);
                            jsonResponseArray = {
                                "error": ex
                            };
                        }
                    }
                    callback({
                        'loadagentname': hostName,
                        'status': 'STOPPED',
                        'message': body
                    });

                });

            }
        } catch (e) {
            console.log("Error in stopLoadAgentThreadgroup " + e);
            callback({
                'loadagentname': hostName,
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Stop Load Agent
function stopLoadAgent(hostName, testRunID) {
    console.log("-----stopLoadAgent()------");
    return new Promise(function (callback, reject) {
        try {
            if ((hostName) && (testRunID)) {
                //console.log('Stopping Load agent : ' + hostName);
                Request.get("http://" + hostName + ":8080/ZantMeterServices/rest/stopallthreadgroup/" + testRunID, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        callback({
                            'loadagentname': hostName,
                            'status': 'ERROR',
                            'message': error
                        });
                    }
                    //console.log(body);

                    callback({
                        'loadagentname': hostName,
                        'status': 'STOPPED',
                        'message': body
                    });

                });
            }
        } catch (e) {
            console.log("Error in stopLoadAgent " + e);
            callback({
                'loadagentname': hostName,
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Terminate Load Agent
function terminateLoadAgent(instanceID, regionCode) {
    console.log("-----terminateLoadAgent()------");
    return new Promise(function (callback, reject) {
        try {
            if ((instanceID) && (regionCode)) {
                var awsServer = config.lambdaAWSServer;
                var URL = "https://" + awsServer + "/EC2/terminateec2?instanceID=" + instanceID + "&region=" + regionCode;
                //console.log(URL);
                Request.get(URL, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        callback({
                            'status': 'ERROR',
                            'message': error
                        });
                    }
                    console.log(body);
                    callback({
                        'status': 'TERMINATED',
                        'message': body
                    });
                });
            }
        } catch (e) {
            console.log("Error in terminateLoadAgent " + e);
            callback({
                'loadagentname': hostName,
                'status': 'ERROR',
                'message': e
            });
        }
    });
}


//Update TestRun Status as Ended
function updateTestRunEnded(record, testRunID) {
    console.log("-----updateTestRunEnded()------");
    return new Promise(function (callback, reject) {
        try {
            if (testRunID) {
                var nowDate = new Date();
                var endDate = nowDate.toISOString();
                var duration = new Date(endDate) - new Date(record.startTime);
                let status = {
                    status: "Ended",
                    endTime: endDate,
                    duration: duration
                };

                var newval = { $set: status }
                var bsonID = mongodb.ObjectID(testRunID);
                db.collection("TestRuns").update({ "_id": bsonID }, newval, function (err, result) {
                    if (err) {
                        console.log("Error in updateTestRuns : " + err);
                        callback({
                            'status': 'error',
                            'message': err
                        });
                    }
                    callback({
                        'status': 'updated',
                        'message': result
                    });
                });
            }
        } catch (e) {
            console.log("Error in updateTestRunEnded " + e);
            return e;
        }
    });
}

//Automate Stop Test
async function automateStopTest(testRunID) {
    console.log("-----automateStopTest()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }
    const testRunResponse = await getTestRunDoc(testRunID);
    await sleep(500);
    //console.log("testRunResponse"+JSON.stringify(testRunResponse));
    if (testRunResponse.status == 'SUCCESS') {
        let testRunDoc = testRunResponse.message;
        console.log("automateStopTest-" + testRunDoc._id);

        var jsonResponseArray = [];
        var loadAgentNames = {};
        var testGroups = testRunDoc.testGroups;

        console.log("testGroups.length-" + testRunDoc.testGroups.length);
        for (let i = 0; i < testRunDoc.testGroups.length; i++) {
            console.log("testGroups[" + i + "] - " + JSON.stringify(testRunDoc.testGroups[i].testGroupName));
            var testGroup = testGroups[i];
            var loadAgent = testGroup.loadAgent;

            let port = testGroup.loadAgent.port;
            if ((port == undefined) || (port == null) || (port == "")) {
                port = 8080;
            }
            if (testGroup.enabled) {
                let loadAgentName;
                if (testRunDoc.testGroups[i].loadAgent.type == "CloudAuto") {
                    let CloudAutoLA_ID = testRunDoc.testGroups[i].loadAgent.CloudAutoLA_ID;
                    let instanceID = testRunDoc.testGroups[i].loadAgent.instanceID;
                    /* console.log(CloudAutoLA_ID);
                    console.log(instanceID); */
                    loadAgentName = await getCloudAutoloadAgentName(parseInt(CloudAutoLA_ID), String(instanceID));
                } else {
                    loadAgentName = testRunDoc.testGroups[i].loadAgent.loadAgentName;
                }
                const stopLoadAgentResponse = await stopLoadAgentThreadgroup(loadAgentName, testRunID, testGroup.testGroupName, port);
                await sleep(500);
                jsonResponseArray.push(stopLoadAgentResponse);
            }
        }

        /* console.log("testGroups.length-" + testRunDoc.testGroups.length);
        for (let i = 0; i < testRunDoc.testGroups.length; i++) {



            console.log("testGroups[" + i + "] - " + JSON.stringify(testRunDoc.testGroups[i].testGroupName));

            var testGroup = testGroups[i];
            //var threadGroupName = testGroup.threadGroupName;
            var loadAgent = testGroup.loadAgent;

            if (testGroup.enabled) {
                if (loadAgent.type == "CloudAuto") {
                    //let query = { 'CloudAutoLA_ID': loadAgent.CloudAutoLA_ID.toString(), 'instanceID': loadAgent.instanceID.toString() };
                    const LoadAgentResponse = await getLoadAgentDoc(loadAgent.CloudAutoLA_ID.toString(), loadAgent.instanceID.toString());
                    if (LoadAgentResponse.status == 'SUCCESS') {
                        var LoadAgentDoc = LoadAgentResponse.message;
                        //console.log(JSON.stringify(LoadAgentDoc));
                        loadAgentNames[LoadAgentDoc.hostName] = { code: LoadAgentDoc.region, instanceID: LoadAgentDoc.instanceID, type: loadAgent.type, _id: LoadAgentDoc._id, testGroupName: testRunDoc.testGroups[i].testGroupName };
                    } else {
                        console.error(LoadAgentResponse);
                    }
                } else {
                    loadAgentNames[loadAgent.loadAgentName] = { type: loadAgent.type, testGroupName: testRunDoc.testGroups[i].testGroupName };
                }
                testRunDoc.testGroups[i].status = "Stopped";
            }
        }

        var loadAgents = Object.keys(loadAgentNames);
        //console.log('Load agents length : ' + loadAgents.length);

        for (var i = 0; i < loadAgents.length; i++) {
            const stopLoadAgentResponse = await stopLoadAgentThreadgroup(loadAgents[i], testRunID, loadAgentNames[loadAgents[i]].testGroupName);
            jsonResponseArray.push(stopLoadAgentResponse);
            //'status': 'STOPPED'
            if(stopLoadAgentResponse.status==="STOPPED"){
                const stopFinalThreadGroupResponse = await stopFinalThreadGroup(testRunID, loadAgentNames[loadAgents[i]].testGroupName);
                await sleep(500);
                jsonResponseArray.push(stopFinalThreadGroupResponse);
            } 
        } */
        /*
         const updateTestRunEndedResponse = await updateTestRunEnded(testRunDoc, testRunID);
         //console.log(updateTestRunEndedResponse.status);
 
         console.log('----Terminating Load agents----');
         for (var i = 0; i < loadAgents.length; i++) {
             if (loadAgentNames[loadAgents[i]].type == "CloudAuto") {
                 //console.log('Terminating Load agent : ' + loadAgents[i]);
                 var region = loadAgentNames[loadAgents[i]].code,
                     instanceID = loadAgentNames[loadAgents[i]].instanceID;
                 if ((region) && (instanceID)) {
                     const getLARegionDocResponse = await getLARegionDocByRegion(region);
                     if (getLARegionDocResponse.status == 'SUCCESS') {
                         var LARegionDoc = getLARegionDocResponse.message;
                         var regionCode = config.defaultRegionCode;//"ap-south-1";;
                         if (LARegionDoc === null || LARegionDoc === undefined || LARegionDoc === "") {
                             regionCode = region;
                         } else {
                             regionCode = LARegionDoc.code;
                         }
                         const terminateLoadAgentResponse = await terminateLoadAgent(instanceID, regionCode);
                         //console.log(terminateLoadAgentResponse);
                         
                        if (terminateLoadAgentResponse.status == 'TERMINATED') {
                            var LoadAgentDoc = LoadAgentResponse.message;
                            const deleteLoadAgentResponse = await deleteLoadAgentDoc(LoadAgentDocID);
                        }
                     } else {
                         console.error(LoadAgentResponse);
                     }
                 }
             }
         } */
        console.log(jsonResponseArray);

        return jsonResponseArray;
    } else {
        console.error(testRunResponse);
    }
}
//stop Test Runs
router.get('/stopTestRun', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----stopTestRun------");
    let testID = req.query.testrunid;

    if (typeof testID === "undefined" || testID == null || testID == "" || validationRoute(testID)) {
        console.log("Test Run ID not exists");
        return res.status(404).json({
            "error": 'test run id is missing'
        });
    }

    var jsonResponseArray = [];
    try {
        jsonResponseArray = await automateStopTest(testID);
        await sleep(500);
        return res.status(200).json(jsonResponseArray);
    } catch (e) {
        console.log("Error stopTestRun " + e);
        return res.status(500).json({
            "error": e
        });
    }
});//end of stop test run 

//stopThreadGroupOfTestRun
async function stopThreadGroupOfTestRun(testRunID, threadGroupName) {
    console.log("-----stopThreadGroupOfTestRun()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }
    const testRunResponse = await getTestRunDoc(testRunID);
    await sleep(500);
    //console.log("testRunResponse"+JSON.stringify(testRunResponse));
    if (testRunResponse.status == 'SUCCESS') {
        let testRunDoc = testRunResponse.message;
        console.log("stopThreadGroupOfTestRun-" + testRunDoc._id);

        var jsonResponseArray = [];
        var loadAgentNames = {};
        var testGroups = testRunDoc.testGroups;

        //console.log("testGroups.length-" + testRunDoc.testGroups.length);
        for (let i = 0; i < testRunDoc.testGroups.length; i++) {
            var testGroup = testGroups[i];

            let port = testGroup.loadAgent.port;
            if ((port == undefined) || (port == null) || (port == "")) {
                port = 8080;
            }
            if (testGroup.enabled) {
                let loadAgentName;
                if (testRunDoc.testGroups[i].loadAgent.type == "CloudAuto") {
                    let CloudAutoLA_ID = testRunDoc.testGroups[i].loadAgent.CloudAutoLA_ID;
                    let instanceID = testRunDoc.testGroups[i].loadAgent.instanceID;
                    /* console.log(CloudAutoLA_ID);
                    console.log(instanceID); */
                    loadAgentName = await getCloudAutoloadAgentName(parseInt(CloudAutoLA_ID), String(instanceID));
                } else {
                    loadAgentName = testRunDoc.testGroups[i].loadAgent.loadAgentName;
                }
                if (testGroup.testGroupName === threadGroupName) {
                    console.log("testGroups[" + i + "] - " + JSON.stringify(testRunDoc.testGroups[i].testGroupName) + " : threadGroupName -" + threadGroupName);
                    const stopLoadAgentResponse = await stopLoadAgentThreadgroup(loadAgentName, testRunID, testGroup.testGroupName, port);
                    await sleep(500);
                    jsonResponseArray.push(stopLoadAgentResponse);
                    break;
                }

            }
        }
        console.log(jsonResponseArray);
        return jsonResponseArray;
    } else {
        console.error(testRunResponse);
    }
}
//stop a Thread Group of Test Run
router.get('/stopThreadGroupOfTestRun', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----stopThreadGroupOfTestRun------");
    let testrunid = req.query.testrunid;
    let threadGroupName = req.query.threadGroupName;

    if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }

    if (threadGroupName === null || threadGroupName === undefined || threadGroupName === "" || validationRoute(threadGroupName)) {
        return res.status(404).json("Thread Group Name is not specified or not valid");
    }

    var jsonResponseArray = [];
    try {
        jsonResponseArray = await stopThreadGroupOfTestRun(testrunid, threadGroupName);
        await sleep(500);
        return res.status(200).json(jsonResponseArray);
    } catch (e) {
        console.log("Error stopThreadGroupOfTestRun " + e);
        return res.status(500).json({
            "error": e
        });
    }
});//end of stop a Thread Group of Test Run



//This service will be called from Tomcat API, after the test stopped automatically (post the set duration)
router.get('/updateStopStatusTestRun', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----updateStopStatusTestRun------");
    let testID = req.query.testrunid;

    if (testID === null || testID === undefined || testID === "" || validationRoute(testID)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }

    try {
        if (testID) {
            var nowDate = new Date();
            let status = {
                status: "Ended",
                endTime: nowDate.toISOString()
            };

            var newval = { $set: status }
            db.collection("TestRuns").update({ "_id": mongodb.ObjectId(testID) }, newval, function (err, result) {
                if (err) {
                    console.log("Error in updateTestRuns : " + err);
                    return res.status(500).json({ "error": err })
                }
                else {
                    console.log('After updating teh Mongo doc in stopped condition');
                    return res.status(200).json({ "status": "Test stopped" });
                }
            });
        }
    } catch (e) {
        console.log("Error in startscript " + e);
        return res.status(500).json({
            "error": e
        });

    }


});//end of stop test run 


//This service will be called from angular, to check the specifc load agent's status
router.get('/checkLoadAgentStatus', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----checkLoadAgentStatus------");
    let loadAgentName = req.query.loadAgentName;

    if (loadAgentName === null || loadAgentName === undefined || loadAgentName === "" || validationRoute(loadAgentName)) {
        return res.status(404).json("Load Agent Name is not specified or not valid");
    }

    let port = req.query.port;
    if (validationRoute(port)) {
        return res.status(404).json("Port is not specified or not valid");
    }
    if (port == null || port == undefined || port == "") {
        port = 8080;
    }
    try {
        if (loadAgentName) {
            console.log("http://" + loadAgentName + ":" + port + "/ZantMeterServices/rest/checkagentstatus");
            Request.get("http://" + loadAgentName + ":" + port + "/ZantMeterServices/rest/checkagentstatus", (error, response, body) => {
                if (error) {
                    console.error(error);
                    /* if ((error.code == "ETIMEDOUT") || (error.code == "ECONNREFUSED")) {   
                        return res.status(200).json({
                            status: "OFFLINE"
                        });
                    } */
                    return res.status(500).json({
                        "error": error
                    });

                }
                //console.log(body);
                return res.status(200).json(body);

            });
        }
    } catch (e) {
        console.log("Error in checkLoadAgentStatus " + e);
        return res.status(500).json({
            "error": e
        });
    }


});//end of 

//TestScenarios

//Add a new Test Scenario
router.post('/addTestScenario', multiUpload, function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----addTestScenario------");
    var testscenariodata = req.body;
    //console.log(JSON.stringify(testscenariodata));

    if (testscenariodata === null || testscenariodata === undefined || testscenariodata === "") {
        return res.status(404).json("Test Scenario Data is not specified");
    }
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    if (testscenariodata) {
        let timestamp = new Date(),
            utcTimestamp = timestamp.toISOString();
        testscenariodata.createdDate = utcTimestamp;
        testscenariodata.updatedDate = utcTimestamp;
        testscenariodata.customerId = bsonCustomerID;
        testscenariodata.appid = mongodb.ObjectID(testscenariodata.appid);
        db.collection('TestScenarios').insert(testscenariodata, function (err, records) {
            if (err) {
                return res.status(500).json(err);
            } else {
                return res.status(200).json({
                    status: 'Added Test Scenario'
                });
            }
        });
    }
});//end of //addTestScenario


//Getting Test Scenarios 
router.get('/getTestScenarios', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestScenarios------");

    var appID = req.query.appid;
    if (appID === null || appID === undefined || appID === "" || validationRoute(appID)) {
        return res.status(404).json("Application ID is not specified or not valid");
    }
    var bsonAppID = mongodb.ObjectID(appID);
    //"appid": bsonAppID

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection("TestScenarios").find({ "customerId": bsonCustomerID, "appid": bsonAppID }).project({ scenarioName: 1, updatedDate: 1, createdDate: 1, }).toArray((err, result) => {
        if (err) {
            console.log("Error in getTestScenarios : " + err);
            return res.status(500).json(err);
        } else {
            /*console.log("Result  "  +result);*/
            return res.status(200).json(result);
        }
    });
});//end of //Getting Test Scenarios

//Getting Test Scenario By ID
router.get('/getTestScenarioByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getTestScenarioByID------");
    var testscenarioid = req.query._id;
    if (testscenarioid === null || testscenarioid === undefined || testscenarioid === "" || validationRoute(testscenarioid)) {
        return res.status(404).json("Test Scenario ID is not specified or not valid");
    }
    if (testscenarioid) {
        var bsonID = mongodb.ObjectID(testscenarioid);
        db.collection('TestScenarios').findOne({ "_id": bsonID }, function (err, records) {
            if (err) {
                console.log("Error in getTestScenarioByID : " + err);
                return res.status(500).json(err);
            } else {
                return res.status(200).json(records);
            }
        });
    }
});//end of //Getting Test Scenario By ID


//Update Test Scenario
router.put('/updateTestScenario', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----updateTestScenario------");
    var testscenariodata = req.body;

    console.log("content-length :" + req.get("content-length"));
    /* let fs = require('fs');

    fs.writeFile('dummy.txt', JSON.stringify(testscenariodata), function (err) {
        if (err) throw err;
        console.log('Saved!');
    }); */

    //console.log(JSON.stringify(testscenariodata));
    if (testscenariodata === null || testscenariodata === undefined || testscenariodata === "") {
        return res.status(404).json("Test Scenario Data is not specified");
    }
    let appid = req.query.appid;

    if (appid === null || appid === undefined || appid === "" || validationRoute(appid)) {
        return res.status(404).json("Application ID is not specified or not valid");
    }

    if (testscenariodata._id) {
        var bsonID = mongodb.ObjectID(testscenariodata._id);

        if (testscenariodata._id === null || testscenariodata._id === undefined || testscenariodata._id === "" || validationRoute(testscenariodata._id)) {
            return res.status(404).json("Test Scenario ID is not specified or not valid");
        }



        var customerID = req.decoded.customerID;
        if (customerID === null || customerID === undefined || customerID === "") {
            return res.status(404).json("Token is not valid");
        }
        var bsonCustomerID = mongodb.ObjectID(customerID);
        //"customerId": bsonCustomerID 

        let timestamp = new Date(),
            utcTimestamp = timestamp.toISOString();
        testscenariodata.updatedDate = utcTimestamp;
        testscenariodata.customerId = bsonCustomerID;
        testscenariodata.appid = mongodb.ObjectID(appid);

        /* fs.writeFile("C:/ZantMeter/temp/sampledoc12.txt", JSON.stringify(testResult), function(err) {
            if(err) {
                return console.log(err);
            }
            console.log("The file was saved!");
        });  */

        //fs.writeFileSync("C:/ZantMeter/temp/sampledoc.txt", JSON.stringify(testResult));
        /* //temporary
        try {
            //temporary
            let testRunDocPath = "C:/PerfAssure/GitLab/CIPTS_Node/mongodocs/" + testscenariodata._id + ".json";
            //temporary
            fs.writeFileSync(testRunDocPath, JSON.stringify(testscenariodata));
            var testRunDocStats = fs.statSync(testRunDocPath);
            console.log('Test Run Doc File Size in Bytes-' + testRunDocStats.size);


            if (testRunDocStats.size > 15000000) {//check > 15Mb
                //temporary
                let threadgroups = JSON.parse(JSON.stringify(testscenariodata.testGroups));
                //temporary
                threadgroups.forEach((obj) => {
                    //obj.dataFiles = [];
                    obj.dataFiles.forEach((obj1) => {
                        obj1.contentAsText = "";
                    });
                    contentAsText
                    obj.xmlContent = "";
                });
                //temporary
                testscenariodata.testGroups = threadgroups;
            } else {
                //temporary
                fs.unlinkSync(testRunDocPath);//remove file
            }
        } catch (err) {
            console.log(err);
        } */

        delete testscenariodata['_id'];

        var newvalues = { $set: testscenariodata };
        console.log("before update");
        db.collection('TestScenarios').update({ '_id': bsonID }, newvalues, function (err, records) {
            if (err) {
                console.log(err);
                return res.status(500).json(err);
            } else {
                return res.status(200).json({
                    status: 'Updated Test Scenario'
                })
            }
        });
    } else {
        return res.status(404).json("Test Scenario ID is not specified or not valid");
    }
});//end of //updateTestScenario

//Getting loadAgents 
router.get('/getloadAgents', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getloadAgents------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection("LoadAgents").find({ "customerId": bsonCustomerID }).toArray((err, result) => {
        if (err) {
            console.log("Error in getloadAgents : " + err);
            return res.status(500).json(err);
        } else {
            /*console.log("Result  "  +result);*/
            return res.status(200).json(result);
        }
    });
});//end of //Getting loadAgents


//This API is called from Tomcat Startup servlet
router.get('/updateLoadAgentStatusOnStartup', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----updateLoadAgentStatusOnStartup------");
    var loadAgentName = req.query.loadAgentName;
    var status = req.query.status;
    if (loadAgentName === null || loadAgentName === undefined || loadAgentName === "" || validationRoute(loadAgentName)) {
        return res.status(404).json("Load Agent Name is not specified or not valid");
    }
    if (status === null || status === undefined || status === "" || status.validation(status)) {
        return res.status(404).json("Status is not specified or not valid");
    }
    //console.log('Load agent name : ' + loadAgentName);
    if (typeof loadAgentName == "undefined" || loadAgentName == null) {
        return res.status(500).json({
            error: 'Load agent name is missing'
        });
    }

    let statusVal = {
        status: status,
    };

    var newval = { $set: statusVal }

    db.collection('LoadAgents').update({ 'loadAgentName': loadAgentName }, newval, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            //console.log('Updating status ' + status + ' for load agent : ' + loadAgentName);
            return res.status(200).json({
                status: 'Updated load agent'
            })
        }
    });


});//end of //updateLoadAgentStatusOnStartup


//Getting loadAgents Configs
router.get('/getLAConfigurations', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getLAConfigurations------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection("LAConfigurations").find({ "customerId": bsonCustomerID }).toArray((err, result) => {
        if (err) {
            console.log("Error in getLAConfigurations : " + err);
            return res.status(500).json(err);
        } else {
            /*console.log("Result  "  +result);*/
            return res.status(200).json(result);
        }
    });
});//end of //Getting loadAgents Configs


//Getting loadAgents Regions
router.get('/getLARegions', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getLARegions------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection("LARegions").find({ "customerId": bsonCustomerID }).toArray((err, result) => {
        if (err) {
            //console.log("Error in getLARegions : " + err);
            return res.status(500).json(err);
        } else {
            /*console.log("Result  "  +result);*/
            return res.status(200).json(result);
        }
    });
});//end of //Getting loadAgents Regions



//Getting loadAgentsByType 
router.get('/getloadAgentsByType', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getloadAgentsByType------");

    let type = req.query.type;
    if (type === null || type === undefined || type === "" || validationRoute(type)) {
        return res.status(404).json("Type is not specified or not valid");
    }

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 

    if (type != 'all') {
        db.collection("LoadAgents").find({ "type": type, "customerId": bsonCustomerID }).toArray((err, result) => {
            if (err) {
                console.log("Error in getloadAgentsByType " + type + " : " + err);
                return res.status(500).json(err);
            } else {
                /*console.log("Result  "  +result);*/
                return res.status(200).json(result);
            }
        });
    } else {
        db.collection("LoadAgents").find({ "customerId": bsonCustomerID }).toArray((err, result) => {
            if (err) {
                console.log("Error in getloadAgentsByType " + type + " : " + err);
                return res.status(500).json(err);
            } else {
                /*console.log("Result  "  +result);*/
                return res.status(200).json(result);
            }
        });
    }

});//end of //Getting loadAgentsByType




//This service will be called from angular, to create the specific cloud load agent
router.get('/createCloudLoadAgent', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----createCloudLoadAgent------");
    let region = req.query.region,
        configuration = req.query.config,
        CloudAutoLA_ID = req.query.CloudAutoLA_ID,
        testRunID = req.query.testRunID,
        hostName = req.query.hostName;
    try {

        if (region === null || region === undefined || region === "" || validationRoute(region)) {
            return res.status(404).json("Region is not specified or not valid");
        }
        if (configuration === null || configuration === undefined || configuration === "" || validationRoute(configuration)) {
            return res.status(404).json("Configuration is not specified or not valid");
        }
        if (CloudAutoLA_ID === null || CloudAutoLA_ID === undefined || CloudAutoLA_ID === "" || validationRoute(CloudAutoLA_ID)) {
            return res.status(404).json("Cloud Load Agent ID is not specified or not valid");
        }

        if (testRunID === null || testRunID === undefined || validationRoute(testRunID)) {
            return res.status(404).json("Test Run ID is not specified or not valid");
        }
        if (hostName === null || hostName === undefined || validationRoute(hostName)) {
            return res.status(404).json("Host Name is not specified or not valid");
        }

        let customerID = req.decoded.customerID;
        if (customerID === null || customerID === undefined || customerID === "") {
            return res.status(404).json("Token is not valid");
        }
        let bsonCustomerID = mongodb.ObjectID(customerID);
        //"customerId": bsonCustomerID 

        if ((region) && (configuration)) {

            // console.log("region  "  +region);
            let query = { 'region': region };
            db.collection("LARegions").findOne(query, function (err, record) {
                if (err) {
                    console.log("Error in getLARegions : " + err);
                    return res.status(500).json(err);
                } else {
                    // console.log("record  "  +record);
                    //return res.status(200).json(record);
                    if (record.code) {

                        var awsServer = config.lambdaAWSServer,//"cp10gul8yg.execute-api.ap-south-1.amazonaws.com",
                            amiName = config.amiName,//"ami-077347933f78802b7",
                            amiImageName = config.amiImageName;//"Zantmeter-LinuxLoadAgent10Jun2019";
                        regionCode = config.defaultRegionCode,//"ap-south-1",
                            instanceType = config.defaultInstanceType,//"t2.medium",
                            keyName = config.defaultKeyName,//"SynMon_Dev_Mumbai",
                            securityGroup = config.defaultSecurityGroup;//"launch-wizard-6";
                        regionCode = record.code;
                        instanceType = configuration;

                        //var URL = "https://" + awsServer + "/EC2/createec2?amiName=" + amiName + "&region=" + regionCode + "&instanceType=" + instanceType + "&keyName=" + keyName + "&securityGroup=" + securityGroup;
                        /* windows 
                        https://cp10gul8yg.execute-api.ap-south-1.amazonaws.com/EC2/createec2acrossregion?
                        amiName=ami-04524043932f34826&region=ap-south-1&instanceType=t2.medium&keyName=SynMon_Dev_Mumbai
                        &securityGroup=launch-wizard-6&name=Zantmeter-WinLoadAgent07Jun2019&hostName=LA01&testRunID=0a1b2c3d4e5f6g7h8i9j007 */
                        /* linux
                        https://cp10gul8yg.execute-api.ap-south-1.amazonaws.com/EC2/createec2acrossregion?
                        amiName=ami-0a880a81552282420&region=ap-south-1&instanceType=t2.medium&keyName=SynMon_Dev_Mumbai
                        &securityGroup=launch-wizard-13&name=Zantmeter-LinuxLoadAgent10Jun2019&hostName=newLA0017&testRunID=0070a1b2c3d4e5f6g7h8i9j32610010 
                         */
                        var URL = "https://" + awsServer + "/EC2/createec2acrossregion?amiName=" + amiName + "&region=" + regionCode + "&instanceType=" + instanceType + "&keyName=" + keyName + "&securityGroup=" + securityGroup + "&name=" + amiImageName + "&hostName=" + hostName + "&testRunID=" + testRunID;

                        console.log(URL);
                        Request.get(URL, (error, response, body) => {
                            if (error) {
                                console.error(error);
                                return res.status(500).json({
                                    "error": error
                                });
                            }
                            //console.log(body);

                            var data = JSON.parse(body);
                            if (data.message.status == "created") {
                                var newLoadAgentData = {
                                    "type": "CloudAuto",
                                    "loadAgentName": "",
                                    "hostName": "",
                                    "instanceID": data.message.instances[0].InstanceId,
                                    "region": region,
                                    "specification": data.message.instances[0].InstanceType,
                                    "status": data.message.instances[0].State.Name,
                                    "currentTestRunID": null,
                                    "CloudAutoLA_ID": parseInt(CloudAutoLA_ID)
                                };

                                newLoadAgentData.customerId = bsonCustomerID;
                                db.collection('LoadAgents').insert(newLoadAgentData, function (err, record) {
                                    if (err) {
                                        return res.status(500).json(err);
                                    } else {
                                        return res.status(200).json({
                                            "status": data.message.status,
                                            "instanceID": data.message.instances[0].InstanceId,
                                            "loadAgent": record.ops[0]
                                        });
                                    }
                                });
                            } else {
                                return res.status(500).json({
                                    "status": "Error while creating load agent",
                                    "message": body.message
                                });
                            }
                        });
                    }
                }
            });
        }
    } catch (e) {
        console.log("Error in createCloudLoadAgent " + e);
        return res.status(500).json({
            "error": e
        });

    }


});//end of create cloud load agent



//This service will be called from angular, to check the specific cloud load agent's status
router.get('/checkCloudLoadAgentStatus', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----checkCloudLoadAgentStatus------");
    let instanceID = req.query.instanceID,
        region = req.query.region;

    try {
        if (instanceID === null || instanceID === undefined || instanceID === "" || validationRoute(instanceID)) {
            return res.status(404).json("Instance ID is not specified or not valid");
        }
        if (region === null || region === undefined || region === "" || validationRoute(region)) {
            return res.status(404).json("Region is not specified or not valid");
        }
        if ((instanceID) && (region)) {
            let query = { 'region': region };
            db.collection("LARegions").findOne(query, function (err, record) {
                if (err) {
                    console.log("Error in checkCloudLoadAgentStatus : " + err);
                    return res.status(500).json(err);
                } else {
                    /*console.log("record  "  +record);*/
                    //return res.status(200).json(record);
                    if (record.code) {
                        var awsServer = config.lambdaAWSServer,
                            regionCode = config.defaultRegionCode,
                            status = "";
                        regionCode = record.code;
                        var URL = "https://" + awsServer + "/EC2/getinstanceinfobyid?instanceID=" + instanceID + "&region=" + regionCode;
                        //console.log(URL);
                        Request.get(URL, (error, response, body) => {
                            if (error) {
                                console.error(error);
                                return res.status(500).json({
                                    "error": error
                                });
                            }
                            //console.log("----body----");
                            //console.log(JSON.stringify(body));
                            //console.log("--------");
                            body = JSON.parse(body);
                            if (body.message.instance.Reservations[0].Instances[0].State.Name == "running") {
                                var newLoadAgentData = {
                                    "loadAgentName": body.message.instance.Reservations[0].Instances[0].PublicDnsName,
                                    "hostName": body.message.instance.Reservations[0].Instances[0].PublicDnsName,
                                    "status": body.message.instance.Reservations[0].Instances[0].State.Name
                                };

                                var newvalues = { $set: newLoadAgentData };

                                db.collection('LoadAgents').update({ 'instanceID': instanceID }, newvalues, function (err, record) {
                                    if (err) {
                                        return res.status(500).json(err);
                                    } else {
                                        console.log('Updated LoadAgents');
                                        return res.status(200).json({
                                            "status": body.message.instance.Reservations[0].Instances[0].State.Name,
                                            "PublicDnsName": body.message.instance.Reservations[0].Instances[0].PublicDnsName
                                        });
                                    }
                                });
                            } else {
                                return res.status(200).json({
                                    "status": body.message.instance.Reservations[0].Instances[0].State.Name,
                                    "PublicDnsName": ""
                                });
                            }
                        });
                    }
                }
            });
        }


    } catch (e) {
        console.log("Error in checkCloudLoadAgentStatus " + e);
        return res.status(500).json({
            "error": e
        });

    }


});//end of check cloud load agent status


//delete Test Scenario
router.delete('/removeTestScenario', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----removeTestScenario------");
    var testscenarioid = req.query._id;
    if (testscenarioid === null || testscenarioid === undefined || testscenarioid === "" || validationRoute(testscenarioid)) {
        return res.status(404).json("Test Scenario ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testscenarioid);


    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection('TestScenarios').deleteOne({ "_id": bsonID, "customerId": bsonCustomerID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({
                status: 'Deleted Test Scenario'
            })
        }
    });
});//end of //delete Test Scenario


//duplicate Test Scenario
router.get('/duplicateTestScenario', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----duplicateTestScenario------");
    var testscenarioid = req.query._id;
    if (testscenarioid === null || testscenarioid === undefined || testscenarioid === "" || validationRoute(testscenarioid)) {
        return res.status(404).json("Test Scenario ID is not specified or not valid");
    }
    var testscenarioname = req.query.scenarioName;
    if (testscenarioname === null || testscenarioname === undefined || testscenarioname === "") {
        return res.status(404).json("Test Scenario Name is not specified or not valid");
    }
    var utcTimestamp = req.query.utcTimestamp;
    if (utcTimestamp === null || utcTimestamp === undefined || utcTimestamp === "") {
        return res.status(404).json("Time Stamp is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testscenarioid);


    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection('TestScenarios').findOne({ "_id": bsonID, "customerId": bsonCustomerID }, function (err, record) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let duplicatedTestScenario = record;
            duplicatedTestScenario.scenarioName = testscenarioname;

            let timestamp = new Date(),
                utcTimestamp = timestamp.toISOString();
            duplicatedTestScenario.updatedDate = utcTimestamp;
            duplicatedTestScenario.createdDate = utcTimestamp;
            delete duplicatedTestScenario['_id'];
            console.log("-----duplicateTestScenario------");
            if (duplicatedTestScenario) {
                db.collection('TestScenarios').insert(duplicatedTestScenario, function (err, records) {
                    if (err) {
                        return res.status(500).json(err);
                    } else {
                        return res.status(200).json({
                            status: 'Duplicated Test Scenario'
                        });
                    }
                });
            }
        }
    });
});//end of //duplicate Test Scenario

//delete Test Run
router.delete('/removeTestRun', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----removeTestRun------");
    var testrunid = req.query._id;
    if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunid);

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    db.collection('TestRuns').deleteOne({ "_id": bsonID, "customerId": bsonCustomerID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            return res.status(200).json({
                status: 'Deleted Test Run'
            })
        }
    });
});//end of //delete Test Run


//stop Thread Group
router.get('/stopThreadGroup', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----stopThreadGroup------");
    let testID = req.query.testrunid;
    let threadgroupname = req.query.threadgroupname;

    if (typeof testID === "undefined" || testID == null || testID == "" || validationRoute(testID)) {
        console.log("Test Run ID not exists");
        return res.status(500).json({
            "error": 'Test Run ID is missing'
        });
    }

    if (typeof threadgroupname === "undefined" || threadgroupname == null || threadgroupname == "" || validationRoute(threadgroupname)) {
        console.log("Thread Group Name not exists");
        return res.status(500).json({
            "error": 'Thread Group Name is missing'
        });
    }

    var jsonResponseArray = [];
    try {
        jsonResponseArray = stopThreadGroup(testID, threadgroupname);
        return res.status(200).json(jsonResponseArray);
    } catch (e) {
        console.log("Error stopThreadGroup " + e);
        return res.status(500).json({
            "error": e
        });
    }
});//end of stop Thread Group



//Automate stopThreadGroup
async function stopThreadGroup(testRunID, threadgroupname) {
    console.log("-----stopThreadGroup()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }

    if (!threadgroupname) {
        return ({ 'status': 'error', 'message': 'threadgroupname missing !' });
    }
    const testRunResponse = await getTestRunDoc(testRunID);

    //console.log("testRunResponse"+JSON.stringify(testRunResponse));
    if (testRunResponse.status == 'SUCCESS') {
        let testRunDoc = testRunResponse.message;
        //console.log(testRunDoc._id);
        let responseMessage;
        for (var i = 0; i < testRunDoc.testGroups.length; i++) {
            if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].testGroupName === threadgroupname)) {
                testRunDoc.testGroups[i].status = "Stopped";
                responseMessage = {
                    'testGroupName': threadgroupname,
                    'status': 'STOPPED'
                }
                break;
            }
        }
        var updateTestRunDocResponse = await updateTestRunDocument(testRunID, testRunDoc);

        if (updateTestRunDocResponse.status == 'SUCCESS') {
            return responseMessage;
        } else {
            return updateTestRunDocResponse;
        }
    } else {
        console.error(testRunResponse);
        return testRunResponse;
    }
}
//stop stopThreadGroup


//Update Test Run Document
function updateTestRunDocument(testRunID, values) {
    console.log("-----updateTestRunDocument()------");
    try {
        if ((typeof testRunID === "undefined" || testRunID == null || testRunID == "") || (typeof values === "undefined" || values == null || values == "")) {
            console.log("Test Run ID not exists");
            return ({
                'status': 'ERROR',
                'message': 'test run id or values are missing'
            });
        }

        let newval = { $set: values }
        let bsonID = mongodb.ObjectID(testRunID);
        return new Promise(function (callback, reject) {
            db.collection("TestRuns").update({ "_id": bsonID }, newval, function (err, result) {

                //db.collection("TestRuns").findAndModify({ "_id": bsonID }, newval, function (err, result) {
                if (err) {
                    console.log(err);
                    reject({
                        'status': 'ERROR',
                        'message': err
                    });
                } else {
                    //console.log("record: " + result);
                    callback({
                        'status': 'SUCCESS',
                        'message': result
                    });
                }
            });
        });
    } catch (e) {
        console.log("Error in updateTestRunDocument " + e);
        return ({
            'status': 'ERROR',
            'message': e
        });
    }
}

/* let testRuns = []; */

//stop Final Thread Group
router.get('/stopFinalThreadGroup', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----testAPI/stopFinalThreadGroup()------");
    let testID = req.query.testrunid;
    let threadgroupname = req.query.threadgroupname;

    if (typeof testID === "undefined" || testID == null || testID == "" || validationRoute(testID)) {
        console.log("Test Run ID not exists");
        return res.status(500).json({
            "error": 'Test Run ID is missing'
        });
    }

    if (typeof threadgroupname === "undefined" || threadgroupname == null || threadgroupname == "" || validationRoute(threadgroupname)) {
        console.log("Thread Group Name not exists");
        return res.status(500).json({
            "error": 'Thread Group Name is missing'
        });
    }

    var jsonResponseArray = [];
    try {
        /* let min = 1000, max = 3000;
        let random = Math.floor(Math.random() * (max - min + 1)) + min;
        await sleep(random); */
        /*  let flag = true;
         let unlock;
         while(flag){
             unlock = await lock(testID).then(()=>{
                 flag=false;
                 console.log(testID+" locked");
             }).catch((exp)=>{
                 console.log(testID+" lock exception :"+exp);
             });
             await sleep(1000);
         } */

        /* let flag = true;
        while (flag) {
            if (!testRuns.includes(testID)) {
                testRuns.push(testID);
                flag = false;
                break;
            }
            await sleep(1000);
        } */
        try {
            let data = {
                testrunid: testID,
                threadgroupname: threadgroupname
            };
            jsonResponseArray = await rabbitMQ(data);
            /* jsonResponseArray = await stopFinalThreadGroup(testID, threadgroupname); */
        } catch (ex) {
            console.log("Error testAPI/stopFinalThreadGroup " + ex);
            jsonResponseArray = {
                "error": ex
            };
        } /* finally {
            unlock();
        } */
        /* for (var i = 0; i < testRuns.length; i++) {
            if (testRuns[i] === testID) {
                testRuns.splice(i, 1);
                break;
            }
        } */
        return res.status(200).json(jsonResponseArray);
    } catch (e) {
        /* for (var i = 0; i < testRuns.length; i++) {
            if (testRuns[i] === testID) {
                testRuns.splice(i, 1);
                break;
            }
        } */
        console.log("Error testAPI/stopFinalThreadGroup " + e);
        return res.status(500).json({
            "error": e
        });
    }
});//end of stop Final Thread Group
//wrap(queue());

function queue(fn) {
    let lastPromise = Promise.resolve();
    return function (req) {
        let returnedPromise = lastPromise.then(() => fn(req));
        // If `returnedPromise` rejected, swallow the rejection for the queue,
        // but `returnedPromise` rejections will still be visible outside the queue
        lastPromise = returnedPromise.catch(() => { });
        return returnedPromise;
    };
}
function wrap(fn) {
    return function (req, res, next) {
        fn(req).then(returnVal => res.json(returnVal)).catch(err => res.status(500).json({ message: err.message }));
    };
}

//stopFinalThreadGroup
async function stopFinalThreadGroup(testRunID, threadgroupname) {
    console.log("-----stopFinalThreadGroup()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }

    if (!threadgroupname) {
        return ({ 'status': 'error', 'message': 'threadgroupname missing !' });
    }
    /* let min = 1000, max = 3000;
    let random = Math.floor(Math.random() * (max - min + 1)) + min;
    await sleep(random); */

    const testRunResponse = await getTestRunDoc(testRunID);

    /*  random = Math.floor(Math.random() * (max - min + 1)) + min;
     await sleep(random); */

    let responseMessage, updateTestRunDocResponse;
    //console.log("testRunResponse"+JSON.stringify(testRunResponse));
    if (testRunResponse.status == 'SUCCESS') {
        let testRunDoc = testRunResponse.message;

        var loadAgentNames = {};
        let TestRunOverallStatus = true;
        let LoadAgentResponse;
        let testRunDocStatus = testRunDoc.status;
        for (var i = 0; i < testRunDoc.testGroups.length; i++) {
            if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].testGroupName === threadgroupname)) {
                testRunDoc.testGroups[i].status = "Stopped";
                itemp = i;
                responseMessage = {
                    'testGroupName': threadgroupname,
                    'status': 'STOPPED'
                }
            } else if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].status === "Running")) {
                TestRunOverallStatus = false;
            }
            if (testRunDoc.testGroups[i].enabled) {
                var loadAgent = testRunDoc.testGroups[i].loadAgent;
                if (loadAgent.type == "CloudAuto") {
                    //let query = { 'CloudAutoLA_ID': loadAgent.CloudAutoLA_ID.toString(), 'instanceID': loadAgent.instanceID.toString() };
                    LoadAgentResponse = await getLoadAgentDoc(String(loadAgent.CloudAutoLA_ID), String(loadAgent.instanceID));
                    if (LoadAgentResponse.status == 'SUCCESS') {
                        var LoadAgentDoc = LoadAgentResponse.message;
                        //console.log(JSON.stringify(LoadAgentDoc));
                        loadAgentNames[LoadAgentDoc.hostName] = { code: LoadAgentDoc.region, instanceID: LoadAgentDoc.instanceID, type: loadAgent.type, _id: LoadAgentDoc._id };
                    } else {
                        console.error(LoadAgentResponse);
                    }
                } else {
                    loadAgentNames[loadAgent.loadAgentName] = { type: loadAgent.type };
                }
            }
        }
        /* if (testRunDoc.status === "Analysed") {
            TestRunOverallStatus = false;
        } */

        var loadAgents = Object.keys(loadAgentNames);
        console.log('Load agents length : ' + loadAgents.length);

        await sleep(500);

        //console.log('testRunDoc : ' + JSON.stringify(testRunDoc.testGroups[itemp]));
        console.log('testRunID : ' + testRunID);
        updateTestRunDocResponse = await updateTestRunDocument(testRunID, testRunDoc);

        await sleep(500);

        console.log('updateTestRunDocResponse : ' + JSON.stringify(updateTestRunDocResponse));
        console.log('threadgroupname : ' + threadgroupname + ', testRunDocStatus : ' + testRunDocStatus + ', TestRunOverallStatus : ' + TestRunOverallStatus);
        if (TestRunOverallStatus) {
            //if (testRunDocStatus == "Running") {
            updateTestRunDocResponse = await updateTestRunEnded(testRunDoc, testRunID);
            //console.log(updateTestRunEndedResponse.status);
            //}

            console.log('----Terminating Load agents----');
            for (var i = 0; i < loadAgents.length; i++) {
                if (loadAgentNames[loadAgents[i]].type == "CloudAuto") {
                    //console.log('Terminating Load agent : ' + loadAgents[i]);
                    var region = loadAgentNames[loadAgents[i]].code,
                        LoadAgentDocID = loadAgentNames[loadAgents[i]]._id,
                        instanceID = loadAgentNames[loadAgents[i]].instanceID;
                    if ((region) && (instanceID) && (LoadAgentDocID)) {
                        const getLARegionDocResponse = await getLARegionDocByRegion(region);
                        if (getLARegionDocResponse.status == 'SUCCESS') {
                            var LARegionDoc = getLARegionDocResponse.message;
                            var regionCode = config.defaultRegionCode;//"ap-south-1";;
                            if (LARegionDoc === null || LARegionDoc === undefined || LARegionDoc === "") {
                                regionCode = region;
                            } else {
                                regionCode = LARegionDoc.code;
                            }
                            const terminateLoadAgentResponse = await terminateLoadAgent(instanceID, regionCode);

                            if (terminateLoadAgentResponse.status == 'TERMINATED') {
                                var LoadAgentDoc = LoadAgentResponse.message;
                                const deleteLoadAgentResponse = await deleteLoadAgentDoc(LoadAgentDocID);
                            }
                            //console.log(terminateLoadAgentResponse);
                        } else {
                            console.error(LoadAgentResponse);
                        }
                    }
                }
            }
            //analyse test run

            var aggregationInterval = 1;
            try {
                //if (testRunDocStatus !== "Analysed") {
                await sleep(500);
                updateTestRunDocResponse = await analyzeTestRun(testRunID, aggregationInterval);
                //}
            } catch (e) {
                console.log("Error analyzeTestRun " + e);
                updateTestRunDocResponse = {
                    "error": e
                };
            }

        }

        if (TestRunOverallStatus) {//((TestRunOverallStatus) && (testRunDocStatus !== "Analysed")) {
            return updateTestRunDocResponse;
        } else {
            return responseMessage;
        }
    } else {
        console.error(testRunResponse);
        return ({ 'status': 'error', 'message': 'testRunID is wrong !' });
    }
}


async function analyzeTestRun(testRunID, aggregationInterval) {

    console.log("-----analyzeTestRun()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }
    let duration = 0;
    let setStatusTestRun = null;



    setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
    //console.log(setStatusTestRun.result);
    let counter = 0;
    while (duration == null || duration == 0) {
        if (counter > 3) {
            break;
        }
        await sleep(1000);
        counter++;
        if (setStatusTestRun.result.nModified != 1) {
            setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
            //console.log(setStatusTestRun.result);
        }
        duration = await getTestRunDuration(testRunID);
        console.log(duration);
    }

    aggregationInterval = getAggregationIntervalByDuration(duration, aggregationInterval);

    await sleep(1000);
    let summary = await getSummary(testRunID);

    await sleep(1000);
    let transactions = await getTransactionsForID(testRunID, aggregationInterval);

    await sleep(1000);
    let responseTime = await getResponseTimeForID(testRunID, aggregationInterval);

    await sleep(1000);
    let vUsers = await getRunningVUsersForID(testRunID, aggregationInterval);

    await sleep(1000);
    let vUsersByThreadGroups = await getVUsersByThreadGroupsForID(testRunID, aggregationInterval);

    await sleep(1000);
    let throughput = await getThroughputBytesPerSecondForID(testRunID, aggregationInterval);

    await sleep(1000);
    let hits = await getHitsPerSecondForID(testRunID, aggregationInterval);

    await sleep(1000);
    let error = await getErrorCountsForID(testRunID, aggregationInterval);

    let observations = "";

    if (duration > 300000) {
        //observations = await getObservations(testRunID, aggregationInterval);//commenting R code
    }

    await sleep(1000);
    let summaryObservation = [], transactionsObservation = [], responseTimeObservation = [], vUsersObservation = [], throughputObservation = [], hitsObservation = [], errorObservation = [], vUsersByThreadGroupsObservation = [];

    if (observations !== null && observations !== undefined && observations !== "") {

        let responseObservations = JSON.parse(observations);
        //console.log(responseObservations.msg);
        responseObservations = null;//commenting R code
        responseObservations = responseObservations.msg;
        if (responseObservations !== null && responseObservations !== undefined && responseObservations !== "") {
            for (let i = 0; i < responseObservations.length; i++) {
                switch (responseObservations[i].type) {
                    case "Transactions": {
                        transactionsObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Response Time": {
                        responseTimeObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "VUsers": {
                        vUsersObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Throughput": {
                        throughputObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Hits Per Second": {
                        hitsObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Error": {
                        errorObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "vUsersByThreadGroups": {
                        vUsersByThreadGroupsObservation.push(responseObservations[i].observation);
                        break;
                    }
                }
            }
        }
    }

    //console.log(JSON.stringify(formatResponseTimeData(responseTime)));
    let summaryData = formatSummaryData(summary),
        VUsersData = formatVUsersData(vUsers);
    let panelSummaryData = formatPanelSummaryData(summaryData, VUsersData, duration);

    let testResult = {
        panelsummary: {
            data: panelSummaryData.panelSummary,
        },
        errorsPerTranscationData: {
            data: panelSummaryData.errorsPerTranscationData,
        },
        stackedbarchartdata: {
            data: panelSummaryData.stackedbarchartdata,
        },
        summary: {
            data: summaryData,
            observations: summaryObservation
        },
        transactions: {
            rawData: transactions,
            data: formatTransactionsData(transactions),
            observations: transactionsObservation
        },
        responseTime: {
            rawData: responseTime,
            data: formatResponseTimeData(responseTime),
            observations: responseTimeObservation
        },
        vUsers: {
            rawData: vUsers,
            data: formatVUsersData(vUsers),
            observations: vUsersObservation
        },
        vUsersByThreadGroups: {
            rawData: vUsersByThreadGroups,
            data: formatVUsersByThreadGroupsData(vUsersByThreadGroups),
            observations: vUsersByThreadGroupsObservation
        },
        throughput: {
            rawData: throughput,
            data: formatThroughputData(throughput),
            observations: throughputObservation
        },
        hits: {
            rawData: hits,
            data: formatHitsPerSecondData(hits),
            observations: hitsObservation
        },
        error: {
            rawData: error,
            data: formatErrorCountsData(error),
            observations: errorObservation
        },
        observations: observations
    };

    await sleep(1000);
    let updateTestRun = await updateAnalysedTestRunDoc(testRunID, testResult);

    await sleep(1000);
    return updateTestRun;

}

async function analyze() {
    console.log("--------started--------");
    let sample = await analyzeTestRun("5bfd43bf3200be0edc57a965", 5);
    console.log("--------finished--------");
    //console.log(JSON.stringify(sample));
}


function getAggregationIntervalByDuration(duration, interval) {
    console.log("-----getAggregationIntervalByDuration()------");
    let aggregationInterval = 1;
    if ((interval != undefined) && (interval != null) && (interval > 0)) {
        aggregationInterval = interval;
    }
    if ((duration != undefined) && (duration != null)) {
        switch (true) {
            case (duration < 300000): {//<5mins
                aggregationInterval = 1;
                break;
            }
            case ((duration >= 300000) && (duration < 600000)): {//>=5mins <10mins
                aggregationInterval = 2;
                break;
            }
            case ((duration >= 600000) && (duration < 1800000)): {//>=10mins <30mins
                aggregationInterval = 5;
                break;
            }
            case ((duration >= 1800000) && (duration < 3600000)): {//>=30mins <60mins
                aggregationInterval = 10;
                break;
            }
            case ((duration >= 3600000) && (duration < 7200000)): {//>=60mins <120mins
                aggregationInterval = 15;
                break;
            }
            case ((duration >= 7200000) && (duration < 14400000)): {//>=120mins <240mins
                aggregationInterval = 30;
                break;
            }
            case ((duration >= 14400000)): {//>=240mins
                aggregationInterval = 60;
                break;
            }
        }
    }

    return aggregationInterval;
}


function formatPanelSummaryData(summaryData, VUsersData, duration) {
    console.log("-----formatPanelSummaryData()------");
    let errorsPerTranscationData = new Array(), stackedbarchartdata = [];
    let panelSummary = [
        { title: "Transactions", value: 0 },
        { title: "Duration", value: "00:00:00" },
        { title: "Max VUsers", value: 0 },
        { title: "Errors", value: 0 }
    ];

    let errorcounts = 0;
    for (let v = 0; v < summaryData.length; v++) {
        errorcounts = errorcounts + summaryData[v].errorcount;
    }
    panelSummary[3].value = errorcounts;

    summaryData.forEach((obj) => {
        obj._90percent = parseFloat(String((obj.passcount / obj.totalcount) * 90)).toFixed(2);
        obj.error = parseFloat(String((obj.errorcount / obj.totalcount) * 100)).toFixed(1);
        errorsPerTranscationData.push({ name: obj.TransactionName, value: parseFloat(String((obj.errorcount / errorcounts) * 100)).toFixed(2) });
        let series = [];
        series.push({
            "name": "Response Time",
            "value": parseFloat(String(obj.avg)).toFixed(0)
        });
        /* series.push({
            "name": "Pass",
            "value": obj.passcount
        });
        series.push({
            "name": "Fail",
            "value": obj.errorcount
        }); */
        stackedbarchartdata.push({
            "name": obj.TransactionName,
            "series": series,
        });
    });

    let stackedbarchartdata1 = stackedbarchartdata.sort((obj1, obj2) => {
        return obj2.series[0].value - obj1.series[0].value;
    });

    if (stackedbarchartdata1.length > 5) {
        stackedbarchartdata = stackedbarchartdata1.splice(0, 5);
    }

    panelSummary[0].value = summaryData.length;
    panelSummary[1].value = getHHmmssFromMilliseconds(duration);
    let values = [];
    if (VUsersData[0].series.length > 0) {
        for (var vi = 0; vi < VUsersData[0].series.length; vi++) {
            values.push(VUsersData[0].series[vi].value);
        }
    }

    let maxVUsers = Math.max(...values);
    panelSummary[2].value = maxVUsers;

    let formatPanelSummaryData = {
        panelSummary: panelSummary,
        errorsPerTranscationData: errorsPerTranscationData,
        stackedbarchartdata: stackedbarchartdata
    };

    return formatPanelSummaryData;
}

function getHHmmssFromMilliseconds(ms) {
    let date = new Date(null);
    var timeOffsetInMS = date.getTimezoneOffset() * 60000;
    ms = ms + timeOffsetInMS;
    date.setMilliseconds(ms);
    let result = date.toTimeString().substr(0, 8);
    //console.log(result);
    return result;
}

function getSummary(testrunid) {
    console.log("-----getSummary()------");
    return new Promise(function (callback, reject) {
        var summaryQuery = "select mean(\"ResponseTime\") as \"avg\", sum(\"TransactionCount\") as \"totalcount\", sum(\"ErrorCount\") as \"errorcount\", percentile(\"ResponseTime\", 90) as percentile from Transactions where RunID='" + testrunid + "' group by \"TransactionName\"";
        influx.query(summaryQuery)
            .then(result => {
                console.log("----------getTestSummary-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => {
                reject(error);
            });
    });
}

function formatSummaryData(Data) {
    console.log("-----formatSummaryData()------");
    Data.forEach((obj) => {
        obj.passcount = obj.totalcount - obj.errorcount;
    });
    return Data;
}

function getTransactionsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getTransactionsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var transactionsQuery = "select \"time\", (sum(\"TransactionCount\")/" + interval + ") as \"totalcount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

        influx.query(transactionsQuery)
            .then((result) => {
                console.log("----------getTransactionsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatTransactionsData(Data) {
    console.log("-----formatTransactionsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].totalcount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatTransactionsData Data length:" + Data.length);
    }
}

function getResponseTimeForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getResponseTimeForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var responseTimeQuery = "select \"time\", mean(\"ResponseTime\") as \"ResponseTime\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getResponseTimeForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatResponseTimeData(Data) {
    console.log("-----formatResponseTimeData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].ResponseTime,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatResponseTimeData Data length:" + Data.length);
    }
}

function customFormatDate(dateTBM) {
    //console.log("-----customFormatDate()------");
    var Mdate = '';
    if (dateTBM) {
        //Mdate = formatDate(dateTBM, 'MM-d-y HH:mm:ss', 'en-US');
        //Mdate = formatDate(dateTBM, 'HH:mm:ss', 'en-US');
        //new Date(dateTBM).getTime()
        Mdate = new Date(dateTBM).getTime();
    }
    return Mdate;
}

function parseNumber(value) {
    return parseFloat(value);
}


function getVUsersByThreadGroupsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getVUsersByThreadGroupsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var VUsersForIDByThreadGroupsQuery = "select \"time\", mean(\"ThreadCount\") as \"ThreadCount\" from ThreadGroupData where RunID='" + testrunid + "' group by time(" + interval + "s), ThreadGroupName fill(none)";

        influx.query(VUsersForIDByThreadGroupsQuery)
            .then((result) => {
                console.log("----------getVUsersByThreadGroupsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatVUsersByThreadGroupsData(Data) {
    console.log("-----formatVUsersByThreadGroupsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            if (obj.ThreadGroupName != '') {
                groupByName[obj.ThreadGroupName] = groupByName[obj.ThreadGroupName] || [];
                groupByName[obj.ThreadGroupName].push(obj);
            }
        });
        //console.log(JSON.stringify(groupByName));
        let ThreadGroupNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < ThreadGroupNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[ThreadGroupNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[ThreadGroupNames[iName]][vi].time),
                    value: groupByName[ThreadGroupNames[iName]][vi].ThreadCount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: ThreadGroupNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatVUsersForIDByThreadGroupsData Data length:" + Data.length);
    }
}

function getRunningVUsersForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getRunningVUsersForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var vUsersQuery = "select time, (sum(ActiveVUsers)/" + interval + ") as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + interval + "s) fill(none)";
        influx.query(vUsersQuery)
            .then((result) => {
                console.log("----------getRunningVUsersForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}


function formatVUsersData(runningVUsersData) {
    console.log("-----formatVUsersData()------");
    //console.log("runningVUsersData length:"+runningVUsersData.length);
    if (runningVUsersData.length > 0) {
        let series = [], values = [];
        for (var vi = 0; vi < runningVUsersData.length; vi++) {
            let seriesVal = {
                name: customFormatDate(runningVUsersData[vi].time),
                value: Math.round(runningVUsersData[vi].ActiveVUsers),
            };
            series.push(seriesVal);
            values.push(runningVUsersData[vi].ActiveVUsers);
        }


        let VUsersData = [
            { name: 'VUsers', series: series, },
        ];
        return VUsersData;
    } else {
        //console.log("formatVUsersData Data length:" + runningVUsersData.length);
    }
}


function getThroughputBytesPerSecondForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getThroughputBytesPerSecondForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var throughputQuery = "select time, (sum(ResponseSize)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)";
        influx.query(throughputQuery)
            .then((result) => {
                console.log("----------getThroughputBytesPerSecondForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatThroughputData(Data) {
    console.log("-----formatThroughputData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: parseNumber(Data[vi].sum),
            };
            series.push(seriesVal);
        }

        let ThroughputData = [
            { name: 'Throughput', series: series, },
        ];
        return ThroughputData;
    } else {
        //console.log("formatThroughputData Data length:" + Data.length);
    }
}


function getHitsPerSecondForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getHitsPerSecondForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var hitsQuery = "select time, (sum(Hits)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
        // var hitsQuery = "select time, (sum(Hits)/" + interval + ") from RequestMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
        influx.query(hitsQuery)
            .then((result) => {
                console.log("----------getHitsPerSecondForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatHitsPerSecondData(Data) {
    console.log("-----formatHitsPerSecondData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: Data[vi].sum,
            };
            series.push(seriesVal);
        }

        let HitsPerSecondData = [
            { name: 'Hits/Second', series: series, },
        ];
        return HitsPerSecondData;
    } else {
        //console.log("formatHitsPerSecondData Data length:" + Data.length);
    }
}

function getErrorCountsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getErrorCountsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var errorQuery = "select \"time\", (sum(\"ErrorCount\")/" + interval + ") as \"ErrorCount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";
        influx.query(errorQuery)
            .then((result) => {
                console.log("----------getErrorCountsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}


function formatErrorCountsData(Data) {
    console.log("-----formatErrorCountsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {

        let ErrorCountsData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].ErrorCount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            ErrorCountsData.push({ name: transcationNames[iName], series: series });
        }
        return ErrorCountsData;
    } else {
        //console.log("formatErrorCountsData Data length:" + Data.length);
    }
}


function getObservations(testRunID, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getObservations()------");
        let URL = "http://" + config.rServer + ":8000/analyze?RunID=" + testRunID + "&aggregationInterval=" + aggregationInterval;
        try {
            Request.get(URL, (error, response, body) => {
                if (error) {
                    console.error(error);
                    reject(error);
                }
                //console.log(body);
                callback(body);
            });
        } catch (e) {
            console.log("Error in getTestRunDoc " + e);
            callback("");
        }
    });
}



function updateAnalysedTestRunDoc(testRunID, testResult) {
    return new Promise(function (callback, reject) {
        console.log("-----updateAnalysedTestRunDoc()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = "Analysed";
        updateTestRun.testResult = testResult;
        console.log("status:: " + updateTestRun.status);
        var newvalues = { $set: updateTestRun };

        db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
            if (err) {
                console.log("Error in updateTestRunDoc : " + err);
                reject(error);
            }
            else {
                console.log("----------updateAnalysedTestRunDoc-----------");
                callback(result);
            }
        });
    });
}



function updateTestRunStatus(testRunID, Status) {
    return new Promise(function (callback, reject) {
        console.log("-----updateTestRunStatus()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = Status;
        console.log("status:: " + updateTestRun.status);
        var newvalues = { $set: updateTestRun };

        db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
            if (err) {
                console.log("Error in updateTestRunStatus : " + err);
                reject(error);
            }
            else {
                console.log("----------updateTestRunStatus-----------");
                callback(result);
            }
        });
    });
}

function getTestRunDuration(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----getTestRunDuration()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, { duration: 1 }, function (err, record) {
            if (err) {
                console.log("Error in getTestRunDuration : " + err);
                reject(err);
            } else {
                callback(record.duration);
            }
        });
    });
}

//getObservations("5bfd43bf3200be0edc57a965");
//5bfd43bf3200be0edc57a965 
//analyze();


//Getting Applications 
router.get('/getApplicationListByCID', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getApplicationListByCID------");

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    customerDB.collection("Customers").find({ "_id": bsonCustomerID }).project({ "application.appid": 1, "application.applicationName": 1, }).toArray((err, result) => {
        if (err) {
            console.log("Error in getApplicationListByCID : " + err);
            return res.status(500).json(err);
        } else {
            //console.log("Result  " + result[0].application);
            return res.status(200).json(result[0].application);
        }
    });
});//end of //Getting Applications 





function getCloudAutoloadAgentName(CloudAutoLA_ID, instanceID) {
    return new Promise(function (callback, reject) {
        console.log("-----getCloudAutoloadAgentName()------");
        console.log(CloudAutoLA_ID);
        console.log(instanceID);
        db.collection('LoadAgents').findOne({ "CloudAutoLA_ID": parseInt(CloudAutoLA_ID), "instanceID": String(instanceID) }, function (err, record) {
            if (err) {
                console.log("Error in getCloudAutoHostName : " + err);
                reject(err);
            } else {
                console.log(record);
                callback(record.loadAgentName);
            }
        });
    });
}


//Start a new Test Run By Scenario
router.get('/startTestRunByScenario', async function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----startTestRunByScenario------");
    let testscenarioid = req.query._id;

    if (testscenarioid === null || testscenarioid === undefined || testscenarioid === "" || validationRoute(testscenarioid)) {
        return res.status(404).json("Test Scenario ID is not specified or not valid");
    }

    let customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    let bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 

    let availablity = await checkTestScenarioLoadAgents(testscenarioid, bsonCustomerID);
    //{ OverallStatus:OverallStatus, currentLoadAgents:currentLoadAgents }
    await sleep(500);
    console.log("testscenarioid: " + testscenarioid + " availablity:" + availablity);
    if (availablity.OverallStatus) {
        let newTestRunID = await automateStartTestRunByScenario(testscenarioid, availablity.currentThreadGroupCloudAutoLAs);
        if (newTestRunID != null) {
            return res.status(200).json({
                status: 'Started Test Run',
                testRunID: newTestRunID
            });
        } else {
            return res.status(404).json({
                status: 'Error'
            });
        }
    } else {
        return res.status(500).json({
            status: 'Error',
            message: 'Load Agents are not available !!'
        });
    }
});//end of //startTestRunByScenario


//Automate Start Test Run By Scenario
async function automateStartTestRunByScenario(testscenarioid, currentThreadGroupCloudAutoLAs) {
    console.log("-----automateStartTestRunByScenario()------");
    let newTestRunID = null;
    try {
        let responseNewTestRun = await getTestScenarioByID(testscenarioid);
        await sleep(500);
        if (responseNewTestRun.status == 'SUCCESS') {
            let newTestRun = responseNewTestRun.message;
            let bsonTestScenarioID = mongodb.ObjectID(newTestRun['_id']);
            newTestRun.testScenarioID = bsonTestScenarioID;
            delete newTestRun['_id'];
            newTestRun.testRunName = newTestRun['scenarioName'];//+ "_" + msTimestamp;
            /* newTestRun.application = "default";
            newTestRun.customerName = "default"; */
            newTestRun.status = "Running";
            let utcTimestamp = new Date();
            let isoTimestamp = utcTimestamp.toISOString();
            newTestRun.startTime = isoTimestamp;
            if (!newTestRun.hasOwnProperty('endTime')) {
                newTestRun.endTime = null;
            }
            if (!newTestRun.hasOwnProperty('duration')) {
                newTestRun.duration = null;
            }
            for (var nit = 0; nit < newTestRun.testGroups.length; nit++) {
                if (newTestRun.testGroups[nit].enabled) {
                    newTestRun.testGroups[nit].status = "Running";
                }
            }
            /////
            //update testrun doc with instance ID for Cloud auto LAs
            var testGroups = newTestRun.testGroups;
            for (let ctgcalas = 0; ctgcalas < currentThreadGroupCloudAutoLAs.length; ctgcalas++) {
                newTestRun.testGroups[currentThreadGroupCloudAutoLAs[ctgcalas].index].loadAgent.instanceID = currentThreadGroupCloudAutoLAs[ctgcalas].instanceID;
            }

            /////
            let responseAddTestScenarioDoc = await addTestScenarioDoc(newTestRun);
            await sleep(500);
            if (responseAddTestScenarioDoc.status == 'Added Test Run') {
                newTestRunID = responseAddTestScenarioDoc.testRunID;
            }


            let jsonResponseArray = [];
            newTestRun._id = newTestRunID;
            if (newTestRun) {
                // console.log("id:" + newTestRun['_id']);
                //Now call the tomcat to start JMeter
                try {
                    if (newTestRun['_id'] && typeof newTestRun.testGroups != "undefined" && newTestRun.testGroups != null && newTestRun.testGroups != []) {

                        var testGroups = newTestRun.testGroups;
                        for (var it = 0; it < testGroups.length; it++) {
                            //await sleep(1000);
                            await (function () {
                                var itg = it;
                                //setTimeout(function(){
                                //console.log(it);
                                //console.log(itg);
                                var testGroup = testGroups[itg];
                                var loadAgent = testGroups[itg].loadAgent;
                                var threadGroupName = testGroups[itg].testGroupName;
                                //console.log("testGroupName " + itg + " :" + testGroups[itg].testGroupName);
                                let port = testGroups[itg].loadAgent.port;
                                if ((port == undefined) || (port == null) || (port == "")) {
                                    port = 8080;
                                }
                                if (testGroup.enabled) {
                                    if (loadAgent.type == "CloudAuto") {
                                        /* 
                                        console.log("------------CloudAutoLA_ID--------------");
                                        //console.log(loadAgent.CloudAutoLA_ID.toString()); */
                                        jsonResponseArray = automateStartTest(String(loadAgent.CloudAutoLA_ID), String(loadAgent.instanceID), threadGroupName, newTestRun['_id'], jsonResponseArray, port);//, token);
                                    } else {
                                        // var startURL = "http://" + testGroups[itg].loadAgent.loadAgentName + ":" + port + "/ZantMeterServices/rest/starttest/" + newTestRun['_id'] + "/" + testGroups[itg].testGroupName + "/" + config.influxDBHost;//+ "/" + token;
                                        var startURL = "http://" + testGroups[itg].loadAgent.loadAgentName + ":" + port + "/ZantMeterServices/rest/starttest/" + newTestRun['_id'] + "/" + testGroups[itg].testGroupName + "/" + config.influxDBHost + "/" + port + "/" + config.influxDBUserName + "/" + config.influxDBPassword;
                                        //startURL=encodeURI(startURL);
                                        console.log(startURL);
                                        Request.get(startURL, (error, response, body) => {
                                            if (error) {
                                                console.error(error);
                                                jsonResponseArray.push({
                                                    'threadgroupname': testGroups[itg].testGroupName,
                                                    'loadagentname': testGroups[itg].loadAgent.loadAgentName,
                                                    'status': 'ERROR',
                                                    'message': error
                                                });
                                            }
                                            //console.log((new Date()) + ': STARTED LOAD AGENT : ' + testGroups[itg].loadAgent.loadAgentName + ' ThreadGroup: ' + testGroups[itg].testGroupName + ', RESPONSE : ' + body);
                                            jsonResponseArray.push({
                                                'threadgroupname': testGroups[itg].testGroupName,
                                                'loadagentname': testGroups[itg].loadAgent.loadAgentName,
                                                'status': 'STARTED',
                                                'message': body
                                            });
                                        });
                                    }
                                }
                            })();
                            await sleep(500);
                        }
                    }
                } catch (e) {
                    console.log("Error in starting automateStartTestRunByScenario " + e);
                }
            }
        }
    } catch (e) {
        console.log("Error in automateStartTestRunByScenario :" + e);
    }

    return newTestRunID;
}




//Get Test Scenario By ID
function getTestScenarioByID(testID) {
    console.log("-----getTestScenarioByID()------");
    return new Promise(function (callback, reject) {
        try {
            if (testID) {
                //console.log("testRunID:" + testRunID);
                var bsonID = mongodb.ObjectID(testID);
                db.collection('TestScenarios').findOne({ "_id": bsonID }, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    //console.log("record:"+record);
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in getTestScenarioByID " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Get Test Scenario By ID
function addTestScenarioDoc(testrundata) {
    console.log("-----addTestScenarioDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if (testrundata) {
                /* try {
                    //temporary
                    var testRunDocPath = "C:/PerfAssure/GitLab/CIPTS_Node/mongodocs/" + testrundata.testScenarioID + ".json";
                    //temporary
                    if (fs.existsSync(testRunDocPath)) {
                        //temporary
                        const testRunDoc = fs.readFileSync(testRunDocPath, { encoding: 'utf8', flag: 'r' });
                        //temporary
                        var testRunJSON = JSON.parse(testRunDoc);
                        //temporary
                        let threadgroupsFile = JSON.parse(JSON.stringify(testRunJSON.testGroups));
                        let threadgroupsMongo = JSON.parse(JSON.stringify(testrundata.testGroups));
                        //temporary
                        threadgroupsFile.forEach((obj1) => {
                            threadgroupsMongo.forEach((obj2) => {
                                if(obj1.testGroupName==obj2.testGroupName){
                                    obj1.status = obj2.status;
                                }
                            });
                        });
                        //temporary
                        testRunJSON.testGroups = threadgroupsFile;
                        //temporary
                        testRunJSON.status = testrundata.status;
                        //temporary
                        testRunJSON.startTime = testrundata.startTime;
                        //temporary
                        if(testrundata.hasOwnProperty("endTime")){
                            testRunJSON.endTime = testrundata.endTime;
                        }
                        //temporary
                        fs.writeFileSync(testRunDocPath, JSON.stringify(testRunJSON));
                    }
                } catch (err) {
                    console.log(err);
                } */
                db.collection('TestRuns').insert(testrundata, function (err, result) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    } else {
                        //console.log("result.ops[0]['_id']:" + result.ops[0]['_id']);
                        /* var id = result.ops[0]['_id'];
                        console.log("id:"+id);  */
                        callback({
                            'status': 'Added Test Run',
                            'testRunID': result.ops[0]['_id']
                        });
                    }
                });
            }
        } catch (e) {
            console.log("Error in addTestScenarioDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}


//Check Test Run Load Agents From Scenario
async function checkTestScenarioLoadAgents(testscenarioid, bsonCustomerID) {
    console.log("-----checkTestScenarioLoadAgents()------");
    let OverallStatus = true;
    let currentLoadAgents = [];
    let currentThreadGroupCloudAutoLAs = [];

    try {
        let responseNewTestRun = await getTestScenarioByID(testscenarioid);
        await sleep(500);
        if (responseNewTestRun.status == 'SUCCESS') {
            let testRunDoc = responseNewTestRun.message;
            let testGroups = testRunDoc.testGroups;
            let CloudAutoLAs = testRunDoc.CloudAutoLAs;
            var loadAgentNames = {};
            let defaultPort = 8080;

            for (var i = 0; i < testGroups.length; i++) {
                var testGroup = testGroups[i];
                //var threadGroupName = testGroup.threadGroupName;
                var loadAgent = testGroup.loadAgent;

                if (testGroup.enabled) {
                    if (loadAgent.type == "Cloud" || loadAgent.type == "OnPremise") {
                        loadAgentNames[loadAgent.loadAgentName] = loadAgent.type;
                    }
                }
            }

            let loadAgentsList = Object.keys(loadAgentNames);
            console.log('Load agents length : ' + loadAgentsList.length);

            for (let ilaList = 0; ilaList < loadAgentsList.length; ilaList++) {
                let threadGroupsNames = [];
                for (let itestGroup = 0; itestGroup < testGroups.length; itestGroup++) {
                    let testGroup = testGroups[itestGroup];
                    if ((loadAgentsList[ilaList] == testGroup.loadAgent.loadAgentName) && (testGroup.enabled) && (testGroup.loadAgent.type != 'CloudAuto')) {
                        threadGroupsNames.push({ name: testGroup.testGroupName, index: itestGroup });
                    }
                }
                let port = JSON.parse(JSON.stringify(defaultPort));
                //let la: loadAgent = loadAgentsList[ilaList];
                if (testGroup.loadAgent.hasOwnProperty('port')) {
                    port = testGroup.loadAgent.port
                }
                if ((threadGroupsNames.length > 0) && (threadGroupsNames.length <= 5)) {
                    let postion = currentLoadAgents.push({ name: loadAgentsList[ilaList], threadGroupsNames: threadGroupsNames, hostName: loadAgentsList[ilaList], status: 'Validating', type: loadAgentNames[loadAgentsList[ilaList]] }) - 1;
                    if (loadAgentsList[ilaList]) {
                        Request.get("http://" + loadAgentsList[ilaList] + ":" + port + "/ZantMeterServices/rest/checkagentstatus", (error, response, body) => {
                            if (error) {
                                console.error(error);
                                return res.status(500).json({
                                    "error": error
                                });

                            }
                            let checkagentstatusObj = JSON.parse(body);

                            console.log(checkagentstatusObj.status + " " + postion);
                            currentLoadAgents[postion].status = checkagentstatusObj.status;
                        });
                        await sleep(500);
                    }
                }
                if (threadGroupsNames.length > 5) {
                    console.log(loadAgentsList[ilaList] + "has more than 5  threadgroups");
                }
            }

            await sleep(500);
            for (let iclaList = 0; iclaList < CloudAutoLAs.length; iclaList++) {
                let threadGroupsNames = [];
                for (let itestGroup = 0; itestGroup < testGroups.length; itestGroup++) {
                    let testGroup = testGroups[itestGroup];
                    if ((parseInt(CloudAutoLAs[iclaList].id) == parseInt(testGroup.loadAgent.CloudAutoLA_ID)) && (testGroup.enabled) && (testGroup.loadAgent.type == 'CloudAuto')) {
                        threadGroupsNames.push({ name: testGroup.testGroupName, index: itestGroup });
                    }
                }
                let cla = CloudAutoLAs[iclaList];
                if ((threadGroupsNames.length > 0) && (threadGroupsNames.length <= 5)) {
                    var postion = currentLoadAgents.push({ name: cla.name + " (" + cla.config + " - " + cla.region + ")", threadGroupsNames: threadGroupsNames, status: 'Creating', type: 'CloudAuto', instanceID: '', id: cla.id }) - 1;

                    let ccalaResponse = await createCloudAutoLoadAgent(cla.region, cla.config, bsonCustomerID, cla.id);
                    //console.log(JSON.stringify(ccalaResponse));
                    console.log("createCloudAutoLoadAgent : " + ccalaResponse.status);
                    if (ccalaResponse.status == "created") {
                        currentLoadAgents[postion].status = ccalaResponse.status;
                        currentLoadAgents[postion].instanceID = ccalaResponse.instanceID;
                        let newla = ccalaResponse.loadAgent;

                        //update testrun doc with instance ID for Cloud auto LAs
                        for (var z = 0; z < threadGroupsNames.length; z++) {
                            testRunDoc.testGroups[threadGroupsNames[z].index].loadAgent.instanceID = ccalaResponse.instanceID;
                            currentThreadGroupCloudAutoLAs.push({ index: threadGroupsNames[z].index, instanceID: ccalaResponse.instanceID });
                        }
                        currentLoadAgents[postion].status = 'created';
                        //checkCloudAutoLoadAgentStatus(newla, threadGroupsNames, postion);
                        //checkCloudAutoLoadAgentStatus(la: any, threadGroupsNames: string[], postion) {

                        await sleep(500);
                        let checkCloudAutoLoadAgentStatusRequest;
                        try {
                            checkCloudAutoLoadAgentStatusRequest = await checkCloudAutoLoadAgentCreationStatus(currentLoadAgents[postion].instanceID, newla.region);
                            currentLoadAgents[postion].status = checkCloudAutoLoadAgentStatusRequest.status;
                            currentLoadAgents[postion].hostName = checkCloudAutoLoadAgentStatusRequest.PublicDnsName;
                        } catch (e) {
                            console.log("Error in checkTestScenarioLoadAgents checkCloudAutoLoadAgentCreationStatus :" + JSON.stringify(e));
                            checkCloudAutoLoadAgentStatusRequest = {
                                status: "Error"
                            };
                        }
                        await sleep(500);
                        while (checkCloudAutoLoadAgentStatusRequest.status != "running") {
                            currentLoadAgents[postion].status = 'Validating';
                            await sleep(3000);
                            try {
                                checkCloudAutoLoadAgentStatusRequest = await checkCloudAutoLoadAgentCreationStatus(currentLoadAgents[postion].instanceID, newla.region);
                                currentLoadAgents[postion].status = checkCloudAutoLoadAgentStatusRequest.status;
                                currentLoadAgents[postion].hostName = checkCloudAutoLoadAgentStatusRequest.PublicDnsName;
                            } catch (e) {
                                console.log("Error in checkTestScenarioLoadAgents checkCloudAutoLoadAgentCreationStatus :" + JSON.stringify(e));
                                checkCloudAutoLoadAgentStatusRequest = {
                                    status: "Error"
                                };
                            }
                        }
                        let cLASResponse, cLASResponseobj;
                        await sleep(500);
                        try {
                            cLASResponse = await checkLoadAgentStatus(checkCloudAutoLoadAgentStatusRequest.PublicDnsName, defaultPort);
                            cLASResponseobj = JSON.parse(cLASResponse);
                            console.log(JSON.stringify(cLASResponseobj));
                            currentLoadAgents[postion].status = cLASResponseobj.status
                        } catch (e) {
                            console.log("Error in checkTestScenarioLoadAgents checkLoadAgentStatus :" + JSON.stringify(e));
                            cLASResponseobj = {
                                status: "Error"
                            };
                        }
                        await sleep(500);
                        while ((cLASResponseobj.status != "AVAILABLE" || cLASResponseobj.status != "BUSY" || cLASResponseobj.status != "OFFLINE" || cLASResponseobj.status == "ERROR")) {
                            try {
                                await sleep(3000);
                                cLASResponse = await checkLoadAgentStatus(checkCloudAutoLoadAgentStatusRequest.PublicDnsName, defaultPort);
                                cLASResponseobj = JSON.parse(cLASResponse);
                                console.log(JSON.stringify(cLASResponseobj));
                                currentLoadAgents[postion].status = cLASResponseobj.status
                                if (cLASResponseobj.status == "AVAILABLE") {
                                    break;
                                }
                            } catch (e) {
                                console.log("Error in checkTestScenarioLoadAgents checkLoadAgentStatus :" + JSON.stringify(e));
                                cLASResponseobj = {
                                    status: "Error"
                                };
                            }
                        }
                    } else {
                        currentLoadAgents[postion].status = "Error";
                    }
                }

                if (threadGroupsNames.length > 5) {
                    //console.log(testGroup.testGroupName + "has more than 5  threadgroups");
                }
                await sleep(500);
            }

            await sleep(500);
            for (let currentlaList = 0; currentlaList < currentLoadAgents.length; currentlaList++) {
                console.log(JSON.stringify(currentLoadAgents[currentlaList]));
                //console.log(currentLoadAgents[currentlaList].status);
                if (currentLoadAgents[currentlaList].status != "AVAILABLE") {// || body.status == 'BUSY' || body.status == 'OFFLINE')){
                    //console.log(JSON.stringify(currentLoadAgents[currentlaList]));
                    OverallStatus = false;
                    break;
                }
            }
            //console.log(JSON.stringify(currentLoadAgents));
        }
    } catch (e) {
        console.log("Error in checkTestScenarioLoadAgents :" + JSON.stringify(e));
    }

    //return OverallStatus;
    return ({
        OverallStatus: OverallStatus,
        currentLoadAgents: currentLoadAgents,
        currentThreadGroupCloudAutoLAs: currentThreadGroupCloudAutoLAs
    });
}

//Create Cloud Load Agent
function createCloudAutoLoadAgent(region, configuration, bsonCustomerID, CloudAutoLA_ID, hostName, testRunID) {
    console.log("-----createCloudAutoLoadAgent()------");
    return new Promise(function (callback, reject) {
        try {
            if ((region) && (configuration) && (bsonCustomerID)) {
                let query = { 'region': region };
                db.collection("LARegions").findOne(query, function (err, record) {
                    if (err) {
                        console.log("Error in getLARegions : " + err);
                        reject(err);
                    } else {
                        /*console.log("record  "  +record);*/
                        //return res.status(200).json(record);
                        if (record.code) {
                            var awsServer = config.lambdaAWSServer,//"cp10gul8yg.execute-api.ap-south-1.amazonaws.com",
                                amiName = config.amiName,//"ami-077347933f78802b7",
                                amiImageName = config.amiImageName;//"Zantmeter-LinuxLoadAgent10Jun2019";
                            regionCode = config.defaultRegionCode,//"ap-south-1",
                                instanceType = config.defaultInstanceType,//"t2.medium",
                                keyName = config.defaultKeyName,//"SynMon_Dev_Mumbai",
                                securityGroup = config.defaultSecurityGroup;//"launch-wizard-6";
                            regionCode = record.code;
                            instanceType = configuration;
                            //var URL = "https://" + awsServer + "/EC2/createec2?amiName=" + amiName + "&region=" + regionCode + "&instanceType=" + instanceType + "&keyName=" + keyName + "&securityGroup=" + securityGroup;
                            /* windows 
                            https://cp10gul8yg.execute-api.ap-south-1.amazonaws.com/EC2/createec2acrossregion?
                            amiName=ami-04524043932f34826&region=ap-south-1&instanceType=t2.medium&keyName=SynMon_Dev_Mumbai
                            &securityGroup=launch-wizard-6&name=Zantmeter-WinLoadAgent07Jun2019&hostName=LA01&testRunID=0a1b2c3d4e5f6g7h8i9j007 */
                            /* linux
                            https://cp10gul8yg.execute-api.ap-south-1.amazonaws.com/EC2/createec2acrossregion?
                            amiName=ami-0a880a81552282420&region=ap-south-1&instanceType=t2.medium&keyName=SynMon_Dev_Mumbai
                            &securityGroup=launch-wizard-13&name=Zantmeter-LinuxLoadAgent10Jun2019&hostName=newLA0017&testRunID=0070a1b2c3d4e5f6g7h8i9j32610010 
                             */
                            var URL = "https://" + awsServer + "/EC2/createec2acrossregion?amiName=" + amiName + "&region=" + regionCode + "&instanceType=" + instanceType + "&keyName=" + keyName + "&securityGroup=" + securityGroup + "&name=" + amiImageName + "&hostName=" + hostName + "&testRunID=" + testRunID;

                            console.log(URL);
                            Request.get(URL, (error, response, body) => {
                                if (error) {
                                    console.error(error);
                                    reject({
                                        "error": error
                                    });
                                }
                                //console.log(body);

                                var data = JSON.parse(body);
                                if (data.message.status == "created") {
                                    var newLoadAgentData = {
                                        "type": "CloudAuto",
                                        "loadAgentName": "",
                                        "hostName": "",
                                        "instanceID": data.message.instances[0].InstanceId,
                                        "region": region,
                                        "specification": data.message.instances[0].InstanceType,
                                        "status": data.message.instances[0].State.Name,
                                        "currentTestRunID": null,
                                        "CloudAutoLA_ID": parseInt(CloudAutoLA_ID)
                                    };

                                    newLoadAgentData.customerId = bsonCustomerID;
                                    db.collection('LoadAgents').insert(newLoadAgentData, function (err, record) {
                                        if (err) {
                                            reject(err);
                                        } else {
                                            callback({
                                                "status": data.message.status,
                                                "instanceID": data.message.instances[0].InstanceId,
                                                "loadAgent": record.ops[0]
                                            });
                                        }
                                    });
                                } else {
                                    reject({
                                        "status": "Error while creating cloud auto load agent",
                                        "message": body.message
                                    });
                                }
                            });
                        }
                    }
                });
            }
        } catch (e) {
            console.log("Error in createCloudAutoLoadAgent " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Check Cloud Auto Load Agent Creation Status
function checkCloudAutoLoadAgentCreationStatus(instanceID, region) {
    console.log("-----checkCloudAutoLoadAgentCreationStatus()------");
    return new Promise(function (callback, reject) {
        try {
            console.log("instanceID  :" + instanceID + " region :" + region);
            if ((instanceID) && (region)) {
                let query = { 'region': region };
                db.collection("LARegions").findOne(query, function (err, record) {
                    if (err) {
                        console.log("Error in checkCloudAutoLoadAgentCreationStatus : " + err);
                        reject(err);
                    } else {
                        console.log("record  :" + record);
                        //return res.status(200).json(record);
                        if (record.code) {
                            var awsServer = config.lambdaAWSServer,
                                regionCode = config.defaultRegionCode,
                                status = "";
                            regionCode = record.code;
                            var URL = "https://" + awsServer + "/EC2/getinstanceinfobyid?instanceID=" + instanceID + "&region=" + regionCode;
                            console.log(URL);
                            Request.get(URL, (error, response, body) => {
                                if (error) {
                                    console.error(error);
                                    reject({
                                        "error": error
                                    });
                                }
                                //console.log("----body----");
                                //console.log(body);
                                //console.log("instance state: "+body.message.instance.Reservations[0].Instances[0].State.Name);
                                //console.log("--------");
                                body = JSON.parse(body);
                                if (body.message.instance.Reservations[0].Instances[0].State.Name == "running") {
                                    var newLoadAgentData = {
                                        "loadAgentName": body.message.instance.Reservations[0].Instances[0].PublicDnsName,
                                        "hostName": body.message.instance.Reservations[0].Instances[0].PublicDnsName,
                                        "status": body.message.instance.Reservations[0].Instances[0].State.Name
                                    };

                                    var newvalues = { $set: newLoadAgentData };

                                    db.collection('LoadAgents').update({ 'instanceID': instanceID }, newvalues, function (err, record) {
                                        if (err) {
                                            reject(err);
                                        } else {
                                            console.log('Updated LoadAgents');
                                            callback({
                                                "status": body.message.instance.Reservations[0].Instances[0].State.Name,
                                                "PublicDnsName": body.message.instance.Reservations[0].Instances[0].PublicDnsName
                                            });
                                        }
                                    });
                                } else {
                                    callback({
                                        "status": body.message.instance.Reservations[0].Instances[0].State.Name,
                                        "PublicDnsName": ""
                                    });
                                }
                            });
                        }
                    }
                });
            }
        } catch (e) {
            console.log("Error in checkCloudAutoLoadAgentCreationStatus " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}


//Get LARegions Doc By Region
function getLARegionsDocByRegion(region) {
    console.log("-----getLARegionsDocByRegion()------");
    return new Promise(function (callback, reject) {
        try {
            if (region) {
                let query = { 'region': region };
                db.collection("LARegions").findOne(query, function (err, record) {
                    if (err) {
                        console.log(err);
                        reject({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    //console.log("record:"+record);
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in getLARegionsDocByRegion " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}


//check load agent status
function checkLoadAgentStatus(loadAgentHostName, port) {
    console.log("-----checkLoadAgentStatus()------");
    return new Promise(function (callback, reject) {
        try {
            if (loadAgentHostName) {
                let URL = "http://" + loadAgentHostName + ":" + port + "/ZantMeterServices/rest/checkagentstatus";
                console.log(URL);
                Request.get(URL, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        reject({
                            'status': 'ERROR',
                            'message': error
                        });

                    }
                    console.log(body);
                    callback(body);
                });

            }
        } catch (e) {
            console.log("Error in checkLoadAgentStatus " + e);
            reject({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}



//Getting loadAgentSync 
router.get('/getloadAgentSync', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getloadAgentSync------");

    let laID = req.query._id;
    if (laID === null || laID === undefined || laID === "" || validationRoute(laID)) {
        return res.status(404).json("Type is not specified or not valid");
    }

    let bsonlaID = mongodb.ObjectID(laID);
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    let bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 
    //console.log("customerId: " + customerID + " ,laID: " + laID);
    let port = req.query.port;
    if (validationRoute(port)) {
        return res.status(404).json("Port is not specified or not valid");
    }
    if ((port == undefined) || (port == null) || (port == "")) {
        port = 8080;
    }
    //await sleep(500);findOne({ "_id": bsonID }, { duration: 1 }, function (err, record) {
    db.collection("LoadAgents").findOne({ "_id": bsonlaID, "customerId": bsonCustomerID }, function (err, result) {
        if (err) {
            console.log("Error in getloadAgentSync  : " + err);
            return res.status(500).json({
                'status': 'ERROR',
                'message': err
            });
        } else {
            //console.log("Result  " + JSON.stringify(result));
            //await sleep(500);
            let loadAgentHostName = result.loadAgentName;
            //console.log("-----------" + loadAgentHostName + "-----------------");
            if (loadAgentHostName) {
                let URL = "http://" + loadAgentHostName + ":" + port + "/ZantMeterServices/rest/checkagentstatus";
                console.log(URL);
                Request.get(URL, (error, response, body) => {
                    if (error) {
                        console.log(error);
                        //{"errno":"ETIMEDOUT","code":"ETIMEDOUT","syscall":"connect","address":"13.127.190.192","port":8080}}
                        if ((error.code == "ETIMEDOUT") || (error.code == "ECONNREFUSED")) {
                            //await sleep(500);
                            newvalues = { $set: { "status": "OFFLINE" } };
                            db.collection('LoadAgents').update({ '_id': bsonlaID, "customerId": bsonCustomerID }, newvalues, function (err, records) {
                                if (err) {
                                    return res.status(500).json({
                                        'status': 'ERROR',
                                        'message': err
                                    });
                                } else {
                                    return res.status(200).json({
                                        status: 'Sync Success'
                                    })
                                }
                            });
                        }
                        /* { Error: connect ECONNREFUSED 127.0.0.1:8080
                            at TCPConnectWrap.afterConnect [as oncomplete] (net.js:1191:14)
                          errno: 'ECONNREFUSED',
                          code: 'ECONNREFUSED',
                          syscall: 'connect',
                          address: '127.0.0.1',
                          port: 8080 } */
                        /* res.status(500).json({
                            'status': 'ERROR',
                            'message': error
                        }); */
                    }
                    console.log(body);
                    if ((body != undefined) && (body != null) && (body != '')) {

                        //await sleep(500);
                        let laStatus = JSON.parse(body);
                        //callback(body);

                        if ((laStatus.status == "AVAILABLE" || laStatus.status == "BUSY" || laStatus.status == "OFFLINE")) {
                            //await sleep(500);
                            newvalues = { $set: laStatus };

                            db.collection('LoadAgents').update({ '_id': bsonlaID, "customerId": bsonCustomerID }, newvalues, function (err, records) {
                                if (err) {
                                    return res.status(500).json({
                                        'status': 'ERROR',
                                        'message': err
                                    });
                                } else {
                                    return res.status(200).json({
                                        status: 'Sync Success'
                                    })
                                }
                            });
                        }
                    }/* else if((error == undefined) && (error == null) && (error == '')){
                        return res.status(404).json({
                            'status': 'ERROR',
                            'message': 'Load agent status not accessible'
                        });
                    } */
                });
            }
            //return res.status(200).json(result); 
        }
    });

});//end of //Getting loadAgentSync





//This service will be called from angular, to create the specific cloud load agent
router.get('/destoryCloudLoadAgent', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----destoryCloudLoadAgent------");
    let loadAgentName = req.query.loadAgentName;
    try {

        if (loadAgentName === null || loadAgentName === undefined || loadAgentName === "" || validationRoute(loadAgentName)) {
            return res.status(404).json("Load Agent is not specified or not valid");
        }

        let customerID = req.decoded.customerID;
        if (customerID === null || customerID === undefined || customerID === "") {
            return res.status(404).json("Token is not valid");
        }
        let bsonCustomerID = mongodb.ObjectID(customerID);
        //"customerId": bsonCustomerID 

        if (loadAgentName) {
            let query = { 'loadAgentName': loadAgentName, 'customerId': bsonCustomerID };
            db.collection("LoadAgents").findOne(query, async function (err, record) {
                if (err) {
                    console.log("Error in getLARegions : " + err);
                    return res.status(500).json(err);
                } else {
                    console.log("record  " + record);
                    //return res.status(200).json(record);
                    if ((record.instanceID) && (record.region)) {
                        const getLARegionDocResponse = await getLARegionDocByRegion(record.region);
                        if (getLARegionDocResponse.status == 'SUCCESS') {
                            var LARegionDoc = getLARegionDocResponse.message;
                            var regionCode = config.defaultRegionCode;//"ap-south-1";;
                            if (LARegionDoc === null || LARegionDoc === undefined || LARegionDoc === "") {
                                regionCode = record.region;
                            } else {
                                regionCode = LARegionDoc.code;
                            }
                            const terminateLoadAgentResponse = await terminateLoadAgent(record.instanceID, regionCode);

                            if (terminateLoadAgentResponse.status == 'TERMINATED') {
                                const deleteLoadAgentResponse = await deleteLoadAgentDoc(record._id);
                            }
                            return res.status(200).json({ "status": "Success" });
                        } else {
                            console.error(getLARegionDocResponse);
                            return res.status(500).json({ "status": "ERROR" });
                        }
                    }
                }
            });
        }
    } catch (e) {
        console.log("Error in destoryCloudLoadAgent " + e);
        return res.status(500).json({
            "status": "ERROR",
            "error": e
        });

    }


});//end of destory cloud load agent



//Get MachinesNames For ID
router.get('/getMachinesNamesForID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getMachinesNamesForID------");
    var testrunnid = req.query.testrunid;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let hosts = [];
            if (records.hasOwnProperty("systemMonitor")) {
                if ((records.systemMonitor.enabled) && (records.systemMonitor.hasOwnProperty("machines"))) {
                    /* let machines = records.systemMonitor.machines;
                    machines.forEach((obj) => {
                        hosts.push(obj.machineName);
                    }); */
                    hosts = records.systemMonitor.machines;
                }
            }
            return res.status(200).json(hosts);
        }
    });
});//end of //getMachinesNamesForID




//Get Specific Response Time Samples For ID
router.get('/getSpecificResponseTimeSamplesForID', async function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getSpecificResponseTimeSamplesForID------");
    var testrunnid = req.query.testrunid;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    /* let fromDateTime = req.query.fromDateTime;
    if (fromDateTime === null || fromDateTime === undefined || fromDateTime === "" || validationRoute(fromDateTime)) {
        return res.status(404).json("From Date Time is not specified or not valid");
    } */
    let toDateTime = req.query.toDateTime;
    if (toDateTime === null || toDateTime === undefined || toDateTime === "" || validationRoute(toDateTime)) {
        return res.status(404).json("To Date Time is not specified or not valid");
    }

    let transactionName = req.query.transactionName;
    if (transactionName === null || transactionName === undefined || transactionName === "") {
        return res.status(404).json("Transaction Name is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);
    // console.log(fromDateTime +" "+1568183344000);
    // console.log(typeof(fromDateTime) +" "+typeof(1568183344000));
    // console.log(toDateTime);

    let duration = await getTestRunDuration(testrunnid);

    let aggregationInterval = getAggregationIntervalByDuration(duration, 0);

    /* db.collection('TestRuns').findOne({ "_id": bsonID }, { projection: { 'testResult.influxRawData.Transactions': true } }, function (err, record) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let data = new Array();
            if (record.hasOwnProperty("testResult")) {
                if (record.testResult.hasOwnProperty("influxRawData")) {
                    if (record.testResult.influxRawData.hasOwnProperty("Transactions")) {
                        data = data.concat(record.testResult.influxRawData.Transactions);
                        // let fromDate = new Date(1568183344000),toDate = new Date(1568183348000);
                        let fromDate = new Date(new Number(fromDateTime)), toDate = new Date(new Number(toDateTime));
                        data.forEach((obj) => {
                            obj.time = new Date(obj.time);
                        });
                        data = data.filter((item) => {
                            return ((item.time.getTime() >= fromDate.getTime()) && (item.time.getTime() <= toDate.getTime()));
                        });
                    }
                }
            }
            return res.status(200).json(data);
        }
    }); */
    let datetime = new Date(new Number(toDateTime));
    // console.log("before : " + new Date(datetime.getTime()));

    // datetime.setSeconds(datetime.getSeconds() - aggregationInterval + 1 );
    datetime.setSeconds(datetime.getSeconds() - aggregationInterval);
    // console.log("after -"+aggregationInterval+"s : " + new Date(datetime.getTime()));
    let fromDateTime = datetime.getTime();
    toDateTime = new Date(new Number(toDateTime));
    toDateTime.setSeconds(toDateTime.getSeconds() + 1);
    toDateTime.setMilliseconds(toDateTime.getMilliseconds() + 500);
    toDateTime = toDateTime.getTime();

    let responseData;
    responseData = await getSpecificResponseTimeSamples(bsonID, fromDateTime, toDateTime, transactionName);
    if (responseData instanceof Array) {
        return res.status(200).json(responseData);
        /* if (responseData.length > 0) {
            return res.status(200).json(responseData);
        }
        fromDateTime = new Date(new Number(fromDateTime));
        fromDateTime.setSeconds(fromDateTime.getSeconds() - aggregationInterval - aggregationInterval);
        fromDateTime = fromDateTime.getTime();

        toDateTime = new Date(new Number(toDateTime));
        toDateTime.setSeconds(toDateTime.getSeconds() + aggregationInterval + aggregationInterval);
        toDateTime = toDateTime.getTime();

        let responseData2;
        responseData2 = await getSpecificResponseTimeSamples(bsonID, fromDateTime, toDateTime, transactionName);

        if (responseData2 instanceof Array) {
            return res.status(200).json(responseData);
        } else {
            return res.status(500).json(responseData);
        } */
    } else {
        return res.status(500).json(responseData);
    }
});//end of //getSpecificResponseTimeSamplesForID


function getSpecificResponseTimeSamples(bsonID, fromDateTime, toDateTime, transactionName) {
    return new Promise(function (callback, reject) {
        console.log("-----getSpecificResponseTimeSamples------");
        db.collection('TestRuns').findOne({ "_id": bsonID }, { projection: { 'testResult.influxRawData.Transactions': true } }, function (err, record) {
            if (err) {
                reject(err);
            } else {
                let data = new Array();
                if (record.hasOwnProperty("testResult")) {
                    if (record.testResult.hasOwnProperty("influxRawData")) {
                        if (record.testResult.influxRawData.hasOwnProperty("Transactions")) {
                            data = data.concat(record.testResult.influxRawData.Transactions);
                            // let fromDate = new Date(1568183344000),toDate = new Date(1568183348000);
                            /* console.log("toDateTime 1-toDateTime: "+toDateTime);
                            console.log("toDateTime 2-new Date(new Number(toDateTime)): "+new Date(new Number(toDateTime)));
                            console.log("toDateTime 3-Date.parse(toDateTime): "+Date.parse(toDateTime));
                            console.log("toDateTime 4-Date.parse(toDateTime)/1000: "+Date.parse(toDateTime)/1000); */
                            let fromDate = new Date(new Number(fromDateTime)), toDate = new Date(new Number(toDateTime));
                            /* console.log("fromDate: " + fromDate + " : " + fromDate.getTime());
                            console.log("toDate: " + toDate + " : " + toDate.getTime()); */
                            data.forEach((obj) => {
                                obj.time = new Date(obj.time);
                            });
                            data = data.filter((item) => {
                                let cDate = new Date(new Number(item.time.getTime()));
                                /* if (item.TransactionName == transactionName) {
                                    console.log("cDate: " + cDate + " : " + cDate.getTime());
                                } */
                                // return ((item.time.getTime() >= fromDate.getTime()) && (item.time.getTime() <= toDate.getTime()) && (item.TransactionName == transactionName));
                                return ((cDate.getTime() >= fromDate.getTime()) && (cDate.getTime() <= toDate.getTime()) && (item.TransactionName == transactionName));
                            });
                        }
                    }
                }
                callback(data);
            }
        });
    });
}


//Get Specific Response Time Breakdown For ID
router.get('/getSpecificResponseTimeBreakdownForID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getSpecificResponseTimeBreakdownForID------");
    var testrunnid = req.query.testrunid;
    if (testrunnid === null || testrunnid === undefined || testrunnid === "" || validationRoute(testrunnid)) {
        return res.status(404).json("Test Run ID is not specified or not valid");
    }
    let TransactionID = req.query.transactionID;
    if (TransactionID === null || TransactionID === undefined || TransactionID === "") {
        return res.status(404).json("Transaction ID is not specified or not valid");
    }
    var bsonID = mongodb.ObjectID(testrunnid);

    db.collection('TestRuns').findOne({ "_id": bsonID }, { projection: { 'testResult.influxRawData.TransactionsSubResults': true } }, function (err, record) {
        if (err) {
            return res.status(500).json(err);
        } else {
            let data = new Array();
            if (record.hasOwnProperty("testResult")) {
                if (record.testResult.hasOwnProperty("influxRawData")) {
                    if (record.testResult.influxRawData.hasOwnProperty("TransactionsSubResults")) {
                        data = data.concat(record.testResult.influxRawData.TransactionsSubResults);
                        data = data.filter((item) => {
                            if (item.hasOwnProperty("TransactionID")) {
                                return (item.TransactionID == TransactionID);
                            }
                        });
                    }
                }
            }
            return res.status(200).json(data);
        }
    });
});//end of //getSpecificResponseTimeBreakdownForID

//Get Access Level
router.get('/getAccessLevelByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getAccessLevelByID------");
    var authorization = req.headers['authorization'];

    var token = '';
    if (typeof authorization !== 'undefined') {
        const bearer = authorization.split(' ');
        token = bearer[1];

        if (token === null || token === undefined || token === "")//|| validationRoute(token))
        {
            return res.status(404).json({ message: "Token is not specified or not valid" });
        }
    } else {
        //If header is undefined return Forbidden (403)
        return res.status(403).send({
            error: true,
            message: "Forbidden - No token found"
        });
    }
    var jwt = require('jsonwebtoken');

    var secretKey = config.bcryptSecretKey;
    jwt.verify(token, secretKey, function (err, decoded) {
        // console.log("decoded: "+JSON.stringify(decoded));
        if (err) { //failed verification.
            console.log(err.message);
            return res.status(403).send({
                error: true,
                message: "Forbidden - No token found"
            });
        }
        let user = decoded;
        var bsonID = mongodb.ObjectID(user.id);
        db.collection('users').findOne({ "_id": bsonID }, function (err, result) {
            if (err) {
                return res.status(500).json(err);
            } else {
                let accesslevel = result.accesslevel;
                if (accesslevel === null || accesslevel === undefined || accesslevel === "") {
                    accesslevel = 0;
                }
                let response = {
                    accesslevel: accesslevel,
                };
                return res.status(200).json(response);
            }
        });
    });
    /* 
  
    jwt.verify(token, secretKey, function (err, decoded) {
        // console.log("decoded: "+JSON.stringify(decoded));
        if (err) { //failed verification.
            console.log(err.message);
            return res.status(403).send({
                error: true,
                message: "Forbidden - No token found"
            });
        }
  
        req.decoded = decoded;
    });
    var bsonID = mongodb.ObjectID(testrunnid);
    db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, records) {
        if (err) {
            return res.status(500).json(err);
        } else {
            // let response = {
            //     scenarioName: records.scenarioName,
            //     status: records.status,
            //     testResult: records.testResult,
            // };
            return res.status(200).json(records);
        }
    }); */
});//end of //getAccessLevelByID


module.exports = router;
