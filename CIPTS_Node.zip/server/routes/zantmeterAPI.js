
var express = require('express');
var router = express.Router();
const Influx = require('influx');
var config = require('../configuration.json');
let validationRoute = require('./validation.js');

// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://' + config.influxDBUserName + ':' + config.influxDBPassword + '@' + config.influxDBHost + ':8086/zantmeter');
//const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
//Get test summary
router.get('/getTestSummaryForID', async function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getTestSummaryForID------");
  //await sleep(20000);
  var testrunid = req.query.testrunid;
  var starttime = new Date(req.query.starttime).getTime();
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  var sql = "select mean(\"ResponseTime\") as \"avg\", mean(\"Latency\") as \"latency\", sum(\"TransactionCount\") as \"totalcount\", sum(\"ErrorCount\") as \"errorcount\" from Transactions where RunID='" + testrunid + "' AND time>=" + starttime + " group by \"TransactionName\"";
  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});


//Get Vusers By Thread Groups data for given test run ids
router.get('/getVusersByThreadGroupsForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getVusersByThreadGroupsForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select \"time\", mean(\"ThreadCount\") as \"ThreadCount\" from ThreadGroupData where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s), ThreadGroupName fill(none)";
  } else {
    sql = "select \"time\", mean(\"ThreadCount\") as \"ThreadCount\" from ThreadGroupData where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s), ThreadGroupName fill(none)";
  }
  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});

//Get Response time data for given test run ids
router.get('/getResponseTimeForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getResponseTimeForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select \"time\", mean(\"ResponseTime\") as \"ResponseTime\" from Transactions where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s), TransactionName fill(none)";
  } else {
    sql = "select \"time\", mean(\"ResponseTime\") as \"ResponseTime\" from Transactions where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s), TransactionName fill(none)";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});

//Get ErrorCounts data for given test run ids
router.get('/getErrorCountsForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getErrorCountsForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select \"time\", (sum(\"ErrorCount\")/" + aggregationInterval + ") as \"ErrorCount\" from Transactions where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s), TransactionName fill(none)";
  } else {
    sql = "select \"time\", (sum(\"ErrorCount\")/" + aggregationInterval + ") as \"ErrorCount\" from Transactions where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s), TransactionName fill(none)";
  }
  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});

//Get Runniing VUsers data
router.get('/getRunningVUsersForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getRunningVUsersForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select time, (sum(ActiveVUsers)/" + aggregationInterval + ") as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s) fill(none)";
  } else {
    sql = "select time, (sum(ActiveVUsers)/" + aggregationInterval + ") as ActiveVUsers from VUsers where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s) fill(none)";
  }
  /* if (intervalRange == 0) {
    sql = "select time, mean(ActiveVUsers) as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s) fill(none)";
  } else {
    sql = "select time, mean(ActiveVUsers) as ActiveVUsers from VUsers where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s) fill(none)";
  } */
  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});


//Get Throughput bytes per second for given testrun id
router.get('/getThroughputBytesPerSecondForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getThroughputBytesPerSecondForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select time, (sum(ResponseSize)/" + aggregationInterval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s)  fill(none)";
  } else {
    sql = "select time, (sum(ResponseSize)/" + aggregationInterval + ") from ClientSideMetrics where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s)  fill(none)";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});


//Get Hits per second for given testrun id
router.get('/getHitsPerSecondForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getHitsPerSecondForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select time, (sum(Hits)/" + aggregationInterval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s)  fill(none)";
    // sql = "select time, (sum(Hits)/" + aggregationInterval + ") from RequestMetrics where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s)  fill(none)";
  } else {
    sql = "select time, (sum(Hits)/" + aggregationInterval + ") from ClientSideMetrics where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s)  fill(none)";
    // sql = "select time, (sum(Hits)/" + aggregationInterval + ") from RequestMetrics where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s)  fill(none)";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});


//Get System Monitoring for given testrun id
router.get('/getSystemMonitoringForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getSystemMonitoringForID------");

  var hostname = req.query.hostname;
  if (hostname === null || hostname === undefined || hostname === "") {
    return res.status(404).json("Host Name is not specified or not valid");
  }
  let sql = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total'";

  influx.query(sql)
    .then(cpu_data => {
      let sql2 = "select LAST(\"Processor_Queue_Length\") from win_system where host='" + hostname + "'";
      influx.query(sql2)
        .then(processor_data => {

          let responseData = {
            cpu_data: [{
              "name": hostname,
              "value": Math.floor(cpu_data[0].last)
            }],
            processor_data: [{
              "name": hostname,
              "value": Math.floor(processor_data[0].last)
            }],
            memory_data: [],
          };
          res.status(200).json(responseData);
        })
        .catch(error => res.status(500).json({ error }));
      //res.status(200).json(result)
    })
    .catch(error => res.status(500).json({ error }));
});

//Get System Monitoring for List of hostnames
router.post('/getSystemMonitoringForHostNames', async function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getSystemMonitoringForHostNames------");
  let reqbody = req.body;
  //console.log(JSON.stringify(reqbody));

  if (reqbody === null || reqbody === undefined || reqbody === "") {
    return res.status(404).json("Hostnames is not specified");
  }
  let hostNames = reqbody.hostnames;
  if (hostNames === null || hostNames === undefined || hostNames === "") {
    return res.status(404).json("Hostnames is not specified");
  }
  if (!(hostNames && typeof hostNames === 'object' && hostNames.constructor === Array)) {
    return res.status(404).json("Hostnames is not specified");
  }
  let cpu_data = [], processor_data = [], memory_data = [];
  for (let i = 0; i < hostNames.length; i++) {
    let CPUForHostName = await getCPUForHostName(hostNames[i]);
    let sample1 = {
      "name": hostNames[i],
      "value": (parseFloat(String(CPUForHostName[0].last)).toFixed(2))//Math.floor(CPUForHostName[0].last)
    };
    cpu_data.push(sample1);

    let ProcessorForHostName = await getProcessorForHostName(hostNames[i]);
    console.log(ProcessorForHostName[0].last);
    let sample2 = {
      "name": hostNames[i],
      "value": (parseFloat(String(ProcessorForHostName[0].last)).toFixed(2) * 100)//Math.floor(ProcessorForHostName[0].last)
    };
    processor_data.push(sample2);

    let AvailableRAMForHostName = await getAvailableRAMDataForHostName(hostNames[i]);
    let sample3 = {
      "name": hostNames[i],
      "value": (parseFloat(String(AvailableRAMForHostName[0].last)).toFixed(2))//Math.floor(AvailableRAMForHostName[0].last)
    };
    memory_data.push(sample3);

  }
  let responseData = {
    cpu_data: cpu_data,
    processor_data: processor_data,
    memory_data: memory_data,
  };
  res.status(200).json(responseData);

});//end of //getSystemMonitoringForHostNames

function getCPUForHostName(hostname) {
  return new Promise(function (callback, reject) {
    console.log("-----getCPUForHostName()------");
    // console.log(hostname);
    // var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total'";
    var CPUQuery = "select (100-LAST(\"usage\")) as \"last\" from cpu where host='" + hostname + "' and cpu= 'cpu-total'";
    influx.query(CPUQuery)
      .then((result) => {
        console.log("----------getCPUForHostName-----------")
        // console.log(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getProcessorForHostName(hostname) {
  return new Promise(function (callback, reject) {
    console.log("-----getProcessorForHostName()------");
    // console.log(hostname);
    // var ProcessorQuery = "select LAST(\"Processor_Queue_Length\") from win_system where host='" + hostname + "'";
    var ProcessorQuery = "select LAST(\"Processor_Queue_Length\") as \"last\" from system where host='" + hostname + "'";
    influx.query(ProcessorQuery)
      .then((result) => {
        console.log("----------getProcessorForHostName-----------")
        // console.log(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getAvailableRAMDataForHostName(hostname) {
  return new Promise(function (callback, reject) {
    console.log("-----getAvailableRAMDataForHostName()------");
    // console.log(hostname);
    // var AvailableRAMQuery = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "'";
    var AvailableRAMQuery = "select ((LAST(\"available\")/1024)/1024) as \"last\" from mem where host='" + hostname + "'";
    influx.query(AvailableRAMQuery)
      .then((result) => {
        console.log("----------getAvailableRAMDataForHostName-----------")
        // console.log(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

//Get Status Codes Counts
router.get('/getStatusCodesCountsForID', async function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getStatusCodesCountsForID------");
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select count(RunID) as \"count\" from RequestMetrics where RunID='" + testrunid + "' group by HTTPStatusCode";
  } else {
    sql = "select count(RunID) as \"count\" from RequestMetrics where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by HTTPStatusCode";
  }

  let responseData = await getStatusCodesCount(sql);

  res.status(200).json(responseData);

});//end of //get Status Codes Counts

function getStatusCodesCount(RequestMetricsQuery) {
  return new Promise(function (callback, reject) {
    console.log("-----getStatusCodesCount()------");
    //console.log(RunID);
    //var RequestMetricsQuery = "select count(RunID) as \"count\" from RequestMetrics where RunID='"+RunID+"' group by HTTPStatusCode;";
    influx.query(RequestMetricsQuery)
      .then((result) => {
        console.log("----------getStatusCodesCount-----------")
        //console.log(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}



//Get List of Status Codes for given test run ids
router.get('/getStatusCodesListForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getStatusCodesListForID------");

  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    //select time, HTTPStatusCode as statuscode, URL from RequestMetrics where RunID='5cd3c70acfba102ed8bbc709' order by desc limit 1;
    sql = "select \"time\", \"SamplerLabel\" as \"label\", \"HTTPStatusCode\" as \"statuscode\", URL from RequestMetrics where RunID='" + testrunid + "' and HTTPStatusCode!='200' and HTTPStatusCode!='302'";
  } else {
    sql = "select \"time\", \"SamplerLabel\" as \"label\", \"HTTPStatusCode\" as \"statuscode\", URL from RequestMetrics where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m  and HTTPStatusCode!='200' and HTTPStatusCode!='302'";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});

//Get AssertionFailureResults data for given test run ids
router.get('/getAssertionFailureResultsForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getAssertionFailureResultsForID------");

  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;

  if (intervalRange == 0) {
    //sql = "select \"time\", \"FailureMessage\" as \"message\", \"ResponseContent\" as \"content\" from AssertionResults where RunID='" + testrunid + "'";
    sql = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\" from AssertionResults where RunID='" + testrunid + "'";
  } else {
    sql = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\" from AssertionResults where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m ";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});


//Get AssertionFailureResultsContent data for given test run ids
router.post('/getAssertionFailureResultsContentForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getAssertionFailureResultsContentForID------");
  let reqbody = req.body;
  console.log(JSON.stringify(reqbody));
  var testrunid = reqbody.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }
  var label = reqbody.label;
  if (label === null || label === undefined || label === "") {
    return res.status(404).json("Label is not specified or not valid");
  }
  var timestamp = reqbody.timestamp;
  if (timestamp === null || timestamp === undefined || timestamp === "") {
    return res.status(404).json("Timestamp is not specified or not valid");
  }

  let sql;
  sql = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\", \"ResponseContent\" as \"content\" from AssertionResults where RunID='" + testrunid + "' and SamplerLabel='" + label + "' and time>='" + timestamp + "' and time<='" + timestamp + "'";
  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json(error));
});


//Get Latency data for given test run id
router.get('/getLatencyForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getLatencyForID------");
  var aggregationInterval = 1;
  if (req.query.aggregationInterval) {
    aggregationInterval = req.query.aggregationInterval;
  }
  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }

  let sql;
  if (intervalRange == 0) {
    sql = "select \"time\", mean(\"Latency\") as \"Latency\" from Transactions where RunID='" + testrunid + "' group by time(" + aggregationInterval + "s), TransactionName fill(none)";
  } else {
    sql = "select \"time\", mean(\"Latency\") as \"Latency\" from Transactions where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by time(" + aggregationInterval + "s), TransactionName fill(none)";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});




//Get Transactions Breakdown data for given test run id
router.get('/getTransactionsBreakdownForID', function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getTransactionsBreakdownForID------");

  var intervalRange = 0;
  if (req.query.intervalRange) {
    intervalRange = req.query.intervalRange;
  }
  var testrunid = req.query.testrunid;
  if (testrunid === null || testrunid === undefined || testrunid === "" || validationRoute(testrunid)) {
    return res.status(404).json("Test Run ID is not specified or not valid");
  }
  let sql;
  if (intervalRange == 0) {
    //select time, mean(ResponseSize) as ResponseSize, mean(ResponseTime) as ResponseTime, count(isSuccessful) as TotalRequests from TransactionsSubResults where RunID='5d6f89153dce4e2f7c93ea32' group by URL;
    sql = "select \"time\", mean(\"ResponseSize\") as \"ResponseSize\", mean(\"ResponseTime\") as \"ResponseTime\", count(\"isSuccessful\") as \"TotalRequests\" from TransactionsSubResults where RunID='" + testrunid + "' group by URL fill(none)";
  } else {
    sql = "select \"time\", mean(\"ResponseSize\") as \"ResponseSize\", mean(\"ResponseTime\") as \"ResponseTime\", count(\"isSuccessful\") as \"TotalRequests\" from TransactionsSubResults where RunID='" + testrunid + "' and time > now() - " + intervalRange + "m group by URL fill(none)";
  }

  influx.query(sql)
    .then(result => res.status(200).json(result))
    .catch(error => res.status(500).json({ error }));
});



//Get System Monitoring for List of hostnames
router.post('/getSystemMonitoringForHostNamesByTime', async function (req, res, next) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----getSystemMonitoringForHostNames------");

  let reqbody = req.body;
  //console.log(JSON.stringify(reqbody));

  if (reqbody === null || reqbody === undefined || reqbody === "") {
    return res.status(404).json("Hostnames is not specified");
  }
  let machines = reqbody.hostnames;
  if (machines === null || machines === undefined || machines === "") {
    return res.status(404).json("Hostnames is not specified");
  }
  if (!(machines && typeof machines === 'object' && machines.constructor === Array)) {
    return res.status(404).json("Hostnames is not specified");
  }

  let intervalRange = 0;
  if (reqbody.intervalRange) {
    intervalRange = reqbody.intervalRange;
  }
  var startTimestamp = reqbody.startTimestamp;
  if (startTimestamp === null || startTimestamp === undefined || startTimestamp === "") {
    return res.status(404).json("Timestamp is not specified");
  }
  let ProcessorSeries = [], CPUSeries = [], MemorySeries = [];
  for (var vi = 0; vi < machines.length; vi++) {

    try {
      // if (machines[vi].metrics.processor) {
      let ProcessorDataForHostName = [];
      ProcessorDataForHostName = await getProcessorDataForHostNameByTime(machines[vi].machineName, startTimestamp, intervalRange);
      // console.log(ProcessorDataForHostName);
      let ProcessorData = formatProcessorDataForHostNameByTime(machines[vi].machineName, ProcessorDataForHostName);
      ProcessorSeries.push(ProcessorData);
      // }
    } catch (ex) {
      console.log("-----getProcessorDataForHostNameByTime------" + ex);
    }
    try {
      // if (machines[vi].metrics.cpu) {
      let CPUDataForHostName = [];
      CPUDataForHostName = await getCPUForHostNameByTime(machines[vi].machineName, startTimestamp, intervalRange);

      let CPUData = formatCPUDataForHostNameByTime(machines[vi].machineName, CPUDataForHostName);
      CPUSeries.push(CPUData);
      // }
    } catch (ex) {
      console.log("-----getCPUForHostNameByTime------" + ex);
    }
    try {
      // if (machines[vi].metrics.memory) {
      let RAMDataForHostName = [];
      RAMDataForHostName = await getAvailableRAMDataForHostNameByTime(machines[vi].machineName, startTimestamp, intervalRange);

      let RAMData = formatAvailableRAMDataForHostNameByTime(machines[vi].machineName, RAMDataForHostName);
      MemorySeries.push(RAMData);
      // }
    } catch (ex) {
      console.log("-----getAvailableRAMDataForHostNameByTime------" + ex);
    }

  }
  let responseData = {
    cpu_data: CPUSeries,
    processor_data: ProcessorSeries,
    memory_data: MemorySeries,
  };
  res.status(200).json(responseData);

});//end of //getSystemMonitoringForHostNames

function getCPUForHostNameByTime(hostname, startTimestamp, intervalRange) {
  return new Promise(function (callback, reject) {
    console.log("-----getCPUForHostNameByTimeByTime()------");

    //var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total'";
    // var CPUQuery = "select \"time\", \"Percent_Processor_Time\", \"host\" from win_cpu where host='" + hostname + "' and instance='_Total' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    //var CPUQuery = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";

    let sql;
    if (intervalRange == 0) {
      sql = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > now() - 60m";
      // sql = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > '" + startTimestamp + "' and time > now() - 60m";
    } else {
      sql = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > now() - " + intervalRange + "m";
      // sql = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > '" + startTimestamp + "' and time > now() - " + intervalRange + "m";
    }
    // console.log(CPUQuery);
    //influx.query(CPUQuery)
    influx.query(sql)
      .then((result) => {
        console.log("----------getCPUForHostNameByTime-----------")
        //console.log(JSON.stringify(result));
        // return (result);
        callback(result);
      })
      .catch(error => {
        // return ([]);
        reject({ error });
      });
  });
}

function formatCPUDataForHostNameByTime(hostname, Data) {
  console.log("-----formatCPUDataForHostNameByTime()------");
  //console.log("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [];
    for (var vi = 0; vi < Data.length; vi++) {
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: Math.floor(parseFloat(String(Data[vi].usage))),
      };
      series.push(seriesVal);
    }

    let CPUData = { name: hostname, series: series, };
    return CPUData;
  } else {
    //console.log("formatCPUDataForHostNameByTime Data length:" + Data.length);
  }
}

function getProcessorDataForHostNameByTime(hostname, startTimestamp, intervalRange) {
  return new Promise(function (callback, reject) {
    console.log("-----getProcessorDataForHostNameByTime()------");
    //select LAST("Percent_Processor_Time") from win_cpu where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total';
    //"select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000
    //select * from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000
    //'2015-08-18T23:00:01.232000000Z'
    //select * from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total' and time => '2019-04-10T10:10:13.232000000Z' and time <= '2019-04-10T10:40:17.232000000Z' group by time(5s)
    //select "time", mean("Processor_Queue_Length") as "Processor_Queue_Length", "host" from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and time > '2019-04-10T10:10:13.232000000Z' and time < '2019-04-10T10:40:17.232000000Z' group by time(5s) fill(none)

    //var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000";
    //var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from win_system where host='" + hostname + "' and time > '2019-04-10T10:10:13.232000000Z' and time < '2019-04-10T10:40:17.232000000Z' group by time(5s) fill(none)";

    // var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from win_system where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    // var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";

    let sql;
    if (intervalRange == 0) {
      sql = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > now() - 60m";
      // sql = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > '" + startTimestamp + "' and time > now() - 60m";
    } else {
      sql = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > now() - " + intervalRange + "m";
      // sql = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > '" + startTimestamp + "' and time > now() - " + intervalRange + "m";
    }
    //influx.query(ProcessorQuery)
    influx.query(sql)
      .then((result) => {
        console.log("----------getProcessorDataForHostNameByTime-----------");
        // console.log(JSON.stringify(result));
        // return (result);
        callback(result);
      })
      .catch(error => {
        // return ([]);
        reject({ error });
      });
  });
}

function formatProcessorDataForHostNameByTime(hostname, Data) {
  console.log("-----formatProcessorDataForHostNameByTime()------");
  //console.log("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [];
    for (var vi = 0; vi < Data.length; vi++) {
      console.log(Data[vi].Processor_Queue_Length);
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: (parseFloat(String(Data[vi].Processor_Queue_Length)).toFixed(2) * 100),//Math.floor(Data[vi].Processor_Queue_Length),
      };
      series.push(seriesVal);
    }

    let ProcessorData = { name: hostname, series: series, };
    return ProcessorData;
  } else {
    //console.log("formatProcessorDataForHostNameByTime Data length:" + Data.length);
  }
}

function getAvailableRAMDataForHostNameByTime(hostname, startTimestamp, intervalRange) {
  return new Promise(function (callback, reject) {
    console.log("-----getAvailableRAMDataForHostNameByTime()------");

    //var AvailableRAMQuery = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";

    let sql;
    if (intervalRange == 0) {
      sql = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > now() - 60m";
      // sql = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > '" + startTimestamp + "' and time > now() - 60m";
    } else {
      sql = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > now() - " + intervalRange + "m";
      // sql = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > '" + startTimestamp + "' and time > now() - " + intervalRange + "m";
    }

    //influx.query(AvailableRAMQuery)
    influx.query(sql)
      .then((result) => {
        console.log("----------getAvailableRAMDataForHostNameByTime-----------");
        //console.log(JSON.stringify(result));
        // return (result);
        callback(result);
      })
      .catch(error => {
        // return ([]);
        reject({ error });
      });
  });
}

function formatAvailableRAMDataForHostNameByTime(hostname, Data) {
  console.log("-----formatAvailableRAMDataForHostNameByTime()------");
  //console.log("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [];
    for (var vi = 0; vi < Data.length; vi++) {
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: Math.floor(Data[vi].AvailableRAM),
      };
      series.push(seriesVal);
    }

    let AvailableRAMData = { name: hostname, series: series, };
    return AvailableRAMData;
  } else {
    //console.log("formatAvailableRAMDataForHostNameByTime Data length:" + Data.length);
  }
}


function customFormatDate(dateTBM) {
  //Logger("-----stopTGAPI/customFormatDate()------");
  var Mdate = '';
  if (dateTBM) {
    //Mdate = formatDate(dateTBM, 'MM-d-y HH:mm:ss', 'en-US');
    //Mdate = formatDate(dateTBM, 'HH:mm:ss', 'en-US');
    //new Date(dateTBM).getTime()
    Mdate = new Date(dateTBM).getTime();
  }
  return Mdate;
}

module.exports = router;