var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

let validationRoute = require('./validation.js');
var Request = require("request");

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('stopTGAPI.js : ERROR: DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('stopTGAPI.js : DB connection established using mongodb!');
    }
});

const Influx = require('influx');
// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://'+config.influxDBUserName+':'+config.influxDBPassword+'@' + config.influxDBHost + ':8086/zantmeter');

const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));

//stop Final Thread Group
router.get('/stopFinalThreadGroup', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----stopTGAPI/stopFinalThreadGroup------");
    let testID = req.query.testrunid;
    let threadgroupname = req.query.threadgroupname;

    if (typeof testID === "undefined" || testID == null || testID == "" || validationRoute(testID)) {
        console.log("Test Run ID not exists");
        return res.status(500).json({
            "error": 'Test Run ID is missing'
        });
    }

    if (typeof threadgroupname === "undefined" || threadgroupname == null || threadgroupname == "" || validationRoute(threadgroupname)) {
        console.log("Thread Group Name not exists");
        return res.status(500).json({
            "error": 'Thread Group Name is missing'
        });
    }

    var jsonResponseArray = [];
    try {
        jsonResponseArray = await stopFinalThreadGroup(testID, threadgroupname);
        return res.status(200).json(jsonResponseArray);
    } catch (e) {
        console.log("Error stopTGAPI/stopFinalThreadGroup " + e);
        return res.status(500).json({
            "error": e
        });
    }
});//end of stop Final Thread Group

//stopFinalThreadGroup
async function stopFinalThreadGroup(testRunID, threadgroupname) {
    console.log("-----stopTGAPI/stopFinalThreadGroup()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }

    if (!threadgroupname) {
        return ({ 'status': 'error', 'message': 'threadgroupname missing !' });
    }
    /* let min = 1000, max = 3000;
    let random = Math.floor(Math.random() * (max - min + 1)) + min;
    await sleep(random); */

    const testRunResponse = await getTestRunDoc(testRunID);

    /*  random = Math.floor(Math.random() * (max - min + 1)) + min;
     await sleep(random); */

    let responseMessage, updateTestRunDocResponse;
    //console.log("testRunResponse"+JSON.stringify(testRunResponse));
    if (testRunResponse.status == 'SUCCESS') {
        let testRunDoc = testRunResponse.message;

        var loadAgentNames = {};
        let TestRunOverallStatus = true;
        let LoadAgentResponse;
        let testRunDocStatus = testRunDoc.status;
        for (var i = 0; i < testRunDoc.testGroups.length; i++) {
            if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].testGroupName === threadgroupname)) {
                var loadAgent = testRunDoc.testGroups[i].loadAgent;
                if (loadAgent.type == "CloudAuto") {
                    //let query = { 'CloudAutoLA_ID': loadAgent.CloudAutoLA_ID.toString(), 'instanceID': loadAgent.instanceID.toString() };
                    LoadAgentResponse = await getLoadAgentDoc(String(loadAgent.CloudAutoLA_ID), String(loadAgent.instanceID));
                    if (LoadAgentResponse.status == 'SUCCESS') {
                        var LoadAgentDoc = LoadAgentResponse.message;
                        //console.log(JSON.stringify(LoadAgentDoc));
                        loadAgentNames[LoadAgentDoc.hostName] = { code: LoadAgentDoc.region, instanceID: LoadAgentDoc.instanceID, type: loadAgent.type, _id: LoadAgentDoc._id };
                    } else {
                        console.error(LoadAgentResponse);
                    }
                } else {
                    loadAgentNames[loadAgent.loadAgentName] = { type: loadAgent.type };
                }

                testRunDoc.testGroups[i].status = "Stopped";
                itemp = i;
                responseMessage = {
                    'testGroupName': threadgroupname,
                    'status': 'STOPPED'
                }
            } else if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].status === "Running")) {
                TestRunOverallStatus = false;
            }
        }
        /* if (testRunDoc.status === "Analysed") {
            TestRunOverallStatus = false;
        } */

        var loadAgents = Object.keys(loadAgentNames);
        console.log('Load agents length : ' + loadAgents.length);

        await sleep(500);

        //console.log('testRunDoc : ' + JSON.stringify(testRunDoc.testGroups[itemp]));
        console.log('testRunID : ' + testRunID);
        updateTestRunDocResponse = await updateTestRunDocument(testRunID, testRunDoc);

        await sleep(500);

        console.log('updateTestRunDocResponse : ' + JSON.stringify(updateTestRunDocResponse));
        console.log('threadgroupname : ' + threadgroupname + ', testRunDocStatus : ' + testRunDocStatus + ', TestRunOverallStatus : ' + TestRunOverallStatus);
        if (TestRunOverallStatus) {
            //if (testRunDocStatus == "Running") {
            updateTestRunDocResponse = await updateTestRunEnded(testRunDoc, testRunID);
            //console.log(updateTestRunEndedResponse.status);
            //}

            console.log('----Terminating Load agents----');
            for (var i = 0; i < loadAgents.length; i++) {
                if (loadAgentNames[loadAgents[i]].type == "CloudAuto") {
                    //console.log('Terminating Load agent : ' + loadAgents[i]);
                    var region = loadAgentNames[loadAgents[i]].code,
                        LoadAgentDocID = loadAgentNames[loadAgents[i]]._id,
                        instanceID = loadAgentNames[loadAgents[i]].instanceID;
                    if ((region) && (instanceID) && (LoadAgentDocID)) {
                        const getLARegionDocResponse = await getLARegionDocByRegion(region);
                        if (getLARegionDocResponse.status == 'SUCCESS') {
                            var LARegionDoc = getLARegionDocResponse.message;
                            var regionCode = config.defaultRegionCode;//"ap-south-1";;
                            if (LARegionDoc === null || LARegionDoc === undefined || LARegionDoc === "") {
                                regionCode = region;
                            } else {
                                regionCode = LARegionDoc.code;
                            }
                            const terminateLoadAgentResponse = await terminateLoadAgent(instanceID, regionCode);

                            if (terminateLoadAgentResponse.status == 'TERMINATED') {
                                var LoadAgentDoc = LoadAgentResponse.message;
                                const deleteLoadAgentResponse = await deleteLoadAgentDoc(LoadAgentDocID);
                            }
                            //console.log(terminateLoadAgentResponse);
                        } else {
                            console.error(LoadAgentResponse);
                        }
                    }
                }
            }
            //analyse test run

            var aggregationInterval = 1;
            try {
                //if (testRunDocStatus !== "Analysed") {
                await sleep(500);
                updateTestRunDocResponse = await analyzeTestRun(testRunID, aggregationInterval);
                //}
            } catch (e) {
                console.log("Error stopTGAPI/analyzeTestRun " + e);
                updateTestRunDocResponse = {
                    "error": e
                };
            }

        }

        if (TestRunOverallStatus) {//((TestRunOverallStatus) && (testRunDocStatus !== "Analysed")) {
            return updateTestRunDocResponse;
        } else {
            return responseMessage;
        }
    } else {
        console.error(testRunResponse);
        return ({ 'status': 'error', 'message': 'testRunID is wrong !' });
    }
}

//Get Test Run Document
function getTestRunDoc(testRunID) {
    console.log("-----stopTGAPI/getTestRunDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if (testRunID) {
                //console.log("testRunID:" + testRunID);
                var bsonID = mongodb.ObjectID(testRunID);
                db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    //console.log("record:"+record);
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in stopTGAPI/getTestRunDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Get Load Agent Document
function getLoadAgentDoc(CloudAutoLA_ID, instanceID) {
    console.log("-----stopTGAPI/getLoadAgentDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if ((CloudAutoLA_ID) && (instanceID)) {
                let query = { 'CloudAutoLA_ID': parseInt(CloudAutoLA_ID), 'instanceID': String(instanceID) };
                db.collection("LoadAgents").findOne(query, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    console.log(record);
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in stopTGAPI/getLoadAgentDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Update Test Run Document
function updateTestRunDocument(testRunID, values) {
    console.log("-----stopTGAPI/updateTestRunDocument()------");
    try {
        if ((typeof testRunID === "undefined" || testRunID == null || testRunID == "") || (typeof values === "undefined" || values == null || values == "")) {
            console.log("Test Run ID not exists");
            return ({
                'status': 'ERROR',
                'message': 'test run id or values are missing'
            });
        }

        let newval = { $set: values }
        let bsonID = mongodb.ObjectID(testRunID);
        return new Promise(function (callback, reject) {
            db.collection("TestRuns").update({ "_id": bsonID }, newval, function (err, result) {

                //db.collection("TestRuns").findAndModify({ "_id": bsonID }, newval, function (err, result) {
                if (err) {
                    console.log(err);
                    reject({
                        'status': 'ERROR',
                        'message': err
                    });
                } else {
                    //console.log("record: " + result);
                    callback({
                        'status': 'SUCCESS',
                        'message': result
                    });
                }
            });
        });
    } catch (e) {
        console.log("Error in stopTGAPI/updateTestRunDocument " + e);
        return ({
            'status': 'ERROR',
            'message': e
        });
    }
}

//Update TestRun Status as Ended
function updateTestRunEnded(record, testRunID) {
    console.log("-----stopTGAPI/updateTestRunEnded()------");
    return new Promise(function (callback, reject) {
        try {
            if (testRunID) {
                var nowDate = new Date();
                var endDate = nowDate.toISOString();
                var duration = new Date(endDate) - new Date(record.startTime);
                let status = {
                    status: "Ended",
                    endTime: endDate,
                    duration: duration
                };

                var newval = { $set: status }
                var bsonID = mongodb.ObjectID(testRunID);
                db.collection("TestRuns").update({ "_id": bsonID }, newval, function (err, result) {
                    if (err) {
                        console.log("Error in stopTGAPI/updateTestRuns : " + err);
                        callback({
                            'status': 'error',
                            'message': err
                        });
                    }
                    callback({
                        'status': 'updated',
                        'message': result
                    });
                });
            }
        } catch (e) {
            console.log("Error in stopTGAPI/updateTestRunEnded " + e);
            return e;
        }
    });
}

//Get LARegion ByRegion Document
function getLARegionDocByRegion(region) {
    console.log("-----stopTGAPI/getLARegionDocByRegion()------");
    return new Promise(function (callback, reject) {
        try {
            if (region) {
                let query = { 'region': region };
                db.collection("LARegions").findOne(query, function (err, record) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    }
                    callback({
                        'status': 'SUCCESS',
                        'message': record
                    });
                });
            }
        } catch (e) {
            console.log("Error in stopTGAPI/getLARegionDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Terminate Load Agent
function terminateLoadAgent(instanceID, regionCode) {
    console.log("-----stopTGAPI/terminateLoadAgent()------");
    return new Promise(function (callback, reject) {
        try {
            if ((instanceID) && (regionCode)) {
                var awsServer = config.lambdaAWSServer;
                var URL = "https://" + awsServer + "/EC2/terminateec2?instanceID=" + instanceID + "&region=" + regionCode;
                //console.log(URL);
                Request.get(URL, (error, response, body) => {
                    if (error) {
                        console.error(error);
                        callback({
                            'status': 'ERROR',
                            'message': error
                        });
                    }
                    console.log(body);
                    callback({
                        'status': 'TERMINATED',
                        'message': body
                    });
                });
            }
        } catch (e) {
            console.log("Error in stopTGAPI/terminateLoadAgent " + e);
            callback({
                'loadagentname': hostName,
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

//Delete Load Agent Document
function deleteLoadAgentDoc(loadAgentid) {
    console.log("-----stopTGAPI/deleteLoadAgentDoc()------");
    return new Promise(function (callback, reject) {
        try {
            if (loadAgentid) {
                var bsonID = mongodb.ObjectID(loadAgentid);
                db.collection('LoadAgents').deleteOne({ "_id": bsonID }, function (err, records) {
                    if (err) {
                        console.log(err);
                        callback({
                            'status': 'ERROR',
                            'message': err
                        });
                    } else {
                        callback({
                            'status': 'SUCCESS',
                            'message': 'Deleted Load Agent'
                        });
                    }
                });
            }
        } catch (e) {
            console.log("Error in stopTGAPI/deleteLoadAgentDoc " + e);
            callback({
                'status': 'ERROR',
                'message': e
            });
        }
    });
}

async function analyzeTestRun(testRunID, aggregationInterval) {

    console.log("-----stopTGAPI/analyzeTestRun()------");
    //await 
    if (!testRunID) {
        return ({ 'status': 'error', 'message': 'testRunID missing !' });
    }
    let duration = 0;
    let setStatusTestRun = null;



    setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
    //console.log(setStatusTestRun.result);
    let counter = 0;
    while (duration == null || duration == 0) {
        if (counter > 3) {
            break;
        }
        await sleep(1000);
        counter++;
        if (setStatusTestRun.result.nModified != 1) {
            setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
            //console.log(setStatusTestRun.result);
        }
        duration = await getTestRunDuration(testRunID);
        console.log(duration);
    }

    aggregationInterval = getAggregationIntervalByDuration(duration, aggregationInterval);

    await sleep(1000);
    let summary = await getSummary(testRunID);

    await sleep(1000);
    let transactions = await getTransactionsForID(testRunID, aggregationInterval);

    await sleep(1000);
    let responseTime = await getResponseTimeForID(testRunID, aggregationInterval);

    await sleep(1000);
    let vUsers = await getRunningVUsersForID(testRunID, aggregationInterval);

    await sleep(1000);
    let vUsersByThreadGroups = await getVUsersByThreadGroupsForID(testRunID, aggregationInterval);

    await sleep(1000);
    let throughput = await getThroughputBytesPerSecondForID(testRunID, aggregationInterval);

    await sleep(1000);
    let hits = await getHitsPerSecondForID(testRunID, aggregationInterval);

    await sleep(1000);
    let error = await getErrorCountsForID(testRunID, aggregationInterval);

    let observations = "";

    if (duration > 300000) {
        //observations = await getObservations(testRunID, aggregationInterval);//commenting R code
    }

    await sleep(1000);
    let summaryObservation = [], transactionsObservation = [], responseTimeObservation = [], vUsersObservation = [], throughputObservation = [], hitsObservation = [], errorObservation = [], vUsersByThreadGroupsObservation = [];

    if (observations !== null && observations !== undefined && observations !== "") {

        let responseObservations = JSON.parse(observations);
        //console.log(responseObservations.msg);
    responseObservations = null;//commenting R code
        responseObservations = responseObservations.msg;
        if (responseObservations !== null && responseObservations !== undefined && responseObservations !== "") {
            for (let i = 0; i < responseObservations.length; i++) {
                switch (responseObservations[i].type) {
                    case "Transactions": {
                        transactionsObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Response Time": {
                        responseTimeObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "VUsers": {
                        vUsersObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Throughput": {
                        throughputObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Hits Per Second": {
                        hitsObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "Error": {
                        errorObservation.push(responseObservations[i].observation);
                        break;
                    }
                    case "vUsersByThreadGroups": {
                        vUsersByThreadGroupsObservation.push(responseObservations[i].observation);
                        break;
                    }
                }
            }
        }
    }

    //console.log(JSON.stringify(formatResponseTimeData(responseTime)));
    let summaryData = formatSummaryData(summary),
        VUsersData = formatVUsersData(vUsers);
    let panelSummaryData = formatPanelSummaryData(summaryData, VUsersData, duration);

    let testResult = {
        panelsummary: {
            data: panelSummaryData.panelSummary,
        },
        errorsPerTranscationData: {
            data: panelSummaryData.errorsPerTranscationData,
        },
        stackedbarchartdata: {
            data: panelSummaryData.stackedbarchartdata,
        },
        summary: {
            data: summaryData,
            observations: summaryObservation
        },
        transactions: {
            rawData: transactions,
            data: formatTransactionsData(transactions),
            observations: transactionsObservation
        },
        responseTime: {
            rawData: responseTime,
            data: formatResponseTimeData(responseTime),
            observations: responseTimeObservation
        },
        vUsers: {
            rawData: vUsers,
            data: formatVUsersData(vUsers),
            observations: vUsersObservation
        },
        vUsersByThreadGroups: {
            rawData: vUsersByThreadGroups,
            data: formatVUsersByThreadGroupsData(vUsersByThreadGroups),
            observations: vUsersByThreadGroupsObservation
        },
        throughput: {
            rawData: throughput,
            data: formatThroughputData(throughput),
            observations: throughputObservation
        },
        hits: {
            rawData: hits,
            data: formatHitsPerSecondData(hits),
            observations: hitsObservation
        },
        error: {
            rawData: error,
            data: formatErrorCountsData(error),
            observations: errorObservation
        },
        observations: observations
    };

    await sleep(1000);
    let updateTestRun = await updateAnalysedTestRunDoc(testRunID, testResult);

    await sleep(1000);
    return updateTestRun;

}

function getAggregationIntervalByDuration(duration, interval) {
    console.log("-----stopTGAPI/getAggregationIntervalByDuration()------");
    let aggregationInterval = 1;
    if ((interval != undefined) && (interval != null) && (interval > 0)) {
        aggregationInterval = interval;
    }
    if ((duration != undefined) && (duration != null)) {
        switch (true) {
            case (duration < 300000): {
                aggregationInterval = 1;
                break;
            }
            case ((duration >= 300000) && (duration < 600000)): {
                aggregationInterval = 2;
                break;
            }
            case ((duration >= 600000) && (duration < 1800000)): {
                aggregationInterval = 5;
                break;
            }
            case ((duration >= 1800000) && (duration < 3600000)): {
                aggregationInterval = 10;
                break;
            }
            case ((duration >= 3600000) && (duration < 7200000)): {
                aggregationInterval = 15;
                break;
            }
            case ((duration >= 7200000) && (duration < 14400000)): {
                aggregationInterval = 30;
                break;
            }
            case ((duration >= 14400000)): {
                aggregationInterval = 60;
                break;
            }
        }
    }

    return aggregationInterval;
}

function formatPanelSummaryData(summaryData, VUsersData, duration) {
    console.log("-----stopTGAPI/formatPanelSummaryData()------");
    let errorsPerTranscationData = new Array(), stackedbarchartdata = [];
    let panelSummary = [
        { title: "Transactions", value: 0 },
        { title: "Duration", value: "00:00:00" },
        { title: "Max VUsers", value: 0 },
        { title: "Errors", value: 0 }
    ];

    let errorcounts = 0;
    for (let v = 0; v < summaryData.length; v++) {
        errorcounts = errorcounts + summaryData[v].errorcount;
    }
    panelSummary[3].value = errorcounts;

    summaryData.forEach((obj) => {
        obj._90percent = parseFloat(String((obj.passcount / obj.totalcount) * 90)).toFixed(2);
        obj.error = parseFloat(String((obj.errorcount / obj.totalcount) * 100)).toFixed(1);
        errorsPerTranscationData.push({ name: obj.TransactionName, value: parseFloat(String((obj.errorcount / errorcounts) * 100)).toFixed(2) });
        let series = [];
        series.push({
            "name": "Response Time",
            "value": parseFloat(String(obj.avg)).toFixed(0)
        });
        /* series.push({
            "name": "Pass",
            "value": obj.passcount
        });
        series.push({
            "name": "Fail",
            "value": obj.errorcount
        }); */
        stackedbarchartdata.push({
            "name": obj.TransactionName,
            "series": series,
        });
    });

    let stackedbarchartdata1 = stackedbarchartdata.sort((obj1, obj2) => {
        return obj2.series[0].value - obj1.series[0].value;
    });

    if (stackedbarchartdata1.length > 5) {
        stackedbarchartdata = stackedbarchartdata1.splice(0, 5);
    }

    panelSummary[0].value = summaryData.length;
    panelSummary[1].value = getHHmmssFromMilliseconds(duration);
    let values = [];
    if (VUsersData[0].series.length > 0) {
        for (var vi = 0; vi < VUsersData[0].series.length; vi++) {
            values.push(VUsersData[0].series[vi].value);
        }
    }

    let maxVUsers = Math.max(...values);
    panelSummary[2].value = maxVUsers;

    let formatPanelSummaryData = {
        panelSummary: panelSummary,
        errorsPerTranscationData: errorsPerTranscationData,
        stackedbarchartdata: stackedbarchartdata
    };

    return formatPanelSummaryData;
}

function getHHmmssFromMilliseconds(ms) {
    let date = new Date(null);
    var timeOffsetInMS = date.getTimezoneOffset() * 60000;
    ms = ms + timeOffsetInMS;
    date.setMilliseconds(ms);
    let result = date.toTimeString().substr(0, 8);
    //console.log(result);
    return result;
}

function getSummary(testrunid) {
    console.log("-----stopTGAPI/getSummary()------");
    return new Promise(function (callback, reject) {
        var summaryQuery = "select mean(\"ResponseTime\") as \"avg\", sum(\"TransactionCount\") as \"totalcount\", sum(\"ErrorCount\") as \"errorcount\", percentile(\"ResponseTime\", 90) as percentile from Transactions where RunID='" + testrunid + "' group by \"TransactionName\"";
        influx.query(summaryQuery)
            .then(result => {
                console.log("----------stopTGAPI/getTestSummary-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => {
                reject(error);
            });
    });
}

function formatSummaryData(Data) {
    console.log("-----stopTGAPI/formatSummaryData()------");
    Data.forEach((obj) => {
        obj.passcount = obj.totalcount - obj.errorcount;
    });
    return Data;
}

function getTransactionsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getTransactionsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var transactionsQuery = "select \"time\", (sum(\"TransactionCount\")/" + interval + ") as \"totalcount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

        influx.query(transactionsQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getTransactionsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatTransactionsData(Data) {
    console.log("-----stopTGAPI/formatTransactionsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].totalcount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatTransactionsData Data length:" + Data.length);
    }
}

function getResponseTimeForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getResponseTimeForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var responseTimeQuery = "select \"time\", mean(\"ResponseTime\") as \"ResponseTime\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getResponseTimeForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatResponseTimeData(Data) {
    console.log("-----stopTGAPI/formatResponseTimeData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].ResponseTime,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatResponseTimeData Data length:" + Data.length);
    }
}

function customFormatDate(dateTBM) {
    //console.log("-----stopTGAPI/customFormatDate()------");
    var Mdate = '';
    if (dateTBM) {
        //Mdate = formatDate(dateTBM, 'MM-d-y HH:mm:ss', 'en-US');
        //Mdate = formatDate(dateTBM, 'HH:mm:ss', 'en-US');
        //new Date(dateTBM).getTime()
        Mdate = new Date(dateTBM).getTime();
    }
    return Mdate;
}

function parseNumber(value) {
    return parseFloat(value);
}


function getVUsersByThreadGroupsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getVUsersByThreadGroupsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var VUsersForIDByThreadGroupsQuery = "select \"time\", mean(\"ThreadCount\") as \"ThreadCount\" from ThreadGroupData where RunID='" + testrunid + "' group by time(" + interval + "s), ThreadGroupName fill(none)";

        influx.query(VUsersForIDByThreadGroupsQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getVUsersByThreadGroupsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatVUsersByThreadGroupsData(Data) {
    console.log("-----stopTGAPI/formatVUsersByThreadGroupsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            if (obj.ThreadGroupName != '') {
                groupByName[obj.ThreadGroupName] = groupByName[obj.ThreadGroupName] || [];
                groupByName[obj.ThreadGroupName].push(obj);
            }
        });
        //console.log(JSON.stringify(groupByName));
        let ThreadGroupNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < ThreadGroupNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[ThreadGroupNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[ThreadGroupNames[iName]][vi].time),
                    value: groupByName[ThreadGroupNames[iName]][vi].ThreadCount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: ThreadGroupNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatVUsersForIDByThreadGroupsData Data length:" + Data.length);
    }
}

function getRunningVUsersForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getRunningVUsersForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var vUsersQuery = "select time, (sum(ActiveVUsers)/" + interval + ") as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + interval + "s) fill(none)";
        influx.query(vUsersQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getRunningVUsersForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatVUsersData(runningVUsersData) {
    console.log("-----stopTGAPI/formatVUsersData()------");
    //console.log("runningVUsersData length:"+runningVUsersData.length);
    if (runningVUsersData.length > 0) {
        let series = [], values = [];
        for (var vi = 0; vi < runningVUsersData.length; vi++) {
            let seriesVal = {
                name: customFormatDate(runningVUsersData[vi].time),
                value: Math.round(runningVUsersData[vi].ActiveVUsers),
            };
            series.push(seriesVal);
            values.push(runningVUsersData[vi].ActiveVUsers);
        }


        let VUsersData = [
            { name: 'VUsers', series: series, },
        ];
        return VUsersData;
    } else {
        //console.log("formatVUsersData Data length:" + runningVUsersData.length);
    }
}

function getThroughputBytesPerSecondForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getThroughputBytesPerSecondForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var throughputQuery = "select time, (sum(ResponseSize)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)";
        influx.query(throughputQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getThroughputBytesPerSecondForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatThroughputData(Data) {
    console.log("-----stopTGAPI/formatThroughputData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: parseNumber(Data[vi].sum),
            };
            series.push(seriesVal);
        }

        let ThroughputData = [
            { name: 'Throughput', series: series, },
        ];
        return ThroughputData;
    } else {
        //console.log("formatThroughputData Data length:" + Data.length);
    }
}

function getHitsPerSecondForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getHitsPerSecondForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var hitsQuery = "select time, (sum(Hits)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
        influx.query(hitsQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getHitsPerSecondForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatHitsPerSecondData(Data) {
    console.log("-----stopTGAPI/formatHitsPerSecondData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: Data[vi].sum,
            };
            series.push(seriesVal);
        }

        let HitsPerSecondData = [
            { name: 'Hits/Second', series: series, },
        ];
        return HitsPerSecondData;
    } else {
        //console.log("formatHitsPerSecondData Data length:" + Data.length);
    }
}

function getErrorCountsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getErrorCountsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var errorQuery = "select \"time\", (sum(\"ErrorCount\")/" + interval + ") as \"ErrorCount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";
        influx.query(errorQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getErrorCountsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatErrorCountsData(Data) {
    console.log("-----stopTGAPI/formatErrorCountsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {

        let ErrorCountsData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].ErrorCount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            ErrorCountsData.push({ name: transcationNames[iName], series: series });
        }
        return ErrorCountsData;
    } else {
        //console.log("formatErrorCountsData Data length:" + Data.length);
    }
}

function getObservations(testRunID, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getObservations()------");
        let URL = "http://" + config.rServer + ":8000/analyze?RunID=" + testRunID + "&aggregationInterval=" + aggregationInterval;
        try {
            Request.get(URL, (error, response, body) => {
                if (error) {
                    console.error(error);
                    reject(error);
                }
                //console.log(body);
                callback(body);
            });
        } catch (e) {
            console.log("Error in stopTGAPI/getTestRunDoc " + e);
            callback("");
        }
    });
}

function updateAnalysedTestRunDoc(testRunID, testResult) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/updateAnalysedTestRunDoc()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = "Analysed";
        updateTestRun.testResult = testResult;
        console.log("status:: " + updateTestRun.status);
        var newvalues = { $set: updateTestRun };

        db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
            if (err) {
                console.log("Error in stopTGAPI/updateTestRunDoc : " + err);
                reject(error);
            }
            else {
                console.log("----------stopTGAPI/updateAnalysedTestRunDoc-----------");
                callback(result);
            }
        });
    });
}

function updateTestRunStatus(testRunID, Status) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/updateTestRunStatus()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = Status;
        console.log("status:: " + updateTestRun.status);
        var newvalues = { $set: updateTestRun };

        db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
            if (err) {
                console.log("Error in stopTGAPI/updateTestRunStatus : " + err);
                reject(error);
            }
            else {
                console.log("----------stopTGAPI/updateTestRunStatus-----------");
                callback(result);
            }
        });
    });
}

function getTestRunDuration(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getTestRunDuration()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, { duration: 1 }, function (err, record) {
            if (err) {
                console.log("Error in stopTGAPI/getTestRunDuration : " + err);
                reject(err);
            } else {
                callback(record.duration);
            }
        });
    });
}


module.exports = router;