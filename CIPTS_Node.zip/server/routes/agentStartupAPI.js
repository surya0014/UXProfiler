var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var config = require('../configuration.json');
let validationRoute = require('./validation.js');

//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('agentStartupAPI.js : ERROR: DB connection failed');
        return err;
    } else {
        db = mydb.db();
        console.log('agentStartupAPI.js : DB connection established!');
    }
});


//This API is called from Tomcat Startup servlet
router.get('/updateLoadAgentStatusOnStartup', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----updateLoadAgentStatusOnStartup------");
    var loadAgentName = req.query.loadAgentName;
    var localHostName = req.query.localHostName;
    var loadAgentType = req.query.loadAgentType;
    var region = req.query.region;
    var status = req.query.status;
    console.log("Load Agent Name:"+loadAgentName);
    console.log("Load Host Name:"+localHostName);
    if (loadAgentName === null || loadAgentName === undefined || loadAgentName === "" || validationRoute(loadAgentName)) {
        return res.status(404).json("Load Agent Name is not specified or not valid");
    }

    if (localHostName === null || localHostName === undefined || localHostName === "" || validationRoute(localHostName)) {
        return res.status(404).json("Local Host Name is not specified or not valid");
    }

    if (loadAgentType === null || loadAgentType === undefined || loadAgentType === "" || validationRoute(loadAgentType)) {
        return res.status(404).json("Load Agent Type is not specified or not valid");
    }

    if (region === null || region === undefined || region === "" || validationRoute(region)) {
        return res.status(404).json("Region is not specified or not valid");
    }

    if (status === null || status === undefined || status === "" || validationRoute(status)) {
        return res.status(404).json("Status is not specified or not valid");
    }

    console.log('Load agent name : ' + loadAgentName);
    console.log('Load agent localHostName : ' + localHostName);
    
    if (typeof loadAgentName == "undefined" || loadAgentName == null) {
        return res.status(500).json({
            error: 'Load agent name is missing'
        });
    }

    db.collection('LoadAgents').findOne({ 'loadAgentName': loadAgentName }, function (err, record) {
        if (err) {
            console.log("Error in findOne LoadAgent : " + err);
            return res.status(500).json(err);
        } else if (record) {
            let statusVal = {
                status: status,
                localHostName: localHostName,
                type: loadAgentType,
                region: region
            };

            var newval = { $set: statusVal }

            db.collection('LoadAgents').update({ 'loadAgentName': loadAgentName }, newval, function (err, records) {
                if (err) {
                    return res.status(500).json(err);
                } else {
                    console.log('Updating status ' + status + ' for load agent : ' + loadAgentName + ", localHostName : " + localHostName);
                    return res.status(200).json({
                        status: 'Updated load agent'
                    })
                }
            });
        } else {

            var newLoadAgentData = {
                "type": loadAgentType,
                "loadAgentName": loadAgentName,
                "hostName": loadAgentName,
                "specification": "",
                "status": status,
                "localHostName": localHostName,
                "currentTestRunID": null,
            };
            //ATD add customer id to the doc

            if (loadAgentType != "OnPremise") {
                newLoadAgentData.region = region;
            } else {
                newLoadAgentData.region = "OnPremise";
            }
            db.collection('LoadAgents').insert(newLoadAgentData, function (err, record) {
                if (err) {
                    return res.status(500).json(err);
                } else {
                    return res.status(200).json({
                        status: 'Inserted load agent'
                    })
                }
            });
        }
    });






});//end of //updateLoadAgentStatusOnStartup



module.exports = router;