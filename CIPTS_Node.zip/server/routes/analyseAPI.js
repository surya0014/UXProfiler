var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

var Request = require("request");
const fs = require('fs');

let validationRoute = require('./validation.js');
var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('analyseAPI.js : ERROR: DB connection failed');
        return err;
    } else {
        db = mydb.db();
        console.log('analyseAPI.js : DB connection established for analyse API!');
    }
});

const Influx = require('influx');
// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://' + config.influxDBUserName + ':' + config.influxDBPassword + '@' + config.influxDBHost + ':8086/zantmeter');

var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
    host: 'http://' + config.elasticsearchDBHost + ':9200',
    log: 'trace'
});
elasticClient.ping({
    requestTimeout: 30000,
}, function (error) {
    if (error) {
        console.log('analyseAPI.js : ERROR: Elasticsearch DB Connection failed !');
    } else {
        console.log('analyseAPI.js : Connection to ElasticSearch DB established !');
    }
});

//analyze Test Runs
router.get('/analyzeTestRun', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----analyzeTestRun------");
    let testID = req.query.testrunid;
    if (typeof testID === "undefined" || testID == null || testID == "" || validationRoute(testID)) {
        console.log("Test Run ID not exists");
        return res.status(500).json({
            "error": 'test run id is missing'
        });
    }

    let aggregationInterval = 1;
    if (req.query.aggregationInterval) {
        aggregationInterval = req.query.aggregationInterval;
    }

    let RAWenabled = false;
    if (req.query.RAWenabled) {
        RAWenabled = req.query.RAWenabled;
    }
    let characters = /^[0-9]+$/;
    if (!characters.test(aggregationInterval)) {
        console.log("Aggregation Interval is Invalid !");
        return res.status(500).json({
            "error": 'Aggregation Interval is Invalid !'
        });
    }
    let jsonResponseArray = [];
    try {
        jsonResponseArray = await analyzeTestRun(testID, aggregationInterval, RAWenabled);
        return res.status(200).json(jsonResponseArray);
    } catch (e) {
        console.log("Error analyzeTestRun " + e);
        return res.status(500).json({
            "error": e
        });
    }
});//end of analyze test run 

async function analyzeTestRun(testRunID, aggregationInterval, RAWenabled) {
    try {
        console.log("-----analyzeTestRun()------");
        //await 
        if (!testRunID) {
            return ({ 'status': 'error', 'message': 'testRunID missing !' });
        }
        let duration = 0;
        let setStatusTestRun = null;

        const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));

        setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
        console.log(setStatusTestRun.result);
        let counter = 0;
        while (duration == null || duration == 0) {
            if (counter > 5) {
                break;
            }
            await sleep(1000);
            counter++;
            if (setStatusTestRun.result.nModified != 1) {
                setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
                console.log(setStatusTestRun.result);
            }
            duration = await getTestRunDuration(testRunID);
            console.log(duration);
        }

        let summary = await getSummary(testRunID);
        //console.log("summary: "+JSON.stringify(summary));
        aggregationInterval = getAggregationIntervalByDuration(duration, aggregationInterval);

        let transactions = await getTransactionsForID(testRunID, aggregationInterval);

        let responseTime = await getResponseTimeForID(testRunID, aggregationInterval);

        let vUsers = await getRunningVUsersForID(testRunID, aggregationInterval);
        //let vUsers = await getRunningVUsersForIDByThreadGroupName(testRunID, aggregationInterval);

        let vUsersByThreadGroups = await getVUsersByThreadGroupsForID(testRunID, aggregationInterval);

        let throughput = await getThroughputBytesPerSecondForID(testRunID, aggregationInterval);

        let hits = await getHitsPerSecondForID(testRunID, aggregationInterval);

        let error = await getErrorCountsForID(testRunID, aggregationInterval);

        await sleep(1000);
        let latency = await getLatencyForID(testRunID, aggregationInterval);

        let statuscodes = await getStatusCodesListForID(testRunID, aggregationInterval);

        let assertionFailures = await getAssertionFailureResultsForID(testRunID, aggregationInterval);

        let observations = "";

        if (duration > 600000) {//>10mins
            // observations = await getObservations(testRunID, aggregationInterval);//commenting R code
        }

        let summaryObservation = [], transactionsObservation = [], responseTimeObservation = [], vUsersObservation = [], throughputObservation = [], hitsObservation = [], errorObservation = [], vUsersByThreadGroupsObservation = [], latencyObservation = [], statuscodesObservation = [];

        if (observations !== null && observations !== undefined && observations !== "") {

            let responseObservations = JSON.parse(observations);
            //console.log(responseObservations.msg);
            responseObservations = null;//uncomment while commenting R code
            responseObservations = responseObservations.msg;
            if (responseObservations !== null && responseObservations !== undefined && responseObservations !== "") {
                for (let i = 0; i < responseObservations.length; i++) {
                    switch (responseObservations[i].type) {
                        case "Transactions": {
                            transactionsObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "Response Time": {
                            responseTimeObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "VUsers": {
                            vUsersObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "Throughput": {
                            throughputObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "Hits Per Second": {
                            hitsObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "Error": {
                            errorObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "vUsersByThreadGroups": {
                            vUsersByThreadGroupsObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "Latency": {
                            latencyObservation.push(responseObservations[i].observation);
                            break;
                        }
                        case "StatusCodes": {
                            statuscodesObservation.push(responseObservations[i].observation);
                            break;
                        }
                    }
                }
            }
        }
        let sla = await getTestRunSLA(testRunID);
        //console.log(JSON.stringify(formatResponseTimeData(responseTime)));
        let FormattedSummaryData = formatSummaryData(summary, sla);

        let summaryData = FormattedSummaryData.summary,
            VUsersData = formatVUsersData(vUsers);
        //Happens only when test does not stop and manual stop required
        if (typeof VUsersData === "undefined" || VUsersData == null) {
            VUsersData = [];
        }
        let panelSummaryData = formatPanelSummaryData(summaryData, VUsersData, duration);
        let TestRunDocument = await getTestRunDocument(testRunID);
        let systemMonitor = TestRunDocument.systemMonitor;
        // console.log(JSON.stringify(systemMonitor));
        let serverMetrics = {};
        if ((systemMonitor != undefined) && (systemMonitor != "") && (systemMonitor != null)) {
            if ((systemMonitor.enabled) && (systemMonitor.hasOwnProperty("machines"))) {
                serverMetrics = await getServerMetrics(systemMonitor.machines, TestRunDocument.startTime, TestRunDocument.endTime);
            }
        }

        let AssertionResultsRawData = [], ClientSideMetricsRawData = [], RequestMetricsRawData = [], ThreadGroupDataRawData = [], TransactionsRawData = [], TransactionsSubResultsRawData = [], VUsersRawData = [], stderrLogs = [], stdoutLogs = [], TransactionsRequestsBreakdown = [], TransactionsRequestsBreakdownSuccessful = [];

        if (RAWenabled == "true") {

            TransactionsRequestsBreakdown = await getTransactionsRequestsBreakdownForID(testRunID, aggregationInterval);

            TransactionsRequestsBreakdownSuccessful = await getTransactionsRequestsBreakdownSuccessfulForID(testRunID, aggregationInterval);

            AssertionResultsRawData = await getAssertionResultsRawDataForID(testRunID);

            ClientSideMetricsRawData = await getClientSideMetricsRawDataForID(testRunID);

            RequestMetricsRawData = await getRequestMetricsRawDataForID(testRunID);

            ThreadGroupDataRawData = await getThreadGroupDataRawDataForID(testRunID);

            TransactionsRawData = await getTransactionsRawDataForID(testRunID);

            TransactionsSubResultsRawData = await getTransactionsSubResultsRawDataForID(testRunID);

            VUsersRawData = await getVUsersRawDataForID(testRunID);

            let gteString = TestRunDocument.startTime;//"now-1h"

            let lteString = "now";

            if (TestRunDocument.endTime !== null || TestRunDocument.endTime !== undefined || TestRunDocument.endTime !== "") {
                lteString = TestRunDocument.endTime;
            }
            await sleep(1000);
            stderrLogs = await getTomcatLogs("apachelogs-stderr", gteString, lteString, testRunID);

            if (!(stderrLogs instanceof Array)) {
                stderrLogs = [];
            }
            await sleep(1000);
            stdoutLogs = await getTomcatLogs("apachelogs-stdout", gteString, lteString, testRunID);

            if (!(stdoutLogs instanceof Array)) {
                stdoutLogs = [];
            }
        }

        let dummysamples = [],
            formattedThroughputData = formatThroughputData(throughput),
            formattedHitsPerSecondData = formatHitsPerSecondData(hits);
        panelSummaryData.panelSummary[4].value = formattedThroughputData.avgThroughput;
        panelSummaryData.panelSummary[5].value = formattedHitsPerSecondData.avgHitsPerSecond;
        let testResult = {
            panelsummary: {
                data: panelSummaryData.panelSummary,
                responsetimehealth: {
                    value: FormattedSummaryData.responsetime.statusCardsvalue,
                    TxCount: FormattedSummaryData.responsetime.TxCount,
                },
                transactionhealth: {
                    value: panelSummaryData.transaction.statusCardsvalue,
                    TxCount: panelSummaryData.transaction.TxCount,
                }
            },
            errorsPerTranscationData: {
                data: panelSummaryData.errorsPerTranscationData,
            },
            stackedbarchartdata: {
                data: panelSummaryData.stackedbarchartdata,
            },
            summary: {
                data: summaryData,
                observations: summaryObservation
            },
            transactions: {
                rawData: dummysamples,
                data: formatTransactionsData(transactions),
                observations: transactionsObservation
            },
            responseTime: {
                rawData: dummysamples,
                data: formatResponseTimeData(responseTime),
                observations: responseTimeObservation
            },
            vUsers: {
                rawData: dummysamples,
                data: formatVUsersData(vUsers),
                observations: vUsersObservation
            },
            vUsersByThreadGroups: {
                rawData: dummysamples,
                data: formatVUsersByThreadGroupsData(vUsersByThreadGroups),
                observations: vUsersByThreadGroupsObservation
            },
            throughput: {
                rawData: dummysamples,
                data: formattedThroughputData.throughputData,
                observations: throughputObservation
            },
            hits: {
                rawData: dummysamples,
                data: formattedHitsPerSecondData.hitsPerSecondData,
                observations: hitsObservation
            },
            error: {
                rawData: dummysamples,
                data: formatErrorCountsData(error),
                observations: errorObservation
            },
            latency: {
                rawData: dummysamples,
                data: formatLatencyData(latency),
                observations: latencyObservation
            },
            statuscodes: {
                rawData: dummysamples,
                data: formatStatusCodesData(statuscodes),
                observations: statuscodesObservation
            },
            assertionerrors: {
                rawData: dummysamples,
                data: formatAssertionFailureData(assertionFailures),
            },

            TransactionsRequestsBreakdown: {
                rawData: dummysamples,
                data: formatTransactionsRequestsBreakdownData(TransactionsRequestsBreakdown, TransactionsRequestsBreakdownSuccessful),
            },
            observations: observations,
            serverMetrics: {
                data: serverMetrics,
                observations: []
            },
            influxRawData: {
                AssertionResults: AssertionResultsRawData,
                ClientSideMetrics: ClientSideMetricsRawData,
                RequestMetrics: RequestMetricsRawData,
                ThreadGroupData: ThreadGroupDataRawData,
                Transactions: TransactionsRawData,
                TransactionsSubResults: TransactionsSubResultsRawData,
                VUsers: VUsersRawData
            },
            TomcatLogs: {
                stdoutLogs: stdoutLogs,
                stderrLogs: stderrLogs
            }
        };

        testResult = await updateFileSystem(testRunID, testResult);
        let updateTestRun = await updateAnalysedTestRunDoc(testRunID, testResult);

        return updateTestRun;
    } catch (e) {
        console.log("Error analyzeTestRun(): " + JSON.stringify(e));
        return ({
            "error": e
        });
    }
}

async function analyze() {
    console.log("--------started--------");
    let sample = await analyzeTestRun("5bfd43bf3200be0edc57a965", 5);
    console.log("--------finished--------");
    //console.log(JSON.stringify(sample));
}

function getAggregationIntervalByDuration(duration, interval) {
    console.log("-----getAggregationIntervalByDuration()------");
    let aggregationInterval = 1;
    if ((interval != undefined) && (interval != null) && (interval > 0)) {
        aggregationInterval = interval;
    }
    if ((duration != undefined) && (duration != null)) {
        switch (true) {
            case (duration < 300000): {//<5mins
                aggregationInterval = 1;
                break;
            }
            case ((duration >= 300000) && (duration < 600000)): {//>=5mins <10mins
                aggregationInterval = 2;
                break;
            }
            case ((duration >= 600000) && (duration < 1800000)): {//>=10mins <30mins
                aggregationInterval = 5;
                break;
            }
            case ((duration >= 1800000) && (duration < 3600000)): {//>=30mins <60mins
                aggregationInterval = 10;
                break;
            }
            case ((duration >= 3600000) && (duration < 7200000)): {//>=60mins <120mins
                aggregationInterval = 15;
                break;
            }
            case ((duration >= 7200000) && (duration < 14400000)): {//>=120mins <240mins
                aggregationInterval = 30;
                break;
            }
            case ((duration >= 14400000)): {//>=240mins
                aggregationInterval = 60;
                break;
            }
        }
    }

    return aggregationInterval;
}

function formatPanelSummaryData(summaryData, VUsersData, duration) {
    console.log("-----formatPanelSummaryData()------");
    /* console.log("summaryData: "+JSON.stringify(summaryData));
    console.log("VUsersData: "+JSON.stringify(VUsersData));
    console.log("duration: "+JSON.stringify(duration)); */
    let errorsPerTranscationData = new Array(), stackedbarchartdata = [];
    let panelSummary = [
        { title: "Transactions", value: 0 },
        { title: "Duration", value: "00:00:00" },
        { title: "Max VUsers", value: 0 },
        { title: "Errors", value: 0 },
        { title: "Avg. Throughput", value: 0 },
        { title: "Avg. Hits", value: 0 }
    ];

    let errorcounts = 0, totalcounts = 0;

    summaryData.forEach((obj) => {
        obj._90percent = parseFloat(String((obj.passcount / obj.totalcount) * 90)).toFixed(2);
        obj.error = parseFloat(String((obj.errorcount / obj.totalcount) * 100)).toFixed(1);
        errorcounts = errorcounts + obj.errorcount;
        totalcounts = totalcounts + obj.totalcount;
        errorsPerTranscationData.push({ name: obj.TransactionName, value: obj.errorcount });
        let series = [];
        series.push({
            "name": "Response Time",
            "value": parseFloat(String(obj.avg)).toFixed(0)
        });
        /* series.push({
            "name": "Pass",
            "value": obj.passcount
        });
        series.push({
            "name": "Fail",
            "value": obj.errorcount
        }); */
        stackedbarchartdata.push({
            "name": obj.TransactionName,
            "series": series,
        });
    });

    /* summaryData.forEach((obj) => {
        errorsPerTranscationData.push({ name: obj.TransactionName, value: parseFloat(String((obj.errorcount / errorcounts) * 100)).toFixed(2) });
    }); */
    let overallerror_percentage = parseFloat(String((errorcounts / totalcounts) * 100)).toFixed(1);
    panelSummary[3].value = errorcounts + " ( " + overallerror_percentage + "% Overall error rate )";

    let stackedbarchartdata1 = stackedbarchartdata.sort((obj1, obj2) => {
        return obj2.series[0].value - obj1.series[0].value;
    });

    if (stackedbarchartdata1.length > 5) {
        stackedbarchartdata = stackedbarchartdata1.splice(0, 5);
    }

    panelSummary[0].value = summaryData.length;
    panelSummary[1].value = getHHmmssFromMilliseconds(duration);
    let values = [];
    if (VUsersData != undefined) {
        if (VUsersData[0].series != undefined) {
            if (VUsersData[0].series.length > 0) {
                for (var vi = 0; vi < VUsersData[0].series.length; vi++) {
                    values.push(VUsersData[0].series[vi].value);
                }
            }
        }
    }

    let maxVUsers = 0;
    if (values.length > 0) {
        maxVUsers = Math.max(...values);
    }

    panelSummary[2].value = maxVUsers;


    let rCount = 0, aCount = 0, gCount = 0;
    summaryData.forEach((obj, index) => {
        //console.log(obj.error);
        switch (true) {
            case (obj.error < 2): {
                gCount++;
                break;
            }
            case ((obj.error >= 2) && (obj.error < 5)): {
                aCount++;
                break;
            }
            case ((obj.error >= 5)): {
                rCount++;
                break;
            }
        }
    });
    let statusCardsvalue_Tx = '', TxCount = 0;
    if ((rCount == 0) && (aCount == 0) && (gCount == 0)) {
        statusCardsvalue_Tx = "N/A";
    } else if (rCount == 0) {
        statusCardsvalue_Tx = "Pass";
    } else {
        statusCardsvalue_Tx = "Fail";
        TxCount = rCount;
    }


    let formatPanelSummaryData = {
        panelSummary: panelSummary,
        errorsPerTranscationData: errorsPerTranscationData,
        stackedbarchartdata: stackedbarchartdata,
        transaction: {
            statusCardsvalue: statusCardsvalue_Tx,
            TxCount: TxCount,
        },
    };

    return formatPanelSummaryData;
}

function getHHmmssFromMilliseconds(ms) {
    let date = new Date(null);
    var timeOffsetInMS = date.getTimezoneOffset() * 60000;
    ms = ms + timeOffsetInMS;
    date.setMilliseconds(ms);
    let result = date.toTimeString().substr(0, 8);
    //console.log(result);
    return result;
}

function getSummary(testrunid) {
    console.log("-----getSummary()------");
    return new Promise(function (callback, reject) {
        var summaryQuery = "select mean(\"ResponseTime\") as \"avg\", mean(\"Latency\") as \"latency\", sum(\"TransactionCount\") as \"totalcount\", sum(\"ErrorCount\") as \"errorcount\", percentile(\"ResponseTime\", 90) as percentile, percentile(\"ResponseTime\", 99) as \"percentile99\", max(\"ResponseTime\") as \"maxRT\"  from Transactions where RunID='" + testrunid + "' group by \"TransactionName\"";
        influx.query(summaryQuery)
            .then(result => {
                console.log("----------getTestSummary-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => {
                reject(error);
            });
    });
}

function formatSummaryData(Data, sla) {
    console.log("-----formatSummaryData()------");
    Data.forEach((obj) => {
        obj.passcount = obj.totalcount - obj.errorcount;
    });
    let statusCardsvalue_RT = '', TxCount_RT = 0;
    let summary = JSON.parse(JSON.stringify(Data));
    if (sla.enabled) {
        let SLAmet = 0, SLAnotmet = 0;
        summary.forEach((tx) => {
            /* { "time" : ISODate("1970-01-01T00:00:00.000Z"), "avg" : 2045.7, "totalcount" : 20, "errorcount" : 0, 
              "percentile" : 2928, "TransactionName" : "01_Launch", "passcount" : 20, "_90percent" : "90.00", "error" : "0.0" } */
            //tx.TransactionName
            let transactionSLA = 0;
            sla.Txs.forEach((transaction) => {
                if (transaction.txName === tx.TransactionName) {
                    transactionSLA = transaction.sla;
                    if (!transaction.hasOwnProperty("enabled")) {
                        tx.enabled = true;
                    } else {
                        tx.enabled = transaction.enabled;
                    }
                }
            });
            tx.slalimit = transactionSLA;

            if (tx.enabled) {
                switch (true) {
                    case (tx.avg <= transactionSLA): {
                        //SLA met
                        tx.sla = "met";
                        SLAmet++;
                        break;
                    }
                    case (tx.avg > transactionSLA): {
                        //SLA not met
                        tx.sla = "not met";
                        SLAnotmet++;
                        break;
                    }
                }
            } else {
                tx.sla = "nil";
            }

        });
        if ((SLAmet == 0) && (SLAnotmet == 0)) {
            statusCardsvalue_RT = "N/A";
        } else if (SLAnotmet == 0) {
            statusCardsvalue_RT = "Pass";
        } else {
            statusCardsvalue_RT = "Fail";
            TxCount_RT = SLAnotmet;
        }
    } else {
        statusCardsvalue_RT = "N/A";
    }

    let FormattedData = {
        summary: summary,
        responsetime: {
            statusCardsvalue: statusCardsvalue_RT,
            TxCount: TxCount_RT,
        },
    };
    return FormattedData;
}

function getTransactionsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getTransactionsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var transactionsQuery = "select \"time\", (sum(\"TransactionCount\")/" + interval + ") as \"totalcount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

        influx.query(transactionsQuery)
            .then((result) => {
                console.log("----------getTransactionsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatTransactionsData(Data) {
    console.log("-----formatTransactionsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].totalcount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatTransactionsData Data length:" + Data.length);
    }
}

function getResponseTimeForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getResponseTimeForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var responseTimeQuery = "select \"time\", mean(\"ResponseTime\") as \"ResponseTime\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";
        //select time, ResponseTime, TransactionID from Transactions where RunID='5d76267177978f3da4011786' group by TransactionName
        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getResponseTimeForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatResponseTimeData(Data) {
    console.log("-----formatResponseTimeData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].ResponseTime,
                };

                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatResponseTimeData Data length:" + Data.length);
    }
}

function getLatencyForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getLatencyForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var latencyQuery = "select \"time\", mean(\"Latency\") as \"Latency\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

        influx.query(latencyQuery)
            .then((result) => {
                console.log("----------getLatencyForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatLatencyData(Data) {
    console.log("-----formatLatencyData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].Latency,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatResponseTimeData Data length:" + Data.length);
    }
}

function customFormatDate(dateTBM) {
    //console.log("-----customFormatDate()------");
    var Mdate = '';
    if (dateTBM) {
        //Mdate = formatDate(dateTBM, 'MM-d-y HH:mm:ss', 'en-US');
        //Mdate = formatDate(dateTBM, 'HH:mm:ss', 'en-US');
        //new Date(dateTBM).getTime()
        Mdate = new Date(dateTBM).getTime();
    }
    return Mdate;
}

function parseNumber(value) {
    return parseFloat(value);
}


function getVUsersByThreadGroupsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getVUsersByThreadGroupsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        var VUsersForIDByThreadGroupsQuery = "select \"time\", mean(\"ThreadCount\") as \"ThreadCount\" from ThreadGroupData where RunID='" + testrunid + "' group by time(" + interval + "s), ThreadGroupName fill(none)";

        influx.query(VUsersForIDByThreadGroupsQuery)
            .then((result) => {
                console.log("----------getVUsersByThreadGroupsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatVUsersByThreadGroupsData(Data) {
    console.log("-----formatVUsersByThreadGroupsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        var formattedData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            if (obj.ThreadGroupName != '') {
                groupByName[obj.ThreadGroupName] = groupByName[obj.ThreadGroupName] || [];
                groupByName[obj.ThreadGroupName].push(obj);
            }
        });
        //console.log(JSON.stringify(groupByName));
        let ThreadGroupNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < ThreadGroupNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[ThreadGroupNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[ThreadGroupNames[iName]][vi].time),
                    value: groupByName[ThreadGroupNames[iName]][vi].ThreadCount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            formattedData.push({ name: ThreadGroupNames[iName], series: series });
        }
        return formattedData;
    } else {
        //console.log("formatVUsersForIDByThreadGroupsData Data length:" + Data.length);
    }
}

function getRunningVUsersForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getRunningVUsersForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var vUsersQuery = "select time, (sum(ActiveVUsers)/" + interval + ") as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + interval + "s) fill(none)";
        //var vUsersQuery = "select time, mean(ActiveVUsers) as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + interval + "s) fill(none)";
        influx.query(vUsersQuery)
            .then((result) => {
                console.log("----------getRunningVUsersForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatVUsersData(runningVUsersData) {
    console.log("-----formatVUsersData()------");
    //console.log("runningVUsersData length:"+runningVUsersData.length);
    if (runningVUsersData.length > 0) {
        let series = [], values = [];
        for (var vi = 0; vi < runningVUsersData.length; vi++) {
            let seriesVal = {
                name: customFormatDate(runningVUsersData[vi].time),
                value: Math.round(runningVUsersData[vi].ActiveVUsers),
            };
            series.push(seriesVal);
            values.push(runningVUsersData[vi].ActiveVUsers);
        }


        let VUsersData = [
            { name: 'VUsers', series: series, },
        ];
        return VUsersData;
    } else {

        let VUsersData = [
            { name: 'VUsers', series: [], },
        ];
        return VUsersData;
        //console.log("formatVUsersData Data length:" + runningVUsersData.length);
    }
}

function getThroughputBytesPerSecondForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getThroughputBytesPerSecondForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var throughputQuery = "select time, (sum(ResponseSize)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)";
        influx.query(throughputQuery)
            .then((result) => {
                console.log("----------getThroughputBytesPerSecondForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatThroughputData(Data) {
    console.log("-----formatThroughputData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [], count = 0, sum = 0;
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: parseNumber(Data[vi].sum),
            };
            series.push(seriesVal);
            sum = sum + Data[vi].sum;
            count++;
        }

        let avgThroughput = Math.round(sum / count);
        let ThroughputData = {
            throughputData: [
                { name: 'Throughput', series: series, },
            ],
            avgThroughput: avgThroughput
        };
        return ThroughputData;
    } else {
        return ({
            throughputData: [
                { name: 'Throughput', series: [], },
            ],
            avgThroughput: 0
        });
        //console.log("formatThroughputData Data length:" + Data.length);
    }
}

function getHitsPerSecondForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getHitsPerSecondForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        // var hitsQuery = "select time, (sum(Hits)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
        
        var hitsQuery = "select time, (sum(TransactionCount)/" + interval + ") from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
        influx.query(hitsQuery)
            .then((result) => {
                console.log("----------getHitsPerSecondForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatHitsPerSecondData(Data) {
    console.log("-----formatHitsPerSecondData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [], count = 0, sum = 0;
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: Data[vi].sum,
            };
            series.push(seriesVal);
            sum = sum + Data[vi].sum;
            count++;
        }
        let avgHitsPerSecond = Math.round(sum / count);
        let HitsPerSecondData = {
            hitsPerSecondData: [
                { name: 'Hits/Second', series: series, },
            ],
            avgHitsPerSecond: avgHitsPerSecond
        };
        return HitsPerSecondData;
    } else {
        //console.log("formatHitsPerSecondData Data length:" + Data.length);
        return ({
            hitsPerSecondData: [
                { name: 'Hits/Second', series: [], },
            ],
            avgHitsPerSecond: 0
        });
    }
}

function getErrorCountsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getErrorCountsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var errorQuery = "select \"time\", (sum(\"ErrorCount\")/" + interval + ") as \"ErrorCount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";
        influx.query(errorQuery)
            .then((result) => {
                console.log("----------getErrorCountsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatErrorCountsData(Data) {
    console.log("-----formatErrorCountsData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {

        let ErrorCountsData = [];
        var groupByName = {};

        Data.forEach((obj) => {
            groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
            groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
            series = [];
            //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
            for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
                seriesVal = {
                    name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
                    value: groupByName[transcationNames[iName]][vi].ErrorCount,
                };
                series.push(seriesVal);
            }
            //console.log(JSON.stringify(series));
            ErrorCountsData.push({ name: transcationNames[iName], series: series });
        }
        return ErrorCountsData;
    } else {
        //console.log("formatErrorCountsData Data length:" + Data.length);
    }
}

function getStatusCodesListForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getStatusCodesForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var statusCodesQuery = "select \"time\", \"SamplerLabel\" as \"label\", \"HTTPStatusCode\" as \"statuscode\", URL from RequestMetrics where RunID='" + testrunid + "'";

        influx.query(statusCodesQuery)
            .then((result) => {
                console.log("----------getStatusCodesForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}


function formatStatusCodesData(Data) {
    console.log("-----formatStatusCodesData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let StatusCodesData = [];
        var groupBystatuscodes = {};

        for (var iData = 0; iData < Data.length; iData++) {
            groupBystatuscodes[Data[iData].statuscode] = "";
        }
        //console.log(JSON.stringify(groupBystatuscodes));
        let statuscodesListNames = Object.keys(groupBystatuscodes);
        for (var istatuscode = 0; istatuscode < statuscodesListNames.length; istatuscode++) {
            //statuscodesList[istatuscode]
            let statuscodeCount = 0;
            for (var iData = 0; iData < Data.length; iData++) {
                //statuscodes[Data[iData].statuscode] = "";
                if (Data[iData].statuscode == statuscodesListNames[istatuscode]) {
                    statuscodeCount++;
                }
            }
            let dataobj = {
                name: statuscodesListNames[istatuscode],
                value: statuscodeCount
            };
            StatusCodesData.push(dataobj);
        }
        return StatusCodesData;
    } else {
        //console.log("formatErrorCountsData Data length:" + Data.length);
    }
}

function getAssertionFailureResultsForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getAssertionFailureResultsForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        //var assertionFailureQuery = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\", \"ResponseContent\" as \"content\" from AssertionResults where RunID='" + testrunid + "'";
        var assertionFailureQuery = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\" from AssertionResults where RunID='" + testrunid + "'";
        influx.query(assertionFailureQuery)
            .then((result) => {
                console.log("----------getAssertionFailureResultsForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatAssertionFailureData(Data) {
    console.log("-----formatAssertionFailureData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        Data.forEach((obj) => {
            if (obj.hasOwnProperty('content')) {
                delete obj['content'];
            }
        });
    } else {
        //console.log("formatErrorCountsData Data length:" + Data.length);
    }
    return Data;
}

function getObservations(testRunID, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getObservations()------");
        let URL = "http://" + config.rServer + ":8000/analyze?RunID=" + testRunID + "&aggregationInterval=" + aggregationInterval;
        try {
            Request.get(URL, (error, response, body) => {
                if (error) {
                    console.error(error);
                    reject(error);
                }
                //console.log(body);
                callback(body);
            });
        } catch (e) {
            console.log("Error in getTestRunDoc " + e);
            callback(null);
        }
    });
}

function updateAnalysedTestRunDoc(testRunID, testResult) {
    return new Promise(function (callback, reject) {
        console.log("-----updateAnalysedTestRunDoc()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = "Analysed";
        updateTestRun.testResult = testResult;
        // console.log(testResult);
        updateTestRun.testGroups = []; //ATD
        console.log("status:: " + updateTestRun.status);
        console.log("testResult:: " + testResult);
        fs.writeFile("C:/ZantMeter/temp/sampletest.json", JSON.stringify(testResult), function (err) {
            if (err) {
                return console.log(err);
            }
            console.log("The file was saved!");
        });
        //File saving
        //fs.writeFileSync("C:/ZantMeter/temp/sampledoc.txt", JSON.stringify(testResult));
        /* var testRunData = JSON.parse(JSON.stringify(updateTestRun));
        try {
            //temporary
            let testRunDocPath = "C:/PerfAssure/GitLab/CIPTS_Node/mongodocs/testruns/" + testRunID + ".json";
            //temporary
            fs.writeFileSync(testRunDocPath, JSON.stringify(testRunData));
            var testRunDocStats = fs.statSync(testRunDocPath);
            console.log('Test Run Doc File Size in Bytes-' + testRunDocStats.size);
            if (testRunDocStats.size < 15000000) {//check < 15Mb
                //temporary
                fs.unlinkSync(testRunDocPath);//remove file
            }
        } catch (err) {
            console.log(err);
        } */
        var newvalues = { $set: updateTestRun };
        //callback(updateTestRun);
        db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
            if (err) {
                console.log("Error in updateTestRunDoc : " + err);
                reject(err);
            }
            else {
                console.log("----------updateAnalysedTestRunDoc-----------");
                callback(result);
            }
        });
    });
}

function updateTestRunStatus(testRunID, Status) {
    return new Promise(function (callback, reject) {
        console.log("-----updateTestRunStatus()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = Status;
        console.log("status:: " + updateTestRun.status);
        var newvalues = { $set: updateTestRun };

        db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
            if (err) {
                console.log("Error in updateTestRunStatus : " + err);
                reject(error);
            }
            else {
                console.log("----------updateTestRunStatus-----------");
                callback(result);
            }
        });
    });
}

function getTestRunDuration(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----getTestRunDuration()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, { duration: 1 }, function (err, record) {
            if (err) {
                console.log("Error in getTestRunDuration : " + err);
                reject(err);
            } else {
                callback(record.duration);
            }
        });
    });
}

function getTestRunSLA(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----getTestRunSLA()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, { sla: 1 }, function (err, record) {
            if (err) {
                console.log("Error in getTestRunDuration : " + err);
                reject(err);
            } else {
                callback(record.sla);
            }
        });
    });
}

function getTestRunDocument(testRunID) {
    return new Promise(function (callback, reject) {
        console.log("-----getTestRunDocument()------");
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, {}, function (err, record) {
            if (err) {
                console.log("Error in getTestRunDocument : " + err);
                reject(err);
            } else {
                callback(record);
            }
        });
    });
}

function getCPUForHostName(hostname, startTimestamp, endTimestamp) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getCPUForHostName()------");

        //var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total'";
        // var CPUQuery = "select \"time\", \"Percent_Processor_Time\", \"host\" from win_cpu where host='" + hostname + "' and instance='_Total' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
        var CPUQuery = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
        // console.log(CPUQuery);
        influx.query(CPUQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getCPUForHostName-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatCPUDataForHostName(hostname, Data) {
    console.log("-----stopTGAPI/formatCPUDataForHostName()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: parseFloat(String(Data[vi].usage)).toFixed(1),//Math.floor(parseFloat(String(Data[vi].usage))),
            };
            series.push(seriesVal);
        }

        let CPUData = { name: hostname, series: series, };
        return CPUData;
    } else {
        //console.log("formatHitsPerSecondData Data length:" + Data.length);
    }
}

function getProcessorDataForHostName(hostname, startTimestamp, endTimestamp) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getProcessorDataForHostName()------");
        //select LAST("Percent_Processor_Time") from win_cpu where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total';
        //"select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000
        //select * from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000
        //'2015-08-18T23:00:01.232000000Z'
        //select * from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total' and time => '2019-04-10T10:10:13.232000000Z' and time <= '2019-04-10T10:40:17.232000000Z' group by time(5s)
        //select "time", mean("Processor_Queue_Length") as "Processor_Queue_Length", "host" from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and time > '2019-04-10T10:10:13.232000000Z' and time < '2019-04-10T10:40:17.232000000Z' group by time(5s) fill(none)

        //var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000";
        //var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from win_system where host='" + hostname + "' and time > '2019-04-10T10:10:13.232000000Z' and time < '2019-04-10T10:40:17.232000000Z' group by time(5s) fill(none)";

        // var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from win_system where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
        var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
        influx.query(ProcessorQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getProcessorDataForHostName-----------");
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatProcessorDataForHostName(hostname, Data) {
    console.log("-----stopTGAPI/formatProcessorDataForHostName()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: (parseFloat(String(Data[vi].Processor_Queue_Length)).toFixed(2) * 100),//Math.floor(Data[vi].Processor_Queue_Length),
            };
            series.push(seriesVal);
        }

        let ProcessorData = { name: hostname, series: series, };
        return ProcessorData;
    } else {
        //console.log("formatHitsPerSecondData Data length:" + Data.length);
    }
}

function getAvailableRAMDataForHostName(hostname, startTimestamp, endTimestamp) {
    return new Promise(function (callback, reject) {
        console.log("-----stopTGAPI/getAvailableRAMDataForHostName()------");

        var AvailableRAMQuery = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
        // console.log(AvailableRAMQuery);
        influx.query(AvailableRAMQuery)
            .then((result) => {
                console.log("----------stopTGAPI/getAvailableRAMDataForHostName-----------");
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatAvailableRAMDataForHostName(hostname, Data) {
    console.log("-----stopTGAPI/formatAvailableRAMDataForHostName()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        let series = [];
        for (var vi = 0; vi < Data.length; vi++) {
            let seriesVal = {
                name: customFormatDate(Data[vi].time),
                value: parseFloat(String(Data[vi].AvailableRAM)).toFixed(1),//Math.floor(Data[vi].AvailableRAM),
            };
            series.push(seriesVal);
        }

        let AvailableRAMData = { name: hostname, series: series, };
        return AvailableRAMData;
    } else {
        //console.log("formatAvailableRAMDataForHostName Data length:" + Data.length);
    }
}

async function getServerMetrics(machines, startTimestamp, endTimestamp) {
    console.log("-----getServerMetrics()------");
    // console.log(JSON.stringify(machines));
    if (machines.length > 0) {
        /* console.log(startTimestamp);
        console.log(endTimestamp); */
        let ProcessorSeries = [], CPUSeries = [], MemorySeries = [];
        for (var vi = 0; vi < machines.length; vi++) {
            if (machines[vi].metrics.processor) {
                let ProcessorDataForHostName = await getProcessorDataForHostName(machines[vi].machineName, startTimestamp, endTimestamp);
                let ProcessorData = formatProcessorDataForHostName(machines[vi].machineName, ProcessorDataForHostName);
                ProcessorSeries.push(ProcessorData);
            }
            if (machines[vi].metrics.cpu) {
                let CPUDataForHostName = await getCPUForHostName(machines[vi].machineName, startTimestamp, endTimestamp);
                let CPUData = formatCPUDataForHostName(machines[vi].machineName, CPUDataForHostName);
                CPUSeries.push(CPUData);
            }
            if (machines[vi].metrics.memory) {
                let RAMDataForHostName = await getAvailableRAMDataForHostName(machines[vi].machineName, startTimestamp, endTimestamp);
                let RAMData = formatAvailableRAMDataForHostName(machines[vi].machineName, RAMDataForHostName);
                MemorySeries.push(RAMData);
            }
        }
        let responseData = {
            cpu_data: CPUSeries,
            processor_data: ProcessorSeries,
            memory_data: MemorySeries,
        };
        return responseData;
    } else {
        //console.log("formatHitsPerSecondData Data length:" + Data.length);
    }
}

function getTransactionsRequestsBreakdownForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getTransactionsRequestsBreakdownForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }

        var TransactionsRequestsBreakdown = "select \"time\", mean(\"ResponseSize\") as \"ResponseSize\", mean(\"ResponseTime\") as \"ResponseTime\", count(\"isSuccessful\") as \"TotalRequests\" from TransactionsSubResults where RunID='" + testrunid + "' group by URL fill(none)";

        influx.query(TransactionsRequestsBreakdown)
            .then((result) => {
                console.log("----------getTransactionsRequestsBreakdownForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getTransactionsRequestsBreakdownSuccessfulForID(testrunid, aggregationInterval) {
    return new Promise(function (callback, reject) {
        console.log("-----getTransactionsRequestsBreakdownSuccessfulForID()------");
        var interval = 1;
        if (aggregationInterval) {
            interval = aggregationInterval;
        }
        //select time, mean(ResponseSize) as ResponseSize, mean(ResponseTime) as ResponseTime, count(isSuccessful) as TotalRequests from TransactionsSubResults where RunID='5d6f89153dce4e2f7c93ea32' and isSuccessful=true group by URL;
        var TransactionsRequestsBreakdownSuccessful = "select \"time\",  count(\"isSuccessful\") as \"SuccessfulRequests\" from TransactionsSubResults where RunID='" + testrunid + "' and isSuccessful=true group by URL fill(none)";

        influx.query(TransactionsRequestsBreakdownSuccessful)
            .then((result) => {
                console.log("----------getTransactionsRequestsBreakdownSuccessfulForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function formatTransactionsRequestsBreakdownData(Data, DataSuccessful) {
    console.log("-----formatTransactionsRequestsBreakdownData()------");
    //console.log("Data length:"+Data.length);
    if (Data.length > 0) {
        /* var formattedData = [];
        var groupByName = {};
    
        Data.forEach((obj) => {
          groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
          groupByName[obj.TransactionName].push(obj);
        });
        //console.log(JSON.stringify(groupByName));
        let transcationNames = Object.keys(groupByName);
        let series, seriesVal;
        for (var iName = 0; iName < transcationNames.length; iName++) {
          series = [];
          //console.log(JSON.stringify(groupByName[transcationNames[iName]]));
          for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
            seriesVal = {
              name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
              value: groupByName[transcationNames[iName]][vi].totalcount,
            };
            series.push(seriesVal);
          }
          //console.log(JSON.stringify(series));
          formattedData.push({ name: transcationNames[iName], series: series });
        }
        return formattedData; */

        /*  [
           {
               "time": "1970-01-01T00:00:00.000Z",
               "ResponseSize": 194948.92307692306,
               "ResponseTime": 1131.1153846153845,
               "TotalRequests": 26,
               "URL": "http://ec2-18-191-165-66.us-east-2.compute.amazonaws.com:8080/SpringMVCHibernateCRUD/"
           }
         ] */
        Data.forEach((obj) => {
            //parseFloat(String(obj.avg)).toFixed(0)
            obj.ResponseTime = parseFloat(String(obj.ResponseTime)).toFixed(0);
            obj.ResponseSize = parseFloat(String(obj.ResponseSize)).toFixed(0);//parseFloat(Math.round(obj.ResponseSize * 100) / 100).toFixed(2);
        });

        if (DataSuccessful.length > 0) {
            Data.forEach((obj) => {
                DataSuccessful.forEach((obj1) => {
                    if (obj.URL === obj1.URL) {
                        obj.passcount = Number(obj1.SuccessfulRequests);
                        obj.failcount = Number(obj.TotalRequests) - Number(obj1.SuccessfulRequests);
                    }
                });
                if (!obj.hasOwnProperty("passcount")) {
                    obj.passcount = 0;
                }
                if (!obj.hasOwnProperty("failcount")) {
                    obj.failcount = 0;
                }
            });
        } else {
            Data.forEach((obj) => {
                obj.passcount = 0;
                obj.failcount = 0;
            });
        }

        return Data;
    } else {
        let sample = [];
        return sample;
        //console.log("formatTransactionsRequestsBreakdownData Data length:" + Data.length);
    }

}

function getAssertionResultsRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getAssertionResultsRawDataForID()------");
        var responseTimeQuery = "select * from AssertionResults where RunID = '" + testrunid + "'";
        // select * from AssertionResults where RunID = '" + testrunid + "'
        // select * from ClientSideMetrics where RunID = '" + testrunid + "'
        // select * from RequestMetrics where RunID = '" + testrunid + "'
        // select * from ThreadGroupData where RunID = '" + testrunid + "'
        // select * from Transactions where RunID = '" + testrunid + "'
        // select * from TransactionsSubResults where RunID = '" + testrunid + "'
        // select * from VUsers where RunID = '" + testrunid + "'
        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getAssertionResultsRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getClientSideMetricsRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getClientSideMetricsRawDataForID()------");
        var responseTimeQuery = "select * from ClientSideMetrics where RunID = '" + testrunid + "'";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getClientSideMetricsRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getRequestMetricsRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getRequestMetricsRawDataForID()------");
        var responseTimeQuery = "select * from RequestMetrics where RunID = '" + testrunid + "'";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getRequestMetricsRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getThreadGroupDataRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getThreadGroupDataRawDataForID()------");
        var responseTimeQuery = "select * from ThreadGroupData where RunID = '" + testrunid + "'";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getThreadGroupDataRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getTransactionsRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getTransactionsRawDataForID()------");
        var responseTimeQuery = "select * from Transactions where RunID = '" + testrunid + "'";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getTransactionsRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getTransactionsSubResultsRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getTransactionsSubResultsRawDataForID()------");
        var responseTimeQuery = "select * from TransactionsSubResults where RunID = '" + testrunid + "'";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getTransactionsSubResultsRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

function getVUsersRawDataForID(testrunid) {
    return new Promise(function (callback, reject) {
        console.log("-----getVUsersRawDataForID()------");
        var responseTimeQuery = "select * from VUsers where RunID = '" + testrunid + "'";

        influx.query(responseTimeQuery)
            .then((result) => {
                console.log("----------getVUsersRawDataForID-----------")
                //console.log(JSON.stringify(result));
                //return(result);
                callback(result);
            })
            .catch(error => reject({ error }));
    });
}

async function getTomcatLogs(indexName, gteString, lteString, testrunid) {
    // async function getESLogsData(indexName, hostName, gteString, lteString, testrunid, docsLimit) {
    try {

        console.log("-----getTomcatLogs()------");
        const ESresponsecount = await elasticClient.count({
            index: indexName,
            body: {
                "query": {
                    "bool": {
                        // "must": [
                        //     {
                        //         "match": {
                        //             "host": hostName
                        //         }
                        //     }
                        // ],
                        "must": [
                            {
                                "match": {
                                    "testrunid": testrunid
                                }
                            }
                        ],
                        "filter": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": gteString,
                                        "lt": lteString
                                    }
                                }
                            }
                        ]
                    }
                }
            }
        });
        // console.log("--------------------ESresponsecount------------------------------");
        // console.log(ESresponsecount);
        // console.log("-----------------------------------------------------------------");
        // {
        //     count: 290,
        //     _shards: { total: 1, successful: 1, skipped: 0, failed: 0 }
        // }
        let DocsCount = ESresponsecount.count;

        let Logs = [];
        if (DocsCount > 0) {
            const ESresponse = await elasticClient.search({
                index: indexName,
                body: {

                    "size": DocsCount,//docsLimit,//4000,
                    "query": {
                        "bool": {
                            /* "must": [
                                {
                                    "match": {
                                        "host": hostName
                                    }
                                }
                            ], */
                            "must": [
                                {
                                    "match": {
                                        "testrunid": testrunid
                                    }
                                }
                            ],
                            "filter": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": gteString,
                                            "lt": lteString
                                        }
                                    }
                                }
                            ]
                        }

                    }/* ,
                    "_source": {
                        "includes": ["id", "post_date"]
                    } */,
                    "sort": [
                        {
                            "@timestamp": {
                                "order": "desc"
                            }
                        }
                    ]
                }
            });
            let Hits = ESresponse.hits.hits;
            if ((Hits != null) || (Hits != undefined) || (Hits != [])) {
                if (indexName == "apachelogs-stderr") {
                    Hits.forEach((hit) => {
                        let Obj = {
                            indexName: hit._index,
                            hostName: hit._source.host,
                            message: hit._source.message,
                            logtype: hit._source.logtype,
                            datetime: hit._source.date + " " + hit._source.time,
                            log: hit._source.log,
                        };

                        if ((Obj.logtype == "WARNING") || (Obj.logtype == "ERROR") || (Obj.logtype == "FATAL")) {
                            Logs.push(Obj);
                        }
                    });
                } else {
                    Hits.forEach((hit) => {
                        let Obj = {
                            indexName: hit._index,
                            hostName: hit._source.host,
                            message: hit._source.message,
                        };
                        Logs.push(Obj);
                    });
                }
            }
        }

        return Logs;
        //return res.status(200).json(Logs);
    } catch (error) {
        // console.log(error.message);
        console.log(error.message);
        return error.message;
        //return res.status(500).json(error.message);
    }
}

//getObservations("5bfd43bf3200be0edc57a965");
//5bfd43bf3200be0edc57a965 
//analyze();


function updateFileSystem(testRunID, testResult) {
    return new Promise(function (callback, reject) {
        console.log("-----updatedFileSystem()------");
        var bsonID = mongodb.ObjectID(testRunID);
        let updateTestRun = {};
        updateTestRun.status = "Analysed";
        testResult.influxRawData={};
        updateTestRun.testResult = testResult;
        updateTestRun.testGroups = []; //ATD
        console.log("updateAnalysedTestRunDoc status:: " + updateTestRun.status);

        try {//temporary 
            let testRunDocDir = config.mongodocsFSPath + "testruns/" + testRunID;

            if (!fs.existsSync(testRunDocDir)) {
                fs.mkdirSync(testRunDocDir);
            }
            let testRunDocPath = testRunDocDir + "/" + testRunID + ".json";
            //temporary
            fs.writeFileSync(testRunDocPath, JSON.stringify(updateTestRun));
            var testRunDocStats = fs.statSync(testRunDocPath);
            console.log('Test Run Doc File Size in Bytes-' + testRunDocStats.size);
            if (testRunDocStats.size > 15000000) {//check > 15Mb

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_transactions.json", JSON.stringify(testResult.transactions));
                testResult.transactions.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_responseTime.json", JSON.stringify(testResult.responseTime));
                testResult.responseTime.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_vUsers.json", JSON.stringify(testResult.vUsers));
                testResult.vUsers.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_vUsersByThreadGroups.json", JSON.stringify(testResult.vUsersByThreadGroups));
                testResult.vUsersByThreadGroups.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_throughput.json", JSON.stringify(testResult.throughput));
                testResult.throughput.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_hits.json", JSON.stringify(testResult.hits));
                testResult.hits.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_error.json", JSON.stringify(testResult.error));
                testResult.error.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_errorsPerTranscationData.json", JSON.stringify(testResult.errorsPerTranscationData));
                testResult.errorsPerTranscationData.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_latency.json", JSON.stringify(testResult.latency));
                testResult.latency.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_statuscodes.json", JSON.stringify(testResult.statuscodes));
                testResult.statuscodes.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_assertionerrors.json", JSON.stringify(testResult.assertionerrors));
                testResult.assertionerrors.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_TransactionsRequestsBreakdown.json", JSON.stringify(testResult.TransactionsRequestsBreakdown));
                testResult.TransactionsRequestsBreakdown.data = [];

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_serverMetrics.json", JSON.stringify(testResult.serverMetrics));
                testResult.serverMetrics.data = {
                    cpu_data: [],
                    processor_data: [],
                    memory_data: []
                };

                fs.writeFileSync(testRunDocDir + "/" + testRunID + "_TomcatLogs.json", JSON.stringify(testResult.TomcatLogs));
                testResult.TomcatLogs = {
                    stdoutLogs: [],
                    stderrLogs: []
                };

                /* let testResult = {
                  panelsummary: {
                    data: panelSummaryData.panelSummary,
                    responsetimehealth: {
                      value: FormattedSummaryData.responsetime.statusCardsvalue,
                      TxCount: FormattedSummaryData.responsetime.TxCount,
                    },
                    transactionhealth: {
                      value: panelSummaryData.transaction.statusCardsvalue,
                      TxCount: panelSummaryData.transaction.TxCount,
                    }
                  },
                  errorsPerTranscationData: {
                    data: panelSummaryData.errorsPerTranscationData,
                  },
                  stackedbarchartdata: {
                    data: panelSummaryData.stackedbarchartdata,
                  },
                  summary: {
                    data: summaryData,
                    observations: summaryObservation
                  },
                  transactions: {
                    rawData: dummysamples,
                    data: formatTransactionsData(transactions),
                    observations: transactionsObservation
                  },
                  responseTime: {
                    rawData: dummysamples,
                    data: formatResponseTimeData(responseTime),
                    observations: responseTimeObservation
                  },
                  vUsers: {
                    rawData: dummysamples,
                    data: formatVUsersData(vUsers),
                    observations: vUsersObservation
                  },
                  vUsersByThreadGroups: {
                    rawData: dummysamples,
                    data: formatVUsersByThreadGroupsData(vUsersByThreadGroups),
                    observations: vUsersByThreadGroupsObservation
                  },
                  throughput: {
                    rawData: dummysamples,
                    data: formatThroughputData(throughput),
                    observations: throughputObservation
                  },
                  hits: {
                    rawData: dummysamples,
                    data: formatHitsPerSecondData(hits),
                    observations: hitsObservation
                  },
                  error: {
                    rawData: dummysamples,
                    data: formatErrorCountsData(error),
                    observations: errorObservation
                  },
                  latency: {
                    rawData: dummysamples,
                    data: formatLatencyData(latency),
                    observations: latencyObservation
                  },
                  statuscodes: {
                    rawData: dummysamples,
                    data: formatStatusCodesData(statuscodes),
                    observations: statuscodesObservation
                  },
                  assertionerrors: {
                    rawData: dummysamples,
                    data: formatAssertionFailureData(assertionFailures),
                  },
        
                  TransactionsRequestsBreakdown: {
                    rawData: dummysamples,
                    data: formatTransactionsRequestsBreakdownData(TransactionsRequestsBreakdown, TransactionsRequestsBreakdownSuccessful),
                  },
                  observations: observations,
                  serverMetrics: {
                    data: serverMetrics,
                    observations: []
                  },
                  influxRawData: {
                    AssertionResults: AssertionResultsRawData,
                    ClientSideMetrics: ClientSideMetricsRawData,
                    RequestMetrics: RequestMetricsRawData,
                    ThreadGroupData: ThreadGroupDataRawData,
                    Transactions: TransactionsRawData,
                    TransactionsSubResults: TransactionsSubResultsRawData,
                    VUsers: VUsersRawData
                  },
                  TomcatLogs: {
                    stdoutLogs: stdoutLogs,
                    stderrLogs: stderrLogs
                  }
                }; */


                callback(testResult);
            } else {
                //temporary
                console.log("removing files");
                // fs.unlinkSync(testRunDocPath);//remove file
                // fs.rmdirSync(testRunDocDir);
                callback(testResult);
            }
        } catch (err) {
            console.log(err);
            reject(testResult);
        }
    });
}

module.exports = router;