var config = require('../configuration.json');

var Request = require("request");

var amqp = require('amqplib/callback_api');

var path = require('path');
var rfs = require("rotating-file-stream");
var stdoutLogStream = rfs(config.workerLogFile, {//'stdout_heartbeat.log', {
  size: config.logFileSize,//"10M",
  interval: config.logFileInterval,//"1d",
  path: config.scriptLogPath,//path: 'C:/ZantMeter/SourceCode/Node-SourceCode/ZantmeterNodeServer_Oct302108/server/logs/',//path.join(__dirname, '/logs/'),
  //compress: "gzip" 
});

var fs = require('fs');
function Logger(content) {
  try {
    console.log(content);
    //fs.appendFile('C:/ZantMeter/SourceCode/Node-SourceCode/ZantmeterNodeServer_Oct302108/server/logs/stdout_heartbeat.log', content + "\r\n", function (err) {
    fs.appendFile(config.scriptLogPath + config.workerLogFile, content + "\r\n", function (err) {
      if (err) throw err;
    });
  } catch (e) {
    console.log("Error in Logger " + e);
  }
}


let validationRoute = require('./validation.js');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let loadSimualtionDb;
MongoClient.connect(dbURL, function (err, mydb) {
  if (err) {
    console.log("worker.js : ERROR: DB connection failed using mongodb");
    //Logger('worker.js : ERROR: DB connection failed using mongodb');
    return err;
  } else {
    loadSimualtionDb = mydb.db();
    console.log('worker.js : DB connection established using mongodb!');
    //Logger('worker.js : DB connection established using mongodb!');
  }
});

const Influx = require('influx');
// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://' + config.influxDBUserName + ':' + config.influxDBPassword + '@' + config.influxDBHost + ':8086/zantmeter');

const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));


var elasticsearch = require('elasticsearch');
var elasticClient = new elasticsearch.Client({
  host: 'http://' + config.elasticsearchDBHost + ':9200',
  log: 'trace'
});
elasticClient.ping({
  requestTimeout: 30000,
}, function (error) {
  if (error) {
    console.log('devAPI.js : ERROR: Elasticsearch DB Connection failed !');
  } else {
    console.log('devAPI.js : Connection to ElasticSearch DB established !');
  }
});


// amqp.connect('amqp://' + config.RabbitMQHost, async function (err, conn) {
amqp.connect('amqp://' + config.RabbitMQUserName + ':' + config.RabbitMQPassword + '@' + config.RabbitMQHost + ':5672', async function (err, conn) {
  if (err !== null) { Logger(err); }
  await conn.createChannel(async function (err1, ch) {
    if (err1 !== null) { Logger(err1); }
    ch.assertQueue(config.queueName, { durable: true });
    ch.prefetch(1);
    Logger(" [*] Waiting for messages in %s. To exit press CTRL+C", config.queueName);

    MongoClient.connect(dbURL, function (err2, mydb) {
      if (err2) {
        Logger('worker.js : ERROR: DB connection failed using mongodb');
        Logger(err2);
        //return err2;
      } else {
        db = mydb.db();
        Logger('worker.js : DB connection established using mongodb!');
      }
    });
    await ch.consume(config.queueName, async function (msg) {

      console.log(" [x] Received %s", msg.content.toString());
      Logger(" [x] Received ");
      Logger(msg.content.toString());
      //let jsonResponseArray = await stopFinalThreadGroup(data.testrunid, data.threadgroupname);
      let jsonResponseArray = await stopFinalThreadGroupService(JSON.parse(msg.content.toString()));
      //Logger(data.testrunid + " - " + data.threadgroupname + " Stopped");
      Logger(" [x] Done " + jsonResponseArray);
      ch.ack(msg);
    }, { noAck: false });
  });
});

//Stop Final Thread Group
function stopFinalThreadGroupService(data) {
  Logger("-----worker/stopFinalThreadGroupService()------");
  return new Promise(async function (callback, reject) {
    try {
      if (data) {
        let testrunid = data.testrunid;
        let threadgroupname = data.threadgroupname;
        if (typeof testrunid === "undefined" || testrunid == null || testrunid == "" || validationRoute(testrunid)) {
          Logger("Test Run ID not exists");
          reject({
            'status': 'ERROR',
            "error": 'Test Run ID is missing'
          });
        }

        if (typeof threadgroupname === "undefined" || threadgroupname == null || threadgroupname == "" || validationRoute(threadgroupname)) {
          Logger("Thread Group Name not exists");
          reject({
            'status': 'ERROR',
            "error": 'Thread Group Name is missing'
          });
        }
        let jsonResponseArray = await stopFinalThreadGroup(testrunid, threadgroupname);
        callback(jsonResponseArray);
        /* let hostURL = "http://localhost:5000";
        //let hostURL = "https://cpcinchdv000849.cts.com";

        let URL = hostURL + "/stopTGAPI/stopFinalThreadGroup?testrunid=" + testrunid + "&threadgroupname=" + threadgroupname;
        Logger(URL);
        let options;
        if (URL.includes("https://")) {
          options = {
            url: URL,
            agentOptions: {
              // cert: fs.readFileSync(certFile),
              // key: fs.readFileSync(keyFile),
              // Or use `pfx` property replacing `cert` and `key` when using private key, certificate and CA certs in PFX or PKCS12 format:
              // pfx: fs.readFileSync(pfxFilePath),
              pfx: fs.readFileSync('../../security/cpcinchdv000849.cts.com.pfx'),//fs.readFileSync('./security/zantmeter.cognizant.com.pfx'),
              passphrase: 'Password1$',
              securityOptions: 'SSL_OP_NO_SSLv3'
            }
          };
        } else {
          options = {
            url: URL,
          };
        }

        //await Request.get(URL, (error, response, body) => {
        await Request.get(options, (error, response, body) => {
          if (error) {
            console.error(error);
            reject({
              'status': 'ERROR',
              'message': error
            });

          }
          Logger(body);
          Logger(testrunid + " - " + threadgroupname + " Stopped");
          callback(body);
        }); */
        /* 
        callback(testrunid + " - " + threadgroupname + " Stopped"); */
      }
    } catch (e) {
      Logger("Error in worker/stopFinalThreadGroupService " + e);
      reject({
        'status': 'ERROR',
        'message': e
      });
    }
  });
}



//stopFinalThreadGroup
async function stopFinalThreadGroup(testRunID, threadgroupname) {
  Logger("-----stopTGAPI/stopFinalThreadGroup()------");
  //await 
  if (!testRunID) {
    return ({ 'status': 'error', 'message': 'testRunID missing !' });
  }

  if (!threadgroupname) {
    return ({ 'status': 'error', 'message': 'threadgroupname missing !' });
  }
  /* let min = 1000, max = 3000;
  let random = Math.floor(Math.random() * (max - min + 1)) + min;
  await sleep(random); */
  try {
    const testRunResponse = await getTestRunDoc(testRunID);

    /*  random = Math.floor(Math.random() * (max - min + 1)) + min;
     await sleep(random); */

    let responseMessage, updateTestRunDocResponse;
    //Logger("testRunResponse"+JSON.stringify(testRunResponse));
    if (testRunResponse.status == 'SUCCESS') {
      let testRunDoc = testRunResponse.message;
      let RAWenabled = false;
      if (testRunDoc.hasOwnProperty("RAWenabled")) {
        RAWenabled = testRunDoc.RAWenabled;
      }
      //if (testRunDoc.status == 'Running') {//Analysed//Analyzing
      if (testRunDoc.status == 'Running') {
        var loadAgentNames = {};
        let TestRunOverallStatus = true;
        let LoadAgentResponse;
        let testRunDocStatus = testRunDoc.status;
        for (var i = 0; i < testRunDoc.testGroups.length; i++) {
          if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].testGroupName === threadgroupname)) {
            testRunDoc.testGroups[i].status = "Stopped";
            itemp = i;
            responseMessage = {
              'testGroupName': threadgroupname,
              'status': 'STOPPED'
            }
          } else if ((testRunDoc.testGroups[i].enabled) & (testRunDoc.testGroups[i].status === "Running")) {
            TestRunOverallStatus = false;
          }
          if (testRunDoc.testGroups[i].enabled) {
            var loadAgent = testRunDoc.testGroups[i].loadAgent;
            if (loadAgent.type == "CloudAuto") {
              //let query = { 'CloudAutoLA_ID': loadAgent.CloudAutoLA_ID.toString(), 'instanceID': loadAgent.instanceID.toString() };
              LoadAgentResponse = await getLoadAgentDoc(String(loadAgent.CloudAutoLA_ID), String(loadAgent.instanceID));
              if (LoadAgentResponse.status == 'SUCCESS') {
                var LoadAgentDoc = LoadAgentResponse.message;
                //Logger(JSON.stringify(LoadAgentDoc));
                loadAgentNames[LoadAgentDoc.hostName] = { code: LoadAgentDoc.region, instanceID: LoadAgentDoc.instanceID, type: loadAgent.type, _id: LoadAgentDoc._id };
              } else {
                console.error(LoadAgentResponse);
              }
            } else {
              loadAgentNames[loadAgent.loadAgentName] = { type: loadAgent.type };
            }
          }
        }
        /* if (testRunDoc.status === "Analysed") {
            TestRunOverallStatus = false;
        } */

        var loadAgents = Object.keys(loadAgentNames);
        Logger('Load agents length : ' + loadAgents.length);

        await sleep(500);

        //Logger('testRunDoc : ' + JSON.stringify(testRunDoc.testGroups[itemp]));
        Logger('testRunID : ' + testRunID);
        updateTestRunDocResponse = await updateTestRunDocument(testRunID, testRunDoc);

        await sleep(500);

        Logger('updateTestRunDocResponse : ' + JSON.stringify(updateTestRunDocResponse));
        Logger('threadgroupname : ' + threadgroupname + ', testRunDocStatus : ' + testRunDocStatus + ', TestRunOverallStatus : ' + TestRunOverallStatus);
        if (TestRunOverallStatus) {
          //if (testRunDocStatus == "Running") {
          updateTestRunDocResponse = await updateTestRunEnded(testRunDoc, testRunID);
          //Logger(updateTestRunEndedResponse.status);
          //}

          Logger('----Terminating Load agents----');
          for (var i = 0; i < loadAgents.length; i++) {
            if (loadAgentNames[loadAgents[i]].type == "CloudAuto") {
              //Logger('Terminating Load agent : ' + loadAgents[i]);
              var region = loadAgentNames[loadAgents[i]].code,
                LoadAgentDocID = loadAgentNames[loadAgents[i]]._id,
                instanceID = loadAgentNames[loadAgents[i]].instanceID;
              if ((region) && (instanceID) && (LoadAgentDocID)) {
                const getLARegionDocResponse = await getLARegionDocByRegion(region);
                if (getLARegionDocResponse.status == 'SUCCESS') {
                  var LARegionDoc = getLARegionDocResponse.message;
                  var regionCode = config.defaultRegionCode;//"ap-south-1";;
                  if (LARegionDoc === null || LARegionDoc === undefined || LARegionDoc === "") {
                    regionCode = region;
                  } else {
                    regionCode = LARegionDoc.code;
                  }
                  const terminateLoadAgentResponse = await terminateLoadAgent(instanceID, regionCode);

                  if (terminateLoadAgentResponse.status == 'TERMINATED') {
                    var LoadAgentDoc = LoadAgentResponse.message;
                    const deleteLoadAgentResponse = await deleteLoadAgentDoc(LoadAgentDocID);
                  }
                  //Logger(terminateLoadAgentResponse);
                } else {
                  console.error(LoadAgentResponse);
                }
              }
            }
          }
          //analyse test run

          var aggregationInterval = 1;
          try {
            //if (testRunDocStatus !== "Analysed") {
            await sleep(500);
            updateTestRunDocResponse = await analyzeTestRun(testRunID, aggregationInterval, RAWenabled);
            //}
          } catch (e) {
            Logger("Error stopTGAPI/analyzeTestRun " + e);
            updateTestRunDocResponse = {
              "error": e
            };
          }

        }

        if (TestRunOverallStatus) {//((TestRunOverallStatus) && (testRunDocStatus !== "Analysed")) {
          return updateTestRunDocResponse;
        } else {
          return responseMessage;
        }
      } else {
        console.error(testRunResponse);
        return ({ 'status': 'error', 'message': 'testRunID is already !' });
      }
    } else {
      console.error(testRunResponse);
      return ({ 'status': 'error', 'message': 'testRunID is wrong !' });
    }
  } catch (e) {
    Logger("Error in stopTGAPI/stopFinalThreadGroup " + e);
    return ({ 'status': 'error', 'message': 'testRun has error !' });
  }
}

//Get Test Run Document
function getTestRunDoc(testRunID) {
  Logger("-----stopTGAPI/getTestRunDoc()------");
  return new Promise(function (callback, reject) {
    try {
      if (testRunID) {
        //Logger("testRunID:" + testRunID);
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection('TestRuns').findOne({ "_id": bsonID }, function (err, record) {
          if (err) {
            Logger(err);
            callback({
              'status': 'ERROR',
              'message': err
            });
          }
          //Logger("record:"+record);
          callback({
            'status': 'SUCCESS',
            'message': record
          });
        });
      }
    } catch (e) {
      Logger("Error in stopTGAPI/getTestRunDoc " + e);
      callback({
        'status': 'ERROR',
        'message': e
      });
    }
  });
}

//Get Load Agent Document
function getLoadAgentDoc(CloudAutoLA_ID, instanceID) {
  Logger("-----stopTGAPI/getLoadAgentDoc()------");
  return new Promise(function (callback, reject) {
    try {
      if ((CloudAutoLA_ID) && (instanceID)) {
        let query = { 'CloudAutoLA_ID': parseInt(CloudAutoLA_ID), 'instanceID': String(instanceID) };
        db.collection("LoadAgents").findOne(query, function (err, record) {
          if (err) {
            Logger(err);
            callback({
              'status': 'ERROR',
              'message': err
            });
          }
          Logger(record);
          callback({
            'status': 'SUCCESS',
            'message': record
          });
        });
      }
    } catch (e) {
      Logger("Error in stopTGAPI/getLoadAgentDoc " + e);
      callback({
        'status': 'ERROR',
        'message': e
      });
    }
  });
}

//Update Test Run Document
function updateTestRunDocument(testRunID, values) {
  Logger("-----stopTGAPI/updateTestRunDocument()------");
  try {
    if ((typeof testRunID === "undefined" || testRunID == null || testRunID == "") || (typeof values === "undefined" || values == null || values == "")) {
      Logger("Test Run ID not exists");
      return ({
        'status': 'ERROR',
        'message': 'test run id or values are missing'
      });
    }

    let newval = { $set: values }
    let bsonID = mongodb.ObjectID(testRunID);
    return new Promise(function (callback, reject) {
      db.collection("TestRuns").update({ "_id": bsonID }, newval, function (err, result) {

        //db.collection("TestRuns").findAndModify({ "_id": bsonID }, newval, function (err, result) {
        if (err) {
          Logger(err);
          reject({
            'status': 'ERROR',
            'message': err
          });
        } else {
          //Logger("record: " + result);
          callback({
            'status': 'SUCCESS',
            'message': result
          });
        }
      });
    });
  } catch (e) {
    Logger("Error in stopTGAPI/updateTestRunDocument " + e);
    return ({
      'status': 'ERROR',
      'message': e
    });
  }
}

//Update TestRun Status as Ended
function updateTestRunEnded(record, testRunID) {
  Logger("-----stopTGAPI/updateTestRunEnded()------");
  return new Promise(function (callback, reject) {
    try {
      if (testRunID) {
        var nowDate = new Date();
        var endDate = nowDate.toISOString();
        var duration = new Date(endDate) - new Date(record.startTime);
        let status = {
          status: "Ended",
          endTime: endDate,
          duration: duration
        };

        var newval = { $set: status }
        var bsonID = mongodb.ObjectID(testRunID);
        db.collection("TestRuns").update({ "_id": bsonID }, newval, function (err, result) {
          if (err) {
            Logger("Error in stopTGAPI/updateTestRuns : " + err);
            callback({
              'status': 'error',
              'message': err
            });
          }
          callback({
            'status': 'updated',
            'message': result
          });
        });
      }
    } catch (e) {
      Logger("Error in stopTGAPI/updateTestRunEnded " + e);
      return e;
    }
  });
}

//Get LARegion ByRegion Document
function getLARegionDocByRegion(region) {
  Logger("-----stopTGAPI/getLARegionDocByRegion()------");
  return new Promise(function (callback, reject) {
    try {
      if (region) {
        let query = { 'region': region };
        db.collection("LARegions").findOne(query, function (err, record) {
          if (err) {
            Logger(err);
            callback({
              'status': 'ERROR',
              'message': err
            });
          }
          callback({
            'status': 'SUCCESS',
            'message': record
          });
        });
      }
    } catch (e) {
      Logger("Error in stopTGAPI/getLARegionDoc " + e);
      callback({
        'status': 'ERROR',
        'message': e
      });
    }
  });
}

//Terminate Load Agent
function terminateLoadAgent(instanceID, regionCode) {
  Logger("-----stopTGAPI/terminateLoadAgent()------");
  return new Promise(function (callback, reject) {
    try {
      if ((instanceID) && (regionCode)) {
        var awsServer = config.lambdaAWSServer;
        var URL = "https://" + awsServer + "/EC2/terminateec2?instanceID=" + instanceID + "&region=" + regionCode;
        //Logger(URL);
        Request.get(URL, (error, response, body) => {
          if (error) {
            console.error(error);
            callback({
              'status': 'ERROR',
              'message': error
            });
          }
          Logger(body);
          callback({
            'status': 'TERMINATED',
            'message': body
          });
        });
      }
    } catch (e) {
      Logger("Error in stopTGAPI/terminateLoadAgent " + e);
      callback({
        'loadagentname': hostName,
        'status': 'ERROR',
        'message': e
      });
    }
  });
}

//Delete Load Agent Document
function deleteLoadAgentDoc(loadAgentid) {
  Logger("-----stopTGAPI/deleteLoadAgentDoc()------");
  return new Promise(function (callback, reject) {
    try {
      if (loadAgentid) {
        var bsonID = mongodb.ObjectID(loadAgentid);
        db.collection('LoadAgents').deleteOne({ "_id": bsonID }, function (err, records) {
          if (err) {
            Logger(err);
            callback({
              'status': 'ERROR',
              'message': err
            });
          } else {
            callback({
              'status': 'SUCCESS',
              'message': 'Deleted Load Agent'
            });
          }
        });
      }
    } catch (e) {
      Logger("Error in stopTGAPI/deleteLoadAgentDoc " + e);
      callback({
        'status': 'ERROR',
        'message': e
      });
    }
  });
}

async function analyzeTestRun(testRunID, aggregationInterval, RAWenabled) {

  Logger("-----stopTGAPI/analyzeTestRun()------");
  //await 
  if (!testRunID) {
    return ({ 'status': 'error', 'message': 'testRunID missing !' });
  }
  let duration = 0;
  let setStatusTestRun = null;

  setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
  //Logger(setStatusTestRun.result);
  let counter = 0;
  while (duration == null || duration == 0) {
    if (counter > 3) {
      break;
    }
    await sleep(1000);
    counter++;
    if (setStatusTestRun.result.nModified != 1) {
      setStatusTestRun = await updateTestRunStatus(testRunID, "Analyzing");
      //Logger(setStatusTestRun.result);
    }
    duration = await getTestRunDuration(testRunID);
  }
  try {
    console.log(" -------licenseValue in worker--------- ");
    //console.log(" duration "+duration)
    var durationInMin = duration / 60000;
    var licenseValue = await getLicenseVerification(testRunID, durationInMin);
  } catch (error) {
    console.log("Error in  license decrement in load simulator ");
    console.log(error);
  }
  aggregationInterval = getAggregationIntervalByDuration(duration, aggregationInterval);

  await sleep(1000);
  let summary = await getSummary(testRunID);

  await sleep(1000);
  let transactions = await getTransactionsForID(testRunID, aggregationInterval);

  await sleep(1000);
  let responseTime = await getResponseTimeForID(testRunID, aggregationInterval);

  await sleep(1000);
  let vUsers = await getRunningVUsersForID(testRunID, aggregationInterval);

  await sleep(1000);
  let vUsersByThreadGroups = await getVUsersByThreadGroupsForID(testRunID, aggregationInterval);

  await sleep(1000);
  let throughput = await getThroughputBytesPerSecondForID(testRunID, aggregationInterval);

  await sleep(1000);
  let hits = await getHitsPerSecondForID(testRunID, aggregationInterval);

  await sleep(1000);
  let error = await getErrorCountsForID(testRunID, aggregationInterval);

  await sleep(1000);
  let latency = await getLatencyForID(testRunID, aggregationInterval);

  await sleep(1000);
  let statuscodes = await getStatusCodesListForID(testRunID, aggregationInterval);

  await sleep(1000);
  let assertionFailures = await getAssertionFailureResultsForID(testRunID, aggregationInterval);

  let observations = "";

  if (duration > 600000) {//>10mins
    //observations = await getObservations(testRunID, aggregationInterval);//commenting R code
  }

  await sleep(1000);
  let summaryObservation = [], transactionsObservation = [], responseTimeObservation = [], vUsersObservation = [], throughputObservation = [], hitsObservation = [], errorObservation = [], vUsersByThreadGroupsObservation = [], latencyObservation = [], statuscodesObservation = [];

  if (observations !== null && observations !== undefined && observations !== "") {

    let responseObservations = JSON.parse(observations);
    //Logger(responseObservations.msg);
    //responseObservations = null;//uncomment while commenting R code
    responseObservations = responseObservations.msg;
    if (responseObservations !== null && responseObservations !== undefined && responseObservations !== "") {
      for (let i = 0; i < responseObservations.length; i++) {
        switch (responseObservations[i].type) {
          case "Transactions": {
            transactionsObservation.push(responseObservations[i].observation);
            break;
          }
          case "Response Time": {
            responseTimeObservation.push(responseObservations[i].observation);
            break;
          }
          case "VUsers": {
            vUsersObservation.push(responseObservations[i].observation);
            break;
          }
          case "Throughput": {
            throughputObservation.push(responseObservations[i].observation);
            break;
          }
          case "Hits Per Second": {
            hitsObservation.push(responseObservations[i].observation);
            break;
          }
          case "Error": {
            errorObservation.push(responseObservations[i].observation);
            break;
          }
          case "vUsersByThreadGroups": {
            vUsersByThreadGroupsObservation.push(responseObservations[i].observation);
            break;
          }
          case "Latency": {
            latencyObservation.push(responseObservations[i].observation);
            break;
          }
          case "StatusCodes": {
            statuscodesObservation.push(responseObservations[i].observation);
            break;
          }
        }
      }
    }
  }

  let sla = await getTestRunSLA(testRunID);
  //Logger(JSON.stringify(formatResponseTimeData(responseTime)));
  let FormattedSummaryData = formatSummaryData(summary, sla);
  let summaryData = FormattedSummaryData.summary,
    VUsersData = formatVUsersData(vUsers);
  //Happens only when test does not stop and manual stop required
  if (typeof VUsersData === "undefined" || VUsersData == null) {
    VUsersData = [];
  }
  let panelSummaryData = formatPanelSummaryData(summaryData, VUsersData, duration);

  let TestRunDocument = await getTestRunDocument(testRunID);
  let systemMonitor = TestRunDocument.systemMonitor;
  let serverMetrics = {};
  if ((systemMonitor != undefined) && (systemMonitor != "") && (systemMonitor != null)) {
    if ((systemMonitor.enabled) && (systemMonitor.hasOwnProperty("machines"))) {
      serverMetrics = await getServerMetrics(systemMonitor.machines, TestRunDocument.startTime, TestRunDocument.endTime);
    }
  }

  let AssertionResultsRawData = [], ClientSideMetricsRawData = [], RequestMetricsRawData = [], ThreadGroupDataRawData = [], TransactionsRawData = [], TransactionsSubResultsRawData = [], VUsersRawData = [], stderrLogs = [], stdoutLogs = [], TransactionsRequestsBreakdown = [], TransactionsRequestsBreakdownSuccessful = [];


  if (RAWenabled) {

    await sleep(1000);
    TransactionsRequestsBreakdown = await getTransactionsRequestsBreakdownForID(testRunID, aggregationInterval);

    await sleep(1000);
    TransactionsRequestsBreakdownSuccessful = await getTransactionsRequestsBreakdownSuccessfulForID(testRunID, aggregationInterval);

    await sleep(1000);
    TransactionsRawData = await getTransactionsRawDataForID(testRunID);

    await sleep(1000);
    TransactionsSubResultsRawData = await getTransactionsSubResultsRawDataForID(testRunID);

    await sleep(1000);
    AssertionResultsRawData = await getAssertionResultsRawDataForID(testRunID);

    await sleep(1000);
    ClientSideMetricsRawData = await getClientSideMetricsRawDataForID(testRunID);

    await sleep(1000);
    RequestMetricsRawData = await getRequestMetricsRawDataForID(testRunID);

    await sleep(1000);
    ThreadGroupDataRawData = await getThreadGroupDataRawDataForID(testRunID);

    await sleep(1000);
    VUsersRawData = await getVUsersRawDataForID(testRunID);

    let gteString = TestRunDocument.startTime;//"now-1h"

    let lteString = "now";

    if (TestRunDocument.endTime !== null || TestRunDocument.endTime !== undefined || TestRunDocument.endTime !== "") {
      lteString = TestRunDocument.endTime;
    }
    await sleep(1000);
    stderrLogs = await getTomcatLogs("apachelogs-stderr", gteString, lteString, testRunID);

    if (!(stderrLogs instanceof Array)) {
      stderrLogs = [];
    }
    await sleep(1000);
    stdoutLogs = await getTomcatLogs("apachelogs-stdout", gteString, lteString, testRunID);

    if (!(stdoutLogs instanceof Array)) {
      stdoutLogs = [];
    }
  }
  let dummysamples = [],
    formattedThroughputData = formatThroughputData(throughput),
    formattedHitsPerSecondData = formatHitsPerSecondData(hits);
  panelSummaryData.panelSummary[4].value = formattedThroughputData.avgThroughput;
  panelSummaryData.panelSummary[5].value = formattedHitsPerSecondData.avgHitsPerSecond;

  let testResult = {
    panelsummary: {
      data: panelSummaryData.panelSummary,
      responsetimehealth: {
        value: FormattedSummaryData.responsetime.statusCardsvalue,
        TxCount: FormattedSummaryData.responsetime.TxCount,
      },
      transactionhealth: {
        value: panelSummaryData.transaction.statusCardsvalue,
        TxCount: panelSummaryData.transaction.TxCount,
      }
    },
    errorsPerTranscationData: {
      data: panelSummaryData.errorsPerTranscationData,
    },
    stackedbarchartdata: {
      data: panelSummaryData.stackedbarchartdata,
    },
    summary: {
      data: summaryData,
      observations: summaryObservation
    },
    transactions: {
      rawData: dummysamples,
      data: formatTransactionsData(transactions),
      observations: transactionsObservation
    },
    responseTime: {
      rawData: dummysamples,
      data: formatResponseTimeData(responseTime),
      observations: responseTimeObservation
    },
    vUsers: {
      rawData: dummysamples,
      data: formatVUsersData(vUsers),
      observations: vUsersObservation
    },
    vUsersByThreadGroups: {
      rawData: dummysamples,
      data: formatVUsersByThreadGroupsData(vUsersByThreadGroups),
      observations: vUsersByThreadGroupsObservation
    },
    throughput: {
      rawData: dummysamples,
      data: formattedThroughputData.throughputData,
      observations: throughputObservation
    },
    hits: {
      rawData: dummysamples,
      data: formattedHitsPerSecondData.hitsPerSecondData,
      observations: hitsObservation
    },
    error: {
      rawData: dummysamples,
      data: formatErrorCountsData(error),
      observations: errorObservation
    },
    latency: {
      rawData: dummysamples,
      data: formatLatencyData(latency),
      observations: latencyObservation
    },
    statuscodes: {
      rawData: dummysamples,
      data: formatStatusCodesData(statuscodes),
      observations: statuscodesObservation
    },
    assertionerrors: {
      rawData: dummysamples,
      data: formatAssertionFailureData(assertionFailures),
    },

    TransactionsRequestsBreakdown: {
      rawData: dummysamples,
      data: formatTransactionsRequestsBreakdownData(TransactionsRequestsBreakdown, TransactionsRequestsBreakdownSuccessful),
    },
    observations: observations,
    serverMetrics: {
      data: serverMetrics,
      observations: []
    },
    influxRawData: {
      AssertionResults: AssertionResultsRawData,
      ClientSideMetrics: ClientSideMetricsRawData,
      RequestMetrics: RequestMetricsRawData,
      ThreadGroupData: ThreadGroupDataRawData,
      Transactions: TransactionsRawData,
      TransactionsSubResults: TransactionsSubResultsRawData,
      VUsers: VUsersRawData
    },
    TomcatLogs: {
      stdoutLogs: stdoutLogs,
      stderrLogs: stderrLogs
    }
  };
  testResult = await updateFileSystem(testRunID, testResult);
  await sleep(1000);
  let updateTestRun = await updateAnalysedTestRunDoc(testRunID, testResult);

  await sleep(1000);
  return updateTestRun;

}

function getAggregationIntervalByDuration(duration, interval) {
  Logger("-----stopTGAPI/getAggregationIntervalByDuration()------");
  let aggregationInterval = 1;
  if ((interval != undefined) && (interval != null) && (interval > 0)) {
    aggregationInterval = interval;
  }
  if ((duration != undefined) && (duration != null)) {
    switch (true) {
      case (duration < 300000): {//<5mins
        aggregationInterval = 1;
        break;
      }
      case ((duration >= 300000) && (duration < 600000)): {//>=5mins <10mins
        aggregationInterval = 2;
        break;
      }
      case ((duration >= 600000) && (duration < 1800000)): {//>=10mins <30mins
        aggregationInterval = 5;
        break;
      }
      case ((duration >= 1800000) && (duration < 3600000)): {//>=30mins <60mins
        aggregationInterval = 10;
        break;
      }
      case ((duration >= 3600000) && (duration < 7200000)): {//>=60mins <120mins
        aggregationInterval = 15;
        break;
      }
      case ((duration >= 7200000) && (duration < 14400000)): {//>=120mins <240mins
        aggregationInterval = 30;
        break;
      }
      case ((duration >= 14400000)): {//>=240mins
        aggregationInterval = 60;
        break;
      }
    }
  }

  return aggregationInterval;
}

function formatPanelSummaryData(summaryData, VUsersData, duration) {
  Logger("-----stopTGAPI/formatPanelSummaryData()------");
  /* Logger("summaryData: "+JSON.stringify(summaryData));
  Logger("VUsersData: "+JSON.stringify(VUsersData));
  Logger("duration: "+JSON.stringify(duration)); */
  let errorsPerTranscationData = new Array(), stackedbarchartdata = [];
  let panelSummary = [
    { title: "Transactions", value: 0 },
    { title: "Duration", value: "00:00:00" },
    { title: "Max VUsers", value: 0 },
    { title: "Errors", value: 0 },
    { title: "Avg. Throughput", value: 0 },
    { title: "Avg. Hits", value: 0 }
  ];

  let errorcounts = 0, totalcounts = 0;

  summaryData.forEach((obj) => {
    obj._90percent = parseFloat(String((obj.passcount / obj.totalcount) * 90)).toFixed(2);
    obj.error = parseFloat(String((obj.errorcount / obj.totalcount) * 100)).toFixed(1);
    errorcounts = errorcounts + obj.errorcount;
    totalcounts = totalcounts + obj.totalcount;
    errorsPerTranscationData.push({ name: obj.TransactionName, value: obj.errorcount });
    let series = [];
    series.push({
      "name": "Response Time",
      "value": parseFloat(String(obj.avg)).toFixed(0)
    });
    /* series.push({
        "name": "Pass",
        "value": obj.passcount
    });
    series.push({
        "name": "Fail",
        "value": obj.errorcount
    }); */
    stackedbarchartdata.push({
      "name": obj.TransactionName,
      "series": series,
    });
  });

  /* summaryData.forEach((obj) => {
    errorsPerTranscationData.push({ name: obj.TransactionName, value: parseFloat(String((obj.errorcount / errorcounts) * 100)).toFixed(2) });
  }); */
  let overallerror_percentage = parseFloat(String((errorcounts / totalcounts) * 100)).toFixed(1);
  panelSummary[3].value = errorcounts + " ( " + overallerror_percentage + "% Overall error rate )";

  let stackedbarchartdata1 = stackedbarchartdata.sort((obj1, obj2) => {
    return obj2.series[0].value - obj1.series[0].value;
  });

  if (stackedbarchartdata1.length > 5) {
    stackedbarchartdata = stackedbarchartdata1.splice(0, 5);
  }

  panelSummary[0].value = summaryData.length;
  panelSummary[1].value = getHHmmssFromMilliseconds(duration);
  let values = [];
  if (VUsersData != undefined) {
    if (VUsersData[0].series != undefined) {
      if (VUsersData[0].series.length > 0) {
        for (var vi = 0; vi < VUsersData[0].series.length; vi++) {
          values.push(VUsersData[0].series[vi].value);
        }
      }
    }
  }

  let maxVUsers = 0;
  if (values.length > 0) {
    maxVUsers = Math.max(...values);
  }

  panelSummary[2].value = maxVUsers;


  let rCount = 0, aCount = 0, gCount = 0;
  summaryData.forEach((obj, index) => {
    //Logger(obj.error);
    switch (true) {
      case (obj.error < 2): {
        gCount++;
        break;
      }
      case ((obj.error >= 2) && (obj.error < 5)): {
        aCount++;
        break;
      }
      case ((obj.error >= 5)): {
        rCount++;
        break;
      }
    }
  });
  let statusCardsvalue_Tx = '', TxCount = 0;
  if ((rCount == 0) && (aCount == 0) && (gCount == 0)) {
    statusCardsvalue_Tx = "N/A";
  } else if (rCount == 0) {
    statusCardsvalue_Tx = "Pass";
  } else {
    statusCardsvalue_Tx = "Fail";
    TxCount = rCount;
  }


  let formatPanelSummaryData = {
    panelSummary: panelSummary,
    errorsPerTranscationData: errorsPerTranscationData,
    stackedbarchartdata: stackedbarchartdata,
    transaction: {
      statusCardsvalue: statusCardsvalue_Tx,
      TxCount: TxCount,
    },
  };

  return formatPanelSummaryData;
}

function getHHmmssFromMilliseconds(ms) {
  let date = new Date(null);
  var timeOffsetInMS = date.getTimezoneOffset() * 60000;
  ms = ms + timeOffsetInMS;
  date.setMilliseconds(ms);
  let result = date.toTimeString().substr(0, 8);
  //Logger(result);
  return result;
}

function getSummary(testrunid) {
  Logger("-----stopTGAPI/getSummary()------");
  return new Promise(function (callback, reject) {
    var summaryQuery = "select mean(\"ResponseTime\") as \"avg\", mean(\"Latency\") as \"latency\", sum(\"TransactionCount\") as \"totalcount\", sum(\"ErrorCount\") as \"errorcount\", percentile(\"ResponseTime\", 90) as percentile, percentile(\"ResponseTime\", 99) as \"percentile99\", max(\"ResponseTime\") as \"maxRT\"  from Transactions where RunID='" + testrunid + "' group by \"TransactionName\"";
    influx.query(summaryQuery)
      .then(result => {
        Logger("----------stopTGAPI/getTestSummary-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => {
        reject(error);
      });
  });
}

function formatSummaryData(Data, sla) {
  Logger("-----stopTGAPI/formatSummaryData()------");
  Data.forEach((obj) => {
    obj.passcount = obj.totalcount - obj.errorcount;
  });
  let statusCardsvalue_RT = '', TxCount_RT = 0;
  let summary = JSON.parse(JSON.stringify(Data));
  if (sla.enabled) {
    let SLAmet = 0, SLAnotmet = 0;
    summary.forEach((tx) => {
      /* { "time" : ISODate("1970-01-01T00:00:00.000Z"), "avg" : 2045.7, "totalcount" : 20, "errorcount" : 0, 
        "percentile" : 2928, "TransactionName" : "01_Launch", "passcount" : 20, "_90percent" : "90.00", "error" : "0.0" } */
      //tx.TransactionName
      let transactionSLA = 0;
      sla.Txs.forEach((transaction) => {
        if (transaction.txName === tx.TransactionName) {
          transactionSLA = transaction.sla;
          if (!transaction.hasOwnProperty("enabled")) {
            tx.enabled = true;
          } else {
            tx.enabled = transaction.enabled;
          }
        }
      });
      tx.slalimit = transactionSLA;

      if (tx.enabled) {
        switch (true) {
          case (tx.avg <= transactionSLA): {
            //SLA met
            tx.sla = "met";
            SLAmet++;
            break;
          }
          case (tx.avg > transactionSLA): {
            //SLA not met
            tx.sla = "not met";
            SLAnotmet++;
            break;
          }
        }
      } else {
        tx.sla = "nil";
      }

    });
    if ((SLAmet == 0) && (SLAnotmet == 0)) {
      statusCardsvalue_RT = "N/A";
    } else if (SLAnotmet == 0) {
      statusCardsvalue_RT = "Pass";
    } else {
      statusCardsvalue_RT = "Fail";
      TxCount_RT = SLAnotmet;
    }
  } else {
    statusCardsvalue_RT = "N/A";
  }

  let FormattedData = {
    summary: summary,
    responsetime: {
      statusCardsvalue: statusCardsvalue_RT,
      TxCount: TxCount_RT,
    },
  };
  return FormattedData;
}

function getTransactionsForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTransactionsForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    var transactionsQuery = "select \"time\", (sum(\"TransactionCount\")/" + interval + ") as \"totalcount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

    influx.query(transactionsQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getTransactionsForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatTransactionsData(Data) {
  Logger("-----stopTGAPI/formatTransactionsData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    var formattedData = [];
    var groupByName = {};

    Data.forEach((obj) => {
      groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
      groupByName[obj.TransactionName].push(obj);
    });
    //Logger(JSON.stringify(groupByName));
    let transcationNames = Object.keys(groupByName);
    let series, seriesVal;
    for (var iName = 0; iName < transcationNames.length; iName++) {
      series = [];
      //Logger(JSON.stringify(groupByName[transcationNames[iName]]));
      for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
        seriesVal = {
          name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
          value: groupByName[transcationNames[iName]][vi].totalcount,
        };
        series.push(seriesVal);
      }
      //Logger(JSON.stringify(series));
      formattedData.push({ name: transcationNames[iName], series: series });
    }
    return formattedData;
  } else {
    //Logger("formatTransactionsData Data length:" + Data.length);
  }
}

function getResponseTimeForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getResponseTimeForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }
    var responseTimeQuery = "select \"time\", mean(\"ResponseTime\") as \"ResponseTime\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";
    //select time, ResponseTime, TransactionID from Transactions where RunID='5d76267177978f3da4011786' group by TransactionName
    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getResponseTimeForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatResponseTimeData(Data) {
  Logger("-----stopTGAPI/formatResponseTimeData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    var formattedData = [];
    var groupByName = {};

    Data.forEach((obj) => {
      groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
      groupByName[obj.TransactionName].push(obj);
    });
    //Logger(JSON.stringify(groupByName));
    let transcationNames = Object.keys(groupByName);
    let series, seriesVal;
    for (var iName = 0; iName < transcationNames.length; iName++) {
      series = [];
      //Logger(JSON.stringify(groupByName[transcationNames[iName]]));
      for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
        seriesVal = {
          name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
          value: groupByName[transcationNames[iName]][vi].ResponseTime,
        };

        series.push(seriesVal);
      }
      //Logger(JSON.stringify(series));
      formattedData.push({ name: transcationNames[iName], series: series });
    }
    return formattedData;
  } else {
    //Logger("formatResponseTimeData Data length:" + Data.length);
  }
}

function getLatencyForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getLatencyForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }
    var latencyQuery = "select \"time\", mean(\"Latency\") as \"Latency\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";

    influx.query(latencyQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getLatencyForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatLatencyData(Data) {
  Logger("-----stopTGAPI/formatLatencyData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    var formattedData = [];
    var groupByName = {};

    Data.forEach((obj) => {
      groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
      groupByName[obj.TransactionName].push(obj);
    });
    //Logger(JSON.stringify(groupByName));
    let transcationNames = Object.keys(groupByName);
    let series, seriesVal;
    for (var iName = 0; iName < transcationNames.length; iName++) {
      series = [];
      //Logger(JSON.stringify(groupByName[transcationNames[iName]]));
      for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
        seriesVal = {
          name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
          value: groupByName[transcationNames[iName]][vi].Latency,
        };
        series.push(seriesVal);
      }
      //Logger(JSON.stringify(series));
      formattedData.push({ name: transcationNames[iName], series: series });
    }
    return formattedData;
  } else {
    //Logger("formatResponseTimeData Data length:" + Data.length);
  }
}

function customFormatDate(dateTBM) {
  //Logger("-----stopTGAPI/customFormatDate()------");
  var Mdate = '';
  if (dateTBM) {
    //Mdate = formatDate(dateTBM, 'MM-d-y HH:mm:ss', 'en-US');
    //Mdate = formatDate(dateTBM, 'HH:mm:ss', 'en-US');
    //new Date(dateTBM).getTime()
    Mdate = new Date(dateTBM).getTime();
  }
  return Mdate;
}

function parseNumber(value) {
  return parseFloat(value);
}


function getVUsersByThreadGroupsForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getVUsersByThreadGroupsForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }
    var VUsersForIDByThreadGroupsQuery = "select \"time\", mean(\"ThreadCount\") as \"ThreadCount\" from ThreadGroupData where RunID='" + testrunid + "' group by time(" + interval + "s), ThreadGroupName fill(none)";

    influx.query(VUsersForIDByThreadGroupsQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getVUsersByThreadGroupsForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatVUsersByThreadGroupsData(Data) {
  Logger("-----stopTGAPI/formatVUsersByThreadGroupsData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    var formattedData = [];
    var groupByName = {};

    Data.forEach((obj) => {
      if (obj.ThreadGroupName != '') {
        groupByName[obj.ThreadGroupName] = groupByName[obj.ThreadGroupName] || [];
        groupByName[obj.ThreadGroupName].push(obj);
      }
    });
    //Logger(JSON.stringify(groupByName));
    let ThreadGroupNames = Object.keys(groupByName);
    let series, seriesVal;
    for (var iName = 0; iName < ThreadGroupNames.length; iName++) {
      series = [];
      //Logger(JSON.stringify(groupByName[transcationNames[iName]]));
      for (var vi = 0; vi < groupByName[ThreadGroupNames[iName]].length; vi++) {
        seriesVal = {
          name: customFormatDate(groupByName[ThreadGroupNames[iName]][vi].time),
          value: groupByName[ThreadGroupNames[iName]][vi].ThreadCount,
        };
        series.push(seriesVal);
      }
      //Logger(JSON.stringify(series));
      formattedData.push({ name: ThreadGroupNames[iName], series: series });
    }
    return formattedData;
  } else {
    //Logger("formatVUsersForIDByThreadGroupsData Data length:" + Data.length);
  }
}

function getRunningVUsersForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getRunningVUsersForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    var vUsersQuery = "select time, (sum(ActiveVUsers)/" + interval + ") as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + interval + "s) fill(none)";
    //var vUsersQuery = "select time, mean(ActiveVUsers) as ActiveVUsers from VUsers where RunID='" + testrunid + "' group by time(" + interval + "s) fill(none)";
    influx.query(vUsersQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getRunningVUsersForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatVUsersData(runningVUsersData) {
  Logger("-----stopTGAPI/formatVUsersData()------");
  //Logger("runningVUsersData length:"+runningVUsersData.length);
  if (runningVUsersData.length > 0) {
    let series = [], values = [];
    for (var vi = 0; vi < runningVUsersData.length; vi++) {
      let seriesVal = {
        name: customFormatDate(runningVUsersData[vi].time),
        value: Math.round(runningVUsersData[vi].ActiveVUsers),
      };
      series.push(seriesVal);
      values.push(runningVUsersData[vi].ActiveVUsers);
    }


    let VUsersData = [
      { name: 'VUsers', series: series, },
    ];
    return VUsersData;
  } else {

    let VUsersData = [
      { name: 'VUsers', series: [], },
    ];
    return VUsersData;
    //Logger("formatVUsersData Data length:" + runningVUsersData.length);
  }
}

function getThroughputBytesPerSecondForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getThroughputBytesPerSecondForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    var throughputQuery = "select time, (sum(ResponseSize)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)";
    influx.query(throughputQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getThroughputBytesPerSecondForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatThroughputData(Data) {
  Logger("-----stopTGAPI/formatThroughputData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [], count = 0, sum = 0;
    for (var vi = 0; vi < Data.length; vi++) {
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: parseNumber(Data[vi].sum),
      };
      series.push(seriesVal);
      sum = sum + Data[vi].sum;
      count++;
    }

    let avgThroughput = Math.round(sum / count);
    let ThroughputData = {
      throughputData: [
        { name: 'Throughput', series: series, },
      ],
      avgThroughput: avgThroughput
    };
    return ThroughputData;
  } else {
    return ({
      throughputData: [
        { name: 'Throughput', series: [], },
      ],
      avgThroughput: 0
    });
    //Logger("formatThroughputData Data length:" + Data.length);
  }
}

function getHitsPerSecondForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getHitsPerSecondForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    // var hitsQuery = "select time, (sum(Hits)/" + interval + ") from ClientSideMetrics where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
    var hitsQuery = "select time, (sum(TransactionCount)/" + interval + ") from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s)  fill(none)"
    influx.query(hitsQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getHitsPerSecondForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatHitsPerSecondData(Data) {
  Logger("-----stopTGAPI/formatHitsPerSecondData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [], count = 0, sum = 0;
    for (var vi = 0; vi < Data.length; vi++) {
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: Data[vi].sum,
      };
      series.push(seriesVal);
      sum = sum + Data[vi].sum;
      count++;
    }
    let avgHitsPerSecond = Math.round(sum / count);
    let HitsPerSecondData = {
      hitsPerSecondData: [
        { name: 'Hits/Second', series: series, },
      ],
      avgHitsPerSecond: avgHitsPerSecond
    };
    return HitsPerSecondData;
  } else {
    //Logger("formatHitsPerSecondData Data length:" + Data.length);
    return ({
      hitsPerSecondData: [
        { name: 'Hits/Second', series: [], },
      ],
      avgHitsPerSecond: 0
    });
  }
}

function getErrorCountsForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getErrorCountsForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    var errorQuery = "select \"time\", (sum(\"ErrorCount\")/" + interval + ") as \"ErrorCount\" from Transactions where RunID='" + testrunid + "' group by time(" + interval + "s), TransactionName fill(none)";
    influx.query(errorQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getErrorCountsForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatErrorCountsData(Data) {
  Logger("-----stopTGAPI/formatErrorCountsData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {

    let ErrorCountsData = [];
    var groupByName = {};

    Data.forEach((obj) => {
      groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
      groupByName[obj.TransactionName].push(obj);
    });
    //Logger(JSON.stringify(groupByName));
    let transcationNames = Object.keys(groupByName);
    let series, seriesVal;
    for (var iName = 0; iName < transcationNames.length; iName++) {
      series = [];
      //Logger(JSON.stringify(groupByName[transcationNames[iName]]));
      for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
        seriesVal = {
          name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
          value: groupByName[transcationNames[iName]][vi].ErrorCount,
        };
        series.push(seriesVal);
      }
      //Logger(JSON.stringify(series));
      ErrorCountsData.push({ name: transcationNames[iName], series: series });
    }
    return ErrorCountsData;
  } else {
    //Logger("formatErrorCountsData Data length:" + Data.length);
  }
}

function getStatusCodesListForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getStatusCodesForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    var statusCodesQuery = "select \"time\", \"SamplerLabel\" as \"label\", \"HTTPStatusCode\" as \"statuscode\", URL from RequestMetrics where RunID='" + testrunid + "'";

    influx.query(statusCodesQuery)
      .then((result) => {
        Logger("----------getStatusCodesForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}


function formatStatusCodesData(Data) {
  Logger("-----stopTGAPI/formatStatusCodesData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    let StatusCodesData = [];
    var groupBystatuscodes = {};

    for (var iData = 0; iData < Data.length; iData++) {
      groupBystatuscodes[Data[iData].statuscode] = "";
    }
    //Logger(JSON.stringify(groupBystatuscodes));
    let statuscodesListNames = Object.keys(groupBystatuscodes);
    for (var istatuscode = 0; istatuscode < statuscodesListNames.length; istatuscode++) {
      //statuscodesList[istatuscode]
      let statuscodeCount = 0;
      for (var iData = 0; iData < Data.length; iData++) {
        //statuscodes[Data[iData].statuscode] = "";
        if (Data[iData].statuscode == statuscodesListNames[istatuscode]) {
          statuscodeCount++;
        }
      }
      let dataobj = {
        name: statuscodesListNames[istatuscode],
        value: statuscodeCount
      };
      StatusCodesData.push(dataobj);
    }
    return StatusCodesData;
  } else {
    //Logger("formatErrorCountsData Data length:" + Data.length);
  }
}

function getAssertionFailureResultsForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getAssertionFailureResultsForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    //var assertionFailureQuery = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\", \"ResponseContent\" as \"content\" from AssertionResults where RunID='" + testrunid + "'";
    var assertionFailureQuery = "select \"time\", \"SamplerLabel\" as \"label\", \"FailureMessage\" as \"message\" from AssertionResults where RunID='" + testrunid + "'";
    influx.query(assertionFailureQuery)
      .then((result) => {
        Logger("----------getAssertionFailureResultsForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatAssertionFailureData(Data) {
  Logger("-----stopTGAPI/formatAssertionFailureData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    Data.forEach((obj) => {
      if (obj.hasOwnProperty('content')) {
        delete obj['content'];
      }
    });
  } else {
    //Logger("formatErrorCountsData Data length:" + Data.length);
  }
  return Data;
}

function getObservations(testRunID, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getObservations()------");
    let URL = "http://" + config.rServer + ":8000/analyze?RunID=" + testRunID + "&aggregationInterval=" + aggregationInterval;
    try {
      Request.get(URL, (error, response, body) => {
        if (error) {
          console.error(error);
          reject(error);
        }
        //Logger(body);
        callback(body);
      });
    } catch (e) {
      Logger("Error in stopTGAPI/getTestRunDoc " + e);
      callback(null);
    }
  });
}

function updateAnalysedTestRunDoc(testRunID, testResult) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/updateAnalysedTestRunDoc()------");
    var bsonID = mongodb.ObjectID(testRunID);
    let updateTestRun = {};
    updateTestRun.status = "Analysed";
    updateTestRun.testResult = testResult;
    updateTestRun.testGroups = []; //ATD
    Logger("status:: " + updateTestRun.status);
    var newvalues = { $set: updateTestRun };

    db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
      if (err) {
        Logger("Error in stopTGAPI/updateAnalysedTestRunDoc : " + err);
        reject(err);
      }
      else {
        Logger("----------stopTGAPI/updateAnalysedTestRunDoc-----------");
        callback(result);
      }
    });
  });
}

function updateTestRunStatus(testRunID, Status) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/updateTestRunStatus()------");
    var bsonID = mongodb.ObjectID(testRunID);
    let updateTestRun = {};
    updateTestRun.status = Status;
    Logger("status:: " + updateTestRun.status);
    var newvalues = { $set: updateTestRun };

    db.collection("TestRuns").update({ '_id': bsonID }, newvalues, function (err, result) {
      if (err) {
        Logger("Error in stopTGAPI/updateTestRunStatus : " + err);
        reject(error);
      }
      else {
        Logger("----------stopTGAPI/updateTestRunStatus-----------");
        callback(result);
      }
    });
  });
}

function getTestRunDuration(testRunID) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTestRunDuration()------");
    var bsonID = mongodb.ObjectID(testRunID);
    db.collection('TestRuns').findOne({ "_id": bsonID }, { duration: 1 }, function (err, record) {
      if (err) {
        Logger("Error in stopTGAPI/getTestRunDuration : " + err);
        reject(err);
      } else {
        callback(record.duration);
      }
    });
  });
}

function getTestRunSLA(testRunID) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTestRunSLA()------");
    var bsonID = mongodb.ObjectID(testRunID);
    db.collection('TestRuns').findOne({ "_id": bsonID }, { sla: 1 }, function (err, record) {
      if (err) {
        Logger("Error in getTestRunDuration : " + err);
        reject(err);
      } else {
        callback(record.sla);
      }
    });
  });
}

function getTestRunDocument(testRunID) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTestRunDocument()------");
    var bsonID = mongodb.ObjectID(testRunID);
    db.collection('TestRuns').findOne({ "_id": bsonID }, {}, function (err, record) {
      if (err) {
        Logger("Error in getTestRunDocument : " + err);
        reject(err);
      } else {
        callback(record);
      }
    });
  });
}

function getCPUForHostName(hostname, startTimestamp, endTimestamp) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getCPUForHostName()------");

    //var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total'";
    // var CPUQuery = "select \"time\", \"Percent_Processor_Time\", \"host\" from win_cpu where host='" + hostname + "' and instance='_Total' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    var CPUQuery = "select \"time\", (100-(\"usage\")) as usage, \"host\" from cpu where host='" + hostname + "' and cpu= 'cpu-total' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    // console.log(CPUQuery);
    influx.query(CPUQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getCPUForHostName-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatCPUDataForHostName(hostname, Data) {
  Logger("-----stopTGAPI/formatCPUDataForHostName()------");
  //console.log("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [];
    for (var vi = 0; vi < Data.length; vi++) {
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: Math.floor(parseFloat(String(Data[vi].usage))),
      };
      series.push(seriesVal);
    }

    let CPUData = { name: hostname, series: series, };
    return CPUData;
  } else {
    //console.log("formatHitsPerSecondData Data length:" + Data.length);
  }
}

function getProcessorDataForHostName(hostname, startTimestamp, endTimestamp) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getProcessorDataForHostName()------");
    //select LAST("Percent_Processor_Time") from win_cpu where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total';
    //"select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000
    //select * from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000
    //'2015-08-18T23:00:01.232000000Z'
    //select * from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and instance='_Total' and time => '2019-04-10T10:10:13.232000000Z' and time <= '2019-04-10T10:40:17.232000000Z' group by time(5s)
    //select "time", mean("Processor_Queue_Length") as "Processor_Queue_Length", "host" from win_system where host='ec2-18-191-165-66.us-east-2.compute.amazonaws.com' and time > '2019-04-10T10:10:13.232000000Z' and time < '2019-04-10T10:40:17.232000000Z' group by time(5s) fill(none)

    //var CPUQuery = "select LAST(\"Percent_Processor_Time\") from win_cpu where host='" + hostname + "' and instance='_Total' and time => 1554895970000000000 and time <= 1554896005000000000";
    //var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from win_system where host='" + hostname + "' and time > '2019-04-10T10:10:13.232000000Z' and time < '2019-04-10T10:40:17.232000000Z' group by time(5s) fill(none)";

    // var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from win_system where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    var ProcessorQuery = "select \"time\", \"Processor_Queue_Length\", \"host\" from system where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    influx.query(ProcessorQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getProcessorDataForHostName-----------");
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatProcessorDataForHostName(hostname, Data) {
  Logger("-----stopTGAPI/formatProcessorDataForHostName()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [];
    for (var vi = 0; vi < Data.length; vi++) {
      console.log(Data[vi].Processor_Queue_Length);
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: (parseFloat(String(Data[vi].Processor_Queue_Length)).toFixed(2) * 100),//Math.floor(Data[vi].Processor_Queue_Length),
      };
      series.push(seriesVal);
    }

    let ProcessorData = { name: hostname, series: series, };
    return ProcessorData;
  } else {
    //Logger("formatHitsPerSecondData Data length:" + Data.length);
  }
}

function getAvailableRAMDataForHostName(hostname, startTimestamp, endTimestamp) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getAvailableRAMDataForHostName()------");

    var AvailableRAMQuery = "SELECT \"time\", ((\"available\"/1024)/1024) as \"AvailableRAM\", \"host\" FROM \"mem\" where host='" + hostname + "' and time > '" + startTimestamp + "' and time < '" + endTimestamp + "'";
    influx.query(AvailableRAMQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getAvailableRAMDataForHostName-----------");
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatAvailableRAMDataForHostName(hostname, Data) {
  Logger("-----stopTGAPI/formatAvailableRAMDataForHostName()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    let series = [];
    for (var vi = 0; vi < Data.length; vi++) {
      let seriesVal = {
        name: customFormatDate(Data[vi].time),
        value: Math.floor(Data[vi].AvailableRAM),
      };
      series.push(seriesVal);
    }

    let AvailableRAMData = { name: hostname, series: series, };
    return AvailableRAMData;
  } else {
    //Logger("formatAvailableRAMDataForHostName Data length:" + Data.length);
  }
}

async function getServerMetrics(machines, startTimestamp, endTimestamp) {
  Logger("-----stopTGAPI/getServerMetrics()------");//Logger("hostnames length:"+hostnames.length);
  if (machines.length > 0) {
    /* 
          Logger(startTimestamp);
          Logger(endTimestamp); */
    let ProcessorSeries = [], CPUSeries = [], MemorySeries = [];
    for (var vi = 0; vi < machines.length; vi++) {
      if (machines[vi].metrics.processor) {
        let ProcessorDataForHostName = await getProcessorDataForHostName(machines[vi].machineName, startTimestamp, endTimestamp);
        let ProcessorData = formatProcessorDataForHostName(machines[vi].machineName, ProcessorDataForHostName);
        ProcessorSeries.push(ProcessorData);
      }
      if (machines[vi].metrics.cpu) {
        let CPUDataForHostName = await getCPUForHostName(machines[vi].machineName, startTimestamp, endTimestamp);
        let CPUData = formatCPUDataForHostName(machines[vi].machineName, CPUDataForHostName);
        CPUSeries.push(CPUData);
      }
      if (machines[vi].metrics.memory) {
        let RAMDataForHostName = await getAvailableRAMDataForHostName(machines[vi].machineName, startTimestamp, endTimestamp);
        let RAMData = formatAvailableRAMDataForHostName(machines[vi].machineName, RAMDataForHostName);
        MemorySeries.push(RAMData);
      }

    }
    let responseData = {
      cpu_data: CPUSeries,
      processor_data: ProcessorSeries,
      memory_data: MemorySeries,
    };
    return responseData;
  } else {
    //Logger("formatHitsPerSecondData Data length:" + Data.length);
  }
}

function getTransactionsRequestsBreakdownForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTransactionsRequestsBreakdownForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }

    var TransactionsRequestsBreakdown = "select \"time\", mean(\"ResponseSize\") as \"ResponseSize\", mean(\"ResponseTime\") as \"ResponseTime\", count(\"isSuccessful\") as \"TotalRequests\" from TransactionsSubResults where RunID='" + testrunid + "' group by URL fill(none)";

    influx.query(TransactionsRequestsBreakdown)
      .then((result) => {
        Logger("----------stopTGAPI/getTransactionsRequestsBreakdownForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getTransactionsRequestsBreakdownSuccessfulForID(testrunid, aggregationInterval) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTransactionsRequestsBreakdownSuccessfulForID()------");
    var interval = 1;
    if (aggregationInterval) {
      interval = aggregationInterval;
    }
    //select time, mean(ResponseSize) as ResponseSize, mean(ResponseTime) as ResponseTime, count(isSuccessful) as TotalRequests from TransactionsSubResults where RunID='5d6f89153dce4e2f7c93ea32' and isSuccessful=true group by URL;
    var TransactionsRequestsBreakdownSuccessful = "select \"time\",  count(\"isSuccessful\") as \"SuccessfulRequests\" from TransactionsSubResults where RunID='" + testrunid + "' and isSuccessful=true group by URL fill(none)";

    influx.query(TransactionsRequestsBreakdownSuccessful)
      .then((result) => {
        Logger("----------stopTGAPI/getTransactionsRequestsBreakdownSuccessfulForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function formatTransactionsRequestsBreakdownData(Data, DataSuccessful) {
  Logger("-----stopTGAPI/formatTransactionsRequestsBreakdownData()------");
  //Logger("Data length:"+Data.length);
  if (Data.length > 0) {
    /* var formattedData = [];
    var groupByName = {};

    Data.forEach((obj) => {
      groupByName[obj.TransactionName] = groupByName[obj.TransactionName] || [];
      groupByName[obj.TransactionName].push(obj);
    });
    //Logger(JSON.stringify(groupByName));
    let transcationNames = Object.keys(groupByName);
    let series, seriesVal;
    for (var iName = 0; iName < transcationNames.length; iName++) {
      series = [];
      //Logger(JSON.stringify(groupByName[transcationNames[iName]]));
      for (var vi = 0; vi < groupByName[transcationNames[iName]].length; vi++) {
        seriesVal = {
          name: customFormatDate(groupByName[transcationNames[iName]][vi].time),
          value: groupByName[transcationNames[iName]][vi].totalcount,
        };
        series.push(seriesVal);
      }
      //Logger(JSON.stringify(series));
      formattedData.push({ name: transcationNames[iName], series: series });
    }
    return formattedData; */

    /*  [
       {
           "time": "1970-01-01T00:00:00.000Z",
           "ResponseSize": 194948.92307692306,
           "ResponseTime": 1131.1153846153845,
           "TotalRequests": 26,
           "URL": "http://ec2-18-191-165-66.us-east-2.compute.amazonaws.com:8080/SpringMVCHibernateCRUD/"
       }
     ] */
    Data.forEach((obj) => {
      //parseFloat(String(obj.avg)).toFixed(0)
      obj.ResponseTime = parseFloat(String(obj.ResponseTime)).toFixed(0);
      obj.ResponseSize = parseFloat(String(obj.ResponseSize)).toFixed(0);//parseFloat(Math.round(obj.ResponseSize * 100) / 100).toFixed(2);
    });

    if (DataSuccessful.length > 0) {
      Data.forEach((obj) => {
        DataSuccessful.forEach((obj1) => {
          if (obj.URL === obj1.URL) {
            obj.passcount = Number(obj1.SuccessfulRequests);
            obj.failcount = Number(obj.TotalRequests) - Number(obj1.SuccessfulRequests);
          }
        });
        if (!obj.hasOwnProperty("passcount")) {
          obj.passcount = 0;
        }
        if (!obj.hasOwnProperty("failcount")) {
          obj.failcount = 0;
        }
      });
    } else {
      Data.forEach((obj) => {
        obj.passcount = 0;
        obj.failcount = 0;
      });
    }

    return Data;
  } else {
    let sample = [];
    return sample;
    //Logger("formatTransactionsRequestsBreakdownData Data length:" + Data.length);
  }

}

function getAssertionResultsRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getAssertionResultsRawDataForID()------");
    var responseTimeQuery = "select * from AssertionResults where RunID = '" + testrunid + "'";
    // select * from AssertionResults where RunID = '" + testrunid + "'
    // select * from ClientSideMetrics where RunID = '" + testrunid + "'
    // select * from RequestMetrics where RunID = '" + testrunid + "'
    // select * from ThreadGroupData where RunID = '" + testrunid + "'
    // select * from Transactions where RunID = '" + testrunid + "'
    // select * from TransactionsSubResults where RunID = '" + testrunid + "'
    // select * from VUsers where RunID = '" + testrunid + "'
    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getAssertionResultsRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getClientSideMetricsRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getClientSideMetricsRawDataForID()------");
    var responseTimeQuery = "select * from ClientSideMetrics where RunID = '" + testrunid + "'";

    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getClientSideMetricsRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getRequestMetricsRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getRequestMetricsRawDataForID()------");
    var responseTimeQuery = "select * from RequestMetrics where RunID = '" + testrunid + "'";

    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getRequestMetricsRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getThreadGroupDataRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getThreadGroupDataRawDataForID()------");
    var responseTimeQuery = "select * from ThreadGroupData where RunID = '" + testrunid + "'";

    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getThreadGroupDataRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getTransactionsRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTransactionsRawDataForID()------");
    var responseTimeQuery = "select * from Transactions where RunID = '" + testrunid + "'";

    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getTransactionsRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getTransactionsSubResultsRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getTransactionsSubResultsRawDataForID()------");
    var responseTimeQuery = "select * from TransactionsSubResults where RunID = '" + testrunid + "'";

    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getTransactionsSubResultsRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

function getVUsersRawDataForID(testrunid) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/getVUsersRawDataForID()------");
    var responseTimeQuery = "select * from VUsers where RunID = '" + testrunid + "'";

    influx.query(responseTimeQuery)
      .then((result) => {
        Logger("----------stopTGAPI/getVUsersRawDataForID-----------")
        //Logger(JSON.stringify(result));
        //return(result);
        callback(result);
      })
      .catch(error => reject({ error }));
  });
}

async function getTomcatLogs(indexName, gteString, lteString, testrunid) {
  // async function getESLogsData(indexName, hostName, gteString, lteString, testrunid, docsLimit) {
  try {

    Logger("-----stopTGAPI/getTomcatLogs()------");
    const ESresponsecount = await elasticClient.count({
      index: indexName,
      body: {
        "query": {
          "bool": {
            // "must": [
            //     {
            //         "match": {
            //             "host": hostName
            //         }
            //     }
            // ],
            "must": [
              {
                "match": {
                  "testrunid": testrunid
                }
              }
            ],
            "filter": [
              {
                "range": {
                  "@timestamp": {
                    "gte": gteString,
                    "lt": lteString
                  }
                }
              }
            ]
          }
        }
      }
    });
    // console.log("--------------------ESresponsecount------------------------------");
    // console.log(ESresponsecount);
    // console.log("-----------------------------------------------------------------");
    // {
    //     count: 290,
    //     _shards: { total: 1, successful: 1, skipped: 0, failed: 0 }
    // }
    let DocsCount = ESresponsecount.count;

    let Logs = [];
    if (DocsCount > 0) {
      const ESresponse = await elasticClient.search({
        index: indexName,
        body: {

          "size": DocsCount,//docsLimit,//4000,
          "query": {
            "bool": {
              /* "must": [
                  {
                      "match": {
                          "host": hostName
                      }
                  }
              ], */
              "must": [
                {
                  "match": {
                    "testrunid": testrunid
                  }
                }
              ],
              "filter": [
                {
                  "range": {
                    "@timestamp": {
                      "gte": gteString,
                      "lt": lteString
                    }
                  }
                }
              ]
            }

          }/* ,
                  "_source": {
                      "includes": ["id", "post_date"]
                  } */,
          "sort": [
            {
              "@timestamp": {
                "order": "desc"
              }
            }
          ]
        }
      });
      let Hits = ESresponse.hits.hits;
      if ((Hits != null) || (Hits != undefined) || (Hits != [])) {
        if (indexName == "apachelogs-stderr") {
          Hits.forEach((hit) => {
            let Obj = {
              indexName: hit._index,
              hostName: hit._source.host,
              message: hit._source.message,
              logtype: hit._source.logtype,
              datetime: hit._source.date + " " + hit._source.time,
              log: hit._source.log,
            };

            if ((Obj.logtype == "WARNING") || (Obj.logtype == "ERROR") || (Obj.logtype == "FATAL")) {
              Logs.push(Obj);
            }
          });
        } else {
          Hits.forEach((hit) => {
            let Obj = {
              indexName: hit._index,
              hostName: hit._source.host,
              message: hit._source.message,
            };
            Logs.push(Obj);
          });
        }
      }
    }

    return Logs;
    //return res.status(200).json(Logs);
  } catch (error) {
    // console.log(error.message);
    Logger(error.message);
    return error.message;
    //return res.status(500).json(error.message);
  }
}


function updateFileSystem(testRunID, testResult) {
  return new Promise(function (callback, reject) {
    Logger("-----stopTGAPI/updatedFileSystem()------");
    var bsonID = mongodb.ObjectID(testRunID);
    let updateTestRun = {};
    updateTestRun.status = "Analysed";
    updateTestRun.testResult = testResult;
    updateTestRun.testGroups = []; //ATD
    Logger("updateAnalysedTestRunDoc status:: " + updateTestRun.status);

    try {//temporary 
      let testRunDocDir = config.mongodocsFSPath + "testruns/" + testRunID;

      if (!fs.existsSync(testRunDocDir)) {
        fs.mkdirSync(testRunDocDir);
      }
      let testRunDocPath = testRunDocDir + "/" + testRunID + ".json";
      //temporary
      fs.writeFileSync(testRunDocPath, JSON.stringify(updateTestRun));
      var testRunDocStats = fs.statSync(testRunDocPath);
      console.log('Test Run Doc File Size in Bytes-' + testRunDocStats.size);
      if (testRunDocStats.size > 15000000) {//check > 15Mb

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_transactions.json", JSON.stringify(testResult.transactions));
        testResult.transactions.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_responseTime.json", JSON.stringify(testResult.responseTime));
        testResult.responseTime.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_vUsers.json", JSON.stringify(testResult.vUsers));
        testResult.vUsers.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_vUsersByThreadGroups.json", JSON.stringify(testResult.vUsersByThreadGroups));
        testResult.vUsersByThreadGroups.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_throughput.json", JSON.stringify(testResult.throughput));
        testResult.throughput.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_hits.json", JSON.stringify(testResult.hits));
        testResult.hits.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_error.json", JSON.stringify(testResult.error));
        testResult.error.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_errorsPerTranscationData.json", JSON.stringify(testResult.errorsPerTranscationData));
        testResult.errorsPerTranscationData.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_latency.json", JSON.stringify(testResult.latency));
        testResult.latency.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_statuscodes.json", JSON.stringify(testResult.statuscodes));
        testResult.statuscodes.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_assertionerrors.json", JSON.stringify(testResult.assertionerrors));
        testResult.assertionerrors.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_TransactionsRequestsBreakdown.json", JSON.stringify(testResult.TransactionsRequestsBreakdown));
        testResult.TransactionsRequestsBreakdown.data = [];

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_serverMetrics.json", JSON.stringify(testResult.serverMetrics));
        testResult.serverMetrics.data = {
          cpu_data: [],
          processor_data: [],
          memory_data: []
        };

        fs.writeFileSync(testRunDocDir + "/" + testRunID + "_TomcatLogs.json", JSON.stringify(testResult.TomcatLogs));
        testResult.TomcatLogs = {
          stdoutLogs: [],
          stderrLogs: []
        };

        /* let testResult = {
          panelsummary: {
            data: panelSummaryData.panelSummary,
            responsetimehealth: {
              value: FormattedSummaryData.responsetime.statusCardsvalue,
              TxCount: FormattedSummaryData.responsetime.TxCount,
            },
            transactionhealth: {
              value: panelSummaryData.transaction.statusCardsvalue,
              TxCount: panelSummaryData.transaction.TxCount,
            }
          },
          errorsPerTranscationData: {
            data: panelSummaryData.errorsPerTranscationData,
          },
          stackedbarchartdata: {
            data: panelSummaryData.stackedbarchartdata,
          },
          summary: {
            data: summaryData,
            observations: summaryObservation
          },
          transactions: {
            rawData: dummysamples,
            data: formatTransactionsData(transactions),
            observations: transactionsObservation
          },
          responseTime: {
            rawData: dummysamples,
            data: formatResponseTimeData(responseTime),
            observations: responseTimeObservation
          },
          vUsers: {
            rawData: dummysamples,
            data: formatVUsersData(vUsers),
            observations: vUsersObservation
          },
          vUsersByThreadGroups: {
            rawData: dummysamples,
            data: formatVUsersByThreadGroupsData(vUsersByThreadGroups),
            observations: vUsersByThreadGroupsObservation
          },
          throughput: {
            rawData: dummysamples,
            data: formatThroughputData(throughput),
            observations: throughputObservation
          },
          hits: {
            rawData: dummysamples,
            data: formatHitsPerSecondData(hits),
            observations: hitsObservation
          },
          error: {
            rawData: dummysamples,
            data: formatErrorCountsData(error),
            observations: errorObservation
          },
          latency: {
            rawData: dummysamples,
            data: formatLatencyData(latency),
            observations: latencyObservation
          },
          statuscodes: {
            rawData: dummysamples,
            data: formatStatusCodesData(statuscodes),
            observations: statuscodesObservation
          },
          assertionerrors: {
            rawData: dummysamples,
            data: formatAssertionFailureData(assertionFailures),
          },

          TransactionsRequestsBreakdown: {
            rawData: dummysamples,
            data: formatTransactionsRequestsBreakdownData(TransactionsRequestsBreakdown, TransactionsRequestsBreakdownSuccessful),
          },
          observations: observations,
          serverMetrics: {
            data: serverMetrics,
            observations: []
          },
          influxRawData: {
            AssertionResults: AssertionResultsRawData,
            ClientSideMetrics: ClientSideMetricsRawData,
            RequestMetrics: RequestMetricsRawData,
            ThreadGroupData: ThreadGroupDataRawData,
            Transactions: TransactionsRawData,
            TransactionsSubResults: TransactionsSubResultsRawData,
            VUsers: VUsersRawData
          },
          TomcatLogs: {
            stdoutLogs: stdoutLogs,
            stderrLogs: stderrLogs
          }
        }; */


        callback(testResult);
      } else {
        //temporary
        fs.unlinkSync(testRunDocPath);//remove file
        fs.rmdirSync(testRunDocDir);
        callback(testResult);
      }
    } catch (err) {
      console.log(err);
      reject(testResult);
    }
  });
}
function getLicenseVerification(testRunID, duration) {
  return new Promise(function (resolve, reject) {

    console.log(" getLicenseVerification() ");
    var PerfAssureUrl = config.PerfAssureUrl;
    var component = "loadsimulation";
    var op = "decrement";
    var users = 0;
    var parJson = {
      "email": config.email,
      "password": config.password
    }
    loadSimualtionDb.collection("TestRuns").find({ "_id": mongodb.ObjectID(testRunID) }).toArray((err, result) => {
      if (err) {
        console.log("Error  : get document from test runs " + err);
        reject(err);
      }
      else {
        if (result.length > 0) {
          var customerId = result[0].customerId
          for (let testGroups of result[0].testGroups) {
            if (testGroups.enabled) {
              if (testGroups.type == "Default") {
                users = users + testGroups.usersCount;
                //duration = duration + (testGroups.duration / 60);
              }
              else {
                for (let userCount of testGroups.threadsSchedule) {
                  users = userCount.startTheardsCount + users;
                  //duration = duration + (userCount.holdLoadFor / 60);
                }
              }
            }
          }
          Request.post({ url: PerfAssureUrl + "/login/login", json: true, body: parJson },
            (errors, response, body) => {
              if (errors) {
                console.log("Error : login failure to PerfAssure Node " + errors);
                reject(errors);
              } else {
                var token = body.data.token;

                Request.get({
                  url: PerfAssureUrl + "/license/LicenseValidatorApi?component=" + component + "&users=" + users + "&op=" + op + "&customerId=" + customerId + "&duration=" + duration,
                  headers: { 'Authorization': 'Bearer ' + token }
                }, (error, response, body) => {
                  if (error) {
                    console.log("Error : connecting to  LicenseValidatorApi failure " + errors);
                    reject(error);
                  } else {
                    //console.log("Validation response in Load Simulation Validation");
                    console.log(body);
                    var msg = JSON.parse(body);
                    if (msg == "updated") {
                      console.log(" license got decrement in load simulator ");
                      resolve("updated");
                    } else {
                      console.log("Error in  license decrement in load simulator ");
                      reject("notupdated");
                    }
                  }
                });
              }
            });
        }
      }
    });

  });

}