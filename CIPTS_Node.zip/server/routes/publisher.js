
var config = require('../configuration.json');

var amqp = require('amqplib/callback_api');

let validationRoute = require('./validation.js');

let addQueue = function (data) {
    console.log("-----stopFinalThreadGroupService()------");
    return new Promise(async function (callback, reject) {
        try {
            if (typeof data.threadgroupname === "undefined" || data.threadgroupname == null || data.threadgroupname == "" || validationRoute(data.threadgroupname)) {
                console.log("Thread Group Name not exists");
                reject({
                    'status': 'ERROR',
                    'message': 'Thread Group Name is missing'
                });
            }
            if (typeof data.testrunid === "undefined" || data.testrunid == null || data.testrunid == "" || validationRoute(data.testrunid)) {
                console.log("Thread Group Name not exists");
                reject({
                    'status': 'ERROR',
                    'message': 'Test Run ID is missing'
                });
            }
            // await amqp.connect('amqp://' + config.RabbitMQHost, function (err, conn) {
            await amqp.connect('amqp://' + config.RabbitMQUserName + ':' + config.RabbitMQPassword + '@' + config.RabbitMQHost + ':5672', async function (err, conn) {
                if (err !== null) { console.log(err); }
                console.log("Connection established RabbitMQ !");
                conn.createChannel(function (err1, ch) {
                    if (err1 !== null) { console.log(err1); }
                    console.log("Channel created RabbitMQ !");
                    ch.assertQueue(config.queueName, { durable: true });
                    ch.sendToQueue(config.queueName, new Buffer(JSON.stringify(data)), { persistent: true });
                    console.log(" [x] Sent '%s'", data);
                });
                setTimeout(function () {
                    conn.close();
                    /* process.exit(0) */
                    console.log("Connection terminated RabbitMQ !");
                }, 2000);
            });
            responseMessage = {
                'testGroupName': data.threadgroupname,
                'status': 'STOPPED'
            }
            callback({
                'status': 'SUCCESS',
                'testGroupName': data.threadgroupname,
                'message': "Added to Queue"
            });
        } catch (e) {
            console.log("Error in addQueue " + e);
            reject({
                'status': 'ERROR',
                'testGroupName': data.threadgroupname,
                'message': e
            });
        }
    });
}


//let s = addQueue(new Date().toString());
module.exports = addQueue;
/*
var amqp = require('amqplib/callback_api');

amqp.connect('amqp://localhost', function(err, conn) {
  conn.createChannel(function(err, ch) {
    var q = 'StopFinalThreadGroup_task_queue';
    var msg = process.argv.slice(2).join(' ') || "Hello World!";

    ch.assertQueue(q, {durable: true});
    ch.sendToQueue(q, new Buffer(msg), {persistent: true});
    console.log(" [x] Sent '%s'", msg);
  });
  setTimeout(function() { conn.close(); process.exit(0) }, 500);
});
 */