var config = require('../configuration.json');

var Request = require("request");

var amqp = require('amqplib/callback_api');

const fs = require('fs');

let validationRoute = require('./validation.js');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;/* 
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('worker.js : ERROR: DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('worker.js : DB connection established using mongodb!');
    }
}); */

const Influx = require('influx');
// const influx = new Influx.InfluxDB('http://' + config.influxDBHost + ':8086/zantmeter');
const influx = new Influx.InfluxDB('http://' + config.influxDBUserName + ':' + config.influxDBPassword + '@' + config.influxDBHost + ':8086/zantmeter');

const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));




// amqp.connect('amqp://' + config.RabbitMQHost, async function (err, conn) {
amqp.connect('amqp://zantmeter:zantmeter2019@' + config.RabbitMQHost+':5672', async function (err, conn) {
  await conn.createChannel(async function (err, ch) {

    ch.assertQueue(config.queueName, { durable: true });
    ch.prefetch(1);
    console.log(" [*] Waiting for messages in %s. To exit press CTRL+C", config.queueName);

    MongoClient.connect(dbURL, function (err, mydb) {
      if (err) {
        console.log('worker.js : ERROR: DB connection failed using mongodb');
        console.log(err);
        //return err;
      } else {
        db = mydb.db();
        console.log('worker.js : DB connection established using mongodb!');
      }
    });
    await ch.consume(config.queueName, async function (msg) {

      console.log(" [x] Received %s", msg.content.toString());
      //let jsonResponseArray = await stopFinalThreadGroup(data.testrunid, data.threadgroupname);
      // let jsonResponseArray = await stopFinalThreadGroupService(JSON.parse(msg.content.toString()));
      let jsonResponseArray = JSON.stringify(JSON.parse(msg.content.toString()));
      //console.log(data.testrunid + " - " + data.threadgroupname + " Stopped");
      console.log(" [x] Done " + jsonResponseArray);
      ch.ack(msg);
    }, { noAck: false });
  });
});
