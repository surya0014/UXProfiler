#!/usr/bin/env node

var debug = require('debug')('passport-mongo');
var app = require('./app');

const https = require('https');
const http = require('http');
const fs = require('fs');

// app.set('port', process.env.PORT || 5000);//Dev 
app.set('port', process.env.PORT || 80);//Prod
// app.set('port', process.env.PORT || 443);//Production

//Dev
var server = app.listen(app.get('port'), function () {
  console.log('Express server listening on port ' + server.address().port);
  debug('Express server listening on port ' + server.address().port);
});

//Prod Redirection

/* var httpserver = http.createServer(function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  // console.log('Redirecting to https://www.ciptszantmeter.com');
  // res.writeHead(301, { "Location": "https://www.ciptszantmeter.com" });
  res.end();
}).listen(5000); //Prod */

/* 
//Prod
var httpserver2 = http.createServer(function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  res.writeHead(301, { "Location": "https://www.ciptszantmeter.com" });
  res.end();
}).listen(80);  */


/* const https = require('https');
const fs = require('fs');

const httpsOptions = {
  key: 'pass',
  cert: fs.readFileSync('./security/zantmeter.cognizant.com.pfx', 'utf8')
}; */
/* const httpsOptions = {
  key: fs.readFileSync('./security/pkey2.pem', 'utf8'),
  cert: fs.readFileSync('./security/server2.crt', 'utf8')
} */
/*,

  // This is necessary only if using the client certificate authentication.
  requestCert: true,
  rejectUnauthorized: true,

  // This is necessary only if the client uses the self-signed certificate.
  ca: [fs.readFileSync('./security/zantmetercom.crt')]*/

/* var server = https.createServer(httpsOptions, app).listen(app.get('port'), function(){
  console.log("HTTPS server started at port "+ server.address().port);
}); */

/* https.createServer(httpsOptions, (req, res) => {
  res.writeHead(200);
  res.end('hello world\n');
}).listen(8000);
 */

/* 
//Prod
var httpserver = http.createServer(function (req, res) {
  res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
  res.end();
}).listen(80);

const httpsOptions = {
  pfx: fs.readFileSync('./security/cpcinchdv000849.cts.com.pfx'),//fs.readFileSync('./security/zantmeter.cognizant.com.pfx'),
  passphrase: 'Password1$',
  // requestCert: true, 
  rejectUnauthorized: true,
};

var server = https.createServer(httpsOptions, app).listen(app.get('port'), function () {
  console.log("HTTPS server started at port " + server.address().port);
}); */