
var config = require('../configuration.json');

let validation = function (data) {
    let validity = true;
    let characters = /^[0-9a-zA-Z .\-@]+$/;
    // /^[a-zA-Z0-9!@#\$%\^\&*\)\(+=._-]+$/g;
    // /^[0-9a-zA-Z .-]+$/;
    //config.validCharacters = /^[0-9a-zA-Z .-]+$/;
    /* console.log(data);
    console.log("data test: "+characters.test(data));
    console.log("data match: "+data.match(characters)); */
    //if (data.match(characters)) {
    // if (data.match(config.validCharacters)) {
    if(characters.test(data)){
        validity = false;
    }
    return validity;
}

/*  let characters = /^[0-9a-zA-Z .\-@]+$/;
 let test="ec2-35-154-49-26.ap-south-1.compute.amazonaws.com";//"77-797-576-23-23423.asdfg-sdfgsd-23.sdfgsdg.hj.com";
//var test="eyJhbGciOiJIUzI1NiIs#$InR5cCI6IkpXVCJ9.eyJpZCI6IjVjMDhmZTJkNzNmZmZmMDU3MDYxZjUwMyIsImN1c3RvbWVySUQiOiIiLCJjdXN0b21lck5hbWUiOiJDVFMiLCJpYXQiOjE1NDQ3Nzg5NDQsImV4cCI6MTU0NTM4Mzc0NH0.C3zHyxfm52yAiOSrVKS5ETMHJTaSfHg8aMIqFPrejMY";
console.log("test1: "+characters.test(test));
console.log("test2: "+test.match(characters));  */


module.exports = validation;