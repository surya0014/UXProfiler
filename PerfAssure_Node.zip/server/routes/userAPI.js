var express = require('express');
var router = express.Router();
var config = require('../configuration.json');

let validationRoute = require('./validation.js');

var mongodb = require('mongodb');
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('userAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('userAPI.js : DB connection established using mongodb!');
    }
});

//Getting Applications 
router.get('/getApplicationListByCID', function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getApplicationListByCID------");

    var customerID = req.decoded.customerID;
    var id = req.decoded.id;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    if (id === null || id === undefined || id === "") {
        return res.status(404).json("Token is not valid");
    }


    var bsonCustomerID = mongodb.ObjectID(customerID);
    //"customerId": bsonCustomerID 

    var bsonID = mongodb.ObjectID(id);

    db.collection("users").findOne({ "_id": bsonID, "customerId": bsonCustomerID }, function (err, result) {
        if (err) {
            return res.status(500).json(err);
        } else {
            // console.log("Result  " + result);
            let appsWithAccess = result.apps;
            // return res.status(200).json(result.apps);
            db.collection("Customers").find({ "_id": bsonCustomerID }).project({ "application.appid": 1, "application.applicationName": 1, }).toArray((err, result) => {
                if (err) {
                    console.log("Error in getApplicationListByCID : " + err);
                    return res.status(500).json(err);
                } else {
                    let appsWithCustomer = JSON.parse(JSON.stringify(result[0].application));
                    let apps = [];
                    //console.log("Result  " + result[0].application);
                    appsWithAccess.forEach((selectedApp, index) => {
                        appsWithCustomer.forEach((app, index) => {
                            if (selectedApp.appid == app.appid) {
                                apps.push(app);
                            }
                        });
                    });
                    return res.status(200).json(apps);
                }
            });
        }
    });
    /* db.collection("Customers").find({ "_id": bsonCustomerID }).project({ "application.appid": 1, "application.applicationName": 1, }).toArray((err, result) => {
        if (err) {
            console.log("Error in getApplicationListByCID : " + err);
            return res.status(500).json(err);
        } else {
            //console.log("Result  " + result[0].application);
            return res.status(200).json(result[0].application);
        }
    }); */
});//end of //Getting Applications 

//Get Access Level
router.get('/getAccessLevelByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getAccessLevelByID------");
    var authorization = req.headers['authorization'];

    var token = '';
    if (typeof authorization !== 'undefined') {
        const bearer = authorization.split(' ');
        token = bearer[1];

        if (token === null || token === undefined || token === "")//|| validationRoute(token))
        {
            return res.status(404).json({ message: "Token is not specified or not valid" });
        }
    } else {
        //If header is undefined return Forbidden (403)
        return res.status(403).send({
            error: true,
            message: "Forbidden - No token found"
        });
    }
    var jwt = require('jsonwebtoken');

    var secretKey = config.bcryptSecretKey;
    jwt.verify(token, secretKey, function (err, decoded) {
        // console.log("decoded: "+JSON.stringify(decoded));
        if (err) { //failed verification.
            console.log(err.message);
            return res.status(403).send({
                error: true,
                message: "Forbidden - No token found"
            });
        }
        let user = decoded;
        var bsonID = mongodb.ObjectID(user.id);
        db.collection('users').findOne({ "_id": bsonID }, function (err, result) {
            if (err) {
                return res.status(500).json(err);
            } else {
                let accesslevel = result.accesslevel;
                if (accesslevel === null || accesslevel === undefined || accesslevel === "") {
                    accesslevel = 0;
                }
                let response = {
                    accesslevel: accesslevel,
                };
                return res.status(200).json(response);
            }
        });
    });
});//end of //getAccessLevelByID


//Get App Access Level
router.get('/getAppAccessLevelByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getAppAccessLevelByID------");
    var customerID = req.decoded.customerID;
    var id = req.decoded.id;
    let appID = req.query.appID;

    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    if (id === null || id === undefined || id === "") {
        return res.status(404).json("Token is not valid");
    }
    if (appID === null || appID === undefined || appID === "") {
        return res.status(404).json("Invalid");
    }

    var bsonID = mongodb.ObjectID(id);
    var bsoncustomerID = mongodb.ObjectID(customerID);
    db.collection('users').findOne({ "_id": bsonID, "customerId": bsoncustomerID }, function (err, result) {
        if (err) {
            return res.status(500).json(err);
        } else {
            var accesslevel;
            // console.log(result);
            var appsACL = result.appsACL;
            var appACL = appsACL.filter((apps) => {
                // console.log(apps.appid+"==="+ appID);
                return (apps.appid === appID);
            });
            // console.log("appACL:" + JSON.stringify(appACL));
            if (appACL.length == 1) {
                accesslevel = appACL[0].accesslevel;
            }
            if (accesslevel === null || accesslevel === undefined || accesslevel === "") {
                accesslevel = 0;
            }
            
            // console.log("accesslevel:" + accesslevel);
            let response = {
                accesslevel: accesslevel,
            };
            return res.status(200).json(response);
        }
    });
});//end of //getAppAccessLevelByID

//Get Application Name
router.get('/getApplicationNameByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getApplicationNameByID------");
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var appID = req.query.applicationId;
    var bsonCustomerID = mongodb.ObjectID(appID);
    var bsonappID = mongodb.ObjectID(appID);
    //"customerId": bsonCustomerID 
    db.collection("Customers").find({ "_id": bsonCustomerID }).project({ "application.appid": 1, "application.applicationName": 1, }).toArray((err, result) => {
        if (err) {
            console.log("Error in getApplicationListByCID : " + err);
            return res.status(500).json(err);
        } else {
            //console.log("Result  " + result[0].application);
            let apps = result[0].application;
            let app = apps.filter(app => app.appid === bsonappID);

            return res.status(200).json(app[0].applicationName);
        }
    });
});//end of //getApplicationName

//Get User Name
router.get('/getUserNameByID', function (req, res, next) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getApplicationNameByID------");
    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json("Token is not valid");
    }
    var userID = req.decoded.id;
    // console.log("id:" + userID);
    var bsonuserID = mongodb.ObjectID(userID);
    //"customerId": bsonCustomerID 

    db.collection('users').findOne({ "_id": bsonuserID }, function (err, result) {
        if (err) {
            console.log("Error in getUserNameByID : " + err);
            return res.status(500).json(err);
        } else {
            /* console.log("Result  " + result);
            let userName = result.userName;*/
            return res.status(200).json(result);
        }
    });
});//end of //getUserName


module.exports = router;
