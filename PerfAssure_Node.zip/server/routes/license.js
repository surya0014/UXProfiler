var express = require('express');
var router = express.Router();
var multer = require('multer');
var fs = require('fs');
var getmac = require('getmac');
var moment = require('moment');
var config = require('../configuration.json');
var licenseFileName = "";
var JavaCommand = "java -jar " + config.jarPath + "encryption.jar "
var mongodb = require('mongodb');
const { stringify } = require('querystring');
var ObjectID = mongodb.ObjectID;
//Using mongoclient, not using mongoose
var MongoClient = mongodb.MongoClient;
var dbURL = config.mongoDBURL;
var CIPTS_DBURL = config.CIPTS_mongoDBURL;
let db;
var CiptsDb;

MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('userAPI.js : ERROR : DB connection failed using mongodb');
        return err;
    } else {
        db = mydb.db();
        console.log('userAPI.js : DB connection established using mongodb!');
    }
});
MongoClient.connect(CIPTS_DBURL, function (err, cipts_db) {
    if (err) {
        console.log('userAPI.js : ERROR : Cipts DB connection failed using mongodb');
        return err;
    } else {
        CiptsDb = cipts_db.db();
        console.log('userAPI.js : Cipts DB connection established using mongodb');
    }
})
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, config.LicenseFilePath)
    },
    filename: function (req, file, cb) {
        var fname = file.originalname;
        licenseFileName = fname + "_" + Date.now()
        cb(null, licenseFileName);
    }
});


router.post('/uploadLicenseFile', function (req, res, next) {

    var upload = multer({
        storage: storage,
        fileFilter: function (req, file, callback) {
            console.log(" file.originalname : " + file.originalname);
            callback(null, true)
        }
    }).single('licenseFile');
    upload(req, res, function (err) {
        if (err) {
            // An error occurred when uploading
            console.log(err);
            return res.status(422).send("" + err);
        } else {
            var customerId = req.decoded.customerID;
            var encryptData = fs.readFileSync(config.LicenseFilePath + licenseFileName);
            //console.log(" encryptValue : ");
            var encryptString = encryptData.toString();
            var encryptValue = encryptString.replace(/(\n)/gm, "")
            //console.log(encryptValue);
            var JsonInput = JavaCommand + "decrypt " + encryptValue;

            const exec = require('child_process').exec;
            const childProcess = exec(JsonInput, function (err, stdout, stderr) {
                if (err) {
                    console.log(err);
                    return res.status(500).json({ "message": "Error in Decrypting License File" });
                }
                else {
                    //console.log(stdout);
                    var resultJson = JSON.parse(stdout);
                    var usageJson = {
                        "macID": resultJson.macID,
                        "startdate": resultJson.startdate,
                        "enddate": resultJson.enddate,
                        "mobperflicense": {},
                        "loadsimulationlicense": {},
                        "activemonitorlicense": {}
                    };
                    usageJson.mobperflicense.numMobReport = resultJson.numMobReport;
                    usageJson.mobperflicense.avbMobReport = resultJson.numMobReport;
                    usageJson.loadsimulationlicense.loadnumofusers = resultJson.loadnumofusers;
                    usageJson.loadsimulationlicense.loadconcurrenttest = resultJson.loadconcurrenttest;
                    usageJson.activemonitorlicense.activemonitorRuns = resultJson.activemonitorRuns;
                    usageJson.activemonitorlicense.avbactiveRuns = resultJson.activemonitorRuns;
                    var macId = getmac.default();
                    var updatedMacId = macId.replace(/:/g, "-");
                    console.log(" updatedMacId : " + updatedMacId);
                    if (resultJson.macID == undefined) {
                        return res.status(500).json({ "message": "MacId of host machine is different .Check License file" });
                    }
                    if (resultJson.macID.toLowerCase() == updatedMacId) {
                        console.log(" macid is matching with machine MacID");
                        resultJson.active = true;
                        resultJson.CustomerId = mongodb.ObjectID(customerId);
                        var licenseId = new ObjectID();
                        var pastLicenseId = "";
                        var LicenseUsageJson = {
                            "encrypted": "",
                            "LicenseId": licenseId,
                            "CustomerId": mongodb.ObjectID(customerId),
                            "active": true
                        }
                        resultJson._id = licenseId;
                        db.collection("LicensePurchaseInfo").find({ "CustomerId": mongodb.ObjectID(customerId), "timeStamp": resultJson.timeStamp }).toArray((err, result) => {
                            if (err) {
                                console.log("Error in  : getLicenseValidation " + err);
                                return res.status(500).json({ "message": " Error in getting LicensePurchaseInfo collections" });
                            } else {
                                if (result.length == 0) {

                                    db.collection("LicensePurchaseInfo").insert(resultJson, function (err, result) {
                                        if (err) {
                                            console.log("Error in adding LicensePurchaseInfo collections : " + err);
                                            return res.status(500).json({ "message": "Error in adding LicensePurchaseInfo collections" });
                                        }
                                        else {
                                            console.log("No Error in  inserting data in  LicensePurchaseInfo : ");

                                            var JsonToString = JSON.stringify(usageJson);
                                            //console.log(" Converted to String : ");
                                            //console.log(JsonToString);
                                            var resultString = JsonToString.replace(/"/g, "\\\"");
                                            //console.log(" replaced String : ");
                                            //console.log(resultString);
                                            var UpdatedInput = JavaCommand + 'encrypt ' + resultString;
                                           // console.log(" json string before encrypt");
                                            //console.log(UpdatedInput);
                                            const encryptChildProcess = exec(UpdatedInput, function (errors, encryptedResult, stderrors) {
                                                if (errors) {
                                                    console.log(errors);
                                                    reject("error in encrypting");
                                                }
                                                else {
                                                    var resultValue = encryptedResult.replace(/(\r\n|\n|\r)/gm, "");
                                                    LicenseUsageJson.encrypted = resultValue;
                                                    db.collection("LicenseUsageInfo").insert(LicenseUsageJson, function (err, result) {
                                                        if (err) {
                                                            console.log("Error in adding LicenseUsageInfo collections : " + err);
                                                            return res.status(500).json({ "message": "Error in inserting data to LicenseUsageInfo collections" });
                                                        }
                                                        else {
                                                            console.log("No Error in  inserting data in  LicenseUsageInfo : ");
                                                            return res.status(200).json("License File  is uploaded  successfully");
                                                        }
                                                    });
                                                }

                                            });
                                        }
                                    });

                                } else {
                                    return res.status(200).json("Uploaded License File is already used");
                                }
                            }
                        });
                    } else {
                        return res.status(500).json({ "message": "macId for host machine is different .Check License file ." });
                    }
                }

            });
        }
    });
});



router.get('/getLicenseInformation', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----getLicenseInformation------");
    var customerId = req.decoded.customerID;
    var licenseInfo = [];
    var count = 0;
    var updatedStatus;
    try {
        updatedStatus = await updateLicenseFileStatus(customerId);
        //console.log(" after updateLicenseFileStatus");
    } catch (error) {
        console.log("Error in  : getLicenseValidation " + err);
        return res.status(500).json({ "message": "Error in getting License Information " });
    }

    db.collection("Customers").find({ "CustomerId": customerId }).toArray((err, resultCust) => {
        if (err) {
            console.log("Error in  : getLicenseValidation " + err);
            return res.status(500).json({ "message": "Error  in Validating License Information" });
        } else {
            var installationType = "hosted";
            if (resultCust.length != 0) {
                installationType = resultCust[0].installationType;
            }
            db.collection("LicensePurchaseInfo").find({ "CustomerId": mongodb.ObjectID(customerId) }).toArray(async (err, result) => {
                if (err) {
                    console.log("Error in  : getting LicenseValidation " + err);
                    return res.status(500).json({ "message": "Error in getting License Information " });
                } else {
                    if (result.length == 0) {
                        //console.log(" No of Documents  : " + result.length);
                        return res.status(500).json({ "message": "License File is not active" });
                    } else {

                        for (let resultObj of result) {

                            db.collection("LicenseUsageInfo").find({ "LicenseId": resultObj._id }).toArray((err, resultData) => {
                                if (err) {
                                    console.log("Error in  : getLicenseValidation " + err);
                                    //return res.status(500).json(err);
                                    return res.status(500).json({ "message": "Error in getting License Information " });
                                } else {
                                    var licenseInfoForLoadSimulation = {
                                        'components': 'Load Simulator',
                                        'licensepurchased': '',
                                        'licenseavailable': '',
                                        'dateofpurchase': '',
                                        'expirydate': '',
                                        'licensestatus': ''
                                    };
                                    var licenseInfoForActiveMonitor = {
                                        'components': 'Active Monitor',
                                        'licensepurchased': '',
                                        'licenseavailable': '',
                                        'dateofpurchase': '',
                                        'expirydate': '',
                                        'licensestatus': ''
                                    }
                                    var licenseInfoForUxMobile = {
                                        'components': 'UX Profiler Mobile',
                                        'licensepurchased': '',
                                        'licenseavailable': '',
                                        'dateofpurchase': '',
                                        'expirydate': '',
                                        'licensestatus': ''
                                    }
                                    //console.log(" purchased license ");
                                    //console.log(resultObj);
                                    
                                    licenseInfoForActiveMonitor.licensepurchased = resultObj.activemonitorRuns + " Measurements";
                                    licenseInfoForUxMobile.licensepurchased = resultObj.numMobReport + " Reports";

                                    var encryptedValue = resultData[0].encrypted;
                                    var encryptedInput = JavaCommand + 'decrypt ' + encryptedValue;
                                    const exec = require('child_process').exec;
                                    const decryptChildProcess = exec(encryptedInput, function (err, stdout, stderr) {
                                        if (err) {
                                            console.log(" Error in decrypting : " + err);
                                            return res.status(500).json({ "message": "Error in getting License Information " });
                                        }
                                        else {
                                            var replacedString = stdout.replace("\\", "");
                                            //console.log(replacedString);
                                            var resultJson = JSON.parse(replacedString);

                                            var start_date = resultJson.startdate
                                            var end_date = resultJson.enddate;
                                            var year = start_date.substring(0, 4);
                                            var month = start_date.substring(4, 6);
                                            var day = start_date.substring(6, 8);
                                            var hour = start_date.substring(9, 11);
                                            var minute = start_date.substring(11, 13);
                                            var second = start_date.substring(13, 15);
                                            var sd = new Date(year, month - 1, day, hour, minute, second);
                                            var startdate = moment(sd).format("DD MMMM YYYY");
                                            var year = end_date.substring(0, 4);
                                            var month = end_date.substring(4, 6);
                                            var day = end_date.substring(6, 8);
                                            var hour = end_date.substring(9, 11);
                                            var minute = end_date.substring(11, 13);
                                            var second = end_date.substring(13, 15);
                                            var ed = new Date(year, month - 1, day, hour, minute, second);
                                            var current_time = new Date();
                                            var enddate = moment(ed).format("DD MMMM YYYY");
                                            licenseInfoForLoadSimulation.dateofpurchase = startdate;
                                            licenseInfoForActiveMonitor.dateofpurchase = startdate;
                                            licenseInfoForUxMobile.dateofpurchase = startdate;
                                            licenseInfoForLoadSimulation.expirydate = enddate;
                                            licenseInfoForActiveMonitor.expirydate = enddate;
                                            licenseInfoForUxMobile.expirydate = enddate;
                                            if (installationType == "hosted") {
                                                licenseInfoForLoadSimulation.licenseavailable = resultJson.loadsimulationlicense.loadnumofusers + " VUH";
                                                licenseInfoForLoadSimulation.licensepurchased = resultObj.loadnumofusers + " VUH";
                                            } else {
                                                licenseInfoForLoadSimulation.licenseavailable = resultJson.loadsimulationlicense.loadnumofusers + " VUSERS";
                                                licenseInfoForLoadSimulation.licensepurchased = resultObj.loadnumofusers + " VUSERS";
                                            }
                                            licenseInfoForActiveMonitor.licenseavailable = resultJson.activemonitorlicense.avbactiveRuns + " Measurements";
                                            licenseInfoForUxMobile.licenseavailable = Math.ceil(resultJson.mobperflicense.avbMobReport) + " Reports";
                                            //console.log(resultData[0].active);
                                            if (resultData[0].active) {
                                                if (sd.getTime() > current_time.getTime()) {
                                                    licenseInfoForLoadSimulation.licensestatus = 'InActive';
                                                    licenseInfoForActiveMonitor.licensestatus = 'InActive';
                                                    licenseInfoForUxMobile.licensestatus = 'InActive';
                                                } else {
                                                    licenseInfoForLoadSimulation.licensestatus = 'Active';
                                                    licenseInfoForActiveMonitor.licensestatus = 'Active';
                                                    licenseInfoForUxMobile.licensestatus = 'Active';
                                                }

                                            } else {
                                                licenseInfoForLoadSimulation.licensestatus = 'Expired';
                                                licenseInfoForActiveMonitor.licensestatus = 'Expired';
                                                licenseInfoForUxMobile.licensestatus = 'Expired';
                                            }
                                            licenseInfo.push(licenseInfoForLoadSimulation);
                                            licenseInfo.push(licenseInfoForActiveMonitor);
                                            licenseInfo.push(licenseInfoForUxMobile);
                                            //console.log(JSON.stringify(licenseInfoForLoadSimulation));
                                            count++;
                                            if (result.length == count) {
                                                //console.log("license Doc count in get License Info : " + licenseInfo.length);
                                                return res.status(200).json(licenseInfo);
                                                //resolve(licenseInfo);
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
            });
        }
    });
    // try {
    //     let ResultLicense = await iterateLicenseValidation(result);
    //     return res.status(200).json(ResultLicense);
    // } catch (error) {
    //     console.log(error);
    //     return res.status(500).json(" Error in getLicenseInformation " + error);
    // }
});
function updateLicenseFileStatus(customerId) {
    return new Promise(function (resolve, reject) {
        console.log(" Checking on updating License Status ");
        var count = 0;
        db.collection("LicensePurchaseInfo").find({ "CustomerId": mongodb.ObjectID(customerId), "active": true }).toArray((err, result) => {
            if (err) {
                console.log("Error in  : getLicenseValidation " + err);
                reject(err);
                //return { "error": true, "message": " Error in getting LicensePurchaseInfo collections" };
            } else {
                if (result.length == 0) {
                    //console.log(" No of Documents in updateLicenseFileStatus : " + result.length);
                    resolve("No documents");
                } else {

                    var DocLength = result.length;
                    for (let resultObj of result) {
                        db.collection("LicenseUsageInfo").find({ "LicenseId": resultObj._id }).toArray((err, resultData) => {
                            if (err) {
                                console.log("Error in  : getLicenseValidation " + err);
                                reject(err);
                                //return {"error":true,"message":err};
                            } else {

                                //console.log(" iteration num " + count);
                                console.log(" inside LicenseUsageInfo collection in license update status ");
                                var encryptedValue = resultData[0].encrypted;
                                var encryptedInput = JavaCommand + 'decrypt ' + encryptedValue;
                                const exec = require('child_process').exec;
                                const decryptChildProcess = exec(encryptedInput, function (err, stdout, stderr) {
                                    if (err) {
                                        console.log(" Error in decrypting : " + err);
                                        reject(err);
                                    }
                                    else {
                                        var replacedString = stdout.replace("\\", "");
                                        //console.log(replacedString);
                                        var resultJson = JSON.parse(replacedString);
                                        var active = checkEndDateValidation(new Date(), resultJson.enddate);
                                        if (!active) {
                                            db.collection("LicensePurchaseInfo").update({ "_id": resultObj._id },
                                                { $set: { "active": false } }, function (err, result) {
                                                    if (err) {
                                                        console.log("Error in updating status : " + err);
                                                        reject(err);
                                                        //return { "error": true, "message": "Error in updating status in LicensePurchaseInfo collections" };
                                                    } else {
                                                        console.log(" updated License active status in LicensePurchaseInfo");

                                                        db.collection("LicenseUsageInfo").update({ "LicenseId": resultObj._id },
                                                            { $set: { "active": false } }, function (err, result) {
                                                                if (err) {
                                                                    console.log("Error in updating status : " + err);
                                                                    reject(err);
                                                                    //return { "error": true, "message": "Error in updating status in LicensePurchaseInfo collections" };
                                                                } else {
                                                                    console.log(" updated License active status in LicenseUsageInfo");
                                                                    count++;
                                                                    if (DocLength == count) {
                                                                        //console.log("license count in License Update status : " + DocLength);
                                                                        resolve("updated");
                                                                        //return res.status(200).json(licenseInfo);
                                                                    }
                                                                }
                                                            });
                                                    }
                                                });

                                        }
                                        else {
                                            count++;
                                            if (DocLength == count) {
                                                //console.log("license count in License Update status : " + DocLength);
                                                resolve("updated");
                                                //return res.status(200).json(licenseInfo);
                                            }
                                        }


                                    }
                                });

                            }
                        });
                    }
                }
            }
        });
    });
}

router.get('/LicenseValidatorApi', async function (req, res) {
    res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    console.log("-----Licensevalidatorapi------");

    var component = req.query.component;
    var users = req.query.users;
    var op = req.query.op;

    var customerID = req.decoded.customerID;
    if (customerID === null || customerID === undefined || customerID === "") {
        return res.status(404).json({ "message": "Token is not valid" });
    }
    var flag = true;
    if (req.query.customerID === null || req.query.customerID === undefined || req.query.customerID === "") {
        flag = false;
    }
    if (flag) {
        var customerID = req.query.customerID;
    }
    if (component === null || component === undefined || component === "" || users === null || users === undefined ||
        users === "" || op === "" || op === undefined || op === null) {
        return res.status(404).json({ "message": " Query parameters is not valid" });
    }
    var duration;
    if (component == "loadsimulation") {
        duration = req.query.duration;
        if (duration === null || duration == undefined || duration === "") {
            return res.status(404).json({ "message": " Query parameters is not valid" });
        }
    }
    var bsonCustomerID = mongodb.ObjectID(customerID);
    var updatedStatus;
    
    try {
        updatedStatus = await updateLicenseFileStatus(customerID);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ "message": " Error in Validating License Information " });
    }

    db.collection("LicenseUsageInfo").find({ "CustomerId": bsonCustomerID, "active": true }).sort({ "_id": -1 }).toArray(async (err, result) => {
        if (err) {
            console.log("Error in  : getLicenseValidation " + err);
            return res.status(500).json({ "message": "Error  in Validating License Information" });
        } else {
            if (result.length == 0) {
                console.log(" No of Documents  : " + result.length);
                return res.status(500).json({ "message": "License File is not active" });
            } else {
                //console.log(" validation or decrement starts ");
                //console.log(" Total  Document count:  " + result.length);
                var count = 0;
                for (let resultObj of result) {
                    var checkStartDate;
                    var licenseId = resultObj.LicenseId;
                    try {
                        //console.log(" before checkStartDateValidation ");
                        checkStartDate = await checkStartDateValidation(resultObj.encrypted);
                        console.log(" after start Date Validation checkStartDate " + checkStartDate);
                        count++;
                        if (checkStartDate == "valid") {
                            switch (component) {
                                case "loadsimulation":
                                    {
                                       
                                        if (op == "validate") {
                                            try {
                                                var checkValue = await checkValidationForLoadSimulation(resultObj.encrypted, users, bsonCustomerID, duration);
                                                //console.log(checkValue);
                                                
                                                if (checkValue.status == "valid") {
                                                    //console.log("valid");
                                                    return res.status(200).json("valid");
                                                } else if (checkValue.status == "invalid") {
                                                    if (count == result.length) {
                                                             //console.log("invalid");
                                                       return res.status(200).json("invalid");                                         
                                                    //    return res.status(200).json("valid");
                                                    } else {
                                                        //console.log(" license invalid in loadsimulation passing to next ");
                                                        break;
                                                    }
                                                } else {
                                                    return res.status(200).json(checkValue.userVUH + " VUH will be used");
                                                }

                                            } catch (error) {
                                                console.log(error);
                                                return res.status(500).json({ "message": " Error in validating License For LoadSimulation" });
                                            }
                                        } else {
                                            try {
                                                var checkValue = await decrementForLoadSimulation(resultObj.encrypted, licenseId, users, bsonCustomerID, duration);
                                                //console.log(checkValue);
                                                if (checkValue == "updated") {
                                                    return res.status(200).json("updated");
                                                } else {
                                                    if (count == result.length) {
                                                        return res.status(200).json("notUpdated");
                                                    } else {
                                                        //console.log(" license invalid in loadsimulation passing to next ");
                                                        break;
                                                    }
                                                }

                                            } catch (error) {
                                                console.log(error);
                                                return res.status(500).json({ "message": " Error in validating License For LoadSimulation" });
                                            }
                                        }
                                    }
                                case "activemonitor":
                                    {
                                        if (op == "validate") {
                                            try {
                                                var checkValue = await checkValidationForActiveMonitor(resultObj.encrypted);
                                                //console.log(" Active Monitor validation " + checkValue);
                                                if (checkValue == "valid") {
                                                    return res.status(200).json("valid");
                                                } else {
                                                    if (count == result.length) {
                                                        //console.log(" count in LicenseValidatorApi in active Monitor : " + count);
                                                        return res.status(200).json("invalid");
                                                    } else {
                                                        //console.log(" license invalid in active Monitor passing to next ");
                                                        break;
                                                    }

                                                }
                                            } catch (error) {
                                                console.log(error);
                                                return res.status(500).json({ "message": " Error in validating License For active Monitor" });
                                            }
                                        } else {
                                            try {
                                                var checkValue = await DecrementForActiveMonitor(resultObj.encrypted, licenseId);
                                                //console.log(checkValue);
                                                if (checkValue == "updated") {
                                                    return res.status(200).json({ "message": "License Details updated For Active Monitor in LicenseUsageInfo", "license": true });
                                                } else {

                                                    if (count == result.length) {
                                                       // console.log(" count in LicenseValidatorApi in active Monitor: " + count);
                                                        return res.status(200).json({ "message": "licenseinvalid", "license": false });

                                                    } else {
                                                       // console.log(" license invalid in Active Monitor ");
                                                        break;
                                                    }


                                                }
                                            } catch (error) {
                                                console.log(error);
                                                return res.status(500).json({ "message": " Error in updating License Details For Active Monitor " });
                                            }
                                        }


                                    }

                                case "uxWeb":
                                    {
                                        try {
                                            console.log(" UxPerf validation");
                                            var checkValue = await checkValidationForUxWeb(resultObj.encrypted);
                                            //console.log(checkValue);
                                            if (checkValue == "valid") {
                                                return res.status(200).json("valid");
                                            } else {
                                                if (count == result.length) {
                                                    return res.status(200).json("invalid");
                                                } else {
                                                    //console.log(" license invalid in uxWeb passing to next ");
                                                    break;
                                                }
                                            }
                                        } catch (error) {
                                            console.log(error);
                                            return res.status(500).json({ "message": " Error in validating License for uxWeb" });
                                        }

                                    }
                                case "uxMobile":
                                    {
                                        if (op == "validate") {
                                            try {
                                                var checkValue = await checkValidationForUxMobile(resultObj.encrypted);
                                                //console.log(checkValue);
                                                if (checkValue == "valid") {
                                                    return res.status(200).json("valid");
                                                } else {
                                                    if (count == result.length) {
                                                        return res.status(200).json("invalid");
                                                    } else {
                                                        //console.log(" license invalid in uxMobile passing to next ");
                                                        break;
                                                    }
                                                }
                                            } catch (error) {
                                                console.log(error);
                                                return res.status(500).json({ "message": " Error in validating License for uxMobile" });
                                            }
                                        } else {
                                            try {
                                                var checkValue = await DecrementForUxMobile(resultObj.encrypted, licenseId, users);
                                                //console.log(checkValue);
                                                if (checkValue == "updated") {
                                                    return res.status(200).json({ "message": "License Details updated For  UxMobile in LicenseUsageInfo", "license": true });
                                                } else {
                                                    if (count == result.length) {
                                                        return res.status(200).json({ "message": "licenseinvalid", "license": false });

                                                    } else {
                                                        //console.log("license invalid in uxMobile passing to next  ");
                                                        break;
                                                    }

                                                }
                                            } catch (error) {
                                                console.log(error);
                                                return res.status(500).json({ "message": " Error in updating in LicenseUsageInfo " });
                                            }
                                        }

                                    }
                            }
                        } else {
                            if (count == result.length) {
                                return res.status(200).json("invalid");
                            }
                        }

                    } catch (error) {
                        console.log(error);
                        return res.status(500).json({ "message": " Error in getting LicenseInformation " });
                    }

                }
            }

        }
    });

});



function checkValidationForUxWeb(encryptedValue) {
    return new Promise(function (resolve, reject) {
        //var JarPath = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar decrypt ';
        var JsonInput = JavaCommand + "decrypt " + encryptedValue;

        const exec = require('child_process').exec;
        const childProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                //console.log(replacedString);
                var resultJson = JSON.parse(replacedString);
                //console.log(JSON.stringify(resultJson));
                var Current_date = new Date();
                var ed = resultJson.enddate;
                var checkEndDateValidate = checkEndDateValidation(Current_date, ed);
                if (checkEndDateValidate) {
                    resolve("valid");
                } else {
                    resolve("invalid");
                }

            }

        });
    });
}

function checkStartDateValidation(encryptedValue) {

    return new Promise(function (resolve, reject) {

        var JsonInput = JavaCommand + "decrypt " + encryptedValue;

        const exec = require('child_process').exec;
        const childProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                var resultJson = JSON.parse(replacedString);
                // console.log(JSON.stringify(resultJson));
                var Current_date = new Date();

                var str = resultJson.startdate;
                var year = str.substring(0, 4);
                var month = str.substring(4, 6);
                var day = str.substring(6, 8);
                var hour = str.substring(9, 11);
                var minute = str.substring(11, 13);
                var second = str.substring(13, 15);
                var start_date = new Date(year, month - 1, day, hour, minute, second);
                console.log(" Current_date " + Current_date);
                console.log(" start_date " + start_date);

                if (Current_date.getTime() > start_date.getTime()) {
                    resolve("valid");
                } else {
                    resolve("invalid");
                }
            }
        });
    });
}
function checkEndDateValidation(Current_date, str) {
    console.log(" checkEndDateValidation /n");
    var year = str.substring(0, 4);
    var month = str.substring(4, 6);
    var day = str.substring(6, 8);
    var hour = str.substring(9, 11);
    var minute = str.substring(11, 13);
    var second = str.substring(13, 15);
    var end_date = new Date(year, month - 1, day, hour, minute, second);
    //console.log(" Current_date " + Current_date);
    //console.log(" end_date " + end_date);
    if (Current_date.getTime() < end_date.getTime()) {
        return true;
    } else {
        return false;
    }

}

function checkValidationForLoadSimulation(encryptedValue, users, customerId, duration) {
    return new Promise(function (resolve, reject) {
        //var JarPath = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar decrypt ';
        var JsonInput = JavaCommand + "decrypt " + encryptedValue;
        var usersCount = Number(users);
        const exec = require('child_process').exec;
        const childProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                //console.log(replacedString);
                var resultJson = JSON.parse(replacedString);
                //console.log(JSON.stringify(resultJson));

                var Current_date = new Date();
                //console.log(resultJson.enddate);

                var ed = resultJson.enddate;
                var checkEndDateValidate = checkEndDateValidation(Current_date, ed);
                if (!checkEndDateValidate) {
                    resolve({ "status": "invalid" });
                }

                db.collection("Customers").find({ "CustomerId": customerId }).toArray((err, resultCust) => {
                    if (err) {
                        console.log("Error in  : getLicenseValidation " + err);
                        return res.status(500).json({ "message": "Error  in Validating License Information" });
                    } else {
                        var installationType = "hosted";
                        if ((resultCust.length != 0) && (resultCust.hasOwnProperty('installationType'))) {
                            installationType = resultCust[0].installationType;
                        }
                        CiptsDb.collection("TestRuns").find({ "customerId": customerId, "status": "Running" }).toArray((err, result) => {
                            if (err) {
                                console.log("Error in  : getLicenseValidation " + err);
                                return res.status(500).json(err);
                            }
                            else {
                                for (let resultObj of result) {
                                    for (let testGroups of resultObj.testGroups) {
                                        if (testGroups.enabled) {
                                            if (testGroups.type == "Default") {
                                                usersCount = usersCount + testGroups.usersCount;
                                            }
                                            else {
                                                for (let threadObj of testGroups.threadsSchedule) {
                                                    usersCount = threadObj.startTheardsCount + usersCount;
                                                }
                                            }
                                        }
                                    }
                                }
                                //console.log(" usersCount " + usersCount);
                                //console.log(" installationType : " + installationType);
                                if (installationType == "hosted") {
                                    var userVUH = Math.ceil((usersCount * duration) / 60);
                                    //console.log("userVUH : " + userVUH)
                                    if (userVUH <= resultJson.loadsimulationlicense.loadnumofusers) {
                                        resolve({ "status": "validForHosted", "userVUH": userVUH });
                                    } else {
                                        resolve({ "status": "invalid" });
                                    }
                                } else {
                                    if (usersCount <= resultJson.loadsimulationlicense.loadnumofusers) {
                                        // currentTestCount <= usersCount <= resultJson.loadsimulationlicense.loadconcurrenttest) {
                                        resolve({ "status": "valid" });
                                    } else {
                                        resolve({ "status": "invalid" });
                                    }
                                }


                            }
                        })
                    }
                });

            }

        });
    });

}

function decrementForLoadSimulation(encryptedValue, licenseId, users, customerId, duration) {
    return new Promise(function (resolve, reject) {
        //var JarPath = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar decrypt ';
        var JsonInput = JavaCommand + "decrypt " + encryptedValue;
        var usersCount = Number(users);
        const exec = require('child_process').exec;
        const childProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                //console.log(replacedString);
                var resultJson = JSON.parse(replacedString);
                //console.log(JSON.stringify(resultJson));

                var Current_date = new Date();
                //console.log(resultJson.enddate);

                var ed = resultJson.enddate;
                var checkEndDateValidate = checkEndDateValidation(Current_date, ed);
                if (!checkEndDateValidate) {
                    resolve({ "status": "invalid" });
                }

                db.collection("Customers").find({ "CustomerId": customerId }).toArray((err, resultCust) => {
                    if (err) {
                        console.log("Error in  : getLicenseValidation " + err);
                        return res.status(500).json({ "message": "Error  in Validating License Information" });
                    } else {
                        var installationType = "hosted";
                        if ((resultCust.length != 0) && (resultCust.hasOwnProperty('installationType'))) {
                            installationType = resultCust[0].installationType;
                        }
                        CiptsDb.collection("TestRuns").find({ "customerId": customerId, "status": "Running" }).toArray((err, result) => {
                            if (err) {
                                console.log("Error in  : getLicenseValidation " + err);
                                return res.status(500).json(err);
                            }
                            else {
                                for (let resultObj of result) {
                                    for (let testGroups of resultObj.testGroups) {
                                        if (testGroups.enabled) {
                                            if (testGroups.type == "Default") {
                                                usersCount = usersCount + testGroups.usersCount;
                                            }
                                            else {
                                                for (let threadObj of testGroups.threadsSchedule) {
                                                    usersCount = threadObj.startTheardsCount + usersCount;
                                                }
                                            }
                                        }
                                    }
                                }
                                //console.log(" usersCount " + usersCount);
                               //console.log(" installationType : " + installationType);
                                if (installationType == "hosted") {
                                   // console.log("duration : "+duration);
                                    var userVUH = Math.ceil((usersCount * duration) / 60);
                                    //console.log("userVUH " + userVUH);
                                    if (resultJson.loadsimulationlicense.loadnumofusers > 0) {
                                        let loadnumofusers = resultJson.loadsimulationlicense.loadnumofusers - userVUH;
                                        resultJson.loadsimulationlicense.loadnumofusers = loadnumofusers;
                                       // console.log(" decrement Load simulation " + resultJson.loadsimulationlicense.loadnumofusers);
                                        var JsonToString = JSON.stringify(resultJson);
                                        //console.log(" Converted to String : ");
                                        //console.log(JsonToString);
                                        var resultString = JsonToString.replace(/"/g, "\\\"");
                                        //console.log(" replaced String : ");
                                        //console.log(resultString);
                                        var UpdatedInput = JavaCommand + 'encrypt ' + resultString;
                                        //console.log(" json string before encrypt");
                                        //console.log(UpdatedInput);
                                        const encryptChildProcess = exec(UpdatedInput, function (errors, result, stderrors) {
                                            if (errors) {
                                                console.log(errors);
                                                reject("error in encrypting");
                                            }
                                            else {
                                                console.log(" result : /n");
                                                //console.log(result);

                                                var resultUpdated = result.replace(/(\r\n|\n|\r)/gm, "");
                                                //console.log("resultUpdated : ");
                                                //console.log(resultUpdated);
                                                db.collection("LicenseUsageInfo").updateOne({ "LicenseId": licenseId }, {
                                                    "$set": {
                                                        "encrypted": resultUpdated,
                                                    }
                                                }, function (err) {
                                                    if (err) {
                                                        console.log(err);
                                                        reject("error in updating to LicenseUsageInfo collection");
                                                    }
                                                    else {
                                                        console.log(" document updated into LicenseUsageInfo collection");
                                                        resolve("updated");
                                                    }
                                                });
                                            }
                                        });

                                    } else {
                                        resolve({ "status": "invalid" });
                                    }

                                } else {
                                    resolve({ "status": "invalid" });
                                }
                            }
                        })
                    }
                });

            }

        });
    });

}

function checkValidationForUxMobile(encryptedValue) {
    return new Promise(function (resolve, reject) {
        //var JarPath = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar decrypt ';
        var JsonInput = JavaCommand + "decrypt " + encryptedValue;

        const exec = require('child_process').exec;
        const childProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                //console.log(replacedString);
                var resultJson = JSON.parse(replacedString);
                var activeRun = Number(resultJson.mobperflicense.avbMobReport);
                var Current_date = new Date();
                //console.log(resultJson.enddate);
                var ed = resultJson.enddate;
                var checkEndDateValidate = checkEndDateValidation(Current_date, ed);
                //console.log(" activeRun " + activeRun);
                if (activeRun > 0 && checkEndDateValidate) {
                    resolve("valid");
                } else {
                    resolve("invalid");
                }
            }

        });
    });
}

function DecrementForUxMobile(encryptedValue, licenseId, transactionCount) {
    return new Promise(function (resolve, reject) {
        //var JarPath = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar ';
        var JsonInput = JavaCommand + "decrypt " + encryptedValue;

        const exec = require('child_process').exec;
        const decryptChildProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error in decrypting");
            }
            else {
                var replacedString = stdout.replace("\\", "");
               // console.log(replacedString);
                var resultJson = JSON.parse(replacedString);
                var activeRun = Number(resultJson.mobperflicense.avbMobReport);
                var transaction = transactionCount / 10;
                if (activeRun - transaction > 0) {
                    activeRun = activeRun - transaction;
                    resultJson.mobperflicense.avbMobReport = "" + activeRun;
                    //console.log(" decrement Mobile Active " + resultJson.mobperflicense.avbMobReport);
                   // console.log(resultJson.mobperflicense.avbMobReport);
                    var JsonToString = JSON.stringify(resultJson);
                    //console.log(" Converted to String : ");
                    //console.log(JsonToString);
                    var resultString = JsonToString.replace(/"/g, "\\\"");
                    //console.log(" replaced String : ");
                    //console.log(resultString);
                    var UpdatedInput = JavaCommand + 'encrypt ' + resultString;
                   // console.log(" json string before encrypt");
                   // console.log(UpdatedInput);
                    const encryptChildProcess = exec(UpdatedInput, function (errors, result, stderrors) {
                        if (errors) {
                            console.log(errors);
                            reject("error in encrypting");
                        }
                        else {
                            console.log(" result : /n");
                            //console.log(result);

                            var resultUpdated = result.replace(/(\r\n|\n|\r)/gm, "");
                            //console.log("resultUpdated : ");
                            //console.log(resultUpdated);
                            db.collection("LicenseUsageInfo").updateOne({ "LicenseId": licenseId }, {
                                "$set": {
                                    "encrypted": resultUpdated,
                                }
                            }, function (err) {
                                if (err) {
                                    console.log(err);
                                    reject("error in updating to LicenseUsageInfo collection");
                                }
                                else {
                                    console.log(" document updated into LicenseUsageInfo collection");
                                    resolve("updated");
                                }
                            });
                        }
                    });
                } else {
                    resolve("invalid")
                }
            }

        });
    });
}

function checkValidationForActiveMonitor(encryptedValue) {
    return new Promise(function (resolve, reject) {
        console.log(" checkValidationForActiveMonitor ");
        var JsonInput = JavaCommand + "decrypt " + encryptedValue;

        const exec = require('child_process').exec;
        const childProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                //console.log(replacedString);
                var resultJson = JSON.parse(replacedString);
                var activeRun = Number(resultJson.activemonitorlicense.avbactiveRuns);
                var Current_date = new Date();
                //console.log(resultJson.enddate);
                var ed = resultJson.enddate;
                var checkEndDateValidate = checkEndDateValidation(Current_date, ed);
                if (activeRun > 0 && checkEndDateValidate) {
                    resolve("valid");
                } else {
                    resolve("invalid");
                }
            }

        });
    });
}

function DecrementForActiveMonitor(encryptedValue, LicenseId) {
    return new Promise(function (resolve, reject) {
        //var JarPath = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar ';

        var JsonInput = JavaCommand + 'decrypt ' + encryptedValue;

        const exec = require('child_process').exec;
        const decryptChildProcess = exec(JsonInput, function (err, stdout, stderr) {
            if (err) {
                console.log(err);
                reject("error in decrypting");
            }
            else {
                var replacedString = stdout.replace("\\", "");
                //console.log(replacedString);
                var resultJson = JSON.parse(replacedString);

                //validate license before decrement 
                var activeRun = Number(resultJson.activemonitorlicense.avbactiveRuns);
                var Current_date = new Date();
                //console.log(resultJson.enddate);
                var ed = resultJson.enddate;
                var checkEndDateValidate = checkEndDateValidation(Current_date, ed);

                if (activeRun > 0 && checkEndDateValidate) {
                    activeRun--;
                    resultJson.activemonitorlicense.avbactiveRuns = "" + activeRun;
                    //console.log(resultJson.activemonitorlicense.avbactiveRuns);
                    var JsonToString = JSON.stringify(resultJson);
                    //console.log(" Converted to String : ");
                    //console.log(JsonToString);
                    var resultString = JsonToString.replace(/"/g, "\\\"");
                    //console.log(" replaced String : ");
                    //console.log(resultString);
                    var UpdatedInput = JavaCommand + 'encrypt ' + resultString;
                    //console.log(" json string before encrypt");
                    //console.log(UpdatedInput);
                    const encryptChildProcess = exec(UpdatedInput, function (errors, result, stderrors) {
                        if (errors) {
                            console.log(errors);
                            reject("error in encrypting");
                        }
                        else {
                            //console.log(" result : /n");
                            //console.log(result);

                            var resultUpdated = result.replace(/(\r\n|\n|\r)/gm, "");
                            //console.log("resultUpdated : ");
                            //console.log(resultUpdated);
                            db.collection("LicenseUsageInfo").updateOne({ "LicenseId": LicenseId }, {
                                "$set": {
                                    "encrypted": resultUpdated,
                                }
                            }, function (err) {
                                if (err) {
                                    console.log(err);
                                    reject("error in updating to LicenseUsageInfo collection");
                                }
                                else {
                                    console.log(" document updated into LicenseUsageInfo collection");
                                    resolve("updated");
                                }
                            });
                        }
                    });
                } else {
                    resolve("invalid");
                }

            }

        });
    });
}

module.exports = router;


// function iterateLicenseValidation(result) {
//     return new Promise(function (resolve, reject) {

//         var licenseInfo = [];
//         var count = 0;
//         console.log(" result : " + result.length);
//         for (let resultObj of result) {
//             var licenseInfoForLoadSimulation = {
//                 'components': 'Load Simulation',
//                 'licensepurchased': '',
//                 'licenseavailable': '',
//                 'dateofpurchase': '',
//                 'expirydate': '',
//                 'licensestatus': ''
//             };
//             var licenseInfoForActiveMonitor = {
//                 'components': 'Active Monitor',
//                 'licensepurchased': '',
//                 'licenseavailable': '',
//                 'dateofpurchase': '',
//                 'expirydate': '',
//                 'licensestatus': ''
//             }
//             var licenseInfoForUxMobile = {
//                 'components': 'UxMobile',
//                 'licensepurchased': '',
//                 'licenseavailable': '',
//                 'dateofpurchase': '',
//                 'expirydate': '',
//                 'licensestatus': ''
//             }
//             var start_date = resultObj.startdate
//             var end_date = resultObj.enddate;
//             var year = start_date.substring(0, 4);
//             var month = start_date.substring(4, 6);
//             var day = start_date.substring(6, 8);
//             var hour = start_date.substring(9, 11);
//             var minute = start_date.substring(11, 13);
//             var second = start_date.substring(13, 15);
//             var sd = new Date(year, month - 1, day, hour, minute, second);
//             var startdate = moment(sd).format("DD MMMM YYYY");
//             var year = end_date.substring(0, 4);
//             var month = end_date.substring(4, 6);
//             var day = end_date.substring(6, 8);
//             var hour = end_date.substring(9, 11);
//             var minute = end_date.substring(11, 13);
//             var second = end_date.substring(13, 15);
//             var ed = new Date(year, month - 1, day, hour, minute, second);
//             var enddate = moment(ed).format("DD MMMM YYYY");
//             licenseInfoForLoadSimulation.dateofpurchase = startdate;
//             licenseInfoForActiveMonitor.dateofpurchase = startdate;
//             licenseInfoForUxMobile.dateofpurchase = startdate;
//             licenseInfoForLoadSimulation.expirydate = enddate;
//             licenseInfoForActiveMonitor.expirydate = enddate;
//             licenseInfoForUxMobile.expirydate = enddate;
//             licenseInfoForLoadSimulation.licensepurchased = resultObj.loadnumofusers + " VUSERS";
//             licenseInfoForActiveMonitor.licensepurchased = resultObj.activemonitorRuns + " Measurements";
//             licenseInfoForUxMobile.licensepurchased = resultObj.numMobReport + " Reports";
//             var licenseId = resultObj._id;

//             db.collection("LicenseUsageInfo").find({ "LicenseId": licenseId }).toArray((err, resultData) => {
//                 if (err) {
//                     console.log("Error in  : getLicenseValidation " + err);
//                     reject(error)
//                     //return res.status(500).json(err);
//                 } else {
//                     var encryptedValue = resultData[0].encrypted;
//                     var encryptedInput = JavaCommand + 'decrypt ' + encryptedValue;
//                     const exec = require('child_process').exec;
//                     const decryptChildProcess = exec(encryptedInput, function (err, stdout, stderr) {
//                         if (err) {
//                             console.log(err);
//                         }
//                         else {
//                             var replacedString = stdout.replace("\\", "");
//                             console.log(replacedString);
//                             var resultJson = JSON.parse(replacedString);
//                             licenseInfoForLoadSimulation.licenseavailable = resultJson.loadsimulationlicense.loadnumofusers + " VUSERS";
//                             licenseInfoForActiveMonitor.licenseavailable = resultJson.activemonitorlicense.avbactiveRuns + " Measurements";
//                             licenseInfoForUxMobile.licenseavailable = resultJson.mobperflicense.avbMobReport + " Reports";
//                             var active = checkEndDateValidation(new Date(), resultJson.enddate);
//                             if (active) {
//                                 licenseInfoForLoadSimulation.licensestatus = 'Active';
//                                 licenseInfoForActiveMonitor.licensestatus = 'Active';
//                                 licenseInfoForUxMobile.licensestatus = 'Active';
//                             } else {
//                                 licenseInfoForLoadSimulation.licensestatus = 'InActive';
//                                 licenseInfoForActiveMonitor.licensestatus = 'InActive';
//                                 licenseInfoForUxMobile.licensestatus = 'InActive';
//                             }
//                             licenseInfo.push(licenseInfoForLoadSimulation);
//                             licenseInfo.push(licenseInfoForActiveMonitor);
//                             licenseInfo.push(licenseInfoForUxMobile);
//                             console.log(JSON.stringify(licenseInfoForLoadSimulation));
//                             count++;
//                             if (result.length == count) {
//                                 console.log("license length : " + licenseInfo.length);
//                                 resolve(licenseInfo);
//                             }
//                         }
//                     });
//                 }
//             });
//         }
//     });
// }






// router.get('/getLicenseValidation', function (req, res) {
//     res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
//     res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
//     console.log("-----getLicenseValidation------");

//     var sampleJson = {
//         "_id": "5ee898063f807d7687a70567",
//         "licensetype": "FreshEvaluation",
//         "macID": "E8-9A-8F-DE-25-8C",
//         "startdate": "20200610-150728",
//         "enddate": "20200610-150728",
//         "licenseModel": "System-Based",
//         "numMobReport": "123123",
//         "loadnumofusers": "5000",
//         "loadconcurrenttest": "2",
//         "activemonitorRuns": "123123123",
//         "timeStamp": "1591781865974",
//         "active": "true",
//         "CustomerId": ""
//     };
//     if (customerID === null || customerID === undefined || customerID === "") {
//         return res.status(404).json("Token is not valid");
//     }
//     var bsonCustomerID = mongodb.ObjectID(customerID);
//     //"customerId": bsonCustomerID 
//     var usageJson = {
//         "macID": sampleJson.macID,
//         "startdate": sampleJson.startdate,
//         "enddate": sampleJson.enddate,
//         "mobperflicense": {},
//         "loadsimulationlicense": {},
//         "activemonitorlicense": {}
//     };
//     usageJson.mobperflicense.numMobReport = sampleJson.numMobReport;
//     usageJson.mobperflicense.avbMobReport = sampleJson.numMobReport;
//     usageJson.loadsimulationlicense.loadnumofusers = sampleJson.loadnumofusers;
//     usageJson.loadsimulationlicense.loadconcurrenttest = sampleJson.loadconcurrenttest;
//     usageJson.activemonitorlicense.activemonitorRuns = sampleJson.activemonitorRuns;
//     usageJson.activemonitorlicense.avbactiveRuns = sampleJson.activemonitorRuns;
//     console.log(" Json to string ");
//     console.log(JSON.stringify(usageJson));
//     var usageJsonString = JSON.stringify(usageJson);
//     var resultString = usageJsonString.replace(/"/g, "\\\"");
//     var JsonInput = +JavaCommand + "encrypt " + resultString;
//     console.log(" before encrypt : ")
//     console.log(JsonInput);
//     var exec = require('child_process').exec;
//     var childProcess = exec(JsonInput, function (err, stdout, stderr) {
//         if (err) {
//             console.log(err)
//         }
//         else {
//             var decJsonInput = 'java -jar C:/PerfAssure/CloudPerfAssure/SourceCode/PerfAssure_Node-Cloud-15June-1400/public/assets/jar/encryption.jar decrypt ' + stdout;
//             console.log(" after encrypt : ");
//             console.log(stdout);
//             console.log("before decrypt : ");
//             console.log(decJsonInput);
//             var decryptProcess = exec(decJsonInput, function (errors, decryptedResult, stderr) {
//                 if (errors) {
//                     console.log(errors)
//                 }
//                 console.log(" after decrypt : ");
//                 console.log(decryptedResult);
//             })
//         }

//     })
//     db.collection("LicensePurchaseInfo").find({ "_id": bsonCustomerID }).toArray((err, result) => {
//         if (err) {
//             console.log("Error in  : getLicenseValidation " + err);
//             return res.status(500).json(err);
//         } else {
//             if (result.length == 0) {

//                 return res.status(200).json("empty");
//             } else {

//                 return res.status(200).json("vales is present");
//             }

//         }
//     });
// });