/* GET home page. */
var express = require('express');
//require the express router
var multer = require('multer');
var router = express.Router();
var app = express();
var mongodb = require('mongodb');
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const saltRounds = 10;
var config = require('../configuration.json');
let validationRoute = require('./validation.js');
//app.set('secretKey', 'nodeRestApi')
//app.use(bodyParser.json({ limit: '50mb' }));
//app.use(bodyParser.urlencoded({ limit: '50mb', extended: false }));
//app.use(redirectToHTTPS([/ec2-52-66-140-197.ap-south-1.compute.amazonaws.com:(\d{4})/], [/\/addNewCustomerAdmin/], 301));

var dbURL = config.mongoDBURL;
var secretKey = config.bcryptSecretKey;
var tokenExpiryTime = config.tokenExpiryTime;//900000 // 15mins //7d

/*var MongoClient = mongodb.MongoClient;
let db;
MongoClient.connect(dbURL, function (err, mydb) {
    if (err) {
        console.log('ERROR: DB connection failed');
        return err;
    } else {
        db = mydb;
        vdb = db.db("ZantmeterDB");
        console.log('DB connection established!');
    }
});*/
let db;
mongodb.MongoClient.connect(dbURL, function (err, mydb) {
  if (err) {
    console.log('login.js : ERROR: DB connection failed');
    return err;
  } else {
    db = mydb.db();
    // console.log("DB type : " + typeof mydb);
    console.log("login.js : Connected to MongoDB");
  }

});


router.post('/login', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----login------");
  const emailId = req.body.email;
  const password = req.body.password;

  // console.log("req.body:   " + JSON.stringify(req.body));
  //console.log("email   " + emailId);
  //console.log("password   " + password);
  if (emailId === null || emailId === undefined || emailId === "" || validationRoute(emailId)) {
    return res.status(404).json("E-Mail ID is not specified or not valid");
  }
  if (password === null || password === undefined || password === "" || validationRoute(password)) {
    return res.status(404).json("Password is not specified or not valid");
  }
  // console.log("DB type : " + typeof db);
  db.collection("users").findOne({ "emailId": emailId }, function (err, result) {
    if (err) {
      return res.status(500).json("Invalid email");
      //next(err);
    }
    else if (result) {
      var blockedUser = false;
      if (result.hasOwnProperty('state')) {
        if (result.state === "blocked") {
          blockedUser = true;
          res.status(401).json({ error: 'Account has been locked, please contact administrator' });
        }
      }
      if (!blockedUser) {
        var userID = result._id, exists = false, userIndex;

        if (bcrypt.compareSync(password, result.password)) {
          let role = result.role;
          if (role === null || role === undefined || role === "") {
            role = "user";
          }
          let accesslevel = result.accesslevel;
          if (accesslevel === null || accesslevel === undefined || accesslevel === "") {
            accesslevel = 0;
          }
          const token = jwt.sign({ id: result._id, customerID: result.customerId, role: role, accesslevel: accesslevel }, secretKey, { expiresIn: tokenExpiryTime });
          // const token = jwt.sign({ id: result._id, customerID: result.customerId, role: role }, secretKey, { expiresIn: tokenExpiryTime });
          //console.log("result._id  ", result._id);
          if (result.hasOwnProperty('incorrect_attempts')) {
            incorrect_attempts = 0;
            db.collection("users").updateOne({ "_id": mongodb.ObjectID(userID) }, {
              "$set": {
                "incorrect_attempts": Number(incorrect_attempts)
              }
            }, function (err, result) {
              if (err) {
                console.log("Error in login : " + err);
              }
            });
          }
          let responseObj = {
            "data": {
              "token": token,
              "userName": result.userName,
              "emailID": result.emailId,
            }
          };
          req.session.user = responseObj;
          /** assign our jwt to the cookie */
          res.cookie('jwt', jwt, {
            httpOnly: true, secure: false// true if https
          });
          res.status(200).json(responseObj);
        } else {
          var incorrect_attempts = 0;
          if (result.hasOwnProperty('incorrect_attempts')) {
            incorrect_attempts = Number(result.incorrect_attempts);
          }
          console.log(userID + " : " + incorrect_attempts);
          incorrect_attempts += 1;
          if (incorrect_attempts >= 3) {//block user
            //"state" : "active" //"state" : "blocked"
            db.collection("users").updateOne({ "_id": mongodb.ObjectID(userID) }, {
              "$set": {
                "state": "blocked",
                "incorrect_attempts": Number(incorrect_attempts)
              }
            }, function (err, result) {
              if (err) {
                console.log("Error in login : " + err);
              }
            });
          } else {
            db.collection("users").updateOne({ "_id": mongodb.ObjectID(userID) }, {
              "$set": {
                "incorrect_attempts": Number(incorrect_attempts)
              }
            }, function (err, result) {
              if (err) {
                console.log("Error in login : " + err);
              }
            });
          }
          res.status(401).json({ error: 'Invalid credentials, please check' });
        }
      }
    } else {
      res.status(401).json({ error: 'Invalid credentials, please check' });
    }
  })

});


router.get('/logout', function (req, res) {
  res.header("Strict-Transport-Security", "max-age=604800"); // 1 week in seconds   
  res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
  console.log("-----logout------");
  let user_session = req.session;
  if (user_session.hasOwnProperty('user')) {
    if (user_session.user) {
      user_session.destroy(function (err) {
        if (err) {
          res.status(401).json({ error: 'Invalid session, please check' });
        } else {
          res.status(200).json({ success: 'Session destroy successfully' });
        }
      });
    } else {
      res.status(401).json({ error: 'Invalid session, please check' });
    }
  } else {
    res.status(401).json({ error: 'Invalid session, please check' });
  }
});

module.exports = router;
